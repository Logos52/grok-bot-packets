# Brief log (format v2, from 2026-08-25)

Old format deliveries completed: 12 (through Mon 2026-08-24). The “after ten briefs” cut-review starts at ten v2 pushes.

| Date (Taipei) | Lines sent | Wedge reacted in chat |
|---|---|---|
| 2026-08-25 | Treasury’s Iran D-Day is a warning, not a bank cutoff: Operation Economic Outcast names ~60 people, entities, and vessels plus five new sectors (digital assets, gold, tech, aviation, shipping), with a defined unwind timeline instead of instant penalties on major foreign banks. https://home.treasury.gov/news/press-releases/sb0613/ |  |
| 2026-08-26 | Nothing that changes today. |  |
| 2026-08-27 | 多恩刊 harvests since 08-23 are still unpasted into tan. Paste or pause? / tsumugu-ed next feature is still open: handwriting vs example sentences vs phonetic browse / Recap: enable the MWF clock after three manual runs? / Intake: pin sources or retire (dark since 08-12)? |  |
| 2026-08-28 | Cursor Cloud Agents no longer need GitHub: Start from scratch mints an Origin repo, with live browser preview and optional Vercel publish. https://cursor.com/changelog / Claude Code 2.1.248 adds --restricted (or CLAUDE_CODE_RESTRICTED=1): drops shell/code tools and WebFetch unless named in --tools, keeps file tools in-cwd, refuses bypassPermissions. https://github.com/anthropics/claude-code/blob/main/CHANGELOG.md |  |
| 2026-08-29 | Claude Code 2.1.251: update. File tools no longer follow a symlink swapped after the permission check (could read or write outside the approved path). https://github.com/anthropics/claude-code/blob/main/CHANGELOG.md |  |
| 2026-08-30 | xAI: Grok Bot now works with X. Connect the X connector (paid users get free API credits); a Bot can search posts, read your timeline, or check mentions. https://x.ai/news/grok-bot-and-x |  |
| 2026-08-31 | Nothing that changes today. |  |
| 2026-09-01 | Nothing that changes today. |  |
| 2026-09-02 | Anthropic Claude Fable 5.1 is live (coding frontier; ~25% cheaper typical / up to ~45% agentic via cheaper cache reads; Mythos 5.1 = trusted-access twin). Try this week. https://www.anthropic.com/claude-fable-and-mythos-5-1 |  |
| 2026-09-03 | Nothing that changes today. |  |
| 2026-09-04 | xAI: Grok Bot for Enterprise is live. Grok/Cursor Enterprise customers get free usage for two weeks from Sep 3 and can invite the whole org (including people without seats). https://x.ai/news/grok-bot-for-enterprise |  |
| 2026-09-05 | Nothing that changes today. |  |
| 2026-09-06 | Nothing that changes today. |  |
| 2026-09-07 | Nothing that changes today. |  |
| 2026-09-08 | tsumugu-core-dev CI failed (~58h, compaction/2026-07) — investigate. https://github.com/Logos52/tsumugu-core-dev/actions/runs/33885746332 / tsumugu-ed validate corpus still red since Sep 2. https://github.com/Logos52/tsumugu-ed/actions/runs/33648836647 / tsumugu-core Deploy red ~65d — ignore or archive? https://github.com/Logos52/tsumugu-core/actions/runs/28697465339 |  |
| 2026-09-09 | Nothing that changes today. |  |
| 2026-09-10 | Nothing that changes today. |  |
| 2026-09-11 | Cursor Projects is live (beta): left-nav coordinator for multi-month features/migrations — shared context across agents, Slack/schedule/PR subscriptions, cloud computer so laptop-close doesn't stop it. Try on one real body of work this week. https://cursor.com/changelog |  |
| 2026-09-16 | Nothing that changes today. |  |
| 2026-09-17 | Grok Build memory is live (16 Sep): background notes on conventions, decisions, and project facts (markdown topics; /memory browse, /dream merge) read back next session — try on one active project. https://x.ai/news/grok-build-memory |  |
| 2026-09-18 | Nothing that changes today. |  |
