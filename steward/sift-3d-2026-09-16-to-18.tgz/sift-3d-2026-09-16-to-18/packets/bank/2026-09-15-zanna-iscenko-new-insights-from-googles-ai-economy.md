---
id: 2026-09-15-zanna-iscenko-new-insights-from-googles-ai-economy
kind: article
title: New insights from Google’s AI & Economy ATLAS
source: "https://blog.google/innovation-and-ai/technology/ai/ai-economy-atlas-september-2026/"
author: Zanna Iscenko; Scott Strand
published: 2026-09-15
captured: 2026-09-15
via: grok-bot/多恩刊
lane: ai
status: raw
private: false
---

New insights from Google’s AI & Economy ATLAS
Sep 15, 2026
Zanna Iscenko, AI & Economy Lead, Chief Economist's Office
Scott Strand, Head of StratOps and Special Projects, Technology & Society

How is AI being used by people every day, including in offices, labs, and creative studios around the world? Insights from Google’s AI & Economy ATLAS show how AI is actively reshaping global work. For example:
- India’s creative industry is using AI at a higher rate than the rest of the world, with arts, design, and media occupations making up 19% of work-related AI usage, 1.6 times the global average.
- The U.S. is leading in technical AI adoption, with computer and mathematical occupations accounting for 30% of work-related AI usage, double the share in the rest of the world.

To make these insights and ATLAS's millions of other global data points easier to explore, we're launching a new interactive, open-access experience. You can look more closely at the rates different occupations are using AI, from electricians to purchasing managers, dive into the ways people are using AI at home, and explore the rate of AI adoption in countries around the world.

And new ATLAS-based research from Google, Google DeepMind, in collaboration with MIT FutureTech provides new insights how scientists are using AI in their work, including:
- Scientists are using AI at a higher rate than many other occupations; nearly half of surveyed scientists use some form of AI every day.
- Both LLMs and specialized models are used widely for science, in mutually reinforcing ways.
- Scientists report saving almost 7 hours a week with AI, freeing up time for more research. However, there are now bottlenecks further down the research production pipeline, creating a backlog of hypotheses.

Which professions are using AI most, and where?
ATLAS data reveals how different professions around the globe are adopting AI, highlighting key regional trends and usage patterns:
- AI by occupation: In OECD countries, computer and mathematical and business and financial operations lead in AI usage. In non-OECD countries, office and administrative support, arts, design, entertainment, sports, and media, and educational instruction and library occupations take the top spots.
- Income level vs. adoption: While AI adoption generally correlates with a country’s income level, countries like Brazil and the UAE stand out with higher adoption rates than their GDP per capita would predict.
- AI for manual tasks: Usage for real-time equipment diagnostics and troubleshooting varies significantly by region. In Brazil and Germany, 7% of work AI usage goes toward manual tasks (1.4 times the global average), compared to 4% in Japan.

How are scientists using AI?
New research also highlights how scientists are using AI in their work. A new study from Google, Google DeepMind, and MIT FutureTech draws on ATLAS data. It’s an analysis of 2600 specialized AI models, and a survey of over 600 U.S. and U.K. scientists, all organized using a new taxonomy from MIT FutureTech that maps out what scientists do.

According to the research, scientists are using AI at a higher rate than many other occupations, and nearly half use some form of AI every day. While scientists are using both specialized models and LLMs, they're using them for different tasks. Usage of LLMs like Gemini is spread widely across scientific fields and task categories, while specialized AI models tend to be relatively more common in health and life sciences and in domain-specific data prediction, generation, and simulation tasks.

Scientists are reporting significant time gains based on AI, with savings of just below seven hours a week, freeing up more time for research. But this may not immediately translate to new discoveries. The research also finds evidence of significant time spent validating AI outputs, an increased backlog of hypotheses yet to be tested, and bottlenecks emerging in areas like physical experimentation and clinical validation. In this way, science is similar to most other occupations: although AI offers significant potential to increase productivity, the large-scale impact on outputs and discoveries may require redesigning scientific processes and workflows to realize the potential of fast-evolving AI capabilities.

What’s ahead?
Many questions about the future of AI and the economy remain. ATLAS is a long-term research project, and we’ll work with partners in academia and elsewhere to identify new areas of research and deliver new insights that contribute to a better understanding of how AI is transforming the economy.
