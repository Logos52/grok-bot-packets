---
id: 2026-09-15-all-in-jensen-huang-the-doomer-hoax-superintelligence
kind: podcast
title: "Jensen Huang: The Doomer Hoax, Superintelligence is Here, and The Future of AI (ft. President Trump)"
source: "https://www.youtube.com/watch?v=S7CrlFLAmEA"
author: All-In Podcast
published: 2026-09-14
captured: 2026-09-15
via: grok-bot/Recap
lane: ideas
status: raw
private: false
---

## Recap · All-In · 2026-09-14 · Jensen Huang: The Doomer Hoax, Superintelligence is Here, and The Future of AI (ft. President Trump)
url: https://www.youtube.com/watch?v=S7CrlFLAmEA + https://allinchamathjason.libsyn.com/jensen-huang-the-doomer-hoax-superintelligence-is-here-and-the-future-of-ai-ft-president-trump  ·  length: 0:46:46  ·  text: captions
### Takeaways, arguments, claims (in order)

**Jensen Huang joins The Besties! (00:00)**
- 00:00 · Cold open / intro package · Preempted weekly show for Jensen (only Trump, Jesus, Jensen). Nvidia framed as full-stack AI factory; revenue +97% YoY; demand accelerating. Standing O; "GPU Jesus"; Jensen in new jacket — auctioned prior open jacket; wants serious talk with energy.

**Thoughts on Dario's blog, Frontier Labs calling to slow down AI, and Doomer psychology (01:39)**
- 01:39 · Chamath · Opens on Dario Amodei's weekend essay; jokes Hemingway / Pangram AI-assist check; notes frontier labs coalescing around the essay. Asks Jensen for high-level read.
- 02:14 · Jensen · Separates threads in the essay: (1) safety is paramount — but safety vs leadership / America leading are false choices; can innovate fast and safely. (2) Internal control — Coxin (captions: coxin) "whistleblower" is serious; credits Coxin with courage; whistleblowing fine, but scientific extinction-style prediction "not grounded on science" even when said by a scientist. (3) Pause / pacing = voluntary tools if a lab feels out of control — possible clumsy research→engineering transition; only Coxin knows what he saw. Blog conflates control, regulation, and civilizational risk in one piece.
- 04:24 · Chamath · Mom ("Jimoth"/Chamath) asks what "civilizational death" / 10% extinction means for normal people — quantization by smart people is what perturbs the public.
- 04:53 · Jensen · "We shouldn't [explain it that way] because it's made up" — irresponsible for well-educated lab researchers to make alarming unscientific predictions. Track record of wrong AI doom/jobs forecasts: radiology would eliminate radiologists in 5 years → opposite (need more radiologists; AI automated scan reading); last-year claim 90% of code AI-generated in 6–12 months → wrong; 50% entry jobs wiped in 6–9 months → wrong; GPT-2 / Llama 3 "too unsafe to release"; half of white-collar jobs gone next year / jobs apocalypse. "Somebody has to take account for all of the stupid predictions." Predictions inconsistent with America winning the AI race.
- 06:51 · Chamath · Analogizes to COVID "trust the experts" — asymmetric awareness that later failed on facts; war between trust-the-experts vs methodical prediction history.
- 07:22 · Chamath · Why from inside the labs — psychology vs business/political incentive?
- 07:38 · Jensen · Frontier labs = consequential companies, extraordinary people; works with them company-to-company but public discourse is "unfortunate." Prefers old mode: build in silence. Nvidia culture: employees don't speak for the org on a bad weekend / rage-quit tweets; no political/race/religion discourse inside — take it home; company a-political / bipartisan, help whichever US government succeed.

**Sensible AI regulation and RSI (09:58)**
- 09:58 · Chamath · Satya (same morning): before regulation that could stymie, get measurement, standardization, engineering right; translate research predictably; keep fear-mongering inside until ready. Demis: FINRA-like org; Dario's transnational control idea unclear. Where does Jensen land?
- 10:38 · Jensen · Regulation should solve actual problems — so far actual problems have come from the frontier labs (they have the most compute, pioneering frontier work); unlikely high-schooler or startup is the source. Labs hair-on-fire building company + culture + tech + products at once. Four incidents one lab + one giant incident another: root-cause from engineering — what happened, what to institutionalize (sandboxes, runtimes, continuous monitors). Bets every case is within lab control to prevent again. Alternative ("we analyzed and have no idea / asking society for help") unlikely — if true, send engineers; doubts it.
- 13:35 · Jason / Sacks · Chinese lab (GLM / Zhipu — captions: zpoo.com) raised ~$5B; announced priority recursive self-improvement (RSI) run (~$3B toward RSI per Jason).
- 14:04 · Jensen · RSI is a system of sensible ideas (in-context, skills, reflection, RL, synthetic data, LoRA without retraining base, later retrain base) — already used to raise AI productivity including building AI. Phrase now "weaponized" to imply spiral out of control. Does not believe uncontrolled spiral: you can RSI inside, but product release still needs evals, regression tests, verification — control improves as labs move research→engineering; that enables safe internal RSI and good external products.

**Hugging Face acquisition, future of Open Source, and the race with China (16:05)**
- 16:05 · Chamath · Hugging Face deal = among most consequential acquisitions; asks first-principles open vs closed vs open weights.
- 16:28 · Jensen · World needs both. Closed models like bottled water; water (and electricity) free in the right places — use the right water in the right places. Open needed for sovereignty, privacy, proprietary tech. Fact: last 6 months ~$400B venture into AI-native companies; ~80% use open models — without open, those dreams (different from frontier-lab dreams) can't be built. Winning AI race = every US company/industry/researcher/teacher/student/startup, not a few tech cos.
- 18:20 · Chamath · Does it matter if open models come from China vs US?
- 18:28 · Jensen · Nvidia contributing to open; vast majority of world's open-source contribution today from China (more engineers / volume; Tsinghua etc.). Once downloaded — Linux, Kubernetes, Chinese models — you fork it, it's yours. Race is who exploits the technology best: last industrial revolution inventors (Maxwell, Volta, Ampère) were European/non-American; US exploited socially better — wants same for this generation.
- 20:04 · Chamath · Why are "the communists" getting their message out so successfully here?
- 20:16 · Jensen · China narrative more practical — no civilizational-end / doomer groups; AI as economy/society advance. Frustrating: if doom were true, spend more time fixing than scaring people who can't act — "It's our job to build it."
- 21:01 · Friedberg · Has so many people ever so vehemently said something demonstrably untrue / not based on science?
- 21:20 · Sacks · Fear of frontier — never been there → easy to scare.
- 21:27 · Jensen · Also life experience: early career before software boom = less typing; now engineers type all day. Mountain of engineering work ahead that isn't typing/coding — "favorite key is backspace"; best software is smallest software. Engineering busy before typing; will be after.

**President Trump calls in live to discuss the Doomer Hoax (22:58)**
- 22:58 · Live · Trump calls Jensen mid-segment (unplanned); Jensen on stage with besties / thousands. Brief gratitude that Trump "saw through" the complexity. Awkward speakerphone bit; Trump jokes Jensen can build un-copyable chips but not put him on speaker.
- 24:42 · Trump · Calls AI doom narrative a "hoax"; China happiest if US slows; some US states happy too (permitting blocks — Google wanting Finland build after US permitting failure). Data centers = "oil of the next 20–25 years," bigger than internet; robots/AI won't take over world; be prudent but don't stop industry while "working on the next 10 years about how to destroy it." "Whoever wins AI wins." Communities dying → wealthy via data centers. Claims ~$20T investment into US in one year vs <<$1T under Biden over four. Praise for Jensen and David (Sacks). Crowd applauds.
- 28:26 · Besties · Thought it might be a bit at first; was real. Anecdote: Oval dinner — Trump insisted they wake vacationing Jensen ("What's vacation?").
- 28:18 · Chamath · Data-center / AI polling ~−80; anyone else in Oval would do the popular shut-down thing — how does Trump call the hoax?
- 29:29 · Jensen · Many falling for it; story first anchored on national security (blown to bits), now on safety. If safety is goal: labs in control + good tests; third-party evaluators like financial auditors (multiple so none get "pilled"). Build safely, test safely; hold extraordinary companies to extraordinary standards — they want that.
- 31:04 · Chamath · Tries to return to open source (was ~18 months behind a year ago).
- 31:13 · Jensen · Hard to say things on a Trump call (joke). Message he wanted Trump to hear: AI creating enormous jobs — Trump's early ask was re-industrialize US, energy for next industrial revolution (no energy → no growth), supply chain. $400B VC in 6 months = jobs + compute + data-center demand. Spoke with Texas Gov. Abbott: be empathetic listeners to small communities while building data centers.

**The AI boom and Nvidia's capital allocation strategy (31:29)**
- 32:53 · Chamath · Nvidia as "bank of AI" — Cloverleaf (land/power/shell), BlackRock/Goldman financing stack; walk capital-allocation / ecosystem underwriting.
- 33:26 · Jensen · New industrial revolution: electricity → internet → AI ("power anything, find anything, ask/know anything"). Intelligence is a production process → infrastructure must be built; then stack is mostly applications + data centers + construction + electricity/power — not just models/chips. Scans ecosystem for bottlenecks/constraints; invests so supply chain is ready when compute deploys (upstream: Corning/Wendell, Lumentum, TSMC, memory — worked early; now also downstream).
- 34:57 · Chamath · Earnings migrate up stack to apps; Hugging Face → serving; OpenRouter / better Bedrock natural; hyperscalers move down — will Nvidia move up?
- 36:14 · Jensen · Year+ ago Nvidia mostly ran OpenAI; now Meta, Grok, Gemini, Anthropic scaling on platform; many more labs (Ineffable, Reflection, Physical Intelligence, etc.) on Nvidia. Strategy: "go up as far as we need to and as low as possible" — help everyone succeed rather than take a slice. Without Nvidia cuDNN / Megatron Core, frameworks and large-scale training wouldn't exist; invent what's necessary then let a thousand flowers bloom.
- 37:54 · Chamath · Pushback: need more hyperscaler-layer competition; NeoClouds good (Nebius etc.) but need 50–1000 of them.
- 38:17 · Jensen · "Surprisingly uncompetitive"; fine with five hyperscalers. Early NeoCloud/NCP customers were hyperscalers — hyperscalers plan yearly, market too volatile, always almost wrong; regional clouds agile on local land/power/shell. Countries treating power as strategic (prefer own companies) — Nvidia helps local NeoClouds (Australia / Fermi etc., SE Asia) — scaling gigawatts (corrects "gigabytes").

**Nvidia's Open Source model ambitions, thoughts on Elon's Terafab (40:21)**
- 40:21 · Chamath · Nvidia going high on open source — Nemotron, Hugging Face, Poolside, Laguna; open self-driving stack. Frontier in five domains; going for gold open-source model? Can open catch closed frontier — is Nvidia the one?
- 40:40 · Jensen · Build because they can and customers need it — not to disrupt. Alpamayo = first "thinking" self-driving stack (reasoning → less need for billions of road hours); every car/ag/truck/van will be autonomous; most OEMs too small for full stack — Nvidia builds stack, customers do last-mile. Same for biology models (ESM-2, OpenFold, AlphaFold 2, equivariant methods, Proteina/Complexa protein synthesis) — Lilly/Merck need it. "We don't wake up… to disrupt anybody… try to help everybody."
- 42:25 · Friedberg · Competitive threats to core? Take on Elon's Terafab (~100M sq ft)?
- 42:38 · Jensen · If anyone can, Elon can; discussed on flight with Trump ("person who sometimes calls you"). Can't discourage Elon — that's his superpower. Nvidia knows process/memory/SiS at scale (designs, doesn't fab) — can talk shop.
- 43:43 · Friedberg · China advanced lithography / native?
- 43:48 · Jensen · They'll get there by ~2030 — "just around the corner"; decades is Nvidia's planning horizon; 2–3 years is a click. China excellent at high-volume production — matter of time; "as far as they're concerned they're already there."
- 44:34 · Jason · Elon, Grok, Gwen — America must run / speedrun; slowing down wrong strategy. Feels like AGI moment (as smart as any human).
- 45:04 · Jensen · Already there on AGI; also already at superintelligence in narrow segments — self-driving (better than human, ~1/10 accident rate); protein synthesis / virtual screening. Having fun on the frontier: future is great; too good not to work even if many won't need to; urge labs on, tone down the drama, need all of America to come along. Close: standing ovation / "Jensen Huang."

### Quotes (verbatim, ≤ 25 words each, 3–6)
- 04:53 Jensen: "Well, first of all, we shouldn't uh because it's made up."
- 15:25 Jensen: "No. No, of course not. And the reason for that is because you could RSI all day long inside your company"
- 16:48 Jensen: "closed models is kind of like bottled water. You know, water is free, you guys."
- 24:42 Trump: "I'm telling you, it's all a hoax. The data centers are great and they make people wealthy"
- 37:51 Jensen: "Our strategy is go up as far as we need to and as low as possible."
- 45:18 Jensen: "that is super intelligent. super it's better it's better than a human"

### One paragraph
All-In Summit-style interview: Jensen Huang dismantles Dario's slowdown essay and Coxin-linked extinction rhetoric as unscientific "made up" predictions with a long wrong track record (radiology, coding %, entry jobs, GPT-2/Llama scare), while still treating whistleblowing and lab safety as serious — safety vs US leadership are false choices, and Nvidia bans employees from rage-quit org-speaking or workplace politics. On regulation he wants root-cause engineering at frontier labs (where compute/danger concentrate), not panic rules; RSI is prosaic tooling (skills/RL/LoRA) gated by evals, not an uncontrolled spiral. Hugging Face / open models are framed as bottled-vs-tap water: ~$400B / 6 months of AI-native VC is ~80% open, China leads open contribution but forks become yours, and the real race is who exploits AI socially (US vs Europe last industrial revolution). Mid-show Trump cold-calls, labels AI doom a China/permitting "hoax," defends data centers as next oil, and repeats "whoever wins AI wins"; Jensen later says the narrative shifted from national-security to safety and should be answered with lab control + multi-auditor evals, not pause. Capital allocation: Nvidia as ecosystem bottleneck-fixer (land/power/shell, Corning/TSMC, NeoClouds) going "up as far as needed, as low as possible" so many labs bloom on CUDA/Megatron — Nemotron/Alpamayo/bio models from customer need, not disruption; Elon's Terafab respected, China lithography ~2030. Close: AGI and narrow superintelligence (AV, proteins) already here — speedrun, tone down drama, bring all of America.

### Footer
canary: published 2026-09-14T21:24:00Z (libsyn RSS) · fetched 2026-09-15 ~04:21 UTC · captions from official YouTube English auto-subs via yt-dlp --skip-download --write-auto-sub --write-subs --sub-lang en (captions.en.vtt; 2681 timed cues; ~8721 words after dedupe) · show-notes chapters from libsyn RSS/og:description as section anchors · ASR name cleanup in body only (Wong/Hang/Long→Huang, Daario/Daria→Dario, Jimoth→Chamath, Chinua→Tsinghua, Laura→LoRA, Grock→Grok, Terraab→Terafab, Neotrons→Nemotron, Alpamo→Alpamayo, zpoo→Zhipu/GLM, NBS→Nebius, Lumenum→Lumentum, Wendle→Wendell, QDNN→cuDNN, gigabytes→gigawatts where self-corrected; Coxin kept as captioned) · quotes verbatim from caption text · no ASR on box · no third-party transcript sites · seen index / latest.md NOT updated (INGEST-only pass) · sibling Shotwell/Elon episode untouched · 2026-09-14-list.md untouched
