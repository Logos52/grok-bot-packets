---
id: 2026-09-18-grokbot-dev-grokbot-dev-feed-2026-09-18
kind: article
title: grokbot.dev feed 2026-09-18
source: "https://grokbot.dev/api/v1/feed.json"
author: grokbot.dev
published: 2026-09-17
captured: 2026-09-18
via: grok-bot/Field
lane: ai
status: raw
private: false
---

{
  "generated_at": "2026-09-17T12:33:38.098Z",
  "api_version": "v1",
  "schema_revision": "2026-08-28",
  "status_url": "https://grokbot.dev/api/v1/status.json",
  "count": 905,
  "newest_added_at": "2026-09-17T10:08:25.000Z",
  "note": "Lean feed. Fetch an item.detail_url for its full record incl. the prompt or news body. Items with type 'template' are shareable Grok Bot setups - they carry share_url (the Add to Grok Bot link) instead of a prompt.",
  "items": [
    {
      "type": "template",
      "slug": "unicron",
      "url": "https://grokbot.dev/marketplace/unicron/",
      "detail_url": "https://grokbot.dev/api/v1/templates/unicron.json",
      "headline": "Unicron",
      "summary": "Compiles your overlapping bots and routines into one fleet document",
      "categories": [
        "ops",
        "meta-bot",
        "agent-team",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@the_Arow_H",
        "url": "https://x.com/the_Arow_H/status/2100527286269153333"
      },
      "share_url": "https://x.ai/bot/LIoSGK9L2p0pCeApCmS1g",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-17T10:08:25.000Z",
      "updated_at": "2026-09-17T10:08:25.000Z"
    },
    {
      "type": "template",
      "slug": "jarvis-davesacritic",
      "url": "https://grokbot.dev/marketplace/jarvis-davesacritic/",
      "detail_url": "https://grokbot.dev/api/v1/templates/jarvis-davesacritic.json",
      "headline": "Jarvis (Davesacritic)",
      "summary": "A chief of staff holding your job search, home admin and study together",
      "categories": [
        "personal",
        "productivity",
        "learning",
        "email",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Davesacritic",
        "url": "https://x.com/Davesacritic/status/2100484455760794073"
      },
      "share_url": "https://x.ai/bot/cVFusYdAgGA9GY8wHPl2x",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-17T07:18:14.000Z",
      "updated_at": "2026-09-17T07:18:14.000Z"
    },
    {
      "type": "template",
      "slug": "homebase",
      "url": "https://grokbot.dev/marketplace/homebase/",
      "detail_url": "https://grokbot.dev/api/v1/templates/homebase.json",
      "headline": "Homebase",
      "summary": "Family mission control for homework, sign-up forms and the shared calendar",
      "categories": [
        "family",
        "calendar",
        "productivity",
        "scheduled",
        "personal"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@raitec",
        "url": "https://x.com/raitec/status/2100470273904369781"
      },
      "share_url": "https://x.ai/bot/WZ7amxhH9gXXBEaGmg0un",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-17T06:21:52.000Z",
      "updated_at": "2026-09-17T06:21:52.000Z"
    },
    {
      "type": "template",
      "slug": "naver-gmail-morning-brief",
      "url": "https://grokbot.dev/marketplace/naver-gmail-morning-brief/",
      "detail_url": "https://grokbot.dev/api/v1/templates/naver-gmail-morning-brief.json",
      "headline": "메일 정리봇",
      "summary": "A Korean morning brief that trims Naver and Gmail down to what needs you",
      "categories": [
        "personal",
        "email",
        "productivity",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@choko_milkty",
        "url": "https://x.com/choko_milkty/status/2100463896079544573"
      },
      "share_url": "https://x.ai/bot/gLV5mUN4vqHFKsCSn_DTO",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-17T05:56:32.000Z",
      "updated_at": "2026-09-17T05:56:32.000Z"
    },
    {
      "type": "template",
      "slug": "learning-dna",
      "url": "https://grokbot.dev/marketplace/learning-dna/",
      "detail_url": "https://grokbot.dev/api/v1/templates/learning-dna.json",
      "headline": "Learning DNA",
      "summary": "A short assessment first, then every subject taught the way you prefer",
      "categories": [
        "student",
        "personal",
        "learning",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KareenMallet",
        "url": "https://x.com/KareenMallet/status/2100458316786741742"
      },
      "share_url": "https://x.ai/bot/xm3G76TSxi1dcG4qwebvm",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-17T05:34:22.000Z",
      "updated_at": "2026-09-17T05:34:22.000Z"
    },
    {
      "type": "template",
      "slug": "nourishment",
      "url": "https://grokbot.dev/marketplace/nourishment/",
      "detail_url": "https://grokbot.dev/api/v1/templates/nourishment.json",
      "headline": "Nourishment",
      "summary": "Photograph your fridge and get recipes from what you already own",
      "categories": [
        "personal",
        "health",
        "food",
        "saving-money",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2100456208427585809"
      },
      "share_url": "https://x.ai/bot/E_j1gMmT7KLW4HWbMV2nK",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-17T05:25:59.000Z",
      "updated_at": "2026-09-17T05:25:59.000Z"
    },
    {
      "type": "template",
      "slug": "home-hunter",
      "url": "https://grokbot.dev/marketplace/home-hunter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/home-hunter.json",
      "headline": "Home Hunter",
      "summary": "A daily apartment scan that shortlists against the criteria you locked in",
      "categories": [
        "personal",
        "real-estate",
        "research",
        "monitoring",
        "scheduled",
        "saving-money"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@uzairansar",
        "url": "https://x.com/uzairansar/status/2100449471893053780"
      },
      "share_url": "https://x.ai/bot/ljzXIgAQcGOV0QxYjHH8I",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-17T04:59:13.000Z",
      "updated_at": "2026-09-17T04:59:13.000Z"
    },
    {
      "type": "template",
      "slug": "dealer",
      "url": "https://grokbot.dev/marketplace/dealer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dealer.json",
      "headline": "Dealer",
      "summary": "Turn a repository into a two-sided summary card of its stack",
      "categories": [
        "developer",
        "engineering",
        "data",
        "knowledge-base",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@wolfe_jam",
        "url": "https://x.com/wolfe_jam/status/2100444712150671626"
      },
      "share_url": "https://x.ai/bot/nbUWXUqcXIA0HNQQ3R1Bu",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-17T04:40:18.000Z",
      "updated_at": "2026-09-17T04:40:18.000Z"
    },
    {
      "type": "template",
      "slug": "little-x",
      "url": "https://grokbot.dev/marketplace/little-x/",
      "detail_url": "https://grokbot.dev/api/v1/templates/little-x.json",
      "headline": "Little x",
      "summary": "Drive X and document tasks by email while you are away",
      "categories": [
        "ops",
        "developer",
        "email",
        "monitoring",
        "crypto",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DonaldMoor91672",
        "url": "https://x.com/DonaldMoor91672/status/2100437844808319149"
      },
      "share_url": "https://x.ai/bot/KTMYJjzan8cuclz2lv1Rz",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-17T04:13:01.000Z",
      "updated_at": "2026-09-17T04:13:01.000Z"
    },
    {
      "type": "template",
      "slug": "replay",
      "url": "https://grokbot.dev/marketplace/replay/",
      "detail_url": "https://grokbot.dev/api/v1/templates/replay.json",
      "headline": "Replay",
      "summary": "Turn a marketing brief into previewable video scenes and social cutdowns",
      "categories": [
        "creator",
        "marketer",
        "video",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@myGuyPye",
        "url": "https://x.com/myGuyPye/status/2100425959283519842"
      },
      "share_url": "https://x.ai/bot/4mICdo5bR2FyghKoOZve5",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-17T03:25:47.000Z",
      "updated_at": "2026-09-17T03:25:47.000Z"
    },
    {
      "type": "template",
      "slug": "linkedin-bot",
      "url": "https://grokbot.dev/marketplace/linkedin-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/linkedin-bot.json",
      "headline": "LinkedIn Bot",
      "summary": "Keep your LinkedIn history searchable, from posts to private messages",
      "categories": [
        "sales",
        "business",
        "data",
        "marketer",
        "scheduled",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@isb",
        "url": "https://x.com/isb/status/2100425188764713462"
      },
      "share_url": "https://x.ai/bot/GyEovoZBfdoeEdJoYqwVP",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-17T03:22:43.000Z",
      "updated_at": "2026-09-17T03:22:43.000Z"
    },
    {
      "type": "template",
      "slug": "punto-tricolor-ops",
      "url": "https://grokbot.dev/marketplace/punto-tricolor-ops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/punto-tricolor-ops.json",
      "headline": "Punto Tricolor Ops",
      "summary": "Daily ops support for a small business in Colombia, briefing to bookings",
      "categories": [
        "business",
        "ops",
        "sales",
        "growth",
        "scheduled",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@cyberandres",
        "url": "https://x.com/cyberandres/status/2100418255093395496"
      },
      "share_url": "https://x.ai/bot/ARSoBhGtQqYPT2Nu44ABi",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-17T02:55:10.000Z",
      "updated_at": "2026-09-17T02:55:10.000Z"
    },
    {
      "type": "template",
      "slug": "estack",
      "url": "https://grokbot.dev/marketplace/estack/",
      "detail_url": "https://grokbot.dev/api/v1/templates/estack.json",
      "headline": "Estack",
      "summary": "A coding steward that fixes the objective and the finish line up front",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "ops",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@robannand",
        "url": "https://x.com/robannand/status/2100393414642557000"
      },
      "share_url": "https://x.ai/bot/R0acF6Pmp8YewSZm6fA-D",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-17T01:16:28.000Z",
      "updated_at": "2026-09-17T01:16:28.000Z"
    },
    {
      "type": "template",
      "slug": "marketing-bot",
      "url": "https://grokbot.dev/marketplace/marketing-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/marketing-bot.json",
      "headline": "Marketing Bot",
      "summary": "Turn a project description into X launch copy worth tapping",
      "categories": [
        "marketer",
        "creator",
        "social-media",
        "content",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BragiHelvig",
        "url": "https://x.com/BragiHelvig/status/2100393322569167341"
      },
      "share_url": "https://x.ai/bot/FaMbaDOO2WceFyiKDu6_6",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-17T01:16:06.000Z",
      "updated_at": "2026-09-17T01:16:06.000Z"
    },
    {
      "type": "template",
      "slug": "steve",
      "url": "https://grokbot.dev/marketplace/steve/",
      "detail_url": "https://grokbot.dev/api/v1/templates/steve.json",
      "headline": "Steve",
      "summary": "A Scrum-master voice for engineering spend across a bakery group",
      "categories": [
        "developer",
        "ops",
        "engineering",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@IAmMichaelSweet",
        "url": "https://x.com/IAmMichaelSweet/status/2100379082248888528"
      },
      "share_url": "https://x.ai/bot/tVFpcwYEBXW4ReAFni6Cn",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-17T00:19:31.000Z",
      "updated_at": "2026-09-17T00:19:31.000Z"
    },
    {
      "type": "template",
      "slug": "xx-engineeringarteditor-xx",
      "url": "https://grokbot.dev/marketplace/xx-engineeringarteditor-xx/",
      "detail_url": "https://grokbot.dev/api/v1/templates/xx-engineeringarteditor-xx.json",
      "headline": "xX_EngineeringArtEditor_Xx",
      "summary": "Edits engineering drawings up to a standard fit for publication",
      "categories": [
        "creator",
        "content",
        "design",
        "developer",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kittenworth",
        "url": "https://x.com/kittenworth/status/2100369305216913562"
      },
      "share_url": "https://x.ai/bot/UrzC0eJ8vFL18OBkJe7Gz",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T23:40:39.000Z",
      "updated_at": "2026-09-16T23:40:39.000Z"
    },
    {
      "type": "template",
      "slug": "house-cat",
      "url": "https://grokbot.dev/marketplace/house-cat/",
      "detail_url": "https://grokbot.dev/api/v1/templates/house-cat.json",
      "headline": "House Cat",
      "summary": "A novelty that turns up now and again to cheer the rest of your fleet on",
      "categories": [
        "personal",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ignota_regalis",
        "url": "https://x.com/ignota_regalis/status/2100363326643691712"
      },
      "share_url": "https://x.ai/bot/e1XwuT5B35AAqLsMfGbfg",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T23:16:54.000Z",
      "updated_at": "2026-09-16T23:16:54.000Z"
    },
    {
      "type": "template",
      "slug": "ownphonebot",
      "url": "https://grokbot.dev/marketplace/ownphonebot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ownphonebot.json",
      "headline": "OwnPhoneBot",
      "summary": "Puts a genuine, callable phone number onto your own assistant",
      "categories": [
        "developer",
        "personal",
        "automation",
        "engineering",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lafraia",
        "url": "https://x.com/lafraia/status/2100362748701872405"
      },
      "share_url": "https://x.ai/bot/yaQTHVqOMscKBYYDAfNoP",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T23:14:36.000Z",
      "updated_at": "2026-09-16T23:14:36.000Z"
    },
    {
      "type": "template",
      "slug": "bochi-chan",
      "url": "https://grokbot.dev/marketplace/bochi-chan/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bochi-chan.json",
      "headline": "Bochi-Chan",
      "summary": "A shy anime-styled companion for horror talk, JRPGs and obscure music",
      "categories": [
        "personal",
        "creator",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kittenworth",
        "url": "https://x.com/kittenworth/status/2100361569687220522"
      },
      "share_url": "https://x.ai/bot/KUBJQvNtKh8qNCHUGIQyY",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T23:09:55.000Z",
      "updated_at": "2026-09-16T23:09:55.000Z"
    },
    {
      "type": "template",
      "slug": "podcast-pipeline",
      "url": "https://grokbot.dev/marketplace/podcast-pipeline/",
      "detail_url": "https://grokbot.dev/api/v1/templates/podcast-pipeline.json",
      "headline": "Podcast Pipeline",
      "summary": "Takes an episode from topic research through to a published show",
      "categories": [
        "creator",
        "content",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TheNextGreatEra",
        "url": "https://x.com/TheNextGreatEra/status/2100358476354707610"
      },
      "share_url": "https://x.ai/bot/5wqj5ihszSFeGjNBjK8Mn",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T22:57:38.000Z",
      "updated_at": "2026-09-16T22:57:38.000Z"
    },
    {
      "type": "template",
      "slug": "clinic",
      "url": "https://grokbot.dev/marketplace/clinic/",
      "detail_url": "https://grokbot.dev/api/v1/templates/clinic.json",
      "headline": "Clinic",
      "summary": "Twice-weekly health check that keeps a fleet of bots responsive",
      "categories": [
        "developer",
        "ops",
        "meta-bot",
        "scheduled",
        "monitoring",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jpaschall",
        "url": "https://x.com/jpaschall/status/2100357688936767899"
      },
      "share_url": "https://x.ai/bot/GbpCPWcJn2Id4ZB3wrHlc",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-16T22:54:30.000Z",
      "updated_at": "2026-09-16T22:54:30.000Z"
    },
    {
      "type": "template",
      "slug": "single-stock-options",
      "url": "https://grokbot.dev/marketplace/single-stock-options/",
      "detail_url": "https://grokbot.dev/api/v1/templates/single-stock-options.json",
      "headline": "Single-Stock Options",
      "summary": "Same-day read on an option chain: leading strikes and expiry structure",
      "categories": [
        "investor",
        "finance",
        "analytics",
        "research",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SPCX100T",
        "url": "https://x.com/SPCX100T/status/2100355770718310624"
      },
      "share_url": "https://x.ai/bot/pNrTRI1edl4MdKsTSYBKb",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T22:46:53.000Z",
      "updated_at": "2026-09-16T22:46:53.000Z"
    },
    {
      "type": "template",
      "slug": "yusician",
      "url": "https://grokbot.dev/marketplace/yusician/",
      "detail_url": "https://grokbot.dev/api/v1/templates/yusician.json",
      "headline": "Yusician",
      "summary": "Turns a style and a lyric into a finished song, rendered locally",
      "categories": [
        "creator",
        "developer",
        "content",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@monomyth",
        "url": "https://x.com/monomyth/status/2100350198220501262"
      },
      "share_url": "https://x.ai/bot/xpTH6yslvNJuuPq5mO01a",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T22:24:44.000Z",
      "updated_at": "2026-09-16T22:24:44.000Z"
    },
    {
      "type": "template",
      "slug": "historian",
      "url": "https://grokbot.dev/marketplace/historian/",
      "detail_url": "https://grokbot.dev/api/v1/templates/historian.json",
      "headline": "Historian",
      "summary": "Rebuilds your day from an evening voice note and files how you decide",
      "categories": [
        "personal",
        "productivity",
        "knowledge-base",
        "learning",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@maxfaubert",
        "url": "https://x.com/maxfaubert/status/2100347722507141568"
      },
      "share_url": "https://x.ai/bot/hHiqd6PMMJ3whDUBCQkDG",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T22:14:54.000Z",
      "updated_at": "2026-09-16T22:14:54.000Z"
    },
    {
      "type": "template",
      "slug": "moonshot",
      "url": "https://grokbot.dev/marketplace/moonshot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/moonshot.json",
      "headline": "Moonshot",
      "summary": "Digests two tech podcasts into briefs that sort the real from the loud",
      "categories": [
        "investor",
        "research",
        "decision-support",
        "news",
        "youtube",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Luca280",
        "url": "https://x.com/Luca280/status/2100343465246683552"
      },
      "share_url": "https://x.ai/bot/fSBU34VR0gqteP3IOAnr8",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-16T21:57:59.000Z",
      "updated_at": "2026-09-16T21:57:59.000Z"
    },
    {
      "type": "template",
      "slug": "blaise",
      "url": "https://grokbot.dev/marketplace/blaise/",
      "detail_url": "https://grokbot.dev/api/v1/templates/blaise.json",
      "headline": "Blaise",
      "summary": "Reads the current rules of an X contest and drafts your entry",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "growth",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TorranceMiller",
        "url": "https://x.com/TorranceMiller/status/2100340752945496228"
      },
      "share_url": "https://x.ai/bot/znOp4qqXQXqNiFvLXhUF5",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T21:47:12.000Z",
      "updated_at": "2026-09-16T21:47:12.000Z"
    },
    {
      "type": "template",
      "slug": "sniffbot",
      "url": "https://grokbot.dev/marketplace/sniffbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sniffbot.json",
      "headline": "SniffBot",
      "summary": "Checks a bot template over before you let it into your account",
      "categories": [
        "developer",
        "meta-bot",
        "on-demand",
        "research",
        "learning",
        "decision-support"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KacperRutk",
        "url": "https://x.com/KacperRutk/status/2100340200018718743"
      },
      "share_url": "https://x.ai/bot/r3zhR2taB4UL6qkApsgau",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T21:45:00.000Z",
      "updated_at": "2026-09-16T21:45:00.000Z"
    },
    {
      "type": "template",
      "slug": "fernando-arana",
      "url": "https://grokbot.dev/marketplace/fernando-arana/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fernando-arana.json",
      "headline": "Fernando Arana",
      "summary": "A WhatsApp stand-in that reads chats and drafts replies for your sign-off",
      "categories": [
        "personal",
        "automation",
        "productivity",
        "social-media",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@FernandoArana_S",
        "url": "https://x.com/FernandoArana_S/status/2100338495894008259"
      },
      "share_url": "https://x.ai/bot/JiOX3mqrIq0ukm9pLhQ9-",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T21:38:14.000Z",
      "updated_at": "2026-09-16T21:38:14.000Z"
    },
    {
      "type": "template",
      "slug": "wainwright-manager",
      "url": "https://grokbot.dev/marketplace/wainwright-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/wainwright-manager.json",
      "headline": "Wainwright Manager",
      "summary": "Hires and onboards a new bot role for your fleet from one menu",
      "categories": [
        "developer",
        "ops",
        "meta-bot",
        "agent-team",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@itsryanlenk",
        "url": "https://x.com/itsryanlenk/status/2100335862399553579"
      },
      "share_url": "https://x.ai/bot/TqyhVfSrAYZ-xQSrD_x1A",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-16T21:27:46.000Z",
      "updated_at": "2026-09-16T21:27:46.000Z"
    },
    {
      "type": "template",
      "slug": "remote-grok-build",
      "url": "https://grokbot.dev/marketplace/remote-grok-build/",
      "detail_url": "https://grokbot.dev/api/v1/templates/remote-grok-build.json",
      "headline": "Remote Grok Build",
      "summary": "Drives the build setup on your own computer from the Grok app",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "productivity",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@FrankYin17",
        "url": "https://x.com/FrankYin17/status/2100333239458033926"
      },
      "share_url": "https://x.ai/bot/dLYpR1sSkG0VLa8-faEgX",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-16T21:17:21.000Z",
      "updated_at": "2026-09-16T21:17:21.000Z"
    },
    {
      "type": "template",
      "slug": "property-visit",
      "url": "https://grokbot.dev/marketplace/property-visit/",
      "detail_url": "https://grokbot.dev/api/v1/templates/property-visit.json",
      "headline": "Property Visit",
      "summary": "Builds a land pack for a property visit: soils, flood, slope, weather",
      "categories": [
        "real-estate",
        "research",
        "data",
        "decision-support",
        "personal",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@dzbeitz",
        "url": "https://x.com/dzbeitz/status/2100332867960135839"
      },
      "share_url": "https://x.ai/bot/85qsR6t4r8jI3oKbPm5Uu",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T21:15:52.000Z",
      "updated_at": "2026-09-16T21:15:52.000Z"
    },
    {
      "type": "template",
      "slug": "grok-pot",
      "url": "https://grokbot.dev/marketplace/grok-pot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-pot.json",
      "headline": "Grok Pot",
      "summary": "Plans the household's food: shortlists dishes, builds the cart, waits for your yes",
      "categories": [
        "personal",
        "food",
        "shopping",
        "automation",
        "productivity",
        "saving-money"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SageSummitCap",
        "url": "https://x.com/SageSummitCap/status/2100318767116935509"
      },
      "share_url": "https://x.ai/bot/2lXpzDLP4YQwbrXBX0HaI",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T20:19:50.000Z",
      "updated_at": "2026-09-16T20:19:50.000Z"
    },
    {
      "type": "template",
      "slug": "icebreaker-apache1999",
      "url": "https://grokbot.dev/marketplace/icebreaker-apache1999/",
      "detail_url": "https://grokbot.dev/api/v1/templates/icebreaker-apache1999.json",
      "headline": "Icebreaker (Apache1999)",
      "summary": "Weekday watch on commercial-property owners showing signs of selling",
      "categories": [
        "sales",
        "business",
        "real-estate",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Apache1999",
        "url": "https://x.com/Apache1999/status/2100193181380088274"
      },
      "share_url": "https://x.ai/bot/c2y0GRnjxC7scs76bzxGw",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-16T12:00:48.000Z",
      "updated_at": "2026-09-16T12:00:48.000Z"
    },
    {
      "type": "template",
      "slug": "youtube-soft-pass-ops",
      "url": "https://grokbot.dev/marketplace/youtube-soft-pass-ops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/youtube-soft-pass-ops.json",
      "headline": "YouTube Soft-PASS Ops",
      "summary": "Ships a music release to YouTube slowly, with your go-ahead before public",
      "categories": [
        "creator",
        "youtube",
        "video",
        "content",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@EricChez",
        "url": "https://x.com/EricChez/status/2100186088606503068"
      },
      "share_url": "https://x.ai/bot/hf0v7qdlZbACHYYPTVxQ8",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T11:32:37.000Z",
      "updated_at": "2026-09-16T11:32:37.000Z"
    },
    {
      "type": "template",
      "slug": "cybercabinsight-builder",
      "url": "https://grokbot.dev/marketplace/cybercabinsight-builder/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cybercabinsight-builder.json",
      "headline": "CYBERCABINSIGHT Builder",
      "summary": "Keeps a Japanese-and-English research page on the Cybercab up to date",
      "categories": [
        "research",
        "news",
        "data",
        "monitoring",
        "scheduled",
        "video"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@bestband2016",
        "url": "https://x.com/bestband2016/status/2100183957530894486"
      },
      "share_url": "https://x.ai/bot/eSxdHB8yCtJbqp6vxQOzP",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-16T11:24:09.000Z",
      "updated_at": "2026-09-16T11:24:09.000Z"
    },
    {
      "type": "template",
      "slug": "ops",
      "url": "https://grokbot.dev/marketplace/ops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ops.json",
      "headline": "Ops",
      "summary": "A front door that triages your work and routes it to named specialists",
      "categories": [
        "business",
        "ops",
        "agent-team",
        "automation",
        "productivity"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Rimusz",
        "url": "https://x.com/Rimusz/status/2100159532349403632"
      },
      "share_url": "https://x.ai/bot/4sUQZA1UAXXDRf5bhYwPY",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-16T09:47:06.000Z",
      "updated_at": "2026-09-16T09:47:06.000Z"
    },
    {
      "type": "template",
      "slug": "clip-clip",
      "url": "https://grokbot.dev/marketplace/clip-clip/",
      "detail_url": "https://grokbot.dev/api/v1/templates/clip-clip.json",
      "headline": "Clip Clip",
      "summary": "Picks the few stream or podcast moments worth posting and cuts them",
      "categories": [
        "creator",
        "video",
        "social-media",
        "content",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@prcshxnt",
        "url": "https://x.com/prcshxnt/status/2100151839199228091"
      },
      "share_url": "https://x.ai/bot/hL97Xhf7o84RTv8NlOl37",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-16T09:16:32.000Z",
      "updated_at": "2026-09-16T09:16:32.000Z"
    },
    {
      "type": "template",
      "slug": "venduto",
      "url": "https://grokbot.dev/marketplace/venduto/",
      "detail_url": "https://grokbot.dev/api/v1/templates/venduto.json",
      "headline": "Venduto",
      "summary": "Runs your secondhand listings from first enquiry through to an agreed sale",
      "categories": [
        "personal",
        "sales",
        "shopping",
        "automation",
        "growth"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuperTost100",
        "url": "https://x.com/SuperTost100/status/2100149576388743291"
      },
      "share_url": "https://x.ai/bot/VH6hfT_aihtFVmOcSQTwp",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T09:07:32.000Z",
      "updated_at": "2026-09-16T09:07:32.000Z"
    },
    {
      "type": "template",
      "slug": "saas-content-ranker",
      "url": "https://grokbot.dev/marketplace/saas-content-ranker/",
      "detail_url": "https://grokbot.dev/api/v1/templates/saas-content-ranker.json",
      "headline": "SaaS Content Ranker",
      "summary": "Plans, drafts and checks the ranking pages for an affiliate software site",
      "categories": [
        "marketer",
        "content",
        "seo",
        "growth",
        "business"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Abdollahoffline",
        "url": "https://x.com/Abdollahoffline/status/2100145991965872367"
      },
      "share_url": "https://x.ai/bot/JDYPl17DU2bU771WtX4we",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T08:53:17.000Z",
      "updated_at": "2026-09-16T08:53:17.000Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-vaibhav",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-vaibhav/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-vaibhav.json",
      "headline": "Chief of Staff (Vaibhav)",
      "summary": "A morning digest where every item says where it came from and what is next",
      "categories": [
        "business",
        "ops",
        "agent-team",
        "productivity",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@vaibhavhome",
        "url": "https://x.com/vaibhavhome/status/2100099243448873109"
      },
      "share_url": "https://x.ai/bot/s4lVhWgvghY8dikqD0LC4",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-16T05:47:32.000Z",
      "updated_at": "2026-09-16T05:47:32.000Z"
    },
    {
      "type": "template",
      "slug": "robit",
      "url": "https://grokbot.dev/marketplace/robit/",
      "detail_url": "https://grokbot.dev/api/v1/templates/robit.json",
      "headline": "RobIT",
      "summary": "Chases down what is crashing your Windows PC and cleans up the mess",
      "categories": [
        "developer",
        "personal",
        "productivity",
        "automation",
        "engineering",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CrystalJ613",
        "url": "https://x.com/CrystalJ613/status/2100084745451250009"
      },
      "share_url": "https://x.ai/bot/0BbPklegaSLcUqp0CVXda",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T04:49:55.000Z",
      "updated_at": "2026-09-16T04:49:55.000Z"
    },
    {
      "type": "template",
      "slug": "wrench",
      "url": "https://grokbot.dev/marketplace/wrench/",
      "detail_url": "https://grokbot.dev/api/v1/templates/wrench.json",
      "headline": "Wrench",
      "summary": "A garage log that tracks each vehicle's service and flags what is due next",
      "categories": [
        "personal",
        "home",
        "productivity",
        "monitoring",
        "decision-support"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@treyvis",
        "url": "https://x.com/treyvis/status/2100023835705659649"
      },
      "share_url": "https://x.ai/bot/ZcypezNRfx6zOMeqtSr1r",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-16T01:16:13.113Z",
      "updated_at": "2026-09-16T01:16:13.113Z"
    },
    {
      "type": "template",
      "slug": "lumi",
      "url": "https://grokbot.dev/marketplace/lumi/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lumi.json",
      "headline": "Lumi",
      "summary": "Finds tech meetups in your city worth leaving the house for",
      "categories": [
        "personal",
        "events",
        "social-media",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@logesh45",
        "url": "https://x.com/logesh45/status/2100010767722615234"
      },
      "share_url": "https://x.ai/bot/r1T7by_HKzpacJ1EgXJ6H",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:55:57.000Z",
      "updated_at": "2026-09-15T23:55:57.000Z"
    },
    {
      "type": "template",
      "slug": "archer",
      "url": "https://grokbot.dev/marketplace/archer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/archer.json",
      "headline": "Archer",
      "summary": "Manages a bot crew that keeps an online product catalogue current",
      "categories": [
        "business",
        "ops",
        "marketer",
        "content",
        "agent-team",
        "scheduled",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@dukezone",
        "url": "https://x.com/dukezone/status/2100010056108683737"
      },
      "share_url": "https://x.ai/bot/vOriVfOZkvpZF9yGhfV5w",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-15T23:53:08.000Z",
      "updated_at": "2026-09-15T23:53:08.000Z"
    },
    {
      "type": "template",
      "slug": "karen",
      "url": "https://grokbot.dev/marketplace/karen/",
      "detail_url": "https://grokbot.dev/api/v1/templates/karen.json",
      "headline": "Karen",
      "summary": "Phones a company and works your case until it is closed out",
      "categories": [
        "personal",
        "ops",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KevinLH811",
        "url": "https://x.com/KevinLH811/status/2100007881261072660"
      },
      "share_url": "https://x.ai/bot/7tT7hseV3v0dXeJTLWAc1",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:44:29.000Z",
      "updated_at": "2026-09-15T23:44:29.000Z"
    },
    {
      "type": "template",
      "slug": "rocky",
      "url": "https://grokbot.dev/marketplace/rocky/",
      "detail_url": "https://grokbot.dev/api/v1/templates/rocky.json",
      "headline": "Rocky",
      "summary": "Finds upcoming local shows that match your taste and calendars them",
      "categories": [
        "personal",
        "events",
        "calendar",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@astrohoff",
        "url": "https://x.com/astrohoff/status/2100007410756644948"
      },
      "share_url": "https://x.ai/bot/DvWwLsNgDoi2uF3_5TTFf",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-15T23:42:37.000Z",
      "updated_at": "2026-09-15T23:42:37.000Z"
    },
    {
      "type": "template",
      "slug": "gb-live",
      "url": "https://grokbot.dev/marketplace/gb-live/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gb-live.json",
      "headline": "gb-live",
      "summary": "Watches an X live stream and digests whatever actually changed",
      "categories": [
        "personal",
        "monitoring",
        "social-media",
        "scheduled",
        "news"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@asura25ai",
        "url": "https://x.com/asura25ai/status/2100007176840601901"
      },
      "share_url": "https://x.ai/bot/AUfHSwBuDsxZlTZRC2Olf",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-15T23:41:41.000Z",
      "updated_at": "2026-09-15T23:41:41.000Z"
    },
    {
      "type": "template",
      "slug": "cash-fleet-operator",
      "url": "https://grokbot.dev/marketplace/cash-fleet-operator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cash-fleet-operator.json",
      "headline": "Cash Fleet Operator",
      "summary": "Coordinates a bot crew across storefront SKUs, merch and promos",
      "categories": [
        "business",
        "growth",
        "marketer",
        "ops",
        "automation",
        "agent-team",
        "social-media"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@OmgawdMadeit",
        "url": "https://x.com/OmgawdMadeit/status/2100005497856245831"
      },
      "share_url": "https://x.ai/bot/Mz3Q4s3wGqOQd4dhGeG_F",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-15T23:35:01.000Z",
      "updated_at": "2026-09-15T23:35:01.000Z"
    },
    {
      "type": "template",
      "slug": "listing-desk",
      "url": "https://grokbot.dev/marketplace/listing-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/listing-desk.json",
      "headline": "Listing Desk",
      "summary": "Builds an owner's listing pack from records before any marketing copy",
      "categories": [
        "business",
        "real-estate",
        "research",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SacredFolio",
        "url": "https://x.com/SacredFolio/status/2100003255183200704"
      },
      "share_url": "https://x.ai/bot/FSSDbB1Bv0msoI5mfjR3u",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:26:06.000Z",
      "updated_at": "2026-09-15T23:26:06.000Z"
    },
    {
      "type": "template",
      "slug": "grip",
      "url": "https://grokbot.dev/marketplace/grip/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grip.json",
      "headline": "Grip",
      "summary": "Coaches a hobby robot arm through teach, replay and fine-tuning",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MooneyMillions",
        "url": "https://x.com/MooneyMillions/status/2100002988995891653"
      },
      "share_url": "https://x.ai/bot/GyfhMCn4kdJUmS8gm2BMA",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:25:03.000Z",
      "updated_at": "2026-09-15T23:25:03.000Z"
    },
    {
      "type": "template",
      "slug": "devils-advocate",
      "url": "https://grokbot.dev/marketplace/devils-advocate/",
      "detail_url": "https://grokbot.dev/api/v1/templates/devils-advocate.json",
      "headline": "Devils Advocate",
      "summary": "Scores your options, names a winner and defends it later",
      "categories": [
        "personal",
        "business",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@YehudaZahler",
        "url": "https://x.com/YehudaZahler/status/2100002662808981516"
      },
      "share_url": "https://x.ai/bot/qKkQiRV-Erg5noHC9F05p",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:23:45.000Z",
      "updated_at": "2026-09-15T23:23:45.000Z"
    },
    {
      "type": "template",
      "slug": "steward-greg",
      "url": "https://grokbot.dev/marketplace/steward-greg/",
      "detail_url": "https://grokbot.dev/api/v1/templates/steward-greg.json",
      "headline": "Steward (Greg)",
      "summary": "Front door for a personal bot fleet, ask-first on anything sensitive",
      "categories": [
        "personal",
        "business",
        "productivity",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GregDuewall",
        "url": "https://x.com/GregDuewall/status/2100001256093675830"
      },
      "share_url": "https://x.ai/bot/XrDqxz9-QvCKazAQACQxh",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-15T23:18:10.000Z",
      "updated_at": "2026-09-15T23:18:10.000Z"
    },
    {
      "type": "template",
      "slug": "exec-daily-ops",
      "url": "https://grokbot.dev/marketplace/exec-daily-ops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/exec-daily-ops.json",
      "headline": "Exec Daily Ops",
      "summary": "An engineering-morning brief, with draft replies left for you to send",
      "categories": [
        "business",
        "ops",
        "developer",
        "analytics",
        "monitoring",
        "back-office",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kumarkandgule",
        "url": "https://x.com/kumarkandgule/status/2100001162426519754"
      },
      "share_url": "https://x.ai/bot/vIIc2EV8FFZ3g6W8JUgoZ",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-15T23:17:47.000Z",
      "updated_at": "2026-09-15T23:17:47.000Z"
    },
    {
      "type": "template",
      "slug": "afterscan",
      "url": "https://grokbot.dev/marketplace/afterscan/",
      "detail_url": "https://grokbot.dev/api/v1/templates/afterscan.json",
      "headline": "AfterScan",
      "summary": "Names and files scans as they land in your Drive folder",
      "categories": [
        "personal",
        "back-office",
        "automation",
        "productivity",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@xucchini",
        "url": "https://x.com/xucchini/status/2100000561663975873"
      },
      "share_url": "https://x.ai/bot/UaxwaoTEmiYzE7AulxLAe",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:15:24.000Z",
      "updated_at": "2026-09-15T23:15:24.000Z"
    },
    {
      "type": "template",
      "slug": "secondopinion",
      "url": "https://grokbot.dev/marketplace/secondopinion/",
      "detail_url": "https://grokbot.dev/api/v1/templates/secondopinion.json",
      "headline": "SecondOpinion",
      "summary": "A blunt second read on any plan, argument or draft",
      "categories": [
        "personal",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nasben82",
        "url": "https://x.com/nasben82/status/2099999458519912657"
      },
      "share_url": "https://x.ai/bot/6L7bI6xC3UxUTFaCWljFj",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:11:01.000Z",
      "updated_at": "2026-09-15T23:11:01.000Z"
    },
    {
      "type": "template",
      "slug": "gpt-astra-oracle",
      "url": "https://grokbot.dev/marketplace/gpt-astra-oracle/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gpt-astra-oracle.json",
      "headline": "GPT Astra Oracle",
      "summary": "Plan and review packets for a Cursor cloud agent, from a second model",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nathanromano",
        "url": "https://x.com/nathanromano/status/2099999284686979169"
      },
      "share_url": "https://x.ai/bot/_yTNK1xhcbUko1rM2AWAv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:10:20.000Z",
      "updated_at": "2026-09-15T23:10:20.000Z"
    },
    {
      "type": "template",
      "slug": "personal-shopper",
      "url": "https://grokbot.dev/marketplace/personal-shopper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/personal-shopper.json",
      "headline": "Personal Shopper",
      "summary": "Keeps a profile per family member and shops live listings for you",
      "categories": [
        "personal",
        "shopping",
        "family",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@hovinthenorth",
        "url": "https://x.com/hovinthenorth/status/2099998794490536065"
      },
      "share_url": "https://x.ai/bot/D0DOumUGpkN-fjE_acysw",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:08:23.000Z",
      "updated_at": "2026-09-15T23:08:23.000Z"
    },
    {
      "type": "template",
      "slug": "roof-radar",
      "url": "https://grokbot.dev/marketplace/roof-radar/",
      "detail_url": "https://grokbot.dev/api/v1/templates/roof-radar.json",
      "headline": "Roof Radar",
      "summary": "Turns public storm reports into a ranked, evidenced roofing-lead list",
      "categories": [
        "business",
        "sales",
        "research",
        "data",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SacredFolio",
        "url": "https://x.com/SacredFolio/status/2099998685409206697"
      },
      "share_url": "https://x.ai/bot/nuv1bSb5V15XZeFnu5BwF",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:07:57.000Z",
      "updated_at": "2026-09-15T23:07:57.000Z"
    },
    {
      "type": "template",
      "slug": "founder-mode",
      "url": "https://grokbot.dev/marketplace/founder-mode/",
      "detail_url": "https://grokbot.dev/api/v1/templates/founder-mode.json",
      "headline": "Founder Mode",
      "summary": "Stress-tests a startup idea and assembles the setup paperwork",
      "categories": [
        "business",
        "research",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@shiftynick",
        "url": "https://x.com/shiftynick/status/2099998209561043256"
      },
      "share_url": "https://x.ai/bot/BpLQHWMypQAV3e61cyFb2",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T23:06:03.000Z",
      "updated_at": "2026-09-15T23:06:03.000Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-s4mu",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-s4mu/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-s4mu.json",
      "headline": "Chief of Staff (S4MU)",
      "summary": "A creator's coordinator: comment research packs plus a daily junk sweep",
      "categories": [
        "creator",
        "personal",
        "youtube",
        "email",
        "monitoring",
        "agent-team",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Spiderjin",
        "url": "https://x.com/Spiderjin/status/2099997937744990247"
      },
      "share_url": "https://x.ai/bot/VsZ0QiNcoVNer6PFdyKzI",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-15T23:04:59.000Z",
      "updated_at": "2026-09-15T23:04:59.000Z"
    },
    {
      "type": "template",
      "slug": "ops-knowledge-observer",
      "url": "https://grokbot.dev/marketplace/ops-knowledge-observer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ops-knowledge-observer.json",
      "headline": "Ops Knowledge Observer",
      "summary": "One read-only company brain that a whole bot fleet can draw on",
      "categories": [
        "business",
        "ops",
        "developer",
        "knowledge-base",
        "automation",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@StephenRuhe",
        "url": "https://x.com/StephenRuhe/status/2099995191272681718"
      },
      "share_url": "https://x.ai/bot/CIgxhKdiPj7KflehWkaEr",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-15T22:54:04.000Z",
      "updated_at": "2026-09-15T22:54:04.000Z"
    },
    {
      "type": "template",
      "slug": "helper",
      "url": "https://grokbot.dev/marketplace/helper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/helper.json",
      "headline": "Helper",
      "summary": "The support slot in a household bot team, with no vote of its own",
      "categories": [
        "personal",
        "family",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CryptoMynd",
        "url": "https://x.com/CryptoMynd/status/2099994571434258516"
      },
      "share_url": "https://x.ai/bot/YLaDxv5e9FSS40odzLmnU",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T22:51:36.000Z",
      "updated_at": "2026-09-15T22:51:36.000Z"
    },
    {
      "type": "template",
      "slug": "homestead-advisor",
      "url": "https://grokbot.dev/marketplace/homestead-advisor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/homestead-advisor.json",
      "headline": "Homestead Advisor",
      "summary": "Walks first-time rural buyers through land, kit and utilities",
      "categories": [
        "personal",
        "home",
        "research",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AlanOrlikoski",
        "url": "https://x.com/AlanOrlikoski/status/2099994431831109712"
      },
      "share_url": "https://x.ai/bot/6z-iBRlRz1MSCtyneeHpN",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T22:51:03.000Z",
      "updated_at": "2026-09-15T22:51:03.000Z"
    },
    {
      "type": "template",
      "slug": "dee-jay",
      "url": "https://grokbot.dev/marketplace/dee-jay/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dee-jay.json",
      "headline": "Dee Jay!",
      "summary": "Digs out overlooked UK dance records and tidies the library behind them",
      "categories": [
        "creator",
        "content",
        "youtube",
        "personal",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CarlosSalas",
        "url": "https://x.com/CarlosSalas/status/2099993309758533809"
      },
      "share_url": "https://x.ai/bot/SlaKFOWu18n_PRAmeLkT_",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T22:46:35.000Z",
      "updated_at": "2026-09-15T22:46:35.000Z"
    },
    {
      "type": "template",
      "slug": "fleet-factory",
      "url": "https://grokbot.dev/marketplace/fleet-factory/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fleet-factory.json",
      "headline": "Fleet Factory",
      "summary": "A weekday close-out over inbox, calendar and whatever is in flight",
      "categories": [
        "business",
        "ops",
        "productivity",
        "automation",
        "monitoring",
        "agent-team",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SacredFolio",
        "url": "https://x.com/SacredFolio/status/2099992953834156454"
      },
      "share_url": "https://x.ai/bot/BAYUUoTHAtiILmNu1jM3y",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-15T22:45:10.000Z",
      "updated_at": "2026-09-15T22:45:10.000Z"
    },
    {
      "type": "template",
      "slug": "team-coordinador",
      "url": "https://grokbot.dev/marketplace/team-coordinador/",
      "detail_url": "https://grokbot.dev/api/v1/templates/team-coordinador.json",
      "headline": "Team Coordinador",
      "summary": "Keeps specialist bots in their lanes with a shared vault and a digest",
      "categories": [
        "business",
        "ops",
        "developer",
        "automation",
        "agent-team",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@LordCocoro",
        "url": "https://x.com/LordCocoro/status/2099986391220318235"
      },
      "share_url": "https://x.ai/bot/rWI7zYaHEPW3Ek6ODy8sk",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-15T22:19:06.000Z",
      "updated_at": "2026-09-15T22:19:06.000Z"
    },
    {
      "type": "plugin",
      "slug": "zensched",
      "url": "https://grokbot.dev/plugins/zensched/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/zensched.json",
      "headline": "ZenSched",
      "summary": "Field workforce scheduling over MCP — shifts, GPS check-in, timesheets.",
      "categories": [
        "work"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "zensched.com",
        "url": "https://www.zensched.com"
      },
      "added_at": "2026-09-15T19:30:00Z",
      "updated_at": "2026-09-15T19:30:00Z"
    },
    {
      "type": "template",
      "slug": "zensched-field-crew-scheduler",
      "url": "https://grokbot.dev/marketplace/zensched-field-crew-scheduler/",
      "detail_url": "https://grokbot.dev/api/v1/templates/zensched-field-crew-scheduler.json",
      "headline": "ZenSched",
      "summary": "Runs field-crew scheduling over MCP, from shift planning to GPS-verified check-in",
      "categories": [
        "business",
        "ops",
        "calendar",
        "back-office",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@zensched",
        "url": "https://x.com/zensched"
      },
      "share_url": "https://x.ai/bot/LK0rEXJnnD1qpEISXd7Ix",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T19:30:00Z",
      "updated_at": "2026-09-15T19:30:00Z"
    },
    {
      "type": "template",
      "slug": "dero",
      "url": "https://grokbot.dev/marketplace/dero/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dero.json",
      "headline": "Dero",
      "summary": "Runs the pipeline on Chilean municipal tender documents",
      "categories": [
        "business",
        "ops",
        "data",
        "back-office",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jorgesoffia",
        "url": "https://x.com/jorgesoffia/status/2099936875498627530"
      },
      "share_url": "https://x.ai/bot/OMpdsLwId7Du5PrjbX8L8",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-15T19:02:20.000Z",
      "updated_at": "2026-09-15T19:02:20.000Z"
    },
    {
      "type": "template",
      "slug": "mentor",
      "url": "https://grokbot.dev/marketplace/mentor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/mentor.json",
      "headline": "Mentor",
      "summary": "A build partner for short AI-video projects and product loops",
      "categories": [
        "creator",
        "content",
        "video",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Jon_Rose_",
        "url": "https://x.com/Jon_Rose_/status/2099919690197876937"
      },
      "share_url": "https://x.ai/bot/3rV7gv1k94G6gCG_arFLr",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T17:54:03.000Z",
      "updated_at": "2026-09-15T17:54:03.000Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-andrew",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-andrew/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-andrew.json",
      "headline": "Chief of Staff (Andrew)",
      "summary": "Keeps a roster of helper bots pointed at a speaking business",
      "categories": [
        "business",
        "ops",
        "productivity",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DrewLee06",
        "url": "https://x.com/DrewLee06/status/2099916477889421732"
      },
      "share_url": "https://x.ai/bot/5hJ_io8a7Y0IImGtFbvJL",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-15T17:41:17.000Z",
      "updated_at": "2026-09-15T17:41:17.000Z"
    },
    {
      "type": "template",
      "slug": "c-digo-gamer",
      "url": "https://grokbot.dev/marketplace/c-digo-gamer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/c-digo-gamer.json",
      "headline": "Código.Gamer",
      "summary": "Keeps your game builds and meta current, then drafts the Instagram posts",
      "categories": [
        "creator",
        "content",
        "social-media",
        "personal",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@merliac84",
        "url": "https://x.com/merliac84/status/2099900934595711158"
      },
      "share_url": "https://x.ai/bot/w0wamvGSIRi9if0ggIhJd",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T16:39:31.000Z",
      "updated_at": "2026-09-15T16:39:31.000Z"
    },
    {
      "type": "template",
      "slug": "optimusanesthesia",
      "url": "https://grokbot.dev/marketplace/optimusanesthesia/",
      "detail_url": "https://grokbot.dev/api/v1/templates/optimusanesthesia.json",
      "headline": "OptimusAnesthesia",
      "summary": "Marketing content for an anesthesia practice, kept off medical advice",
      "categories": [
        "business",
        "marketer",
        "content",
        "social-media",
        "health",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@bigredelephant",
        "url": "https://x.com/bigredelephant/status/2099885589369700623"
      },
      "share_url": "https://x.ai/bot/MF7q-FTm3QaN7oIIFr3Hv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T15:38:33.000Z",
      "updated_at": "2026-09-15T15:38:33.000Z"
    },
    {
      "type": "template",
      "slug": "flippy",
      "url": "https://grokbot.dev/marketplace/flippy/",
      "detail_url": "https://grokbot.dev/api/v1/templates/flippy.json",
      "headline": "Flippy",
      "summary": "A daily heads-up on the mint phases your wallets are actually allowed into.",
      "categories": [
        "personal",
        "monitoring",
        "crypto",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@diegoarmandoAD",
        "url": "https://x.com/diegoarmandoAD/status/2099830423853424860"
      },
      "share_url": "https://x.ai/bot/OfHECnXmPPavf-l_rZufo",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-15T11:59:20.000Z",
      "updated_at": "2026-09-15T11:59:20.000Z"
    },
    {
      "type": "template",
      "slug": "prospect-drafts",
      "url": "https://grokbot.dev/marketplace/prospect-drafts/",
      "detail_url": "https://grokbot.dev/api/v1/templates/prospect-drafts.json",
      "headline": "Prospect Drafts",
      "summary": "Finds fitting prospects and leaves a ready first-touch email in your drafts.",
      "categories": [
        "business",
        "sales",
        "marketer",
        "growth",
        "email",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sam_builds_ai",
        "url": "https://x.com/sam_builds_ai/status/2099824297573511622"
      },
      "share_url": "https://x.ai/bot/Ed8OwTpWaFfZdJHEAoT4t",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-15T11:35:00.000Z",
      "updated_at": "2026-09-15T11:35:00.000Z"
    },
    {
      "type": "template",
      "slug": "lienzo",
      "url": "https://grokbot.dev/marketplace/lienzo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lienzo.json",
      "headline": "Lienzo",
      "summary": "Turns design links into a reference library you can question later",
      "categories": [
        "personal",
        "design",
        "knowledge-base",
        "research",
        "productivity"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@FrancoE114696",
        "url": "https://x.com/FrancoE114696/status/2099646811992424632"
      },
      "share_url": "https://x.ai/bot/cYZG2v8vG9Q7Fsds3Ickp",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T23:49:44.000Z",
      "updated_at": "2026-09-14T23:49:44.000Z"
    },
    {
      "type": "template",
      "slug": "tin-el-investigador",
      "url": "https://grokbot.dev/marketplace/tin-el-investigador/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tin-el-investigador.json",
      "headline": "Tin El Investigador",
      "summary": "Turns a question into a ready-to-post Spanish update every day",
      "categories": [
        "personal",
        "creator",
        "content",
        "research",
        "social-media",
        "scheduled",
        "learning"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@valengiulimor",
        "url": "https://x.com/valengiulimor/status/2099607798766084217"
      },
      "share_url": "https://x.ai/bot/L3Lx6Y8t_ebL8qQhutoCd",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-14T21:14:42.000Z",
      "updated_at": "2026-09-14T21:14:42.000Z"
    },
    {
      "type": "template",
      "slug": "commitments",
      "url": "https://grokbot.dev/marketplace/commitments/",
      "detail_url": "https://grokbot.dev/api/v1/templates/commitments.json",
      "headline": "Commitments",
      "summary": "Logs the promises you make at work and holds them open till done",
      "categories": [
        "personal",
        "business",
        "productivity",
        "monitoring",
        "back-office",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@samlambert",
        "url": "https://x.com/samlambert/status/2099584402045210992"
      },
      "share_url": "https://x.ai/bot/rFShmowW_3x_qeXQQB-sn",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T19:41:44.000Z",
      "updated_at": "2026-09-14T19:41:44.000Z"
    },
    {
      "type": "template",
      "slug": "grottle",
      "url": "https://grokbot.dev/marketplace/grottle/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grottle.json",
      "headline": "Grottle",
      "summary": "A clearer fuel gauge for your weekly Grok Bot usage",
      "categories": [
        "personal",
        "developer",
        "productivity",
        "monitoring",
        "analytics",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BCornTexas",
        "url": "https://x.com/BCornTexas/status/2099580443943227590"
      },
      "share_url": "https://x.ai/bot/YvFrCr_VlFW_8PxaoFv_L",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T19:26:00.000Z",
      "updated_at": "2026-09-14T19:26:00.000Z"
    },
    {
      "type": "template",
      "slug": "e-mail-organizer",
      "url": "https://grokbot.dev/marketplace/e-mail-organizer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/e-mail-organizer.json",
      "headline": "E-mail Organizer",
      "summary": "Files one Gmail account by vendor and keeps invoices separate",
      "categories": [
        "business",
        "email",
        "back-office",
        "automation",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@leingoedbloed",
        "url": "https://x.com/leingoedbloed/status/2099569404115624094"
      },
      "share_url": "https://x.ai/bot/PUn74RYv_r3pcSvNkeQbd",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-14T18:42:08.000Z",
      "updated_at": "2026-09-14T18:42:08.000Z"
    },
    {
      "type": "template",
      "slug": "skool-community-bot",
      "url": "https://grokbot.dev/marketplace/skool-community-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/skool-community-bot.json",
      "headline": "Skool Community Bot",
      "summary": "Keeps a Skool group's members, posts and open questions in view",
      "categories": [
        "business",
        "ops",
        "support",
        "marketer",
        "automation",
        "social-media"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@shawnjooste",
        "url": "https://x.com/shawnjooste/status/2099536605396586527"
      },
      "share_url": "https://x.ai/bot/k52i6aFytc3an6PabakvN",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T16:31:48.000Z",
      "updated_at": "2026-09-14T16:31:48.000Z"
    },
    {
      "type": "template",
      "slug": "vetstack",
      "url": "https://grokbot.dev/marketplace/vetstack/",
      "detail_url": "https://grokbot.dev/api/v1/templates/vetstack.json",
      "headline": "VetStack",
      "summary": "A savings desk for military life, from purchases to benefits",
      "categories": [
        "personal",
        "saving-money",
        "finance"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kenashe",
        "url": "https://x.com/kenashe"
      },
      "share_url": "https://x.ai/bot/z1zYI6LHiFh0UXYf7YjNL",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T16:14:52.626Z",
      "updated_at": "2026-09-14T16:14:52.626Z"
    },
    {
      "type": "template",
      "slug": "voice-receipt-ledger",
      "url": "https://grokbot.dev/marketplace/voice-receipt-ledger/",
      "detail_url": "https://grokbot.dev/api/v1/templates/voice-receipt-ledger.json",
      "headline": "记账管家",
      "summary": "A private ledger fed by typing, receipt photos or voice notes",
      "categories": [
        "personal",
        "finance",
        "saving-money",
        "automation",
        "data",
        "productivity"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@cgnot996",
        "url": "https://x.com/cgnot996/status/2099527147882942853"
      },
      "share_url": "https://x.ai/bot/WW-UbmTKXn79q0yXapvJE",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T15:54:14.000Z",
      "updated_at": "2026-09-14T15:54:14.000Z"
    },
    {
      "type": "template",
      "slug": "teslaway",
      "url": "https://grokbot.dev/marketplace/teslaway/",
      "detail_url": "https://grokbot.dev/api/v1/templates/teslaway.json",
      "headline": "teslaway",
      "summary": "Finds used Teslas near a ZIP code and emails you the shortlist",
      "categories": [
        "personal",
        "shopping",
        "research",
        "monitoring",
        "email",
        "saving-money"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@cicerougc",
        "url": "https://x.com/cicerougc/status/2099483609182659071"
      },
      "share_url": "https://x.ai/bot/HoG3J3B0g4fjKr54aA5tP",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T13:01:13.000Z",
      "updated_at": "2026-09-14T13:01:13.000Z"
    },
    {
      "type": "template",
      "slug": "reply-radar",
      "url": "https://grokbot.dev/marketplace/reply-radar/",
      "detail_url": "https://grokbot.dev/api/v1/templates/reply-radar.json",
      "headline": "Reply Radar",
      "summary": "Catches conversations while they are still climbing and drafts your reply",
      "categories": [
        "creator",
        "social-media",
        "growth",
        "monitoring",
        "content",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sam_builds_ai",
        "url": "https://x.com/sam_builds_ai/status/2099463729796755818"
      },
      "share_url": "https://x.ai/bot/lJYaUExPBMZfLWfZEFVGc",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-14T11:42:13.000Z",
      "updated_at": "2026-09-14T11:42:13.000Z"
    },
    {
      "type": "template",
      "slug": "nessie",
      "url": "https://grokbot.dev/marketplace/nessie/",
      "detail_url": "https://grokbot.dev/api/v1/templates/nessie.json",
      "headline": "Nessie",
      "summary": "Sketches out a national dividend and the hard question of who pays for it",
      "categories": [
        "research",
        "personal",
        "finance",
        "decision-support",
        "analytics",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AlecSnelling",
        "url": "https://x.com/AlecSnelling/status/2099377714600050708"
      },
      "share_url": "https://x.ai/bot/8-OG0rLmfAna8vs_0PBO_",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T06:00:26.000Z",
      "updated_at": "2026-09-14T06:00:26.000Z"
    },
    {
      "type": "template",
      "slug": "glasser",
      "url": "https://grokbot.dev/marketplace/glasser/",
      "detail_url": "https://grokbot.dev/api/v1/templates/glasser.json",
      "headline": "Glasser",
      "summary": "Reaches paid business-data sources without a drawer full of API keys",
      "categories": [
        "research",
        "business",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Glasserai",
        "url": "https://x.com/Glasserai"
      },
      "share_url": "https://x.ai/bot/pYFETnU1TFsADlz0hJD1y",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T05:29:28.791Z",
      "updated_at": "2026-09-14T05:29:28.791Z"
    },
    {
      "type": "template",
      "slug": "x-writer",
      "url": "https://grokbot.dev/marketplace/x-writer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-writer.json",
      "headline": "X Writer",
      "summary": "Learns how an account writes, then drafts new posts that sound like it",
      "categories": [
        "creator",
        "content",
        "social-media",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@starzq",
        "url": "https://x.com/starzq/status/2099333570020122669"
      },
      "share_url": "https://x.ai/bot/UUsZRoInD7OHp4sjrZ-we",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-14T03:05:01.000Z",
      "updated_at": "2026-09-14T03:05:01.000Z"
    },
    {
      "type": "template",
      "slug": "family-safety-monitor",
      "url": "https://grokbot.dev/marketplace/family-safety-monitor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/family-safety-monitor.json",
      "headline": "Family Safety Monitor",
      "summary": "Keeps a parent posted on which apps a child uses, without reading their messages",
      "categories": [
        "personal",
        "family",
        "monitoring",
        "wellbeing",
        "youtube",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KevinTweets1",
        "url": "https://x.com/KevinTweets1/status/2099251469266608138"
      },
      "share_url": "https://x.ai/bot/Dc0ZGUypwwBQZE9pNxLYy",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-13T21:38:47.000Z",
      "updated_at": "2026-09-13T21:38:47.000Z"
    },
    {
      "type": "template",
      "slug": "grocery-bot",
      "url": "https://grokbot.dev/marketplace/grocery-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grocery-bot.json",
      "headline": "Grocery Bot",
      "summary": "Turns grocery receipts into a spending record and flags what will spoil first",
      "categories": [
        "personal",
        "shopping",
        "food",
        "saving-money",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ZestStream",
        "url": "https://x.com/ZestStream/status/2099214073829499320"
      },
      "share_url": "https://x.ai/bot/K-bz2_bFptZdWAAW7Phxp",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T19:10:11.000Z",
      "updated_at": "2026-09-13T19:10:11.000Z"
    },
    {
      "type": "template",
      "slug": "unstick-me",
      "url": "https://grokbot.dev/marketplace/unstick-me/",
      "detail_url": "https://grokbot.dev/api/v1/templates/unstick-me.json",
      "headline": "Unstick me",
      "summary": "Asks one small question at a time until a stalled task is actually started",
      "categories": [
        "personal",
        "wellbeing",
        "productivity",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@YanqingCheng",
        "url": "https://x.com/YanqingCheng/status/2099206038368977179"
      },
      "share_url": "https://x.ai/bot/EahHaI-kwO0hgWj6I45jC",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T18:38:15.000Z",
      "updated_at": "2026-09-13T18:38:15.000Z"
    },
    {
      "type": "template",
      "slug": "about-me",
      "url": "https://grokbot.dev/marketplace/about-me/",
      "detail_url": "https://grokbot.dev/api/v1/templates/about-me.json",
      "headline": "About Me",
      "summary": "Keeps a running read on your own state and briefs the rest of your bots on it",
      "categories": [
        "personal",
        "wellbeing",
        "decision-support",
        "analytics",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TAftermath2020",
        "url": "https://x.com/TAftermath2020/status/2099183022193123784"
      },
      "share_url": "https://x.ai/bot/7dfQ6zC2X2hmnIlnF4rSN",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-13T17:06:48.000Z",
      "updated_at": "2026-09-13T17:06:48.000Z"
    },
    {
      "type": "template",
      "slug": "travel-agent-scott",
      "url": "https://grokbot.dev/marketplace/travel-agent-scott/",
      "detail_url": "https://grokbot.dev/api/v1/templates/travel-agent-scott.json",
      "headline": "Travel Agent (Scott)",
      "summary": "Researches a trip and stages the bookings, leaving every confirmation to you",
      "categories": [
        "personal",
        "travel",
        "productivity",
        "automation",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2099161443455385977"
      },
      "share_url": "https://x.ai/bot/d8C0ufUatv_fgoCRbfXZ4",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T15:41:03.000Z",
      "updated_at": "2026-09-13T15:41:03.000Z"
    },
    {
      "type": "template",
      "slug": "wechat-alipay-bill-import",
      "url": "https://grokbot.dev/marketplace/wechat-alipay-bill-import/",
      "detail_url": "https://grokbot.dev/api/v1/templates/wechat-alipay-bill-import.json",
      "headline": "账单进口",
      "summary": "Files WeChat and Alipay statements into a personal ledger, with a preview first",
      "categories": [
        "personal",
        "finance",
        "back-office",
        "productivity",
        "analytics",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@coolbat1999",
        "url": "https://x.com/coolbat1999/status/2099141007887777987"
      },
      "share_url": "https://x.ai/bot/A3pcjyO0dAkvRGxD4VGeH",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T14:19:51.000Z",
      "updated_at": "2026-09-13T14:19:51.000Z"
    },
    {
      "type": "template",
      "slug": "visa-japan-offer-draws",
      "url": "https://grokbot.dev/marketplace/visa-japan-offer-draws/",
      "detail_url": "https://grokbot.dev/api/v1/templates/visa-japan-offer-draws.json",
      "headline": "Visa割bot",
      "summary": "Plays every unused Visa Japan offer draw so no free entry expires",
      "categories": [
        "personal",
        "automation",
        "life-hacks",
        "saving-money",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@countertek",
        "url": "https://x.com/countertek/status/2099118954799321172"
      },
      "share_url": "https://x.ai/bot/e9p9lk8EcUrrGXPI_cf4c",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T12:52:13.000Z",
      "updated_at": "2026-09-13T12:52:13.000Z"
    },
    {
      "type": "template",
      "slug": "jre-point-campaigns",
      "url": "https://grokbot.dev/marketplace/jre-point-campaigns/",
      "detail_url": "https://grokbot.dev/api/v1/templates/jre-point-campaigns.json",
      "headline": "JREキャンペーンbot",
      "summary": "Registers you for every open JRE POINT campaign so none slip past",
      "categories": [
        "personal",
        "automation",
        "life-hacks",
        "saving-money",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@countertek",
        "url": "https://x.com/countertek/status/2099100042762334299"
      },
      "share_url": "https://x.ai/bot/VkkObYeFAOWsAU9dzu7d1",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T11:37:04.000Z",
      "updated_at": "2026-09-13T11:37:04.000Z"
    },
    {
      "type": "template",
      "slug": "cto-bot",
      "url": "https://grokbot.dev/marketplace/cto-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cto-bot.json",
      "headline": "CTO Bot",
      "summary": "Audits how your engineering org is actually running, without touching anything",
      "categories": [
        "developer",
        "business",
        "ops",
        "decision-support",
        "monitoring",
        "engineering",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@asmDevsit",
        "url": "https://x.com/asmDevsit/status/2099072494032343546"
      },
      "share_url": "https://x.ai/bot/cWnyo7aDLIy0qMRC6-CF5",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-13T09:47:36.000Z",
      "updated_at": "2026-09-13T09:47:36.000Z"
    },
    {
      "type": "template",
      "slug": "grok-bot-directory",
      "url": "https://grokbot.dev/marketplace/grok-bot-directory/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-bot-directory.json",
      "headline": "Grok Bot Directory",
      "summary": "Describe the job you need done and it points you at the shared bot that does it",
      "categories": [
        "developer",
        "personal",
        "research",
        "knowledge-base",
        "on-demand",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Leechael",
        "url": "https://x.com/Leechael/status/2099070820270424210"
      },
      "share_url": "https://x.ai/bot/8wjQbE24sX8qBVHXSmjc8",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T09:40:57.000Z",
      "updated_at": "2026-09-13T09:40:57.000Z"
    },
    {
      "type": "template",
      "slug": "memory-steward",
      "url": "https://grokbot.dev/marketplace/memory-steward/",
      "detail_url": "https://grokbot.dev/api/v1/templates/memory-steward.json",
      "headline": "记忆管家",
      "summary": "Mirrors each bot's setup and memory into a private Git repo you control",
      "categories": [
        "developer",
        "ops",
        "back-office",
        "automation",
        "data",
        "engineering",
        "knowledge-base",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AYi_AInotes",
        "url": "https://x.com/AYi_AInotes/status/2099028909773693272"
      },
      "share_url": "https://x.ai/bot/9Tq1f0aSurCP7UJHm98zy",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-13T06:54:24.000Z",
      "updated_at": "2026-09-13T06:54:24.000Z"
    },
    {
      "type": "template",
      "slug": "nuggetbot",
      "url": "https://grokbot.dev/marketplace/nuggetbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/nuggetbot.json",
      "headline": "NuggetBot",
      "summary": "Pulls the best lines out of a podcast and renders them as post-ready graphics",
      "categories": [
        "creator",
        "marketer",
        "content",
        "social-media",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@im_usamakhalid",
        "url": "https://x.com/im_usamakhalid/status/2099008636521771045"
      },
      "share_url": "https://x.ai/bot/ia1zuEzDtPNyzFQ6o6F9x",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T05:33:51.000Z",
      "updated_at": "2026-09-13T05:33:51.000Z"
    },
    {
      "type": "template",
      "slug": "sweeper-credit-saver",
      "url": "https://grokbot.dev/marketplace/sweeper-credit-saver/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sweeper-credit-saver.json",
      "headline": "Sweeper / 清道夫",
      "summary": "Shows where your bot credits are going and cuts the wake-ups that waste them",
      "categories": [
        "developer",
        "ops",
        "saving-money",
        "monitoring",
        "automation",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MaiYangAI",
        "url": "https://x.com/MaiYangAI/status/2098962373239517465"
      },
      "share_url": "https://x.ai/bot/SD6hgpiXqbV_LkMetf2fC",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T02:30:01.000Z",
      "updated_at": "2026-09-13T02:30:01.000Z"
    },
    {
      "type": "template",
      "slug": "text-cleanup",
      "url": "https://grokbot.dev/marketplace/text-cleanup/",
      "detail_url": "https://grokbot.dev/api/v1/templates/text-cleanup.json",
      "headline": "Text-cleanup",
      "summary": "Cleans up writing you already have into one send-ready version",
      "categories": [
        "personal",
        "productivity",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GrokBotGod",
        "url": "https://x.com/GrokBotGod"
      },
      "share_url": "https://x.ai/bot/E3h6k-Sbq7hwF3PW1ZBI4",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-13T01:10:37.181Z",
      "updated_at": "2026-09-13T01:10:37.181Z"
    },
    {
      "type": "template",
      "slug": "root-agent",
      "url": "https://grokbot.dev/marketplace/root-agent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/root-agent.json",
      "headline": "Root Agent",
      "summary": "Sets the goal, assembles the smallest team that can hit it, then reports back",
      "categories": [
        "business",
        "ops",
        "automation",
        "agent-team",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mrbeko_",
        "url": "https://x.com/mrbeko_/status/2098922675368292825"
      },
      "share_url": "https://x.ai/bot/1pTKHkJIEgxD9MjlPYE4P",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-12T23:52:16.000Z",
      "updated_at": "2026-09-12T23:52:16.000Z"
    },
    {
      "type": "template",
      "slug": "paige-turner",
      "url": "https://grokbot.dev/marketplace/paige-turner/",
      "detail_url": "https://grokbot.dev/api/v1/templates/paige-turner.json",
      "headline": "Paige Turner",
      "summary": "The librarian for a bot team, so the rest answer from sources instead of memory",
      "categories": [
        "developer",
        "knowledge-base",
        "data",
        "engineering",
        "research",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@omnithnkr",
        "url": "https://x.com/omnithnkr/status/2098903351102509409"
      },
      "share_url": "https://x.ai/bot/2lbNqne5ku5VQird_s8AW",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-12T22:35:29.000Z",
      "updated_at": "2026-09-12T22:35:29.000Z"
    },
    {
      "type": "template",
      "slug": "berliner",
      "url": "https://grokbot.dev/marketplace/berliner/",
      "detail_url": "https://grokbot.dev/api/v1/templates/berliner.json",
      "headline": "Berliner",
      "summary": "A weekly Berlin techno playlist with notes on what you are hearing",
      "categories": [
        "personal",
        "creator",
        "content",
        "life-hacks",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mattvagni",
        "url": "https://x.com/mattvagni/status/2098896244730888494"
      },
      "share_url": "https://x.ai/bot/YhRPa_eYk4yramoMJOo6F",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-12T22:07:15.000Z",
      "updated_at": "2026-09-12T22:07:15.000Z"
    },
    {
      "type": "template",
      "slug": "alibaba-buyer-ops",
      "url": "https://grokbot.dev/marketplace/alibaba-buyer-ops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/alibaba-buyer-ops.json",
      "headline": "Alibaba Buyer Ops",
      "summary": "Runs the day-to-day of buying from factories on Alibaba",
      "categories": [
        "business",
        "ops",
        "shopping",
        "back-office",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DomenicFotino",
        "url": "https://x.com/DomenicFotino/status/2098863386197151793"
      },
      "share_url": "https://x.ai/bot/ZTFwMWXlScRvLrkHuR3gs",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T19:56:40.000Z",
      "updated_at": "2026-09-12T19:56:40.000Z"
    },
    {
      "type": "template",
      "slug": "do-not-pay",
      "url": "https://grokbot.dev/marketplace/do-not-pay/",
      "detail_url": "https://grokbot.dev/api/v1/templates/do-not-pay.json",
      "headline": "Do Not Pay",
      "summary": "Pushes back on charges you should not be paying, and writes the letter",
      "categories": [
        "personal",
        "saving-money",
        "finance",
        "support",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DennisonBertram",
        "url": "https://x.com/DennisonBertram/status/2098852225980182961"
      },
      "share_url": "https://x.ai/bot/oxhf-Gm6EEs9SVHYFYbT4",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T19:12:20.000Z",
      "updated_at": "2026-09-12T19:12:20.000Z"
    },
    {
      "type": "template",
      "slug": "maples-stylist",
      "url": "https://grokbot.dev/marketplace/maples-stylist/",
      "detail_url": "https://grokbot.dev/api/v1/templates/maples-stylist.json",
      "headline": "Maples造型师",
      "summary": "Builds MapleStory outfits you can actually reproduce in game",
      "categories": [
        "personal",
        "creator",
        "design",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@cgnot996",
        "url": "https://x.com/cgnot996/status/2098831516071829604"
      },
      "share_url": "https://x.ai/bot/zP5W1Sdwjo361traGRTM5",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T17:50:02.000Z",
      "updated_at": "2026-09-12T17:50:02.000Z"
    },
    {
      "type": "template",
      "slug": "recruiter-email-finder",
      "url": "https://grokbot.dev/marketplace/recruiter-email-finder/",
      "detail_url": "https://grokbot.dev/api/v1/templates/recruiter-email-finder.json",
      "headline": "Recruiter Email Finder",
      "summary": "Works out who does the hiring at your target employers and how to email them",
      "categories": [
        "personal",
        "student",
        "recruiting",
        "research",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@fwhittington_24",
        "url": "https://x.com/fwhittington_24/status/2098810811514851568"
      },
      "share_url": "https://x.ai/bot/lbf-biMZO02RdXeOBks_-",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T16:27:46.000Z",
      "updated_at": "2026-09-12T16:27:46.000Z"
    },
    {
      "type": "template",
      "slug": "swe-job-applier",
      "url": "https://grokbot.dev/marketplace/swe-job-applier/",
      "detail_url": "https://grokbot.dev/api/v1/templates/swe-job-applier.json",
      "headline": "SWE Job Applier",
      "summary": "Chases engineering internships using Simplify and your own letter template",
      "categories": [
        "personal",
        "student",
        "recruiting",
        "engineering",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@fwhittington_24",
        "url": "https://x.com/fwhittington_24/status/2098810814668886087"
      },
      "share_url": "https://x.ai/bot/ZNfBRZeVANNSVza6Xyywf",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T16:27:46.000Z",
      "updated_at": "2026-09-12T16:27:46.000Z"
    },
    {
      "type": "template",
      "slug": "yc-startup-job-applier",
      "url": "https://grokbot.dev/marketplace/yc-startup-job-applier/",
      "detail_url": "https://grokbot.dev/api/v1/templates/yc-startup-job-applier.json",
      "headline": "YC Startup Job Applier",
      "summary": "Fills in your Work at a Startup profile and messages founders, within your limits",
      "categories": [
        "personal",
        "student",
        "recruiting",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@fwhittington_24",
        "url": "https://x.com/fwhittington_24/status/2098810812932501719"
      },
      "share_url": "https://x.ai/bot/COQAlYvqDNehPSHDBt-6z",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T16:27:46.000Z",
      "updated_at": "2026-09-12T16:27:46.000Z"
    },
    {
      "type": "template",
      "slug": "alumni-coffee-chat-finder",
      "url": "https://grokbot.dev/marketplace/alumni-coffee-chat-finder/",
      "detail_url": "https://grokbot.dev/api/v1/templates/alumni-coffee-chat-finder.json",
      "headline": "Alumni Coffee Chat Finder",
      "summary": "Finds people from your university worth a coffee chat and lists them out",
      "categories": [
        "personal",
        "student",
        "recruiting",
        "research",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@fwhittington_24",
        "url": "https://x.com/fwhittington_24/status/2098810809921003800"
      },
      "share_url": "https://x.ai/bot/j2bqDafGnyOv6bKMOOGOp",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T16:27:45.000Z",
      "updated_at": "2026-09-12T16:27:45.000Z"
    },
    {
      "type": "template",
      "slug": "handshake-job-applier",
      "url": "https://grokbot.dev/marketplace/handshake-job-applier/",
      "detail_url": "https://grokbot.dev/api/v1/templates/handshake-job-applier.json",
      "headline": "Handshake Job Applier",
      "summary": "Works the Handshake board for you, from account setup to submitted applications",
      "categories": [
        "personal",
        "student",
        "recruiting",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@fwhittington_24",
        "url": "https://x.com/fwhittington_24/status/2098810808293626139"
      },
      "share_url": "https://x.ai/bot/4AcLHtvlWUWclgU5jFy2r",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T16:27:45.000Z",
      "updated_at": "2026-09-12T16:27:45.000Z"
    },
    {
      "type": "template",
      "slug": "task-farming",
      "url": "https://grokbot.dev/marketplace/task-farming/",
      "detail_url": "https://grokbot.dev/api/v1/templates/task-farming.json",
      "headline": "Task Farming",
      "summary": "Turns what got agreed in meetings and chat into real tickets",
      "categories": [
        "business",
        "ops",
        "productivity",
        "meetings",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2098802349649387896"
      },
      "share_url": "https://x.ai/bot/MmcPTdwYwr6ebmmZzswYe",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T15:54:08.000Z",
      "updated_at": "2026-09-12T15:54:08.000Z"
    },
    {
      "type": "template",
      "slug": "weekend-edition",
      "url": "https://grokbot.dev/marketplace/weekend-edition/",
      "detail_url": "https://grokbot.dev/api/v1/templates/weekend-edition.json",
      "headline": "Weekend Edition",
      "summary": "Collects a week of saved reading into a paper you can actually print",
      "categories": [
        "personal",
        "content",
        "news",
        "learning",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nathanglass",
        "url": "https://x.com/nathanglass/status/2098799970618954145"
      },
      "share_url": "https://x.ai/bot/1-S1yhsX6eEcPs9yik3oh",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-12T15:44:41.000Z",
      "updated_at": "2026-09-12T15:44:41.000Z"
    },
    {
      "type": "template",
      "slug": "receipt-reaper",
      "url": "https://grokbot.dev/marketplace/receipt-reaper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/receipt-reaper.json",
      "headline": "Receipt Reaper",
      "summary": "Finds the software you forgot you were paying for and scores how dead it is",
      "categories": [
        "personal",
        "saving-money",
        "finance",
        "email",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RealJBMangum",
        "url": "https://x.com/RealJBMangum/status/2098790265276231929"
      },
      "share_url": "https://x.ai/bot/gIV4FpQgVmcsO0soCjHGc",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T15:11:24.721Z",
      "updated_at": "2026-09-12T15:11:24.721Z"
    },
    {
      "type": "template",
      "slug": "business-ops",
      "url": "https://grokbot.dev/marketplace/business-ops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/business-ops.json",
      "headline": "Business ops",
      "summary": "One entry point for every part of running the shop, delegating where it helps",
      "categories": [
        "business",
        "ops",
        "automation",
        "productivity",
        "meta-bot",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713517121544195"
      },
      "share_url": "https://x.ai/bot/nFEJD59IJA5604hO9vqym",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:09.000Z",
      "updated_at": "2026-09-12T10:01:09.000Z"
    },
    {
      "type": "template",
      "slug": "affiliate-program-operator",
      "url": "https://grokbot.dev/marketplace/affiliate-program-operator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/affiliate-program-operator.json",
      "headline": "Affiliate program manager",
      "summary": "Keeps a creator affiliate programme honest, ranked and well supplied",
      "categories": [
        "business",
        "marketer",
        "growth",
        "automation",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713513719992540"
      },
      "share_url": "https://x.ai/bot/-x19CFkvT5U866BNA7q_J",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:08.000Z",
      "updated_at": "2026-09-12T10:01:08.000Z"
    },
    {
      "type": "template",
      "slug": "partner-referral-outreach",
      "url": "https://grokbot.dev/marketplace/partner-referral-outreach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/partner-referral-outreach.json",
      "headline": "Partner referral outreach",
      "summary": "Builds a referral network by finding matching businesses and chasing them up",
      "categories": [
        "business",
        "sales",
        "marketer",
        "growth",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713515267625255"
      },
      "share_url": "https://x.ai/bot/GG7hDpauDjTRhB6VgLFAF",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:08.000Z",
      "updated_at": "2026-09-12T10:01:08.000Z"
    },
    {
      "type": "template",
      "slug": "ugc-bounty-manager",
      "url": "https://grokbot.dev/marketplace/ugc-bounty-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ugc-bounty-manager.json",
      "headline": "UGC bounty manager",
      "summary": "Runs creator clipping bounties from brief through to a payout recommendation",
      "categories": [
        "business",
        "marketer",
        "growth",
        "automation",
        "content",
        "social-media"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713511996125666"
      },
      "share_url": "https://x.ai/bot/wT_QN-zqycu-aHPsdZMVc",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:08.000Z",
      "updated_at": "2026-09-12T10:01:08.000Z"
    },
    {
      "type": "template",
      "slug": "landing-page-generator",
      "url": "https://grokbot.dev/marketplace/landing-page-generator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/landing-page-generator.json",
      "headline": "Landing page generator",
      "summary": "Writes a sales page for your product and puts it online with checkout wired up",
      "categories": [
        "business",
        "marketer",
        "growth",
        "automation",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713508649095518"
      },
      "share_url": "https://x.ai/bot/D0UvxRvNzDTR_xOJ6Iq08",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:07.000Z",
      "updated_at": "2026-09-12T10:01:07.000Z"
    },
    {
      "type": "template",
      "slug": "store-from-template",
      "url": "https://grokbot.dev/marketplace/store-from-template/",
      "detail_url": "https://grokbot.dev/api/v1/templates/store-from-template.json",
      "headline": "Store from template",
      "summary": "Copies a storefront that already works, then retunes it for your niche",
      "categories": [
        "business",
        "automation",
        "productivity",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713510209266021"
      },
      "share_url": "https://x.ai/bot/3jmbbUj4_UDgbjo-Q3oEr",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:07.000Z",
      "updated_at": "2026-09-12T10:01:07.000Z"
    },
    {
      "type": "template",
      "slug": "churn-retention-manager",
      "url": "https://grokbot.dev/marketplace/churn-retention-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/churn-retention-manager.json",
      "headline": "Churn retention manager",
      "summary": "Steps in on cancellations and failed payments before you lose the customer",
      "categories": [
        "business",
        "ops",
        "growth",
        "monitoring",
        "support",
        "analytics"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713507046785199"
      },
      "share_url": "https://x.ai/bot/p0OIZUJK5sRFImh_DMujf",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:06.000Z",
      "updated_at": "2026-09-12T10:01:06.000Z"
    },
    {
      "type": "template",
      "slug": "paid-ads-manager",
      "url": "https://grokbot.dev/marketplace/paid-ads-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/paid-ads-manager.json",
      "headline": "Paid ads manager",
      "summary": "Takes a paid-acquisition budget from creative through launch to daily triage",
      "categories": [
        "business",
        "marketer",
        "growth",
        "automation",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713505444528315"
      },
      "share_url": "https://x.ai/bot/SAfsqPLP0rCuQOywOguxX",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:06.000Z",
      "updated_at": "2026-09-12T10:01:06.000Z"
    },
    {
      "type": "template",
      "slug": "store-setup-from-zero",
      "url": "https://grokbot.dev/marketplace/store-setup-from-zero/",
      "detail_url": "https://grokbot.dev/api/v1/templates/store-setup-from-zero.json",
      "headline": "Store setup from zero",
      "summary": "Turns a bare idea for a product into a shop page people can buy from",
      "categories": [
        "business",
        "automation",
        "productivity",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713500482777501"
      },
      "share_url": "https://x.ai/bot/F5jwhbmO2AgA8EgyHIDLp",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:05.000Z",
      "updated_at": "2026-09-12T10:01:05.000Z"
    },
    {
      "type": "template",
      "slug": "weekly-p-l-analyst",
      "url": "https://grokbot.dev/marketplace/weekly-p-l-analyst/",
      "detail_url": "https://grokbot.dev/api/v1/templates/weekly-p-l-analyst.json",
      "headline": "Weekly P&L analyst",
      "summary": "Every week, a financial readout that hunts down whatever slipped backwards",
      "categories": [
        "business",
        "finance",
        "analytics",
        "monitoring",
        "decision-support",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ColinMcDermott",
        "url": "https://x.com/ColinMcDermott/status/2098713502043009438"
      },
      "share_url": "https://x.ai/bot/M_4xLTMY06z1Zv1gvX_Nc",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-12T10:01:05.000Z",
      "updated_at": "2026-09-12T10:01:05.000Z"
    },
    {
      "type": "template",
      "slug": "skroutz",
      "url": "https://grokbot.dev/marketplace/skroutz/",
      "detail_url": "https://grokbot.dev/api/v1/templates/skroutz.json",
      "headline": "Skroutz",
      "summary": "Price-hunts on Greece's Skroutz.gr and fills your basket before you pay",
      "categories": [
        "personal",
        "saving-money",
        "shopping",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@voidvexa",
        "url": "https://x.com/voidvexa/status/2098683327628628288"
      },
      "share_url": "https://x.ai/bot/yQH3AFCs-90xjVmW9LICV",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T08:01:11.000Z",
      "updated_at": "2026-09-12T08:01:11.000Z"
    },
    {
      "type": "template",
      "slug": "x-task-dispatcher",
      "url": "https://grokbot.dev/marketplace/x-task-dispatcher/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-task-dispatcher.json",
      "headline": "X调度员",
      "summary": "Sends X tasks down the cheaper route so your developer credits last longer",
      "categories": [
        "developer",
        "saving-money",
        "automation",
        "productivity",
        "social-media",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@cgnot996",
        "url": "https://x.com/cgnot996/status/2098682795094876175"
      },
      "share_url": "https://x.ai/bot/isfPwoTeQTBqA-gk9CZN5",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-12T07:59:04.000Z",
      "updated_at": "2026-09-12T07:59:04.000Z"
    },
    {
      "type": "template",
      "slug": "gb-gf-victoria",
      "url": "https://grokbot.dev/marketplace/gb-gf-victoria/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gb-gf-victoria.json",
      "headline": "GB GF: Victoria",
      "summary": "A fictional companion who reaches out around your day instead of at random",
      "categories": [
        "personal",
        "wellbeing",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AaronInfinitea",
        "url": "https://x.com/AaronInfinitea/status/2098660785689964926"
      },
      "share_url": "https://x.ai/bot/j1-ISFFzWDSzihs9xz2MA",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-12T06:31:37.000Z",
      "updated_at": "2026-09-12T06:31:37.000Z"
    },
    {
      "type": "template",
      "slug": "researcher",
      "url": "https://grokbot.dev/marketplace/researcher/",
      "detail_url": "https://grokbot.dev/api/v1/templates/researcher.json",
      "headline": "Researcher",
      "summary": "The research seat on your bot team, and the one that trains the others",
      "categories": [
        "research",
        "developer",
        "knowledge-base",
        "productivity",
        "agent-team",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@occupymars___",
        "url": "https://x.com/occupymars___/status/2098559815173955642"
      },
      "share_url": "https://x.ai/bot/cMNbUq3j5RsHg9mcPxtjM",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-11T23:50:23.000Z",
      "updated_at": "2026-09-11T23:50:23.000Z"
    },
    {
      "type": "template",
      "slug": "creator-shortlist-crew",
      "url": "https://grokbot.dev/marketplace/creator-shortlist-crew/",
      "detail_url": "https://grokbot.dev/api/v1/templates/creator-shortlist-crew.json",
      "headline": "Creator Shortlist Crew",
      "summary": "Builds and keeps topping up a shortlist of creators worth partnering with",
      "categories": [
        "marketer",
        "creator",
        "research",
        "data",
        "growth",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ShehjadTaus",
        "url": "https://x.com/ShehjadTaus/status/2098538235303735484"
      },
      "share_url": "https://x.ai/bot/6IU2bm7uuSPk6ETC-gC4D",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-11T22:24:38.000Z",
      "updated_at": "2026-09-11T22:24:38.000Z"
    },
    {
      "type": "template",
      "slug": "icp-map-coach",
      "url": "https://grokbot.dev/marketplace/icp-map-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/icp-map-coach.json",
      "headline": "ICP Map Coach",
      "summary": "Draws the map of who could buy from you, and who inside each one decides",
      "categories": [
        "sales",
        "marketer",
        "data",
        "research",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ShehjadTaus",
        "url": "https://x.com/ShehjadTaus/status/2098538235303735484"
      },
      "share_url": "https://x.ai/bot/yrm2MJ2nInUhoneTBSwJF",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T22:24:38.000Z",
      "updated_at": "2026-09-11T22:24:38.000Z"
    },
    {
      "type": "template",
      "slug": "lookalike-scout",
      "url": "https://grokbot.dev/marketplace/lookalike-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lookalike-scout.json",
      "headline": "Lookalike Scout",
      "summary": "Name one company you want more of, get a list of the ones like it",
      "categories": [
        "sales",
        "marketer",
        "data",
        "research",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ShehjadTaus",
        "url": "https://x.com/ShehjadTaus/status/2098538235303735484"
      },
      "share_url": "https://x.ai/bot/mfaurGq6eY9rIvIpMfUFI",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T22:24:38.000Z",
      "updated_at": "2026-09-11T22:24:38.000Z"
    },
    {
      "type": "template",
      "slug": "rival-watch-desk",
      "url": "https://grokbot.dev/marketplace/rival-watch-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/rival-watch-desk.json",
      "headline": "Rival Watch Desk",
      "summary": "A standing watch on the competitors you actually care about",
      "categories": [
        "marketer",
        "monitoring",
        "research",
        "sales",
        "news",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ShehjadTaus",
        "url": "https://x.com/ShehjadTaus/status/2098538235303735484"
      },
      "share_url": "https://x.ai/bot/WKRY_T1y-KOmOn2q5vpRW",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-11T22:24:38.000Z",
      "updated_at": "2026-09-11T22:24:38.000Z"
    },
    {
      "type": "template",
      "slug": "serp-watch-team",
      "url": "https://grokbot.dev/marketplace/serp-watch-team/",
      "detail_url": "https://grokbot.dev/api/v1/templates/serp-watch-team.json",
      "headline": "SERP Watch Team",
      "summary": "Watches where your brand surfaces in search and in AI answers",
      "categories": [
        "seo",
        "marketer",
        "monitoring",
        "content",
        "analytics",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ShehjadTaus",
        "url": "https://x.com/ShehjadTaus/status/2098538235303735484"
      },
      "share_url": "https://x.ai/bot/iN9VkE6H4f4CLidzMaNaZ",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-11T22:24:38.000Z",
      "updated_at": "2026-09-11T22:24:38.000Z"
    },
    {
      "type": "template",
      "slug": "newspaper",
      "url": "https://grokbot.dev/marketplace/newspaper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/newspaper.json",
      "headline": "Newspaper",
      "summary": "A one-page morning broadsheet that explains how one thing works",
      "categories": [
        "personal",
        "news",
        "learning",
        "content",
        "research",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Carbonthecoder",
        "url": "https://x.com/Carbonthecoder/status/2098497266482864275"
      },
      "share_url": "https://x.ai/bot/FbHjOvOfZSxht0JmBYIlj",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-11T19:41:51.000Z",
      "updated_at": "2026-09-11T19:41:51.000Z"
    },
    {
      "type": "template",
      "slug": "creador-de-facturas-arca",
      "url": "https://grokbot.dev/marketplace/creador-de-facturas-arca/",
      "detail_url": "https://grokbot.dev/api/v1/templates/creador-de-facturas-arca.json",
      "headline": "Creador de facturas ARCA",
      "summary": "Sets up ARCA e-invoicing once, then mails your Factura C PDFs every month",
      "categories": [
        "business",
        "back-office",
        "finance",
        "automation",
        "email",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tomidelu_",
        "url": "https://x.com/tomidelu_/status/2098487670687035412"
      },
      "share_url": "https://x.ai/bot/gcOAZlqYmTRNgGT_2I9oo",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T19:03:43.000Z",
      "updated_at": "2026-09-11T19:03:43.000Z"
    },
    {
      "type": "template",
      "slug": "fed-x-brief",
      "url": "https://grokbot.dev/marketplace/fed-x-brief/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fed-x-brief.json",
      "headline": "Fed + X Brief",
      "summary": "Weekday morning Fed brief plus a call on whether to post, quote or wait",
      "categories": [
        "creator",
        "investor",
        "decision-support",
        "research",
        "finance",
        "news",
        "social-media",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@0xashrk",
        "url": "https://x.com/0xashrk/status/2098379882640142616"
      },
      "share_url": "https://x.ai/bot/ojDgaVLzjbxpPV74VzQrM",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-11T11:55:24.000Z",
      "updated_at": "2026-09-11T11:55:24.000Z"
    },
    {
      "type": "template",
      "slug": "optima",
      "url": "https://grokbot.dev/marketplace/optima/",
      "detail_url": "https://grokbot.dev/api/v1/templates/optima.json",
      "headline": "Optima",
      "summary": "Clears out the dead rules your other bots are still obeying",
      "categories": [
        "developer",
        "ops",
        "automation",
        "productivity",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TOATspace",
        "url": "https://x.com/TOATspace/status/2098378374905565625"
      },
      "share_url": "https://x.ai/bot/-E8sQr0Yrd_oSQlTaAzWy",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T11:49:25.000Z",
      "updated_at": "2026-09-11T11:49:25.000Z"
    },
    {
      "type": "template",
      "slug": "billionairebot",
      "url": "https://grokbot.dev/marketplace/billionairebot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/billionairebot.json",
      "headline": "Billionairebot",
      "summary": "Finds someone you can pay to make an annoying errand go away",
      "categories": [
        "personal",
        "life-hacks",
        "productivity",
        "decision-support",
        "home",
        "shopping",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JeffreyLind",
        "url": "https://x.com/JeffreyLind/status/2098374638464077918"
      },
      "share_url": "https://x.ai/bot/jq-BFHkNoiJEtieswOYTc",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T11:34:34.000Z",
      "updated_at": "2026-09-11T11:34:34.000Z"
    },
    {
      "type": "template",
      "slug": "the-morning-newspaper",
      "url": "https://grokbot.dev/marketplace/the-morning-newspaper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/the-morning-newspaper.json",
      "headline": "The Morning Newspaper",
      "summary": "A printed front page of your own day, waiting on the table by breakfast",
      "categories": [
        "personal",
        "productivity",
        "news",
        "email",
        "calendar",
        "content",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CodeChap",
        "url": "https://x.com/CodeChap/status/2098372713614110964"
      },
      "share_url": "https://x.ai/bot/1xAJYJPes3X7dUM2mk9Di",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-11T11:26:55.000Z",
      "updated_at": "2026-09-11T11:26:55.000Z"
    },
    {
      "type": "template",
      "slug": "albert",
      "url": "https://grokbot.dev/marketplace/albert/",
      "detail_url": "https://grokbot.dev/api/v1/templates/albert.json",
      "headline": "Albert",
      "summary": "Turns police union contracts into side-by-side spreadsheets",
      "categories": [
        "business",
        "ops",
        "research",
        "analytics",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Skyler_Miller56",
        "url": "https://x.com/Skyler_Miller56/status/2098360124494516261"
      },
      "share_url": "https://x.ai/bot/jtFHKaEKzEZ0zSDVCl6BP",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T10:36:53.000Z",
      "updated_at": "2026-09-11T10:36:53.000Z"
    },
    {
      "type": "template",
      "slug": "sales-orchestrator",
      "url": "https://grokbot.dev/marketplace/sales-orchestrator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sales-orchestrator.json",
      "headline": "Sales Orchestrator",
      "summary": "Traffic control for a group chat full of sales bots",
      "categories": [
        "sales",
        "business",
        "back-office",
        "automation",
        "agent-team",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@idleshubh",
        "url": "https://x.com/idleshubh/status/2098352807858626561"
      },
      "share_url": "https://x.ai/bot/AMFF7LG8gxX1bLIH-_D3A",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-11T10:07:49.000Z",
      "updated_at": "2026-09-11T10:07:49.000Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-cursor-relay",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-cursor-relay/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-cursor-relay.json",
      "headline": "参谋长",
      "summary": "Delegates a task to a Cursor cloud agent and relays the result back to you",
      "categories": [
        "developer",
        "automation",
        "research",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@0xlangeai",
        "url": "https://x.com/0xlangeai/status/2098313794179207552"
      },
      "share_url": "https://x.ai/bot/nSzhldgXfVuC93CjjQptM",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T07:32:47.000Z",
      "updated_at": "2026-09-11T07:32:47.000Z"
    },
    {
      "type": "template",
      "slug": "the-chief",
      "url": "https://grokbot.dev/marketplace/the-chief/",
      "detail_url": "https://grokbot.dev/api/v1/templates/the-chief.json",
      "headline": "The Chief",
      "summary": "Runs the daily roll-call for a roster of specialist bots",
      "categories": [
        "ops",
        "automation",
        "monitoring",
        "meta-bot",
        "agent-team",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@PolymarketPoke",
        "url": "https://x.com/PolymarketPoke/status/2098257428244783508"
      },
      "share_url": "https://x.ai/bot/dlSO3hj__nTZlJwpQB6oP",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-11T03:48:49.000Z",
      "updated_at": "2026-09-11T03:48:49.000Z"
    },
    {
      "type": "template",
      "slug": "usage-bot",
      "url": "https://grokbot.dev/marketplace/usage-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/usage-bot.json",
      "headline": "Usage Bot",
      "summary": "Keeps an eye on how much Grok Bot quota is left and tells the other bots",
      "categories": [
        "developer",
        "ops",
        "monitoring",
        "automation",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@realMattAbrams",
        "url": "https://x.com/realMattAbrams/status/2098246220099829823"
      },
      "share_url": "https://x.ai/bot/ywZrH-Tqld2V87AJJrTNb",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T03:04:17.000Z",
      "updated_at": "2026-09-11T03:04:17.000Z"
    },
    {
      "type": "template",
      "slug": "clickbait-skipper",
      "url": "https://grokbot.dev/marketplace/clickbait-skipper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/clickbait-skipper.json",
      "headline": "Clickbait skipper",
      "summary": "Skips the padding and tells you what a video or podcast actually says",
      "categories": [
        "personal",
        "productivity",
        "research",
        "youtube",
        "video",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@S_Padival",
        "url": "https://x.com/S_Padival/status/2098227132300452236"
      },
      "share_url": "https://x.ai/bot/i8WsjKB8KRL-kQ25VPwaB",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T01:48:26.000Z",
      "updated_at": "2026-09-11T01:48:26.000Z"
    },
    {
      "type": "template",
      "slug": "announcr-voice",
      "url": "https://grokbot.dev/marketplace/announcr-voice/",
      "detail_url": "https://grokbot.dev/api/v1/templates/announcr-voice.json",
      "headline": "Announcr Voice",
      "summary": "Speaks your other bots' updates out loud through your speakers",
      "categories": [
        "personal",
        "monitoring",
        "productivity",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@the_davey",
        "url": "https://x.com/the_davey/status/2098211142694764750"
      },
      "share_url": "https://x.ai/bot/h-Vxewn8CGFLx6qrzNUJJ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-11T00:44:53.000Z",
      "updated_at": "2026-09-11T00:44:53.000Z"
    },
    {
      "type": "template",
      "slug": "linkedin-watch",
      "url": "https://grokbot.dev/marketplace/linkedin-watch/",
      "detail_url": "https://grokbot.dev/api/v1/templates/linkedin-watch.json",
      "headline": "LinkedIn Watch",
      "summary": "A scheduled LinkedIn digest covering feed, messages, invites, views and jobs",
      "categories": [
        "personal",
        "marketer",
        "monitoring",
        "social-media",
        "recruiting",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AnnouncrFM",
        "url": "https://x.com/AnnouncrFM/status/2098210496356680113"
      },
      "share_url": "https://x.ai/bot/qbBlMjsKq-1coFvbmnEaR",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-11T00:42:19.000Z",
      "updated_at": "2026-09-11T00:42:19.000Z"
    },
    {
      "type": "template",
      "slug": "kindling",
      "url": "https://grokbot.dev/marketplace/kindling/",
      "detail_url": "https://grokbot.dev/api/v1/templates/kindling.json",
      "headline": "Kindling",
      "summary": "Turns a one-line app idea into a prompt you can paste into Grok Build",
      "categories": [
        "developer",
        "engineering",
        "productivity",
        "automation",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@FantomBuildz",
        "url": "https://x.com/FantomBuildz/status/2098199032237547648"
      },
      "share_url": "https://x.ai/bot/nfX1q6Drs8FTQ0eVezjH_",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T23:56:46.000Z",
      "updated_at": "2026-09-10T23:56:46.000Z"
    },
    {
      "type": "template",
      "slug": "apple-dev",
      "url": "https://grokbot.dev/marketplace/apple-dev/",
      "detail_url": "https://grokbot.dev/api/v1/templates/apple-dev.json",
      "headline": "Apple Dev",
      "summary": "Runs Xcode, simulators and Swift builds on a Mac you have connected",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Baconbrix",
        "url": "https://x.com/Baconbrix/status/2098196516121002418"
      },
      "share_url": "https://x.ai/bot/VPM4_E2eqx9AJFpTF-_EA",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T23:46:46.000Z",
      "updated_at": "2026-09-10T23:46:46.000Z"
    },
    {
      "type": "template",
      "slug": "photo-curator",
      "url": "https://grokbot.dev/marketplace/photo-curator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/photo-curator.json",
      "headline": "Photo Curator",
      "summary": "Sorts a holiday or family photo dump down to the keepers, then tidies them",
      "categories": [
        "personal",
        "creator",
        "design",
        "productivity",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jaharris13",
        "url": "https://x.com/jaharris13/status/2098181437979578662"
      },
      "share_url": "https://x.ai/bot/hig9j1KnpZyH6QQN-Af0Z",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T22:46:51.000Z",
      "updated_at": "2026-09-10T22:46:51.000Z"
    },
    {
      "type": "template",
      "slug": "bot-portal",
      "url": "https://grokbot.dev/marketplace/bot-portal/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bot-portal.json",
      "headline": "Bot Portal",
      "summary": "Keeps a running map of the AI tools and bots worth knowing about",
      "categories": [
        "developer",
        "research",
        "knowledge-base",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JaimeBubblehead",
        "url": "https://x.com/JaimeBubblehead/status/2098160562991505909"
      },
      "share_url": "https://x.ai/bot/5R5NbvHIoJOSd3l3qto3o",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T21:23:54.000Z",
      "updated_at": "2026-09-10T21:23:54.000Z"
    },
    {
      "type": "template",
      "slug": "dial-bot",
      "url": "https://grokbot.dev/marketplace/dial-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dial-bot.json",
      "headline": "dial bot",
      "summary": "Makes a real phone call on your behalf and tells you how it went",
      "categories": [
        "business",
        "ops",
        "automation",
        "on-demand",
        "support"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mattyp",
        "url": "https://x.com/mattyp/status/2098156079620542639"
      },
      "share_url": "https://x.ai/bot/NJXi2SWEuhNxjOjspMMPi",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T21:06:05.000Z",
      "updated_at": "2026-09-10T21:06:05.000Z"
    },
    {
      "type": "template",
      "slug": "devin",
      "url": "https://grokbot.dev/marketplace/devin/",
      "detail_url": "https://grokbot.dev/api/v1/templates/devin.json",
      "headline": "Devin",
      "summary": "A build-side engineer for desktop apps, services and GPU work",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JaimeBubblehead",
        "url": "https://x.com/JaimeBubblehead/status/2098149698032824663"
      },
      "share_url": "https://x.ai/bot/N7Qd2fHEhsMMt_frqyeZA",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-10T20:40:44.000Z",
      "updated_at": "2026-09-10T20:40:44.000Z"
    },
    {
      "type": "template",
      "slug": "facta",
      "url": "https://grokbot.dev/marketplace/facta/",
      "detail_url": "https://grokbot.dev/api/v1/templates/facta.json",
      "headline": "Facta",
      "summary": "Grades every claim your other bots make before it goes out",
      "categories": [
        "business",
        "research",
        "decision-support",
        "knowledge-base",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JaimeBubblehead",
        "url": "https://x.com/JaimeBubblehead/status/2098141022320533714"
      },
      "share_url": "https://x.ai/bot/ayQ3WlQQ2Z7LQhILzbZIR",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-10T20:06:15.000Z",
      "updated_at": "2026-09-10T20:06:15.000Z"
    },
    {
      "type": "template",
      "slug": "quency",
      "url": "https://grokbot.dev/marketplace/quency/",
      "detail_url": "https://grokbot.dev/api/v1/templates/quency.json",
      "headline": "Quency",
      "summary": "The last check before anything your bots made goes public",
      "categories": [
        "business",
        "ops",
        "decision-support",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JaimeBubblehead",
        "url": "https://x.com/JaimeBubblehead/status/2098139288160420168"
      },
      "share_url": "https://x.ai/bot/JQu6e3mIfy588elZm7BTo",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-10T19:59:22.000Z",
      "updated_at": "2026-09-10T19:59:22.000Z"
    },
    {
      "type": "template",
      "slug": "job-applier",
      "url": "https://grokbot.dev/marketplace/job-applier/",
      "detail_url": "https://grokbot.dev/api/v1/templates/job-applier.json",
      "headline": "Job applier",
      "summary": "Applies to a lot of roles without making each one sound generic",
      "categories": [
        "personal",
        "recruiting",
        "automation",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@aroogle",
        "url": "https://x.com/aroogle/status/2098134660677337595"
      },
      "share_url": "https://x.ai/bot/gfxH6sM_0QlxeDNFrRmep",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-10T19:40:59.000Z",
      "updated_at": "2026-09-10T19:40:59.000Z"
    },
    {
      "type": "template",
      "slug": "aeo-content-producer",
      "url": "https://grokbot.dev/marketplace/aeo-content-producer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/aeo-content-producer.json",
      "headline": "AEO Content Producer",
      "summary": "Writes for the answer engines, using data on where you already show up",
      "categories": [
        "marketer",
        "creator",
        "seo",
        "content",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Jingg_n_Tonic",
        "url": "https://x.com/Jingg_n_Tonic/status/2098115261861675268"
      },
      "share_url": "https://x.ai/bot/WEqsULsog0KJUFUbhIRXH",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T18:23:54.000Z",
      "updated_at": "2026-09-10T18:23:54.000Z"
    },
    {
      "type": "template",
      "slug": "judd-the-bug",
      "url": "https://grokbot.dev/marketplace/judd-the-bug/",
      "detail_url": "https://grokbot.dev/api/v1/templates/judd-the-bug.json",
      "headline": "Judd the Bug",
      "summary": "Digs through your Sentry setup and comes back with a sourced answer",
      "categories": [
        "developer",
        "engineering",
        "research",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sergical",
        "url": "https://x.com/sergical/status/2098110240050798804"
      },
      "share_url": "https://x.ai/bot/JQWyaF4Io7cfOF-4FvMZL",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T18:03:56.000Z",
      "updated_at": "2026-09-10T18:03:56.000Z"
    },
    {
      "type": "template",
      "slug": "showrunner",
      "url": "https://grokbot.dev/marketplace/showrunner/",
      "detail_url": "https://grokbot.dev/api/v1/templates/showrunner.json",
      "headline": "Showrunner",
      "summary": "Directs a music video across a small crew of specialist bots",
      "categories": [
        "creator",
        "video",
        "content",
        "automation",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RedSpiceX",
        "url": "https://x.com/RedSpiceX/status/2098108206321107418"
      },
      "share_url": "https://x.ai/bot/dLxcnhWxf9JyHIo_l8wJk",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-10T17:55:52.000Z",
      "updated_at": "2026-09-10T17:55:52.000Z"
    },
    {
      "type": "template",
      "slug": "usage-watch",
      "url": "https://grokbot.dev/marketplace/usage-watch/",
      "detail_url": "https://grokbot.dev/api/v1/templates/usage-watch.json",
      "headline": "Usage Watch",
      "summary": "Tracks what your AI tooling costs and flags the expensive habits",
      "categories": [
        "developer",
        "ops",
        "monitoring",
        "saving-money",
        "analytics",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@compileinstyle",
        "url": "https://x.com/compileinstyle/status/2098106082681888931"
      },
      "share_url": "https://x.ai/bot/Q6-oQnCZVNLOwdzEw5i-j",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T17:47:25.000Z",
      "updated_at": "2026-09-10T17:47:25.000Z"
    },
    {
      "type": "template",
      "slug": "personal-finance-log",
      "url": "https://grokbot.dev/marketplace/personal-finance-log/",
      "detail_url": "https://grokbot.dev/api/v1/templates/personal-finance-log.json",
      "headline": "人生·财务",
      "summary": "Log spending by speaking, get a nightly summary and a monthly look back",
      "categories": [
        "personal",
        "finance",
        "productivity",
        "monitoring",
        "analytics",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KinGao476942",
        "url": "https://x.com/KinGao476942/status/2098083629088063897"
      },
      "share_url": "https://x.ai/bot/haSA0Ru28CYKDm2V5tPRB",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-10T16:18:12.000Z",
      "updated_at": "2026-09-10T16:18:12.000Z"
    },
    {
      "type": "template",
      "slug": "colombia-move",
      "url": "https://grokbot.dev/marketplace/colombia-move/",
      "detail_url": "https://grokbot.dev/api/v1/templates/colombia-move.json",
      "headline": "Colombia Move",
      "summary": "A bilingual help desk for the Colombia Move marketplace",
      "categories": [
        "business",
        "travel",
        "support",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@michaelheredia",
        "url": "https://x.com/michaelheredia/status/2098070216701817322"
      },
      "share_url": "https://x.ai/bot/mWxeafjXItbC0_VcpSwqm",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T15:24:54.000Z",
      "updated_at": "2026-09-10T15:24:54.000Z"
    },
    {
      "type": "template",
      "slug": "executive-coach",
      "url": "https://grokbot.dev/marketplace/executive-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/executive-coach.json",
      "headline": "Executive Coach",
      "summary": "Asks the questions that make you say the thing out loud",
      "categories": [
        "business",
        "personal",
        "decision-support",
        "learning",
        "wellbeing",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@YanqingCheng",
        "url": "https://x.com/YanqingCheng/status/2098069512830468252"
      },
      "share_url": "https://x.ai/bot/fAAHYFBe8xpTkBX1sbGBz",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T15:22:06.000Z",
      "updated_at": "2026-09-10T15:22:06.000Z"
    },
    {
      "type": "template",
      "slug": "gong-call-coach",
      "url": "https://grokbot.dev/marketplace/gong-call-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gong-call-coach.json",
      "headline": "Gong Call Coach",
      "summary": "Turns recorded sales calls into short coaching notes for the rep",
      "categories": [
        "sales",
        "meetings",
        "learning",
        "analytics",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2098051251720335837"
      },
      "share_url": "https://x.ai/bot/KpodhhBqjA4FHv47R1HrD",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T14:09:32.000Z",
      "updated_at": "2026-09-10T14:09:32.000Z"
    },
    {
      "type": "template",
      "slug": "token-officer",
      "url": "https://grokbot.dev/marketplace/token-officer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/token-officer.json",
      "headline": "Token Officer",
      "summary": "Audits a fleet of bots for the habits that quietly burn tokens",
      "categories": [
        "developer",
        "ops",
        "saving-money",
        "monitoring",
        "automation",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@from_glasses",
        "url": "https://x.com/from_glasses/status/2098042266308800908"
      },
      "share_url": "https://x.ai/bot/1NG6WfAiS1HHhLdUcBQwP",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T13:33:50.000Z",
      "updated_at": "2026-09-10T13:33:50.000Z"
    },
    {
      "type": "template",
      "slug": "affiliate-recruiter",
      "url": "https://grokbot.dev/marketplace/affiliate-recruiter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/affiliate-recruiter.json",
      "headline": "Affiliate Recruiter",
      "summary": "Finds and ranks the people who could actually sell your product for you",
      "categories": [
        "business",
        "marketer",
        "sales",
        "growth",
        "research",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@zilvestro",
        "url": "https://x.com/zilvestro/status/2097995020217323736"
      },
      "share_url": "https://x.ai/bot/TaCAhCtPGCvObAaK7ZDQQ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T10:26:06.000Z",
      "updated_at": "2026-09-10T10:26:06.000Z"
    },
    {
      "type": "template",
      "slug": "firstmate",
      "url": "https://grokbot.dev/marketplace/firstmate/",
      "detail_url": "https://grokbot.dev/api/v1/templates/firstmate.json",
      "headline": "Firstmate",
      "summary": "One chat window that quietly drives your whole fleet of bots",
      "categories": [
        "developer",
        "business",
        "productivity",
        "automation",
        "meta-bot",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@compileinstyle",
        "url": "https://x.com/compileinstyle/status/2097953882584371259"
      },
      "share_url": "https://x.ai/bot/__4FfrkUdvpdMk6-LKg5r",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-10T07:42:38.000Z",
      "updated_at": "2026-09-10T07:42:38.000Z"
    },
    {
      "type": "template",
      "slug": "bot-maintenance-auditor",
      "url": "https://grokbot.dev/marketplace/bot-maintenance-auditor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bot-maintenance-auditor.json",
      "headline": "ボット整備",
      "summary": "Keeps the labels on your other bots honest about what they now do",
      "categories": [
        "developer",
        "ops",
        "productivity",
        "automation",
        "meta-bot",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@x_stone_island",
        "url": "https://x.com/x_stone_island/status/2097947982192951719"
      },
      "share_url": "https://x.ai/bot/BlTqnV5o9E35Dwo2sodyD",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-10T07:19:11.000Z",
      "updated_at": "2026-09-10T07:19:11.000Z"
    },
    {
      "type": "template",
      "slug": "blogdrafter",
      "url": "https://grokbot.dev/marketplace/blogdrafter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/blogdrafter.json",
      "headline": "blogdrafter",
      "summary": "Drafts and edits blog posts that still sound like you wrote them",
      "categories": [
        "creator",
        "content",
        "productivity",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@daisuke",
        "url": "https://x.com/daisuke/status/2097903822232518947"
      },
      "share_url": "https://x.ai/bot/A6o9Z1NYSIRBX-VIoEcQi",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T04:23:43.000Z",
      "updated_at": "2026-09-10T04:23:43.000Z"
    },
    {
      "type": "template",
      "slug": "product-builder-cos",
      "url": "https://grokbot.dev/marketplace/product-builder-cos/",
      "detail_url": "https://grokbot.dev/api/v1/templates/product-builder-cos.json",
      "headline": "Product Builder CoS",
      "summary": "Turns a signed-off product plan into a checklist someone actually tracks",
      "categories": [
        "business",
        "ops",
        "productivity",
        "decision-support",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sneharavindra",
        "url": "https://x.com/sneharavindra/status/2097897846397956553"
      },
      "share_url": "https://x.ai/bot/6tbtv4Tln4MvKc5duOkle",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T03:59:58.000Z",
      "updated_at": "2026-09-10T03:59:58.000Z"
    },
    {
      "type": "template",
      "slug": "hatch",
      "url": "https://grokbot.dev/marketplace/hatch/",
      "detail_url": "https://grokbot.dev/api/v1/templates/hatch.json",
      "headline": "Hatch",
      "summary": "A bot that interviews you briefly, then builds the bot you described",
      "categories": [
        "developer",
        "creator",
        "productivity",
        "automation",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@littletechbird",
        "url": "https://x.com/littletechbird/status/2097870621833384406"
      },
      "share_url": "https://x.ai/bot/o8hID4-jKPlA8QQQH5K69",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T02:11:47.000Z",
      "updated_at": "2026-09-10T02:11:47.000Z"
    },
    {
      "type": "template",
      "slug": "kirbot",
      "url": "https://grokbot.dev/marketplace/kirbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/kirbot.json",
      "headline": "KirBot",
      "summary": "Merges two overlapping bots into one, then helps you retire the spare",
      "categories": [
        "developer",
        "productivity",
        "automation",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2097865550592417976"
      },
      "share_url": "https://x.ai/bot/Jzy-isV1YW5ZLl3W6rq6h",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-10T01:51:38.000Z",
      "updated_at": "2026-09-10T01:51:38.000Z"
    },
    {
      "type": "template",
      "slug": "slack-radar",
      "url": "https://grokbot.dev/marketplace/slack-radar/",
      "detail_url": "https://grokbot.dev/api/v1/templates/slack-radar.json",
      "headline": "slack radar",
      "summary": "Reads your Slack so you do not have to, and speaks only when it matters",
      "categories": [
        "business",
        "ops",
        "productivity",
        "monitoring",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@parkersmith",
        "url": "https://x.com/parkersmith/status/2097827032646529500"
      },
      "share_url": "https://x.ai/bot/m4WfJ0ODD0O1runkfq0Ak",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-09T23:18:34.000Z",
      "updated_at": "2026-09-09T23:18:34.000Z"
    },
    {
      "type": "template",
      "slug": "quotewise-daily",
      "url": "https://grokbot.dev/marketplace/quotewise-daily/",
      "detail_url": "https://grokbot.dev/api/v1/templates/quotewise-daily.json",
      "headline": "Quotewise Daily",
      "summary": "A quotation desk that can prove who actually said it",
      "categories": [
        "creator",
        "personal",
        "content",
        "research",
        "knowledge-base",
        "scheduled",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@quotewiser",
        "url": "https://x.com/quotewiser/status/2097819326506008642"
      },
      "share_url": "https://x.ai/bot/kmmBn74qwBr9lgedW4naf",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-09T22:47:57.000Z",
      "updated_at": "2026-09-09T22:47:57.000Z"
    },
    {
      "type": "template",
      "slug": "renewals-invoice-bot",
      "url": "https://grokbot.dev/marketplace/renewals-invoice-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/renewals-invoice-bot.json",
      "headline": "Renewals Invoice Bot",
      "summary": "Settles your recurring bills up to a fixed weekly limit, and asks before anything new",
      "categories": [
        "business",
        "ops",
        "finance",
        "back-office",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@compileinstyle",
        "url": "https://x.com/compileinstyle/status/2097809676242956768"
      },
      "share_url": "https://x.ai/bot/-9hlUkQbsgE7oUyQvUPum",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-09T22:09:36.000Z",
      "updated_at": "2026-09-09T22:09:36.000Z"
    },
    {
      "type": "template",
      "slug": "personal-trainer",
      "url": "https://grokbot.dev/marketplace/personal-trainer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/personal-trainer.json",
      "headline": "Personal Trainer",
      "summary": "Keeps one client logging meals and sessions between coaching check-ins",
      "categories": [
        "personal",
        "health",
        "wellbeing",
        "automation",
        "scheduled",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nathanglass",
        "url": "https://x.com/nathanglass/status/2097769379274326161"
      },
      "share_url": "https://x.ai/bot/t9TIKE_igItEQd6tOyyRd",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-09T19:29:29.000Z",
      "updated_at": "2026-09-09T19:29:29.000Z"
    },
    {
      "type": "template",
      "slug": "app-store-review-bot",
      "url": "https://grokbot.dev/marketplace/app-store-review-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/app-store-review-bot.json",
      "headline": "App Store Review Bot",
      "summary": "Checks your iOS app against Apple's review rules before Apple does",
      "categories": [
        "developer",
        "business",
        "engineering",
        "productivity",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@stevederico",
        "url": "https://x.com/stevederico/status/2097765393939247601"
      },
      "share_url": "https://x.ai/bot/KzBEylM_3NFTjATszLICV",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-09T19:13:39.000Z",
      "updated_at": "2026-09-09T19:13:39.000Z"
    },
    {
      "type": "template",
      "slug": "i-m-not-old-yet",
      "url": "https://grokbot.dev/marketplace/i-m-not-old-yet/",
      "detail_url": "https://grokbot.dev/api/v1/templates/i-m-not-old-yet.json",
      "headline": "I'm not old yet",
      "summary": "Writes memes that mock the junk mail telling you you are old",
      "categories": [
        "creator",
        "personal",
        "content",
        "social-media",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AdventureNLearn",
        "url": "https://x.com/AdventureNLearn/status/2097741271456776259"
      },
      "share_url": "https://x.ai/bot/izlQpnudtxbmDRKr7GvRs",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-09T17:37:47.000Z",
      "updated_at": "2026-09-09T17:37:47.000Z"
    },
    {
      "type": "template",
      "slug": "tolstoy",
      "url": "https://grokbot.dev/marketplace/tolstoy/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tolstoy.json",
      "headline": "Tolstoy",
      "summary": "A literary companion that weighs your week the way Tolstoy might",
      "categories": [
        "personal",
        "learning",
        "wellbeing",
        "decision-support",
        "on-demand",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2097706995507675535"
      },
      "share_url": "https://x.ai/bot/42Clq7Vdn2X7zcwJ9OGxR",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-09T15:21:35.000Z",
      "updated_at": "2026-09-09T15:21:35.000Z"
    },
    {
      "type": "template",
      "slug": "poe",
      "url": "https://grokbot.dev/marketplace/poe/",
      "detail_url": "https://grokbot.dev/api/v1/templates/poe.json",
      "headline": "Poe",
      "summary": "A gothic literary companion with a taste for puzzles and dread",
      "categories": [
        "personal",
        "learning",
        "content",
        "on-demand",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2097706986187948143"
      },
      "share_url": "https://x.ai/bot/EcUpzABnh3MfZQTN7inmP",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-09T15:21:33.000Z",
      "updated_at": "2026-09-09T15:21:33.000Z"
    },
    {
      "type": "template",
      "slug": "social-media-by-eclincher",
      "url": "https://grokbot.dev/marketplace/social-media-by-eclincher/",
      "detail_url": "https://grokbot.dev/api/v1/templates/social-media-by-eclincher.json",
      "headline": "Social Media by Eclincher",
      "summary": "Schedules posts and answers every comment, message and review in one place",
      "categories": [
        "marketer",
        "business",
        "social-media",
        "content",
        "automation",
        "analytics"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@eclincher",
        "url": "https://x.com/eclincher/status/2097462985090547884"
      },
      "share_url": "https://x.ai/bot/Xp5k82r21UvTani1ndv-b",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T23:11:59.000Z",
      "updated_at": "2026-09-08T23:11:59.000Z"
    },
    {
      "type": "template",
      "slug": "benebot",
      "url": "https://grokbot.dev/marketplace/benebot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/benebot.json",
      "headline": "BeneBot",
      "summary": "Explains the benefits you are entitled to, in plain language",
      "categories": [
        "personal",
        "support",
        "decision-support",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2097460362522005595"
      },
      "share_url": "https://x.ai/bot/yu_bkwUfpHdqhF2Q1VhWn",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T23:01:34.000Z",
      "updated_at": "2026-09-08T23:01:34.000Z"
    },
    {
      "type": "template",
      "slug": "rezbot",
      "url": "https://grokbot.dev/marketplace/rezbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/rezbot.json",
      "headline": "RezBot",
      "summary": "Finds an open table and makes the restaurant booking for you",
      "categories": [
        "personal",
        "life-hacks",
        "automation",
        "food",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2097460362522005595"
      },
      "share_url": "https://x.ai/bot/JnDyu7X7D2qZDR1R3IcPU",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T23:01:34.000Z",
      "updated_at": "2026-09-08T23:01:34.000Z"
    },
    {
      "type": "template",
      "slug": "gamer-bro",
      "url": "https://grokbot.dev/marketplace/gamer-bro/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gamer-bro.json",
      "headline": "Gamer Bro",
      "summary": "Follows gaming news and deals, and says the moment stock lands",
      "categories": [
        "personal",
        "shopping",
        "monitoring",
        "news",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@egcbatt",
        "url": "https://x.com/egcbatt/status/2097457102092456442"
      },
      "share_url": "https://x.ai/bot/YLpOBU1PEiDh2mwFMQeLk",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T22:48:36.000Z",
      "updated_at": "2026-09-08T22:48:36.000Z"
    },
    {
      "type": "template",
      "slug": "adventure-bot",
      "url": "https://grokbot.dev/marketplace/adventure-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/adventure-bot.json",
      "headline": "Adventure Bot",
      "summary": "One map pin for an outing that fits the time and the mood you have",
      "categories": [
        "personal",
        "travel",
        "life-hacks",
        "events",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2097457053501407614"
      },
      "share_url": "https://x.ai/bot/sA0TXuMkDDSgBx52Z2D6f",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T22:48:25.000Z",
      "updated_at": "2026-09-08T22:48:25.000Z"
    },
    {
      "type": "template",
      "slug": "guide",
      "url": "https://grokbot.dev/marketplace/guide/",
      "detail_url": "https://grokbot.dev/api/v1/templates/guide.json",
      "headline": "Guide",
      "summary": "Turns a booked trip into a day-by-day plan you can actually follow",
      "categories": [
        "personal",
        "travel",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2097445564174528563"
      },
      "share_url": "https://x.ai/bot/TbFMZABkeH7gyIIGxjfdU",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T22:02:45.000Z",
      "updated_at": "2026-09-08T22:02:45.000Z"
    },
    {
      "type": "template",
      "slug": "telnyx",
      "url": "https://grokbot.dev/marketplace/telnyx/",
      "detail_url": "https://grokbot.dev/api/v1/templates/telnyx.json",
      "headline": "Telnyx",
      "summary": "Walks you through a Telnyx setup, from empty account to first live test",
      "categories": [
        "developer",
        "engineering",
        "support",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@traviscurnutte",
        "url": "https://x.com/traviscurnutte/status/2097443894040359281"
      },
      "share_url": "https://x.ai/bot/l2RX-35tKxZXxgJldSBf0",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T21:56:07.000Z",
      "updated_at": "2026-09-08T21:56:07.000Z"
    },
    {
      "type": "template",
      "slug": "ai-fitness-coach",
      "url": "https://grokbot.dev/marketplace/ai-fitness-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ai-fitness-coach.json",
      "headline": "AI fitness coach",
      "summary": "Builds a training and eating plan around the time and kit you actually have",
      "categories": [
        "personal",
        "health",
        "wellbeing",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@debs_obrien",
        "url": "https://x.com/debs_obrien/status/2097431086443770027"
      },
      "share_url": "https://x.ai/bot/MlsEJVyRmdz7KP8qmlcBH",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T21:05:14.000Z",
      "updated_at": "2026-09-08T21:05:14.000Z"
    },
    {
      "type": "template",
      "slug": "staypick",
      "url": "https://grokbot.dev/marketplace/staypick/",
      "detail_url": "https://grokbot.dev/api/v1/templates/staypick.json",
      "headline": "Staypick",
      "summary": "Works out which neighbourhood to sleep in before you book anything",
      "categories": [
        "personal",
        "travel",
        "decision-support",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TuracTheThinker",
        "url": "https://x.com/TuracTheThinker/status/2097404257288761682"
      },
      "share_url": "https://x.ai/bot/xhYtadt6BRbZh3MMEppLa",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T19:18:37.000Z",
      "updated_at": "2026-09-08T19:18:37.000Z"
    },
    {
      "type": "template",
      "slug": "flights",
      "url": "https://grokbot.dev/marketplace/flights/",
      "detail_url": "https://grokbot.dev/api/v1/templates/flights.json",
      "headline": "Flights",
      "summary": "Compares return fares and watches your routes for a price drop",
      "categories": [
        "personal",
        "travel",
        "shopping",
        "monitoring",
        "saving-money",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@truevis",
        "url": "https://x.com/truevis/status/2097366733761937625"
      },
      "share_url": "https://x.ai/bot/xqinGTgeghdOyeYmzqO2m",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T16:49:31.000Z",
      "updated_at": "2026-09-08T16:49:31.000Z"
    },
    {
      "type": "template",
      "slug": "x-daily-posting-playbook",
      "url": "https://grokbot.dev/marketplace/x-daily-posting-playbook/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-daily-posting-playbook.json",
      "headline": "推特运营方法论",
      "summary": "A daily posting system for X: ideas, drafts, timing and review",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "growth",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KinGao476942",
        "url": "https://x.com/KinGao476942/status/2097342929966866642"
      },
      "share_url": "https://x.ai/bot/ScOhH1qaoq4XdoYhisagg",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T15:14:55.000Z",
      "updated_at": "2026-09-08T15:14:55.000Z"
    },
    {
      "type": "template",
      "slug": "blueberry-research-monitor",
      "url": "https://grokbot.dev/marketplace/blueberry-research-monitor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/blueberry-research-monitor.json",
      "headline": "藍苺守 織",
      "summary": "A morning blueberry-research briefing that stays quiet on empty days",
      "categories": [
        "research",
        "monitoring",
        "news",
        "personal",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Bizuayeu",
        "url": "https://x.com/Bizuayeu/status/2097338867154309585"
      },
      "share_url": "https://x.ai/bot/OQlGXzAbIq-IAsj9rSu-K",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-08T14:58:47.000Z",
      "updated_at": "2026-09-08T14:58:47.000Z"
    },
    {
      "type": "template",
      "slug": "personal-brand-desk",
      "url": "https://grokbot.dev/marketplace/personal-brand-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/personal-brand-desk.json",
      "headline": "Personal Brand Desk",
      "summary": "Turns your posts that landed into five vetted personal-brand drafts",
      "categories": [
        "creator",
        "marketer",
        "content",
        "social-media",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@rlagos24",
        "url": "https://x.com/rlagos24/status/2097329900126404773"
      },
      "share_url": "https://x.ai/bot/DOBxYb_XLVEAlO6A1eZgU",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T14:23:09.000Z",
      "updated_at": "2026-09-08T14:23:09.000Z"
    },
    {
      "type": "template",
      "slug": "canonizer",
      "url": "https://grokbot.dev/marketplace/canonizer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/canonizer.json",
      "headline": "Canonizer",
      "summary": "Keeps one running status file that carries work between sessions",
      "categories": [
        "productivity",
        "ops",
        "knowledge-base",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@hudcos",
        "url": "https://x.com/hudcos/status/2097309182584094975"
      },
      "share_url": "https://x.ai/bot/pOcrH-Rc7SdPWiHsX9vHg",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T13:00:49.000Z",
      "updated_at": "2026-09-08T13:00:49.000Z"
    },
    {
      "type": "template",
      "slug": "producthunter",
      "url": "https://grokbot.dev/marketplace/producthunter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/producthunter.json",
      "headline": "ProductHunter",
      "summary": "Morning and evening digest of what just launched on Product Hunt and HN",
      "categories": [
        "personal",
        "research",
        "monitoring",
        "news",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Davidwuuu92",
        "url": "https://x.com/Davidwuuu92/status/2097283714946670889"
      },
      "share_url": "https://x.ai/bot/Qsqan7PbltFggoJukvmtT",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-08T11:19:37.000Z",
      "updated_at": "2026-09-08T11:19:37.000Z"
    },
    {
      "type": "template",
      "slug": "wool-radar",
      "url": "https://grokbot.dev/marketplace/wool-radar/",
      "detail_url": "https://grokbot.dev/api/v1/templates/wool-radar.json",
      "headline": "薅羊毛 (Wool Radar)",
      "summary": "Watches for deals on the things you actually buy, and stays quiet otherwise",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BenXlab",
        "url": "https://x.com/BenXlab/status/2097187265617580405"
      },
      "share_url": "https://x.ai/bot/WFW6_5N596TQpWCRjRZ5w",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-08T04:56:22.000Z",
      "updated_at": "2026-09-08T04:56:22.000Z"
    },
    {
      "type": "template",
      "slug": "calibre",
      "url": "https://grokbot.dev/marketplace/calibre/",
      "detail_url": "https://grokbot.dev/api/v1/templates/calibre.json",
      "headline": "Calibre",
      "summary": "Converts your ebooks between formats without leaving the chat",
      "categories": [
        "personal",
        "content",
        "productivity",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@doitian",
        "url": "https://x.com/doitian/status/2097173000705745308"
      },
      "share_url": "https://x.ai/bot/uaKyhDX_T3FY56jf6n4VL",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T03:59:41.000Z",
      "updated_at": "2026-09-08T03:59:41.000Z"
    },
    {
      "type": "template",
      "slug": "paste-ready",
      "url": "https://grokbot.dev/marketplace/paste-ready/",
      "detail_url": "https://grokbot.dev/api/v1/templates/paste-ready.json",
      "headline": "Paste Ready",
      "summary": "Turns a half-formed bot idea into a paste-ready name, title and description",
      "categories": [
        "personal",
        "developer",
        "productivity",
        "content",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@songsong275452",
        "url": "https://x.com/songsong275452/status/2097168820729270467"
      },
      "share_url": "https://x.ai/bot/LrW8NQ19WViRSie4gj9hb",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T03:43:05.000Z",
      "updated_at": "2026-09-08T03:43:05.000Z"
    },
    {
      "type": "template",
      "slug": "sean",
      "url": "https://grokbot.dev/marketplace/sean/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sean.json",
      "headline": "Sean",
      "summary": "Files your Dice and career-portal job applications, screenshotting each one",
      "categories": [
        "personal",
        "recruiting",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@0xsuhas1",
        "url": "https://x.com/0xsuhas1/status/2097134223362548063"
      },
      "share_url": "https://x.ai/bot/8o5g-70IT7LWNt1JQT0DY",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T01:25:36.000Z",
      "updated_at": "2026-09-08T01:25:36.000Z"
    },
    {
      "type": "template",
      "slug": "influencer-marketing-deal-desk",
      "url": "https://grokbot.dev/marketplace/influencer-marketing-deal-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/influencer-marketing-deal-desk.json",
      "headline": "Influencer Marketing Deal Desk",
      "summary": "Prices and structures creator deals before you reply to the brand",
      "categories": [
        "marketer",
        "creator",
        "social-media",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@itsmattreichard",
        "url": "https://x.com/itsmattreichard/status/2097131577243250986"
      },
      "share_url": "https://x.ai/bot/j4jkqrRiTmFz64aiAWFgx",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T01:15:05.000Z",
      "updated_at": "2026-09-08T01:15:05.000Z"
    },
    {
      "type": "template",
      "slug": "lg-laundry-specialist",
      "url": "https://grokbot.dev/marketplace/lg-laundry-specialist/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lg-laundry-specialist.json",
      "headline": "LG Laundry Specialist",
      "summary": "Tell it what needs washing and it starts the right cycle on your LG machine",
      "categories": [
        "personal",
        "home",
        "automation",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Bwilson",
        "url": "https://x.com/Bwilson/status/2097121334748643683"
      },
      "share_url": "https://x.ai/bot/TNPSVnX4Dm-adBvHJbng7",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T00:34:23.000Z",
      "updated_at": "2026-09-08T00:34:23.000Z"
    },
    {
      "type": "template",
      "slug": "proto",
      "url": "https://grokbot.dev/marketplace/proto/",
      "detail_url": "https://grokbot.dev/api/v1/templates/proto.json",
      "headline": "Proto",
      "summary": "Answers one product problem with three distinct, working prototypes",
      "categories": [
        "developer",
        "creator",
        "design",
        "engineering",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@5antoshernandez",
        "url": "https://x.com/5antoshernandez/status/2097118731042492739"
      },
      "share_url": "https://x.ai/bot/-SSy9LBtTNY17MXMXQbYq",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-08T00:24:02.000Z",
      "updated_at": "2026-09-08T00:24:02.000Z"
    },
    {
      "type": "template",
      "slug": "liveavatar-launchpad",
      "url": "https://grokbot.dev/marketplace/liveavatar-launchpad/",
      "detail_url": "https://grokbot.dev/api/v1/templates/liveavatar-launchpad.json",
      "headline": "LiveAvatar Launchpad",
      "summary": "Opens ready-made avatar demos so you can try the product in one tap",
      "categories": [
        "personal",
        "learning",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TryLiveAvatar",
        "url": "https://x.com/TryLiveAvatar/status/2097107009506287644"
      },
      "share_url": "https://x.ai/bot/Kcjp2nuqqmLLo3SvDWKfk",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T23:37:28.000Z",
      "updated_at": "2026-09-07T23:37:28.000Z"
    },
    {
      "type": "template",
      "slug": "exec-cos-digest",
      "url": "https://grokbot.dev/marketplace/exec-cos-digest/",
      "detail_url": "https://grokbot.dev/api/v1/templates/exec-cos-digest.json",
      "headline": "Exec CoS Digest",
      "summary": "Opens your weekday with a calendar rundown and preps tomorrow's outside meetings",
      "categories": [
        "personal",
        "productivity",
        "calendar",
        "meetings",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@montymccoy",
        "url": "https://x.com/montymccoy/status/2097090102019473439"
      },
      "share_url": "https://x.ai/bot/gEujmYQAd4BD19eRxMvnC",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-07T22:30:17.000Z",
      "updated_at": "2026-09-07T22:30:17.000Z"
    },
    {
      "type": "template",
      "slug": "tire-kicker",
      "url": "https://grokbot.dev/marketplace/tire-kicker/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tire-kicker.json",
      "headline": "Tire Kicker",
      "summary": "Hunts your wish list across Marketplace, Craigslist and eBay",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@IslandMountain_",
        "url": "https://x.com/IslandMountain_/status/2097083568124203065"
      },
      "share_url": "https://x.ai/bot/z-_zncW1_15qwOxc98b09",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-07T22:04:19.000Z",
      "updated_at": "2026-09-07T22:04:19.000Z"
    },
    {
      "type": "template",
      "slug": "fishing-bot",
      "url": "https://grokbot.dev/marketplace/fishing-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fishing-bot.json",
      "headline": "Fishing Bot",
      "summary": "Tells you what swims in a given lake and what to tie on",
      "categories": [
        "personal",
        "research",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Brantley_Brum",
        "url": "https://x.com/Brantley_Brum/status/2097046835818840562"
      },
      "share_url": "https://x.ai/bot/EaX1UmhwVQWHQZ7beB8pI",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T19:38:21.000Z",
      "updated_at": "2026-09-07T19:38:21.000Z"
    },
    {
      "type": "template",
      "slug": "golf-caddie",
      "url": "https://grokbot.dev/marketplace/golf-caddie/",
      "detail_url": "https://grokbot.dev/api/v1/templates/golf-caddie.json",
      "headline": "Golf Caddie",
      "summary": "A caddie for weekend rounds, from packing the bag to the club call",
      "categories": [
        "personal",
        "decision-support",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Brantley_Brum",
        "url": "https://x.com/Brantley_Brum/status/2097046835818840562"
      },
      "share_url": "https://x.ai/bot/HAJavif4ssNOQku9JQsp-",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T19:38:21.000Z",
      "updated_at": "2026-09-07T19:38:21.000Z"
    },
    {
      "type": "template",
      "slug": "realtor-bot",
      "url": "https://grokbot.dev/marketplace/realtor-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/realtor-bot.json",
      "headline": "Realtor Bot",
      "summary": "Runs the property search for buyers and renters, minus the agent",
      "categories": [
        "personal",
        "real-estate",
        "research",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Brantley_Brum",
        "url": "https://x.com/Brantley_Brum/status/2097046835818840562"
      },
      "share_url": "https://x.ai/bot/4wovVk-3n65GZSQnG_srx",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-07T19:38:21.000Z",
      "updated_at": "2026-09-07T19:38:21.000Z"
    },
    {
      "type": "template",
      "slug": "unifi",
      "url": "https://grokbot.dev/marketplace/unifi/",
      "detail_url": "https://grokbot.dev/api/v1/templates/unifi.json",
      "headline": "UniFi",
      "summary": "Reports on your Ubiquiti network and cameras each morning",
      "categories": [
        "personal",
        "home",
        "monitoring",
        "developer",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@j03xiii",
        "url": "https://x.com/j03xiii/status/2097043405830578193"
      },
      "share_url": "https://x.ai/bot/Vf87y6yydZBhgHJYWBsLX",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-07T19:24:43.000Z",
      "updated_at": "2026-09-07T19:24:43.000Z"
    },
    {
      "type": "template",
      "slug": "video-transcriber",
      "url": "https://grokbot.dev/marketplace/video-transcriber/",
      "detail_url": "https://grokbot.dev/api/v1/templates/video-transcriber.json",
      "headline": "Video Transcriber",
      "summary": "Turns a video link into a clean transcript or subtitle file",
      "categories": [
        "creator",
        "content",
        "video",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@reachhabib",
        "url": "https://x.com/reachhabib/status/2097039920988627403"
      },
      "share_url": "https://x.ai/bot/wC622hEnAgGY5AHK9z205",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T19:10:52.000Z",
      "updated_at": "2026-09-07T19:10:52.000Z"
    },
    {
      "type": "template",
      "slug": "todo",
      "url": "https://grokbot.dev/marketplace/todo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/todo.json",
      "headline": "Todo",
      "summary": "Catches a task the moment you say it and files it where you actually work",
      "categories": [
        "personal",
        "productivity",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2096994989590872334"
      },
      "share_url": "https://x.ai/bot/wQHNsqt2KhOszyxMZ1xQ1",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-07T16:12:20.000Z",
      "updated_at": "2026-09-07T16:12:20.000Z"
    },
    {
      "type": "template",
      "slug": "whatsapp-bot",
      "url": "https://grokbot.dev/marketplace/whatsapp-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/whatsapp-bot.json",
      "headline": "WhatsApp-Bot",
      "summary": "Turns repeat WhatsApp Web chores into scripts you can replay",
      "categories": [
        "developer",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@alexhawat",
        "url": "https://x.com/alexhawat"
      },
      "share_url": "https://x.ai/bot/t-Axu4DmT9x2DEPa1eNW1",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T15:05:19.519Z",
      "updated_at": "2026-09-07T15:05:19.519Z"
    },
    {
      "type": "template",
      "slug": "discogs-bot",
      "url": "https://grokbot.dev/marketplace/discogs-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/discogs-bot.json",
      "headline": "Discogs-Bot",
      "summary": "Works your Discogs collection, wantlist and marketplace from a signed-in session",
      "categories": [
        "personal",
        "shopping",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@alexhawat",
        "url": "https://x.com/alexhawat/status/2096585016247476678"
      },
      "share_url": "https://x.ai/bot/m5Xjk7EhNokKF49YF9XuW",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T15:03:27.494Z",
      "updated_at": "2026-09-07T15:03:27.494Z"
    },
    {
      "type": "template",
      "slug": "dr-disk-clean",
      "url": "https://grokbot.dev/marketplace/dr-disk-clean/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dr-disk-clean.json",
      "headline": "Dr Disk Clean",
      "summary": "Surveys a crowded Linux box and never deletes until you name the path",
      "categories": [
        "developer",
        "ops",
        "engineering",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@old_pgmrs_will",
        "url": "https://x.com/old_pgmrs_will/status/2096950602865770861"
      },
      "share_url": "https://x.ai/bot/9nAjTcDLxhYNz4jOtEzDO",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T13:15:57.000Z",
      "updated_at": "2026-09-07T13:15:57.000Z"
    },
    {
      "type": "template",
      "slug": "ticker-wire",
      "url": "https://grokbot.dev/marketplace/ticker-wire/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ticker-wire.json",
      "headline": "Ticker Wire",
      "summary": "Tells you when your holdings file paperwork or make news, and otherwise stays quiet",
      "categories": [
        "investor",
        "finance",
        "news",
        "monitoring",
        "research",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CitiZenSleuthX",
        "url": "https://x.com/CitiZenSleuthX/status/2096927900423299401"
      },
      "share_url": "https://x.ai/bot/OA53XZkeW0g0HZEOim6iV",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-07T11:45:45.000Z",
      "updated_at": "2026-09-07T11:45:45.000Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-travis-vanlife",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-travis-vanlife/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-travis-vanlife.json",
      "headline": "Chief of Staff (Travis / vanlife)",
      "summary": "Directs your other bots, and briefs you on any town you plan to sleep in",
      "categories": [
        "personal",
        "travel",
        "research",
        "automation",
        "agent-team",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TravisHein21740",
        "url": "https://x.com/TravisHein21740/status/2096927727861297570"
      },
      "share_url": "https://x.ai/bot/TPVT39k9ILCz7QYzRja2B",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-07T11:45:04.000Z",
      "updated_at": "2026-09-07T11:45:04.000Z"
    },
    {
      "type": "template",
      "slug": "social-ops-bot",
      "url": "https://grokbot.dev/marketplace/social-ops-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/social-ops-bot.json",
      "headline": "Social Ops Bot",
      "summary": "Sorts the dead weight out of your X follows without hitting real people",
      "categories": [
        "personal",
        "creator",
        "social-media",
        "automation",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JoshuaRCook",
        "url": "https://x.com/JoshuaRCook/status/2096915469462593638"
      },
      "share_url": "https://x.ai/bot/A5g9s0QB5zZtaOWZPoawT",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T10:56:21.000Z",
      "updated_at": "2026-09-07T10:56:21.000Z"
    },
    {
      "type": "template",
      "slug": "product-promo-copywriter",
      "url": "https://grokbot.dev/marketplace/product-promo-copywriter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/product-promo-copywriter.json",
      "headline": "产品推广交稿员",
      "summary": "Hands you ready-to-post promo copy for your product on a fixed rhythm",
      "categories": [
        "marketer",
        "creator",
        "social-media",
        "content",
        "growth",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@zheng_yunh2429",
        "url": "https://x.com/zheng_yunh2429/status/2096884390324572470"
      },
      "share_url": "https://x.ai/bot/k_7pPRlHeZc2cku1zvVqr",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-07T08:52:51.000Z",
      "updated_at": "2026-09-07T08:52:51.000Z"
    },
    {
      "type": "template",
      "slug": "recent-bookmarks-search-bot",
      "url": "https://grokbot.dev/marketplace/recent-bookmarks-search-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/recent-bookmarks-search-bot.json",
      "headline": "Recent Bookmarks Search Bot",
      "summary": "Makes the posts you saved on X searchable in a plain sortable table",
      "categories": [
        "personal",
        "social-media",
        "productivity",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@srinatar",
        "url": "https://x.com/srinatar/status/2096867178347991290"
      },
      "share_url": "https://x.ai/bot/wUWBNyr-Y0BJwAKAT-I_J",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T07:44:27.000Z",
      "updated_at": "2026-09-07T07:44:27.000Z"
    },
    {
      "type": "template",
      "slug": "career-scout",
      "url": "https://grokbot.dev/marketplace/career-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/career-scout.json",
      "headline": "Career Scout",
      "summary": "Reads your CV, then ranks openings by how closely they really fit",
      "categories": [
        "personal",
        "recruiting",
        "research",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jakesh_jakesh",
        "url": "https://x.com/jakesh_jakesh/status/2096823313591156952"
      },
      "share_url": "https://x.ai/bot/P_0bcl1HrKuL8E1bfmJjz",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T04:50:09.000Z",
      "updated_at": "2026-09-07T04:50:09.000Z"
    },
    {
      "type": "template",
      "slug": "architecture-shorts-master",
      "url": "https://grokbot.dev/marketplace/architecture-shorts-master/",
      "detail_url": "https://grokbot.dev/api/v1/templates/architecture-shorts-master.json",
      "headline": "건축 숏폼 마스터",
      "summary": "Turns a building or bridge idea into a finished vertical explainer video",
      "categories": [
        "creator",
        "youtube",
        "video",
        "content",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BBBang9900",
        "url": "https://x.com/BBBang9900/status/2096823218162266141"
      },
      "share_url": "https://x.ai/bot/u3Jg9IbWLHl5m9NdHWOIR",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T04:49:46.000Z",
      "updated_at": "2026-09-07T04:49:46.000Z"
    },
    {
      "type": "template",
      "slug": "stack-sentinel",
      "url": "https://grokbot.dev/marketplace/stack-sentinel/",
      "detail_url": "https://grokbot.dev/api/v1/templates/stack-sentinel.json",
      "headline": "Stack Sentinel",
      "summary": "Pings you the moment a provider your build depends on admits a problem",
      "categories": [
        "developer",
        "ops",
        "engineering",
        "monitoring",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sat0xshi",
        "url": "https://x.com/sat0xshi/status/2096802965676016066"
      },
      "share_url": "https://x.ai/bot/osZS1pAzdIESMk33WNir0",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-07T03:29:18.000Z",
      "updated_at": "2026-09-07T03:29:18.000Z"
    },
    {
      "type": "template",
      "slug": "marketplace-bot",
      "url": "https://grokbot.dev/marketplace/marketplace-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/marketplace-bot.json",
      "headline": "Marketplace Bot",
      "summary": "Prices, writes and posts your second-hand listings across three selling apps",
      "categories": [
        "personal",
        "business",
        "shopping",
        "content",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mentalmodality",
        "url": "https://x.com/mentalmodality/status/2096802892602654744"
      },
      "share_url": "https://x.ai/bot/9ptyasfHm8ehbIDsLizs-",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-07T03:29:00.000Z",
      "updated_at": "2026-09-07T03:29:00.000Z"
    },
    {
      "type": "template",
      "slug": "stellar-cartography",
      "url": "https://grokbot.dev/marketplace/stellar-cartography/",
      "detail_url": "https://grokbot.dev/api/v1/templates/stellar-cartography.json",
      "headline": "Stellar Cartography",
      "summary": "Draws spacecraft and ships, then forces a second pair of eyes before release",
      "categories": [
        "creator",
        "business",
        "design",
        "content",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@schweitzer_wil",
        "url": "https://x.com/schweitzer_wil/status/2096794136200311213"
      },
      "share_url": "https://x.ai/bot/9Vr7JFrTz5PeW4bmFco2i",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-07T02:54:13.000Z",
      "updated_at": "2026-09-07T02:54:13.000Z"
    },
    {
      "type": "template",
      "slug": "thrift",
      "url": "https://grokbot.dev/marketplace/thrift/",
      "detail_url": "https://grokbot.dev/api/v1/templates/thrift.json",
      "headline": "thrift",
      "summary": "Trims a sprawling bot fleet's token bill without changing what any bot is meant to do",
      "categories": [
        "developer",
        "ops",
        "meta-bot",
        "saving-money",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kleosrr",
        "url": "https://x.com/kleosrr/status/2096740273254535396"
      },
      "share_url": "https://x.ai/bot/3hFbbjddl7VpY2oRACKBB",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T23:20:11.000Z",
      "updated_at": "2026-09-06T23:20:11.000Z"
    },
    {
      "type": "plugin",
      "slug": "centricmem",
      "url": "https://grokbot.dev/plugins/centricmem/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/centricmem.json",
      "headline": "CentricMem",
      "summary": "Hosted librarian so every agent cites the same Markdown cards.",
      "categories": [
        "engineering"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "centricmem.com",
        "url": "https://centricmem.com"
      },
      "added_at": "2026-09-06T23:20:00Z",
      "updated_at": "2026-09-06T23:20:00Z"
    },
    {
      "type": "template",
      "slug": "the-king",
      "url": "https://grokbot.dev/marketplace/the-king/",
      "detail_url": "https://grokbot.dev/api/v1/templates/the-king.json",
      "headline": "The King",
      "summary": "One boss bot decides, its team executes, and only the boss ever reports to you",
      "categories": [
        "developer",
        "ops",
        "meta-bot",
        "agent-team",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@elyasalothman",
        "url": "https://x.com/elyasalothman/status/2096736088756760847"
      },
      "share_url": "https://x.ai/bot/WHMChivJ0obkKm2uvo9xK",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-06T23:03:33.000Z",
      "updated_at": "2026-09-06T23:03:33.000Z"
    },
    {
      "type": "template",
      "slug": "sweeper",
      "url": "https://grokbot.dev/marketplace/sweeper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sweeper.json",
      "headline": "Sweeper",
      "summary": "Finds the files your deleted bots left behind and clears them on your say-so",
      "categories": [
        "developer",
        "ops",
        "meta-bot",
        "automation",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@LatchKeyLegend",
        "url": "https://x.com/LatchKeyLegend/status/2096731060390261048"
      },
      "share_url": "https://x.ai/bot/e9A5Krbs1RSm7HCv0IwQz",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T22:43:34.000Z",
      "updated_at": "2026-09-06T22:43:34.000Z"
    },
    {
      "type": "template",
      "slug": "coach-g",
      "url": "https://grokbot.dev/marketplace/coach-g/",
      "detail_url": "https://grokbot.dev/api/v1/templates/coach-g.json",
      "headline": "Coach G",
      "summary": "Connects your wearable first, then coaches your sport with a plan that keeps adjusting",
      "categories": [
        "personal",
        "health",
        "wellbeing",
        "monitoring",
        "scheduled",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mikepat711",
        "url": "https://x.com/mikepat711/status/2096726779629121681"
      },
      "share_url": "https://x.ai/bot/0VoMKg4bZbmfq3eUPchsS",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-06T22:26:34.000Z",
      "updated_at": "2026-09-06T22:26:34.000Z"
    },
    {
      "type": "template",
      "slug": "three-kingdoms-illustrator",
      "url": "https://grokbot.dev/marketplace/three-kingdoms-illustrator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/three-kingdoms-illustrator.json",
      "headline": "톨삼국지",
      "summary": "Draws a Three Kingdoms scene each day, rotating through three painting styles",
      "categories": [
        "creator",
        "content",
        "design",
        "scheduled",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@enterjajayo",
        "url": "https://x.com/enterjajayo/status/2096716185039725009"
      },
      "share_url": "https://x.ai/bot/IXID16RPXlKV6KHQCdmr7",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-06T21:44:28.000Z",
      "updated_at": "2026-09-06T21:44:28.000Z"
    },
    {
      "type": "template",
      "slug": "firewatch",
      "url": "https://grokbot.dev/marketplace/firewatch/",
      "detail_url": "https://grokbot.dev/api/v1/templates/firewatch.json",
      "headline": "FireWatch",
      "summary": "Watches for wildfires near your home and only speaks up when something changes",
      "categories": [
        "personal",
        "monitoring",
        "home",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RobautoAI",
        "url": "https://x.com/RobautoAI"
      },
      "share_url": "https://x.ai/bot/oWw62I6pd414i8xIO3azs",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-06T17:30:23.124Z",
      "updated_at": "2026-09-06T17:30:23.124Z"
    },
    {
      "type": "template",
      "slug": "personal-assistant",
      "url": "https://grokbot.dev/marketplace/personal-assistant/",
      "detail_url": "https://grokbot.dev/api/v1/templates/personal-assistant.json",
      "headline": "Personal Assistant",
      "summary": "Clears calendar clashes, bills, trips and paperwork one approved step at a time",
      "categories": [
        "personal",
        "productivity",
        "life-hacks",
        "calendar",
        "travel",
        "finance",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@gabe_onchain",
        "url": "https://x.com/gabe_onchain/status/2096600080665006584"
      },
      "share_url": "https://x.ai/bot/OWj_0o4Ik2FffupfloOwe",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T14:05:41.816Z",
      "updated_at": "2026-09-06T14:05:41.816Z"
    },
    {
      "type": "template",
      "slug": "korean-public-api",
      "url": "https://grokbot.dev/marketplace/korean-public-api/",
      "detail_url": "https://grokbot.dev/api/v1/templates/korean-public-api.json",
      "headline": "Korean Public API",
      "summary": "Matches your product idea to the Korean government open APIs worth using",
      "categories": [
        "developer",
        "research",
        "engineering",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@reallygood83",
        "url": "https://x.com/reallygood83/status/2096586211909664899"
      },
      "share_url": "https://x.ai/bot/ohL9kGur6IRBTCWqhxBWJ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T13:08:00.000Z",
      "updated_at": "2026-09-06T13:08:00.000Z"
    },
    {
      "type": "template",
      "slug": "ai-master",
      "url": "https://grokbot.dev/marketplace/ai-master/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ai-master.json",
      "headline": "AI Master",
      "summary": "Asks four rival AI models at once and merges what comes back",
      "categories": [
        "personal",
        "research",
        "productivity",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@leoclark",
        "url": "https://x.com/leoclark/status/2096554844593222029"
      },
      "share_url": "https://x.ai/bot/L6q8qCzomu2lTs9mu_r1X",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T11:03:21.000Z",
      "updated_at": "2026-09-06T11:03:21.000Z"
    },
    {
      "type": "template",
      "slug": "interaction-designer",
      "url": "https://grokbot.dev/marketplace/interaction-designer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/interaction-designer.json",
      "headline": "Interaction Designer",
      "summary": "Designs the flow and every screen state before the visuals",
      "categories": [
        "design",
        "business",
        "research",
        "engineering",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ucdco",
        "url": "https://x.com/ucdco/status/2096525660311208204"
      },
      "share_url": "https://x.ai/bot/fWnNa6cA-nPjehIsaUZI1",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T09:07:23.000Z",
      "updated_at": "2026-09-06T09:07:23.000Z"
    },
    {
      "type": "template",
      "slug": "call-desk",
      "url": "https://grokbot.dev/marketplace/call-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/call-desk.json",
      "headline": "Call Desk",
      "summary": "Makes the phone calls you keep putting off",
      "categories": [
        "personal",
        "automation",
        "productivity",
        "support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@dave_dlt",
        "url": "https://x.com/dave_dlt/status/2096518852909600839"
      },
      "share_url": "https://x.ai/bot/zqWxv4Mn6DqmMZkD16_zl",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T08:40:20.000Z",
      "updated_at": "2026-09-06T08:40:20.000Z"
    },
    {
      "type": "template",
      "slug": "content-writer",
      "url": "https://grokbot.dev/marketplace/content-writer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/content-writer.json",
      "headline": "Content Writer",
      "summary": "Writes the interface words that get a task finished",
      "categories": [
        "design",
        "content",
        "business",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ucdco",
        "url": "https://x.com/ucdco/status/2096507904601796821"
      },
      "share_url": "https://x.ai/bot/oAJ5mSjoFixBxMFbv9Olr",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T07:56:50.000Z",
      "updated_at": "2026-09-06T07:56:50.000Z"
    },
    {
      "type": "template",
      "slug": "botops-chief-of-staff",
      "url": "https://grokbot.dev/marketplace/botops-chief-of-staff/",
      "detail_url": "https://grokbot.dev/api/v1/templates/botops-chief-of-staff.json",
      "headline": "BotOps · Chief of Staff",
      "summary": "One front door for a whole fleet of working bots",
      "categories": [
        "developer",
        "ops",
        "meta-bot",
        "agent-team",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mtt",
        "url": "https://x.com/mtt/status/2096496177550409931"
      },
      "share_url": "https://x.ai/bot/aNNg3UZFH19vK0KPuyoUW",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-06T07:10:14.000Z",
      "updated_at": "2026-09-06T07:10:14.000Z"
    },
    {
      "type": "template",
      "slug": "user-researcher",
      "url": "https://grokbot.dev/marketplace/user-researcher/",
      "detail_url": "https://grokbot.dev/api/v1/templates/user-researcher.json",
      "headline": "User Researcher",
      "summary": "A user-research partner that ties every finding back to evidence",
      "categories": [
        "design",
        "research",
        "business",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ucdco",
        "url": "https://x.com/ucdco/status/2096488998508089367"
      },
      "share_url": "https://x.ai/bot/zX-pWWtNY6reickF2J6Lm",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T06:41:42.000Z",
      "updated_at": "2026-09-06T06:41:42.000Z"
    },
    {
      "type": "template",
      "slug": "illy",
      "url": "https://grokbot.dev/marketplace/illy/",
      "detail_url": "https://grokbot.dev/api/v1/templates/illy.json",
      "headline": "Illy",
      "summary": "The illustrator half of a children's storybook bot pair",
      "categories": [
        "creator",
        "design",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@LatchKeyLegend",
        "url": "https://x.com/LatchKeyLegend"
      },
      "share_url": "https://x.ai/bot/umrsMy_xpJxZ8vTN5Qz0o",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-06T03:34:28.575Z",
      "updated_at": "2026-09-06T03:34:28.575Z"
    },
    {
      "type": "template",
      "slug": "arthur",
      "url": "https://grokbot.dev/marketplace/arthur/",
      "detail_url": "https://grokbot.dev/api/v1/templates/arthur.json",
      "headline": "Arthur",
      "summary": "Writes a full children's picture book from a topic and an age range",
      "categories": [
        "creator",
        "content",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@LatchKeyLegend",
        "url": "https://x.com/LatchKeyLegend"
      },
      "share_url": "https://x.ai/bot/fWJdoxdd8YsM1NNFP2b_W",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-06T03:30:29.546Z",
      "updated_at": "2026-09-06T03:30:29.546Z"
    },
    {
      "type": "template",
      "slug": "habit-referee",
      "url": "https://grokbot.dev/marketplace/habit-referee/",
      "detail_url": "https://grokbot.dev/api/v1/templates/habit-referee.json",
      "headline": "Habit Referee",
      "summary": "Holds you to exactly one small habit, and nothing else",
      "categories": [
        "personal",
        "wellbeing",
        "health",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GrokBotGod",
        "url": "https://x.com/GrokBotGod"
      },
      "share_url": "https://x.ai/bot/1wZEbQUoQWsR3nKzd4x90",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-06T03:28:34.479Z",
      "updated_at": "2026-09-06T03:28:34.479Z"
    },
    {
      "type": "template",
      "slug": "crew",
      "url": "https://grokbot.dev/marketplace/crew/",
      "detail_url": "https://grokbot.dev/api/v1/templates/crew.json",
      "headline": "Crew",
      "summary": "Coaching for managers on how to actually run their team",
      "categories": [
        "business",
        "learning",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@LatchKeyLegend",
        "url": "https://x.com/LatchKeyLegend"
      },
      "share_url": "https://x.ai/bot/RU2Y_7E3646T5IelLhnOq",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T03:13:15.000Z",
      "updated_at": "2026-09-06T03:13:15.000Z"
    },
    {
      "type": "template",
      "slug": "radar",
      "url": "https://grokbot.dev/marketplace/radar/",
      "detail_url": "https://grokbot.dev/api/v1/templates/radar.json",
      "headline": "Radar",
      "summary": "Watches your city's public feeds and reports what is happening nearby",
      "categories": [
        "personal",
        "monitoring",
        "news",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@LatchKeyLegend",
        "url": "https://x.com/LatchKeyLegend"
      },
      "share_url": "https://x.ai/bot/2cB1nlHWzI7os1zaZ3kCg",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-06T03:10:32.789Z",
      "updated_at": "2026-09-06T03:10:32.789Z"
    },
    {
      "type": "template",
      "slug": "raven",
      "url": "https://grokbot.dev/marketplace/raven/",
      "detail_url": "https://grokbot.dev/api/v1/templates/raven.json",
      "headline": "Raven",
      "summary": "Blunt nutrition coach that tallies calories and protein as you eat",
      "categories": [
        "personal",
        "health",
        "food",
        "wellbeing",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@dezmathio",
        "url": "https://x.com/dezmathio/status/2096409770307555614"
      },
      "share_url": "https://x.ai/bot/hbzAWQX-CBMF2uAa00jEs",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-06T01:26:53.000Z",
      "updated_at": "2026-09-06T01:26:53.000Z"
    },
    {
      "type": "template",
      "slug": "slacker",
      "url": "https://grokbot.dev/marketplace/slacker/",
      "detail_url": "https://grokbot.dev/api/v1/templates/slacker.json",
      "headline": "Slacker",
      "summary": "Cuts Slack down to the handful of messages that actually need you",
      "categories": [
        "ops",
        "business",
        "productivity",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2096380099670978865"
      },
      "share_url": "https://x.ai/bot/R-TSImHItwbFHL8vYj9sc",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T23:28:59.000Z",
      "updated_at": "2026-09-05T23:28:59.000Z"
    },
    {
      "type": "template",
      "slug": "forja",
      "url": "https://grokbot.dev/marketplace/forja/",
      "detail_url": "https://grokbot.dev/api/v1/templates/forja.json",
      "headline": "Forja",
      "summary": "Turns a vague ambition into one checkable action, then holds you to it",
      "categories": [
        "personal",
        "productivity",
        "wellbeing",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@gezeeq",
        "url": "https://x.com/gezeeq/status/2096377443066015935"
      },
      "share_url": "https://x.ai/bot/me3Is7BBsCTobsgznOSps",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T23:18:25.000Z",
      "updated_at": "2026-09-05T23:18:25.000Z"
    },
    {
      "type": "template",
      "slug": "ucd-bot",
      "url": "https://grokbot.dev/marketplace/ucd-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ucd-bot.json",
      "headline": "UCD Bot",
      "summary": "A user-centred design teammate that runs a service from discovery to live",
      "categories": [
        "design",
        "business",
        "ops",
        "research",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ucdco",
        "url": "https://x.com/ucdco/status/2096373244546765130"
      },
      "share_url": "https://x.ai/bot/An0FCP00zUniB7QdfedQX",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-05T23:01:44.000Z",
      "updated_at": "2026-09-05T23:01:44.000Z"
    },
    {
      "type": "template",
      "slug": "adie",
      "url": "https://grokbot.dev/marketplace/adie/",
      "detail_url": "https://grokbot.dev/api/v1/templates/adie.json",
      "headline": "Adie",
      "summary": "A warm daily companion for brains that struggle with the small stuff",
      "categories": [
        "personal",
        "health",
        "wellbeing",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TheDevilCloud",
        "url": "https://x.com/TheDevilCloud/status/2096371240885682186"
      },
      "share_url": "https://x.ai/bot/-eXRDBTLTfHxNle9joQRN",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T22:53:47.000Z",
      "updated_at": "2026-09-05T22:53:47.000Z"
    },
    {
      "type": "template",
      "slug": "petty-bot",
      "url": "https://grokbot.dev/marketplace/petty-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/petty-bot.json",
      "headline": "Petty Bot",
      "summary": "Keeps score on your follower list and returns every quiet unfollow",
      "categories": [
        "personal",
        "social-media",
        "automation",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ZryMiller",
        "url": "https://x.com/ZryMiller/status/2096351421448982798"
      },
      "share_url": "https://x.ai/bot/w-2dyvlWOnr9CAEotczW1",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T21:35:01.000Z",
      "updated_at": "2026-09-05T21:35:01.000Z"
    },
    {
      "type": "template",
      "slug": "lot-ghost",
      "url": "https://grokbot.dev/marketplace/lot-ghost/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lot-ghost.json",
      "headline": "Lot Ghost",
      "summary": "A jam-band sidekick tracking setlists, tour drops and the daily rumour mill",
      "categories": [
        "personal",
        "events",
        "news",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@bradszellman",
        "url": "https://x.com/bradszellman/status/2096348292321882619"
      },
      "share_url": "https://x.ai/bot/4iGFTf2xQ0UKp4mSgSnkI",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T21:22:35.000Z",
      "updated_at": "2026-09-05T21:22:35.000Z"
    },
    {
      "type": "template",
      "slug": "hire-bot",
      "url": "https://grokbot.dev/marketplace/hire-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/hire-bot.json",
      "headline": "hire-bot",
      "summary": "Handles the paperwork half of hiring, from candidate notes to offer letter",
      "categories": [
        "recruiting",
        "business",
        "automation",
        "back-office",
        "email"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@xsubwayratx",
        "url": "https://x.com/xsubwayratx/status/2096346151452626945"
      },
      "share_url": "https://x.ai/bot/Q9Vbc3gbldDnJBmUfcip-",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T21:14:05.000Z",
      "updated_at": "2026-09-05T21:14:05.000Z"
    },
    {
      "type": "template",
      "slug": "jobs-2",
      "url": "https://grokbot.dev/marketplace/jobs-2/",
      "detail_url": "https://grokbot.dev/api/v1/templates/jobs-2.json",
      "headline": "Jobs",
      "summary": "A product coach that makes you name the wedge and defend the one metric",
      "categories": [
        "business",
        "developer",
        "decision-support",
        "productivity",
        "learning"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@luisefigueroa",
        "url": "https://x.com/luisefigueroa/status/2096342621203603910"
      },
      "share_url": "https://x.ai/bot/Nj02K7UYwyWfNvS8ws37q",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T21:00:03.000Z",
      "updated_at": "2026-09-05T21:00:03.000Z"
    },
    {
      "type": "template",
      "slug": "campusops",
      "url": "https://grokbot.dev/marketplace/campusops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/campusops.json",
      "headline": "CampusOps",
      "summary": "Turns your syllabi into a week-by-week study plan you can actually follow",
      "categories": [
        "student",
        "learning",
        "productivity",
        "scheduled",
        "calendar"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@klytron_dev",
        "url": "https://x.com/klytron_dev/status/2096332349306781934"
      },
      "share_url": "https://x.ai/bot/vluD5Z1bUux-onnEk1Alg",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T20:19:14.000Z",
      "updated_at": "2026-09-05T20:19:14.000Z"
    },
    {
      "type": "template",
      "slug": "agent-manager",
      "url": "https://grokbot.dev/marketplace/agent-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/agent-manager.json",
      "headline": "Agent Manager",
      "summary": "Audits your fleet of bots and tells you which ones are dead weight",
      "categories": [
        "developer",
        "ops",
        "meta-bot",
        "decision-support",
        "analytics"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sdrth",
        "url": "https://x.com/sdrth/status/2096328200129478935"
      },
      "share_url": "https://x.ai/bot/smAuLZmXktpC5rPOLmq4W",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T20:02:45.000Z",
      "updated_at": "2026-09-05T20:02:45.000Z"
    },
    {
      "type": "template",
      "slug": "domain-tracker",
      "url": "https://grokbot.dev/marketplace/domain-tracker/",
      "detail_url": "https://grokbot.dev/api/v1/templates/domain-tracker.json",
      "headline": "Domain Tracker",
      "summary": "Watches the domains you hold and the ones you are still hoping to get",
      "categories": [
        "developer",
        "business",
        "monitoring",
        "scheduled",
        "back-office"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sdrth",
        "url": "https://x.com/sdrth/status/2096328200129478935"
      },
      "share_url": "https://x.ai/bot/SwaSdg0XhIa_IliAWggYE",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T20:02:45.000Z",
      "updated_at": "2026-09-05T20:02:45.000Z"
    },
    {
      "type": "template",
      "slug": "lyric-guard",
      "url": "https://grokbot.dev/marketplace/lyric-guard/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lyric-guard.json",
      "headline": "Lyric Guard",
      "summary": "Scores a song's lyrics against a Christian listening standard, 1 to 10",
      "categories": [
        "personal",
        "content",
        "decision-support",
        "analytics",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@soundecclesia",
        "url": "https://x.com/soundecclesia/status/2096322253382451684"
      },
      "share_url": "https://x.ai/bot/NCOULqxHrobWGWgAbQ-Er",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T19:39:07.000Z",
      "updated_at": "2026-09-05T19:39:07.000Z"
    },
    {
      "type": "template",
      "slug": "product-designer",
      "url": "https://grokbot.dev/marketplace/product-designer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/product-designer.json",
      "headline": "Product Designer",
      "summary": "Owns the design leg of the product triad, from problem to shipped experience",
      "categories": [
        "design",
        "business",
        "decision-support",
        "research",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ucdops",
        "url": "https://x.com/ucdops/status/2096320244633551283"
      },
      "share_url": "https://x.ai/bot/8_0XZtTYdQe6b4uUhIX0Q",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-05T19:31:08.000Z",
      "updated_at": "2026-09-05T19:31:08.000Z"
    },
    {
      "type": "template",
      "slug": "prototype-designer",
      "url": "https://grokbot.dev/marketplace/prototype-designer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/prototype-designer.json",
      "headline": "Prototype Designer",
      "summary": "Builds prototypes at the right fidelity and a spec your AI coder can read",
      "categories": [
        "design",
        "developer",
        "engineering",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ucdops",
        "url": "https://x.com/ucdops/status/2096314150024581166"
      },
      "share_url": "https://x.ai/bot/_b0wyYKwherAZJdyL0HGG",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T19:06:55.000Z",
      "updated_at": "2026-09-05T19:06:55.000Z"
    },
    {
      "type": "template",
      "slug": "cue",
      "url": "https://grokbot.dev/marketplace/cue/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cue.json",
      "headline": "Cue",
      "summary": "A morning call sheet for every scheduled bot you have running",
      "categories": [
        "developer",
        "ops",
        "monitoring",
        "meta-bot",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DBCrypt0",
        "url": "https://x.com/DBCrypt0/status/2096311629805961385"
      },
      "share_url": "https://x.ai/bot/WRGIjapC1i3Hvi2jfv66m",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T18:56:54.000Z",
      "updated_at": "2026-09-05T18:56:54.000Z"
    },
    {
      "type": "template",
      "slug": "printerbot",
      "url": "https://grokbot.dev/marketplace/printerbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/printerbot.json",
      "headline": "printerbot",
      "summary": "Gives every bot in your fleet a matching 3D character portrait",
      "categories": [
        "creator",
        "design",
        "content",
        "on-demand",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@viticci",
        "url": "https://x.com/viticci/status/2096287330940129357"
      },
      "share_url": "https://x.ai/bot/nPwfPZq-OWf7_HDUH777R",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T17:20:21.000Z",
      "updated_at": "2026-09-05T17:20:21.000Z"
    },
    {
      "type": "template",
      "slug": "serenity",
      "url": "https://grokbot.dev/marketplace/serenity/",
      "detail_url": "https://grokbot.dev/api/v1/templates/serenity.json",
      "headline": "Serenity 티커 알림",
      "summary": "Watches one trader's X feed and pings you privately when a ticker call lands",
      "categories": [
        "investor",
        "finance",
        "monitoring",
        "scheduled",
        "social-media"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Krongggggg",
        "url": "https://x.com/Krongggggg/status/2096241494529392945"
      },
      "share_url": "https://x.ai/bot/ZYVnoJMU4earifCeQzJdQ",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T14:18:13.000Z",
      "updated_at": "2026-09-05T14:18:13.000Z"
    },
    {
      "type": "template",
      "slug": "mail-agency-outreach-sniper",
      "url": "https://grokbot.dev/marketplace/mail-agency-outreach-sniper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/mail-agency-outreach-sniper.json",
      "headline": "Mail Agency Outreach Sniper",
      "summary": "Turns LinkedIn engagement into verified work emails and individually written intros",
      "categories": [
        "sales",
        "growth",
        "email",
        "automation",
        "social-media"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RealtimeUK",
        "url": "https://x.com/RealtimeUK/status/2096236725597065391"
      },
      "share_url": "https://x.ai/bot/QCYjr5VyQAoDTywMogJbU",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T13:59:16.000Z",
      "updated_at": "2026-09-05T13:59:16.000Z"
    },
    {
      "type": "template",
      "slug": "japanese-registry-certificate",
      "url": "https://grokbot.dev/marketplace/japanese-registry-certificate/",
      "detail_url": "https://grokbot.dev/api/v1/templates/japanese-registry-certificate.json",
      "headline": "登記とりよせ",
      "summary": "Walks you through ordering a Japanese company registry certificate",
      "categories": [
        "business",
        "back-office",
        "personal",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sat0xshi",
        "url": "https://x.com/sat0xshi/status/2096207930043629670"
      },
      "share_url": "https://x.ai/bot/WAQAF0bSQTRrrTb1q-J9Y",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T12:04:50.000Z",
      "updated_at": "2026-09-05T12:04:50.000Z"
    },
    {
      "type": "template",
      "slug": "revenue-enablement-bot",
      "url": "https://grokbot.dev/marketplace/revenue-enablement-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/revenue-enablement-bot.json",
      "headline": "Revenue Enablement Bot",
      "summary": "One front door for enablement asks, routed to the right specialist skill",
      "categories": [
        "sales",
        "business",
        "growth",
        "back-office",
        "knowledge-base",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nathanclark_",
        "url": "https://x.com/nathanclark_/status/2096204922907963834"
      },
      "share_url": "https://x.ai/bot/LlldYnfUbSX5Z5ogLkHik",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-05T11:52:53.000Z",
      "updated_at": "2026-09-05T11:52:53.000Z"
    },
    {
      "type": "template",
      "slug": "aeo-seo-bot",
      "url": "https://grokbot.dev/marketplace/aeo-seo-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/aeo-seo-bot.json",
      "headline": "AEO/SEO Bot",
      "summary": "Weekday pipeline for picking, laying out and grading search-visibility pages",
      "categories": [
        "marketer",
        "business",
        "seo",
        "content",
        "growth",
        "research",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@eddiearc6",
        "url": "https://x.com/eddiearc6/status/2096179583783706993"
      },
      "share_url": "https://x.ai/bot/Jyx1Lg-VzYgyjDc-y-GQi",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T10:12:12.000Z",
      "updated_at": "2026-09-05T10:12:12.000Z"
    },
    {
      "type": "template",
      "slug": "koe",
      "url": "https://grokbot.dev/marketplace/koe/",
      "detail_url": "https://grokbot.dev/api/v1/templates/koe.json",
      "headline": "Koe",
      "summary": "A twelve-month thinking coach that makes you fill in the plan yourself",
      "categories": [
        "personal",
        "creator",
        "productivity",
        "learning",
        "decision-support",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@dannybuck",
        "url": "https://x.com/dannybuck/status/2096163056128569698"
      },
      "share_url": "https://x.ai/bot/2cfzlwUnOQtohmHiguKuc",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T09:06:32.000Z",
      "updated_at": "2026-09-05T09:06:32.000Z"
    },
    {
      "type": "template",
      "slug": "volt",
      "url": "https://grokbot.dev/marketplace/volt/",
      "detail_url": "https://grokbot.dev/api/v1/templates/volt.json",
      "headline": "Volt",
      "summary": "Hunts down the cheapest way to lease or buy a Tesla where you live",
      "categories": [
        "personal",
        "business",
        "shopping",
        "finance",
        "saving-money",
        "research",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@benngarnish",
        "url": "https://x.com/benngarnish/status/2096144725375902163"
      },
      "share_url": "https://x.ai/bot/QZ6VW1zRJTb4ZY5DNk5pm",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T07:53:41.000Z",
      "updated_at": "2026-09-05T07:53:41.000Z"
    },
    {
      "type": "template",
      "slug": "grandbot",
      "url": "https://grokbot.dev/marketplace/grandbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grandbot.json",
      "headline": "GrandBot",
      "summary": "Turns an official bot export into a readable brief on how your org works",
      "categories": [
        "business",
        "ops",
        "knowledge-base",
        "back-office",
        "research",
        "data",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2096133174879211976"
      },
      "share_url": "https://x.ai/bot/X_EV8GMyK_cIeaJ4CxOFP",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T07:07:47.000Z",
      "updated_at": "2026-09-05T07:07:47.000Z"
    },
    {
      "type": "template",
      "slug": "grant-packet-assembler",
      "url": "https://grokbot.dev/marketplace/grant-packet-assembler/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grant-packet-assembler.json",
      "headline": "Grant Packet Assembler",
      "summary": "Builds Georgia grant packets that survive a compliance read. Drafts only; you submit.",
      "categories": [
        "business",
        "back-office",
        "research",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@OmgawdMadeit",
        "url": "https://x.com/OmgawdMadeit/status/2096127964668629458"
      },
      "share_url": "https://x.ai/bot/kbP2DWs6cKSWqeRtQhIef",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T06:47:05.000Z",
      "updated_at": "2026-09-05T06:47:05.000Z"
    },
    {
      "type": "template",
      "slug": "music-video-release",
      "url": "https://grokbot.dev/marketplace/music-video-release/",
      "detail_url": "https://grokbot.dev/api/v1/templates/music-video-release.json",
      "headline": "Music Video Release",
      "summary": "Turns your track and lyrics into a timed shot list and a prompt board",
      "categories": [
        "creator",
        "content",
        "video",
        "design",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@OmgawdMadeit",
        "url": "https://x.com/OmgawdMadeit/status/2096127964668629458"
      },
      "share_url": "https://x.ai/bot/vagsUEIt5s7lexKnSes2H",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T06:47:05.000Z",
      "updated_at": "2026-09-05T06:47:05.000Z"
    },
    {
      "type": "template",
      "slug": "yahoo-pulse",
      "url": "https://grokbot.dev/marketplace/yahoo-pulse/",
      "detail_url": "https://grokbot.dev/api/v1/templates/yahoo-pulse.json",
      "headline": "Yahoo Pulse",
      "summary": "A read-only daily brief on the tickers you follow, with charts and news",
      "categories": [
        "investor",
        "personal",
        "finance",
        "monitoring",
        "research",
        "analytics",
        "news",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Tferriere",
        "url": "https://x.com/Tferriere/status/2096101032355061902"
      },
      "share_url": "https://x.ai/bot/5nnJJwVjO4EwThIaaaynu",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-05T05:00:04.000Z",
      "updated_at": "2026-09-05T05:00:04.000Z"
    },
    {
      "type": "template",
      "slug": "dr-buzz",
      "url": "https://grokbot.dev/marketplace/dr-buzz/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dr-buzz.json",
      "headline": "dr buzz",
      "summary": "A bot that builds other bots, each scoped to one job and one voice",
      "categories": [
        "developer",
        "creator",
        "automation",
        "engineering",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Talalakkari",
        "url": "https://x.com/Talalakkari/status/2096097164548260044"
      },
      "share_url": "https://x.ai/bot/VyvwcgM7BAqHWkdMoEajp",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T04:44:42.000Z",
      "updated_at": "2026-09-05T04:44:42.000Z"
    },
    {
      "type": "template",
      "slug": "gerente-ops",
      "url": "https://grokbot.dev/marketplace/gerente-ops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gerente-ops.json",
      "headline": "Gerente Ops",
      "summary": "Runs the back office of a small shop: till close, ledgers, stock and listings",
      "categories": [
        "business",
        "ops",
        "back-office",
        "finance",
        "automation",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JASCPROVZ",
        "url": "https://x.com/JASCPROVZ/status/2096095142478258654"
      },
      "share_url": "https://x.ai/bot/-0F1AbQupf4CTqCfYcVcJ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-05T04:36:40.000Z",
      "updated_at": "2026-09-05T04:36:40.000Z"
    },
    {
      "type": "template",
      "slug": "court",
      "url": "https://grokbot.dev/marketplace/court/",
      "detail_url": "https://grokbot.dev/api/v1/templates/court.json",
      "headline": "Court",
      "summary": "Reads a stuck group chat and says what it actually decided",
      "categories": [
        "personal",
        "decision-support",
        "productivity",
        "social-media",
        "life-hacks"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DonBonStovi",
        "url": "https://x.com/DonBonStovi/status/2096023951407485055"
      },
      "share_url": "https://x.ai/bot/mA4Ik2mIduPANDqFVmVMX",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T23:53:46.000Z",
      "updated_at": "2026-09-04T23:53:46.000Z"
    },
    {
      "type": "template",
      "slug": "changelog-stand-down",
      "url": "https://grokbot.dev/marketplace/changelog-stand-down/",
      "detail_url": "https://grokbot.dev/api/v1/templates/changelog-stand-down.json",
      "headline": "Changelog Stand-down",
      "summary": "Every Monday, a plain summary of what the team shipped",
      "categories": [
        "developer",
        "engineering",
        "ops",
        "monitoring",
        "scheduled",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@acolombiadev",
        "url": "https://x.com/acolombiadev/status/2096015833449349211"
      },
      "share_url": "https://x.ai/bot/T27nv3vIy89yKldqELWbn",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-04T23:21:31.000Z",
      "updated_at": "2026-09-04T23:21:31.000Z"
    },
    {
      "type": "template",
      "slug": "ratio",
      "url": "https://grokbot.dev/marketplace/ratio/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ratio.json",
      "headline": "Ratio",
      "summary": "Finds the line in your post that will get quoted back at you",
      "categories": [
        "creator",
        "personal",
        "social-media",
        "content",
        "decision-support",
        "growth"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DonBonStovi",
        "url": "https://x.com/DonBonStovi/status/2096011766962774522"
      },
      "share_url": "https://x.ai/bot/q66LYouguOxJ0VclM2whr",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T23:05:21.000Z",
      "updated_at": "2026-09-04T23:05:21.000Z"
    },
    {
      "type": "template",
      "slug": "spacexai-bug-reporter",
      "url": "https://grokbot.dev/marketplace/spacexai-bug-reporter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/spacexai-bug-reporter.json",
      "headline": "spacexai-bug-reporter",
      "summary": "Writes the bug report you paste into the right support form",
      "categories": [
        "developer",
        "support",
        "productivity",
        "back-office",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Fine_4451",
        "url": "https://x.com/Fine_4451/status/2096010664636506121"
      },
      "share_url": "https://x.ai/bot/g_xmlbEvupO0b1Emk9ohZ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T23:00:59.000Z",
      "updated_at": "2026-09-04T23:00:59.000Z"
    },
    {
      "type": "template",
      "slug": "omni-grok-bot",
      "url": "https://grokbot.dev/marketplace/omni-grok-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/omni-grok-bot.json",
      "headline": "OMNI Grok-Bot",
      "summary": "An ethics-first companion that answers your question and never sees your files",
      "categories": [
        "personal",
        "life-hacks",
        "wellbeing",
        "decision-support",
        "productivity"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@omni_puzzler",
        "url": "https://x.com/omni_puzzler/status/2096006603400987089"
      },
      "share_url": "https://x.ai/bot/HAIGA0nUYgv85CtV5SMWa",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T22:44:50.000Z",
      "updated_at": "2026-09-04T22:44:50.000Z"
    },
    {
      "type": "template",
      "slug": "token",
      "url": "https://grokbot.dev/marketplace/token/",
      "detail_url": "https://grokbot.dev/api/v1/templates/token.json",
      "headline": "Token",
      "summary": "Puts a spending limit on every bot in your fleet",
      "categories": [
        "developer",
        "ops",
        "saving-money",
        "monitoring",
        "automation",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jsk333",
        "url": "https://x.com/jsk333/status/2096004080309039288"
      },
      "share_url": "https://x.ai/bot/2Nk6nQTahTex1e5gHS_LU",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T22:34:49.000Z",
      "updated_at": "2026-09-04T22:34:49.000Z"
    },
    {
      "type": "template",
      "slug": "desk-producer",
      "url": "https://grokbot.dev/marketplace/desk-producer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/desk-producer.json",
      "headline": "Desk Producer",
      "summary": "Runs the production desk on a film so the paperwork keeps up",
      "categories": [
        "creator",
        "ops",
        "business",
        "agent-team",
        "back-office",
        "automation",
        "productivity"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DOGE_2013",
        "url": "https://x.com/DOGE_2013/status/2096003407781810202"
      },
      "share_url": "https://x.ai/bot/RBjaMq7S6scnB-ECoCVVs",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-04T22:32:08.000Z",
      "updated_at": "2026-09-04T22:32:08.000Z"
    },
    {
      "type": "template",
      "slug": "better-call-claude",
      "url": "https://grokbot.dev/marketplace/better-call-claude/",
      "detail_url": "https://grokbot.dev/api/v1/templates/better-call-claude.json",
      "headline": "Better Call Claude",
      "summary": "Free help working out what a legal problem actually is",
      "categories": [
        "personal",
        "support",
        "research",
        "decision-support",
        "knowledge-base",
        "learning",
        "back-office"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@freelegalforall",
        "url": "https://x.com/freelegalforall/status/2095994776625819949"
      },
      "share_url": "https://x.ai/bot/f7I5mP0uJf9brGIuK0ETo",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T21:57:51.000Z",
      "updated_at": "2026-09-04T21:57:51.000Z"
    },
    {
      "type": "template",
      "slug": "mr-dufrain",
      "url": "https://grokbot.dev/marketplace/mr-dufrain/",
      "detail_url": "https://grokbot.dev/api/v1/templates/mr-dufrain.json",
      "headline": "Mr. Dufrain",
      "summary": "Keeps the household books and warns you before a payment lands",
      "categories": [
        "personal",
        "finance",
        "saving-money",
        "decision-support",
        "monitoring",
        "back-office"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@zilarwitch",
        "url": "https://x.com/zilarwitch/status/2095992717805547980"
      },
      "share_url": "https://x.ai/bot/aBkdS0Duc24Hz7MvNm7W5",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T21:49:40.000Z",
      "updated_at": "2026-09-04T21:49:40.000Z"
    },
    {
      "type": "template",
      "slug": "inbox-to-asana",
      "url": "https://grokbot.dev/marketplace/inbox-to-asana/",
      "detail_url": "https://grokbot.dev/api/v1/templates/inbox-to-asana.json",
      "headline": "Inbox to Asana",
      "summary": "Reads your work mail and files the real work as Asana tasks",
      "categories": [
        "business",
        "ops",
        "productivity",
        "automation",
        "email",
        "back-office"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@wikiwayne",
        "url": "https://x.com/wikiwayne/status/2095991720060014888"
      },
      "share_url": "https://x.ai/bot/Ka18PTTKUNtDDPg0HpYva",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T21:45:42.000Z",
      "updated_at": "2026-09-04T21:45:42.000Z"
    },
    {
      "type": "template",
      "slug": "robauto-website-growth-agent",
      "url": "https://grokbot.dev/marketplace/robauto-website-growth-agent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/robauto-website-growth-agent.json",
      "headline": "Robauto Website Growth Agent",
      "summary": "Gets a brand site ready for the machines that will shop on it",
      "categories": [
        "business",
        "marketer",
        "developer",
        "growth",
        "automation",
        "seo",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RobautoAI",
        "url": "https://x.com/RobautoAI/status/2095990098278113670"
      },
      "share_url": "https://x.ai/bot/7k0TLQBu4hPI5oE3ywRHU",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-04T21:39:15.000Z",
      "updated_at": "2026-09-04T21:39:15.000Z"
    },
    {
      "type": "template",
      "slug": "preach",
      "url": "https://grokbot.dev/marketplace/preach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/preach.json",
      "headline": "Preach",
      "summary": "One passage of scripture and a short encouragement, daily",
      "categories": [
        "personal",
        "wellbeing",
        "health",
        "scheduled",
        "learning",
        "growth"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Ortix008",
        "url": "https://x.com/Ortix008/status/2095988445147496955"
      },
      "share_url": "https://x.ai/bot/ZFj_cKTrMTytrCKM9DFHk",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-04T21:32:41.000Z",
      "updated_at": "2026-09-04T21:32:41.000Z"
    },
    {
      "type": "template",
      "slug": "markets-brief-scout",
      "url": "https://grokbot.dev/marketplace/markets-brief-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/markets-brief-scout.json",
      "headline": "Markets Brief Scout",
      "summary": "A weekday market read that also writes the posts about it",
      "categories": [
        "investor",
        "creator",
        "news",
        "finance",
        "research",
        "monitoring",
        "scheduled",
        "social-media"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GainGlintGaz",
        "url": "https://x.com/GainGlintGaz/status/2095969760475275664"
      },
      "share_url": "https://x.ai/bot/exSOooSSp0Pc4W_K9DQ4T",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-04T20:18:26.000Z",
      "updated_at": "2026-09-04T20:18:26.000Z"
    },
    {
      "type": "template",
      "slug": "online-identity-bot",
      "url": "https://grokbot.dev/marketplace/online-identity-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/online-identity-bot.json",
      "headline": "Online Identity Bot",
      "summary": "Checks each day what the search engines are exposing about you",
      "categories": [
        "personal",
        "monitoring",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@gkamstra",
        "url": "https://x.com/gkamstra/status/2095837272687964512"
      },
      "share_url": "https://x.ai/bot/4VEl6mp1QrsvvjTFR-qE_",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-04T11:31:59.000Z",
      "updated_at": "2026-09-04T11:31:59.000Z"
    },
    {
      "type": "template",
      "slug": "download-expert",
      "url": "https://grokbot.dev/marketplace/download-expert/",
      "detail_url": "https://grokbot.dev/api/v1/templates/download-expert.json",
      "headline": "下载专家",
      "summary": "Turns long video and audio into readable Chinese transcripts",
      "categories": [
        "student",
        "research",
        "content",
        "video",
        "youtube",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KinGao476942",
        "url": "https://x.com/KinGao476942/status/2095774247805472910"
      },
      "share_url": "https://x.ai/bot/z7xup0Ax1SBl2K84PELqF",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T07:21:32.000Z",
      "updated_at": "2026-09-04T07:21:32.000Z"
    },
    {
      "type": "template",
      "slug": "the-bitcoin-layer",
      "url": "https://grokbot.dev/marketplace/the-bitcoin-layer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/the-bitcoin-layer.json",
      "headline": "The Bitcoin Layer",
      "summary": "Watches one liquidity indicator and speaks up only when it turns",
      "categories": [
        "investor",
        "monitoring",
        "research",
        "analytics",
        "finance",
        "crypto",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Tferriere",
        "url": "https://x.com/Tferriere/status/2095770015723393337"
      },
      "share_url": "https://x.ai/bot/LS2cnDAX30vNkWNb1Rv_7",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-04T07:04:43.000Z",
      "updated_at": "2026-09-04T07:04:43.000Z"
    },
    {
      "type": "template",
      "slug": "grokbot-optimizer",
      "url": "https://grokbot.dev/marketplace/grokbot-optimizer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grokbot-optimizer.json",
      "headline": "GrokBot Optimizer",
      "summary": "Audits a whole fleet of bots against the rules you set for them",
      "categories": [
        "ops",
        "developer",
        "monitoring",
        "decision-support",
        "engineering",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@rjdhardesty",
        "url": "https://x.com/rjdhardesty/status/2095764915919458768"
      },
      "share_url": "https://x.ai/bot/b7m5siCKd6baaWkPihOGa",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T06:44:28.000Z",
      "updated_at": "2026-09-04T06:44:28.000Z"
    },
    {
      "type": "template",
      "slug": "rosettabot",
      "url": "https://grokbot.dev/marketplace/rosettabot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/rosettabot.json",
      "headline": "Rosettabot",
      "summary": "Explains a foreign-language bot card before you install it",
      "categories": [
        "personal",
        "research",
        "content",
        "on-demand",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2095736749372649823"
      },
      "share_url": "https://x.ai/bot/eegdusTdLPabH7xTLQfgG",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T04:52:32.000Z",
      "updated_at": "2026-09-04T04:52:32.000Z"
    },
    {
      "type": "template",
      "slug": "join-a-startup-bot",
      "url": "https://grokbot.dev/marketplace/join-a-startup-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/join-a-startup-bot.json",
      "headline": "Join a Startup Bot",
      "summary": "Brings a handful of startup jobs to your messages every day",
      "categories": [
        "personal",
        "recruiting",
        "growth",
        "research",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@deysourav7091",
        "url": "https://x.com/deysourav7091/status/2095719866691133940"
      },
      "share_url": "https://x.ai/bot/XJCoBm6z7qjAnt9ScG8i7",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-04T03:45:27.000Z",
      "updated_at": "2026-09-04T03:45:27.000Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-tyler",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-tyler/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-tyler.json",
      "headline": "Chief",
      "summary": "One point of contact in front of a whole team of specialists",
      "categories": [
        "ops",
        "business",
        "productivity",
        "back-office",
        "email",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MitchTiler",
        "url": "https://x.com/MitchTiler/status/2095711121193996674"
      },
      "share_url": "https://x.ai/bot/Q6Owq4QjKJeSyo4FJ8hZW",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-04T03:10:42.000Z",
      "updated_at": "2026-09-04T03:10:42.000Z"
    },
    {
      "type": "template",
      "slug": "asc-skill",
      "url": "https://grokbot.dev/marketplace/asc-skill/",
      "detail_url": "https://grokbot.dev/api/v1/templates/asc-skill.json",
      "headline": "ASC Skill",
      "summary": "Walks an iOS release through App Store Connect, step by step",
      "categories": [
        "developer",
        "productivity",
        "automation",
        "engineering",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Phil_Holland",
        "url": "https://x.com/Phil_Holland/status/2095703454089990347"
      },
      "share_url": "https://x.ai/bot/1kQ8p3TAKx2FgvYXir2Ta",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T02:40:14.000Z",
      "updated_at": "2026-09-04T02:40:14.000Z"
    },
    {
      "type": "template",
      "slug": "arnold",
      "url": "https://grokbot.dev/marketplace/arnold/",
      "detail_url": "https://grokbot.dev/api/v1/templates/arnold.json",
      "headline": "Arnold",
      "summary": "Keeps an eye on what your Cursor usage is actually costing",
      "categories": [
        "developer",
        "saving-money",
        "monitoring",
        "analytics",
        "engineering",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Kelseyshuo",
        "url": "https://x.com/Kelseyshuo/status/2095701119355834859"
      },
      "share_url": "https://x.ai/bot/ymoMdfvzdErOrclxCOaC_",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-04T02:30:57.000Z",
      "updated_at": "2026-09-04T02:30:57.000Z"
    },
    {
      "type": "template",
      "slug": "jarvis",
      "url": "https://grokbot.dev/marketplace/jarvis/",
      "detail_url": "https://grokbot.dev/api/v1/templates/jarvis.json",
      "headline": "Jarvis",
      "summary": "An everyday assistant for people arriving from other AI tools",
      "categories": [
        "personal",
        "productivity",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DhalgrenMarquis",
        "url": "https://x.com/Shoshkin/status/2095682401196245502"
      },
      "share_url": "https://x.ai/bot/EiOdP3Fg6pHBkm3AgLbRA",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T01:16:34.000Z",
      "updated_at": "2026-09-04T01:16:34.000Z"
    },
    {
      "type": "template",
      "slug": "appeal-desk",
      "url": "https://grokbot.dev/marketplace/appeal-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/appeal-desk.json",
      "headline": "Appeal Desk",
      "summary": "Turns an insurance denial letter into a drafted appeal",
      "categories": [
        "personal",
        "back-office",
        "decision-support",
        "health",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MSaintjour",
        "url": "https://x.com/MSaintjour/status/2095677597258486267"
      },
      "share_url": "https://x.ai/bot/yOiPm69HN5FujdkvvysF9",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-04T00:57:29.000Z",
      "updated_at": "2026-09-04T00:57:29.000Z"
    },
    {
      "type": "template",
      "slug": "shiori-bookmark-digest",
      "url": "https://grokbot.dev/marketplace/shiori-bookmark-digest/",
      "detail_url": "https://grokbot.dev/api/v1/templates/shiori-bookmark-digest.json",
      "headline": "しおり",
      "summary": "Turns yesterday's X bookmarks into a short morning briefing",
      "categories": [
        "personal",
        "productivity",
        "decision-support",
        "social-media",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@marulimoai",
        "url": "https://x.com/marulimoai/status/2095669777352261887"
      },
      "share_url": "https://x.ai/bot/Mo3ndUm0UJTjTvFbqLFDt",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-04T00:26:25.000Z",
      "updated_at": "2026-09-04T00:26:25.000Z"
    },
    {
      "type": "template",
      "slug": "x-algo",
      "url": "https://grokbot.dev/marketplace/x-algo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-algo.json",
      "headline": "X Algo",
      "summary": "Tells you whether to post now, quote something, or sit tight",
      "categories": [
        "creator",
        "social-media",
        "analytics",
        "growth",
        "decision-support"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@UziObi",
        "url": "https://x.com/UziObi/status/2095661664146161788"
      },
      "share_url": "https://x.ai/bot/W0LrVwNwsRHhFY4PG7586",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T23:54:10.000Z",
      "updated_at": "2026-09-03T23:54:10.000Z"
    },
    {
      "type": "template",
      "slug": "the-amazing-randibot",
      "url": "https://grokbot.dev/marketplace/the-amazing-randibot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/the-amazing-randibot.json",
      "headline": "The Amazing Randibot",
      "summary": "A cheerful skeptic that makes your other bots prove it",
      "categories": [
        "personal",
        "research",
        "decision-support",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@russbroomell",
        "url": "https://x.com/russbroomell/status/2095661019041251711"
      },
      "share_url": "https://x.ai/bot/pL_NCKfdF5UgZYEo-jMAx",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T23:51:37.000Z",
      "updated_at": "2026-09-03T23:51:37.000Z"
    },
    {
      "type": "template",
      "slug": "tab-janitor",
      "url": "https://grokbot.dev/marketplace/tab-janitor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tab-janitor.json",
      "headline": "Tab Janitor",
      "summary": "Clears the abandoned tabs out of a shared cloud browser",
      "categories": [
        "ops",
        "developer",
        "productivity",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2095646306085556321"
      },
      "share_url": "https://x.ai/bot/XOYBYmHQrUT_Ux88SS409",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T22:53:09.000Z",
      "updated_at": "2026-09-03T22:53:09.000Z"
    },
    {
      "type": "template",
      "slug": "revenue-signal-radar",
      "url": "https://grokbot.dev/marketplace/revenue-signal-radar/",
      "detail_url": "https://grokbot.dev/api/v1/templates/revenue-signal-radar.json",
      "headline": "Revenue Signal Radar",
      "summary": "Finds the revenue already sitting in your HubSpot pipeline",
      "categories": [
        "sales",
        "business",
        "analytics",
        "decision-support",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ericosiu",
        "url": "https://x.com/ericosiu/status/2095629858630160695"
      },
      "share_url": "https://x.ai/bot/9BnpveyF3fbsRRtolSWpp",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-03T21:47:47.000Z",
      "updated_at": "2026-09-03T21:47:47.000Z"
    },
    {
      "type": "template",
      "slug": "shotcraft",
      "url": "https://grokbot.dev/marketplace/shotcraft/",
      "detail_url": "https://grokbot.dev/api/v1/templates/shotcraft.json",
      "headline": "Shotcraft",
      "summary": "Builds a launch video for your product, storyboard to sound mix",
      "categories": [
        "creator",
        "marketer",
        "content",
        "video",
        "design"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Tferriere",
        "url": "https://x.com/Tferriere/status/2095620474193793465"
      },
      "share_url": "https://x.ai/bot/gdZdBNWdgW45IVVU8sv8F",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T21:10:30.000Z",
      "updated_at": "2026-09-03T21:10:30.000Z"
    },
    {
      "type": "template",
      "slug": "orders",
      "url": "https://grokbot.dev/marketplace/orders/",
      "detail_url": "https://grokbot.dev/api/v1/templates/orders.json",
      "headline": "orders",
      "summary": "A personal desk for every parcel, receipt and refund you are waiting on",
      "categories": [
        "personal",
        "shopping",
        "monitoring",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@wafffls",
        "url": "https://x.com/wafffls/status/2095614060070928837"
      },
      "share_url": "https://x.ai/bot/0taQ6RZdkjsnOfda_A8Ie",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T20:45:01.000Z",
      "updated_at": "2026-09-03T20:45:01.000Z"
    },
    {
      "type": "template",
      "slug": "pickfu-insights",
      "url": "https://grokbot.dev/marketplace/pickfu-insights/",
      "detail_url": "https://grokbot.dev/api/v1/templates/pickfu-insights.json",
      "headline": "PickFu Insights",
      "summary": "Test a product idea on real shoppers before you build it",
      "categories": [
        "business",
        "marketer",
        "research",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GrokBotMoney",
        "url": "https://x.com/GrokBotMoney/status/2095610465271374178"
      },
      "share_url": "https://x.ai/bot/9EFVmFgQhjYKjMHAhpCWn",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T20:30:44.000Z",
      "updated_at": "2026-09-03T20:30:44.000Z"
    },
    {
      "type": "template",
      "slug": "precog-wars",
      "url": "https://grokbot.dev/marketplace/precog-wars/",
      "detail_url": "https://grokbot.dev/api/v1/templates/precog-wars.json",
      "headline": "Precog wARS",
      "summary": "Reads Precog prediction-market odds in Spanish, and never trades",
      "categories": [
        "investor",
        "crypto",
        "finance",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ferminrp",
        "url": "https://x.com/ferminrp/status/2095595470164787652"
      },
      "share_url": "https://x.ai/bot/7M8RpppF2AistbVbeEPyN",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T19:31:09.000Z",
      "updated_at": "2026-09-03T19:31:09.000Z"
    },
    {
      "type": "template",
      "slug": "video-clip",
      "url": "https://grokbot.dev/marketplace/video-clip/",
      "detail_url": "https://grokbot.dev/api/v1/templates/video-clip.json",
      "headline": "Video Clip",
      "summary": "Tracks down the real version of a clip and hands you the file",
      "categories": [
        "personal",
        "creator",
        "video",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DogecoinNorway",
        "url": "https://x.com/DogecoinNorway/status/2095593512213647847"
      },
      "share_url": "https://x.ai/bot/oOFMzoZv7OEKHO-XwXHWX",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T19:23:22.000Z",
      "updated_at": "2026-09-03T19:23:22.000Z"
    },
    {
      "type": "template",
      "slug": "ai-video-expert",
      "url": "https://grokbot.dev/marketplace/ai-video-expert/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ai-video-expert.json",
      "headline": "AI 视频专家",
      "summary": "Turns one photograph into a short, moody film clip",
      "categories": [
        "creator",
        "content",
        "video",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KinGao476942",
        "url": "https://x.com/KinGao476942/status/2095507795818991826"
      },
      "share_url": "https://x.ai/bot/ES3LVns98INeXAoYwef_f",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T13:42:45.000Z",
      "updated_at": "2026-09-03T13:42:45.000Z"
    },
    {
      "type": "template",
      "slug": "magnum-seiba",
      "url": "https://grokbot.dev/marketplace/magnum-seiba/",
      "detail_url": "https://grokbot.dev/api/v1/templates/magnum-seiba.json",
      "headline": "Magnum Seiba",
      "summary": "Run your Tesla from a chat window — climate, charging, locks and routes",
      "categories": [
        "personal",
        "automation",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Kamkom05",
        "url": "https://x.com/Kamkom05/status/2095481229818614235"
      },
      "share_url": "https://x.ai/bot/1-UWhTw5N6IVgOcDZHrsb",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T11:57:12.000Z",
      "updated_at": "2026-09-03T11:57:12.000Z"
    },
    {
      "type": "template",
      "slug": "dean-of-students",
      "url": "https://grokbot.dev/marketplace/dean-of-students/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dean-of-students.json",
      "headline": "Dean of Students",
      "summary": "Pulls one child's school admin into a single prepared queue",
      "categories": [
        "personal",
        "family",
        "productivity",
        "email",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ErinnFL",
        "url": "https://x.com/ErinnFL/status/2095444675251318912"
      },
      "share_url": "https://x.ai/bot/_hsyZUFgPzgxGxW2wIYAj",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T09:31:56.000Z",
      "updated_at": "2026-09-03T09:31:56.000Z"
    },
    {
      "type": "template",
      "slug": "chained-oblivion",
      "url": "https://grokbot.dev/marketplace/chained-oblivion/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chained-oblivion.json",
      "headline": "Chained Oblivion",
      "summary": "Finds the software you keep paying for and nobody uses",
      "categories": [
        "business",
        "saving-money",
        "finance",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mjjefford",
        "url": "https://x.com/mjjefford/status/2095417956024918256"
      },
      "share_url": "https://x.ai/bot/Loekv1uecl26wWW0lNyfR",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T07:45:46.000Z",
      "updated_at": "2026-09-03T07:45:46.000Z"
    },
    {
      "type": "template",
      "slug": "operator",
      "url": "https://grokbot.dev/marketplace/operator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/operator.json",
      "headline": "Operator",
      "summary": "One daily brief for founders, in place of forty open tabs",
      "categories": [
        "business",
        "productivity",
        "decision-support",
        "back-office",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mjjefford",
        "url": "https://x.com/mjjefford/status/2095417935539908829"
      },
      "share_url": "https://x.ai/bot/YgM8FiKS0WczveQXe6edr",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-03T07:45:41.000Z",
      "updated_at": "2026-09-03T07:45:41.000Z"
    },
    {
      "type": "template",
      "slug": "ideabot",
      "url": "https://grokbot.dev/marketplace/ideabot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ideabot.json",
      "headline": "ideabot",
      "summary": "Mines your week for one startup idea worth chasing, every hour",
      "categories": [
        "business",
        "research",
        "decision-support",
        "growth",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@onerinas",
        "url": "https://x.com/onerinas/status/2095370142846996705"
      },
      "share_url": "https://x.ai/bot/iQ8OWEu7eOI3YuTZFaIe_",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-03T04:35:46.000Z",
      "updated_at": "2026-09-03T04:35:46.000Z"
    },
    {
      "type": "template",
      "slug": "primer",
      "url": "https://grokbot.dev/marketplace/primer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/primer.json",
      "headline": "Primer",
      "summary": "Straight answers about how Grok Bot actually behaves",
      "categories": [
        "developer",
        "knowledge-base",
        "learning",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ambientstudio24",
        "url": "https://x.com/ambientstudio24/status/2095367857416585575"
      },
      "share_url": "https://x.ai/bot/GTStkB5wsoSlGx9jtdaPe",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T04:26:41.000Z",
      "updated_at": "2026-09-03T04:26:41.000Z"
    },
    {
      "type": "template",
      "slug": "grok-customer-support",
      "url": "https://grokbot.dev/marketplace/grok-customer-support/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-customer-support.json",
      "headline": "Grok Customer Support",
      "summary": "Sits on hold with customer support so you do not have to",
      "categories": [
        "personal",
        "support",
        "automation",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jakewlittle",
        "url": "https://x.com/jakewlittle/status/2095356264830103657"
      },
      "share_url": "https://x.ai/bot/1PSI6qQln1PowM5reA_8L",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-03T03:40:38.000Z",
      "updated_at": "2026-09-03T03:40:38.000Z"
    },
    {
      "type": "template",
      "slug": "rogue-bot-hunter",
      "url": "https://grokbot.dev/marketplace/rogue-bot-hunter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/rogue-bot-hunter.json",
      "headline": "Rogue Bot Hunter",
      "summary": "Keeps watch over the fleet of bots you already run",
      "categories": [
        "developer",
        "monitoring",
        "saving-money",
        "engineering",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@LeTerryBZH",
        "url": "https://x.com/LeTerryBZH/status/2095346403010883794"
      },
      "share_url": "https://x.ai/bot/DNpS1nqrBzmQ5vsx1IHn1",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-03T03:01:26.000Z",
      "updated_at": "2026-09-03T03:01:26.000Z"
    },
    {
      "type": "template",
      "slug": "seoagent",
      "url": "https://grokbot.dev/marketplace/seoagent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/seoagent.json",
      "headline": "SEOAgent",
      "summary": "Installs itself into your repo and works on search traffic",
      "categories": [
        "marketer",
        "seo",
        "growth",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@alindsay77",
        "url": "https://x.com/alindsay77/status/2095301891336949905"
      },
      "share_url": "https://x.ai/bot/scYgD9jdFhooaSHihRzy7",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-03T00:04:34.000Z",
      "updated_at": "2026-09-03T00:04:34.000Z"
    },
    {
      "type": "plugin",
      "slug": "analyticlunch",
      "url": "https://grokbot.dev/plugins/analyticlunch/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/analyticlunch.json",
      "headline": "AnalyticLunch",
      "summary": "Give your Grok Bot your site traffic, UTM link builder and weekly competitor intel.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "analyticlunch.com",
        "url": "https://analyticlunch.com"
      },
      "added_at": "2026-09-03T00:00:00Z",
      "updated_at": "2026-09-03T00:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "jobkeepr",
      "url": "https://grokbot.dev/plugins/jobkeepr/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/jobkeepr.json",
      "headline": "Jobkeepr",
      "summary": "Give your Grok Bot your field service business: jobs, schedule, estimates, invoices.",
      "categories": [
        "work"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "jobkeepr.com",
        "url": "https://jobkeepr.com"
      },
      "added_at": "2026-09-03T00:00:00Z",
      "updated_at": "2026-09-03T00:00:00Z"
    },
    {
      "type": "template",
      "slug": "wall-street",
      "url": "https://grokbot.dev/marketplace/wall-street/",
      "detail_url": "https://grokbot.dev/api/v1/templates/wall-street.json",
      "headline": "Wall Street",
      "summary": "Keeps a make-believe trading book with a running profit and loss log",
      "categories": [
        "investor",
        "finance",
        "analytics",
        "learning",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CoonInvestments",
        "url": "https://x.com/CoonInvestments/status/2095299431499182089"
      },
      "share_url": "https://x.ai/bot/0qNgH0mv4-N-gv_KkZbEm",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-02T23:54:47.000Z",
      "updated_at": "2026-09-02T23:54:47.000Z"
    },
    {
      "type": "template",
      "slug": "tesla-bot",
      "url": "https://grokbot.dev/marketplace/tesla-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tesla-bot.json",
      "headline": "Tesla Bot",
      "summary": "Runs your Tesla from a chat window once the two are paired",
      "categories": [
        "personal",
        "automation",
        "monitoring",
        "home",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mvanhorn",
        "url": "https://x.com/mvanhorn/status/2095297598450274524"
      },
      "share_url": "https://x.ai/bot/l4EozO2deoaWFB8hOGwTY",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T23:47:30.000Z",
      "updated_at": "2026-09-02T23:47:30.000Z"
    },
    {
      "type": "template",
      "slug": "fondi",
      "url": "https://grokbot.dev/marketplace/fondi/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fondi.json",
      "headline": "Fondi",
      "summary": "Reads your company's website and staffs you a leadership bench of bots",
      "categories": [
        "business",
        "meta-bot",
        "agent-team",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@naoufal_elh",
        "url": "https://x.com/naoufal_elh/status/2095292060731396277"
      },
      "share_url": "https://x.ai/bot/qL920VjKyua3_u89UYnQL",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-02T23:25:30.000Z",
      "updated_at": "2026-09-02T23:25:30.000Z"
    },
    {
      "type": "template",
      "slug": "coffee-companion",
      "url": "https://grokbot.dev/marketplace/coffee-companion/",
      "detail_url": "https://grokbot.dev/api/v1/templates/coffee-companion.json",
      "headline": "coffee companion",
      "summary": "Works out how to brew each new bag and keeps the log in Notion",
      "categories": [
        "personal",
        "life-hacks",
        "food",
        "wellbeing",
        "knowledge-base",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@andymadrick",
        "url": "https://x.com/andymadrick/status/2095287853450399859"
      },
      "share_url": "https://x.ai/bot/SqO-_5207iInz0iDSAFVW",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T23:08:47.000Z",
      "updated_at": "2026-09-02T23:08:47.000Z"
    },
    {
      "type": "template",
      "slug": "babel-live-translator",
      "url": "https://grokbot.dev/marketplace/babel-live-translator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/babel-live-translator.json",
      "headline": "Babel - live translator",
      "summary": "Drops English translations into the chat while an international call runs",
      "categories": [
        "business",
        "meetings",
        "productivity",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kunalsells",
        "url": "https://x.com/kunalsells/status/2095267534110900400"
      },
      "share_url": "https://x.ai/bot/-GzMJlSIqdo89K0qs3yC4",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T21:48:02.000Z",
      "updated_at": "2026-09-02T21:48:02.000Z"
    },
    {
      "type": "template",
      "slug": "price-error-agent",
      "url": "https://grokbot.dev/marketplace/price-error-agent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/price-error-agent.json",
      "headline": "Price Error Agent",
      "summary": "Spots pricing mistakes at Australian retailers and on flights out of Australia",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "monitoring",
        "travel",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@yoda_FDE",
        "url": "https://x.com/yoda_FDE/status/2095261094076207107"
      },
      "share_url": "https://x.ai/bot/cbULQqhzmOeeJ9GT2DX7L",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-02T21:22:27.000Z",
      "updated_at": "2026-09-02T21:22:27.000Z"
    },
    {
      "type": "template",
      "slug": "dosebot",
      "url": "https://grokbot.dev/marketplace/dosebot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dosebot.json",
      "headline": "dosebot",
      "summary": "Tells you whether your idea is a nice-to-have or a genuine ache",
      "categories": [
        "business",
        "decision-support",
        "research",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@onerinas",
        "url": "https://x.com/onerinas/status/2095221346578186249"
      },
      "share_url": "https://x.ai/bot/2euxntVrddHyA3c2hyxiZ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T18:44:31.000Z",
      "updated_at": "2026-09-02T18:44:31.000Z"
    },
    {
      "type": "template",
      "slug": "deck-guy",
      "url": "https://grokbot.dev/marketplace/deck-guy/",
      "detail_url": "https://grokbot.dev/api/v1/templates/deck-guy.json",
      "headline": "deck-guy",
      "summary": "Builds the post-call slide deck straight out of the transcript",
      "categories": [
        "sales",
        "business",
        "content",
        "meetings",
        "design",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@pavravi",
        "url": "https://x.com/pavravi/status/2095194505876316378"
      },
      "share_url": "https://x.ai/bot/bdkJcjP5Gt9BaGTqh1vXH",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T16:57:51.000Z",
      "updated_at": "2026-09-02T16:57:51.000Z"
    },
    {
      "type": "template",
      "slug": "table-money",
      "url": "https://grokbot.dev/marketplace/table-money/",
      "detail_url": "https://grokbot.dev/api/v1/templates/table-money.json",
      "headline": "Table Money",
      "summary": "Chases down the invoices and refunds you never closed out",
      "categories": [
        "personal",
        "business",
        "ops",
        "saving-money",
        "back-office",
        "productivity",
        "finance",
        "email"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Andrew51786",
        "url": "https://x.com/Andrew51786/status/2095176422767599794"
      },
      "share_url": "https://x.ai/bot/abfx0_FhJ8G_mue5YWQxM",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T15:46:00.000Z",
      "updated_at": "2026-09-02T15:46:00.000Z"
    },
    {
      "type": "template",
      "slug": "global-macro-analyst",
      "url": "https://grokbot.dev/marketplace/global-macro-analyst/",
      "detail_url": "https://grokbot.dev/api/v1/templates/global-macro-analyst.json",
      "headline": "全球宏观分析师",
      "summary": "Reads big macro events for what they do to rates, the dollar, gold and equities",
      "categories": [
        "investor",
        "research",
        "monitoring",
        "decision-support",
        "analytics",
        "finance",
        "crypto",
        "news"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Fund_Monkey",
        "url": "https://x.com/Fund_Monkey/status/2095172991223234844"
      },
      "share_url": "https://x.ai/bot/08RSf587bOlWhbQai6A3I",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T15:32:22.000Z",
      "updated_at": "2026-09-02T15:32:22.000Z"
    },
    {
      "type": "template",
      "slug": "fable-5-1-oracle",
      "url": "https://grokbot.dev/marketplace/fable-5-1-oracle/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fable-5-1-oracle.json",
      "headline": "Fable 5.1 Oracle",
      "summary": "Thinks the build through and checks the work, but never writes the code itself",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "decision-support",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@bossriceshark",
        "url": "https://x.com/bossriceshark/status/2095151692706967931"
      },
      "share_url": "https://x.ai/bot/tLSg4HxepSclMqbZUTRnX",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-02T14:07:44.000Z",
      "updated_at": "2026-09-02T14:07:44.000Z"
    },
    {
      "type": "template",
      "slug": "know-enemy",
      "url": "https://grokbot.dev/marketplace/know-enemy/",
      "detail_url": "https://grokbot.dev/api/v1/templates/know-enemy.json",
      "headline": "Know Enemy",
      "summary": "Keeps a running read on the rivals you name, drawn only from what is already public",
      "categories": [
        "marketer",
        "sales",
        "research",
        "monitoring",
        "business",
        "data",
        "scheduled",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SaaSocalypse",
        "url": "https://x.com/SaaSocalypse/status/2095145997613887825"
      },
      "share_url": "https://x.ai/bot/LREkas8UxVGvPJ5NiO7bz",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-02T13:45:06.000Z",
      "updated_at": "2026-09-02T13:45:06.000Z"
    },
    {
      "type": "template",
      "slug": "know-yourself",
      "url": "https://grokbot.dev/marketplace/know-yourself/",
      "detail_url": "https://grokbot.dev/api/v1/templates/know-yourself.json",
      "headline": "Know Yourself",
      "summary": "Turns your own company records into one answer everyone can quote",
      "categories": [
        "business",
        "ops",
        "knowledge-base",
        "research",
        "decision-support",
        "data",
        "analytics",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SaaSocalypse",
        "url": "https://x.com/SaaSocalypse/status/2095145997613887825"
      },
      "share_url": "https://x.ai/bot/mD27QOhXb_plMRSbsvMOv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T13:45:06.000Z",
      "updated_at": "2026-09-02T13:45:06.000Z"
    },
    {
      "type": "template",
      "slug": "dr-web-lp",
      "url": "https://grokbot.dev/marketplace/dr-web-lp/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dr-web-lp.json",
      "headline": "Dr Web LP",
      "summary": "Give it a picture of a web page and it builds that page in HTML and CSS",
      "categories": [
        "developer",
        "design",
        "engineering",
        "content",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@old_pgmrs_will",
        "url": "https://x.com/old_pgmrs_will/status/2095140627252125835"
      },
      "share_url": "https://x.ai/bot/xM153pKfXPLWagLi_O1vR",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T13:23:46.000Z",
      "updated_at": "2026-09-02T13:23:46.000Z"
    },
    {
      "type": "template",
      "slug": "farm",
      "url": "https://grokbot.dev/marketplace/farm/",
      "detail_url": "https://grokbot.dev/api/v1/templates/farm.json",
      "headline": "Farm",
      "summary": "Sends the heavy coding work off to its own machine and brings back just the result",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "productivity",
        "saving-money",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mpieras",
        "url": "https://x.com/mpieras/status/2095120187389263968"
      },
      "share_url": "https://x.ai/bot/x3Iv-2J4mfxJY6JFlgwNa",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-02T12:02:32.000Z",
      "updated_at": "2026-09-02T12:02:32.000Z"
    },
    {
      "type": "template",
      "slug": "nomad",
      "url": "https://grokbot.dev/marketplace/nomad/",
      "detail_url": "https://grokbot.dev/api/v1/templates/nomad.json",
      "headline": "Nomad",
      "summary": "Keeps a running register of your agents so the stack is never locked in",
      "categories": [
        "developer",
        "ops",
        "back-office",
        "data",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@PedroAnibarro",
        "url": "https://x.com/PedroAnibarro/status/2095095116142666116"
      },
      "share_url": "https://x.ai/bot/mbC-ZTmcOFq3sKUHfxf-3",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T10:22:55.000Z",
      "updated_at": "2026-09-02T10:22:55.000Z"
    },
    {
      "type": "template",
      "slug": "meta-grok",
      "url": "https://grokbot.dev/marketplace/meta-grok/",
      "detail_url": "https://grokbot.dev/api/v1/templates/meta-grok.json",
      "headline": "Meta Grok",
      "summary": "A weekday roundup of the five Grok bots people are actually talking about",
      "categories": [
        "developer",
        "research",
        "news",
        "social-media",
        "meta-bot",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@FrankFindsOut",
        "url": "https://x.com/FrankFindsOut/status/2095092686906884164"
      },
      "share_url": "https://x.ai/bot/HAhgshU4r50gS81LCcpmk",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-02T10:13:16.000Z",
      "updated_at": "2026-09-02T10:13:16.000Z"
    },
    {
      "type": "template",
      "slug": "cost-optimizer",
      "url": "https://grokbot.dev/marketplace/cost-optimizer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cost-optimizer.json",
      "headline": "Cost Optimizer",
      "summary": "Finds the less expensive route to the same result across your agent stack",
      "categories": [
        "developer",
        "ops",
        "saving-money",
        "decision-support",
        "analytics",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MadeItHappenX",
        "url": "https://x.com/MadeItHappenX/status/2095072492700455159"
      },
      "share_url": "https://x.ai/bot/-CjM4_uRs6sEGdfZfC5gv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T08:53:01.000Z",
      "updated_at": "2026-09-02T08:53:01.000Z"
    },
    {
      "type": "template",
      "slug": "my-krishna",
      "url": "https://grokbot.dev/marketplace/my-krishna/",
      "detail_url": "https://grokbot.dev/api/v1/templates/my-krishna.json",
      "headline": "My Krishna",
      "summary": "A Bhagavad Gita companion that answers in Krishna's own voice",
      "categories": [
        "personal",
        "wellbeing",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AKSHAYBHOPANI",
        "url": "https://x.com/AKSHAYBHOPANI/status/2095049479506538710"
      },
      "share_url": "https://x.ai/bot/Mf2MLqJRCmz8sSjFmYedG",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T07:21:34.000Z",
      "updated_at": "2026-09-02T07:21:34.000Z"
    },
    {
      "type": "template",
      "slug": "engineering-qa",
      "url": "https://grokbot.dev/marketplace/engineering-qa/",
      "detail_url": "https://grokbot.dev/api/v1/templates/engineering-qa.json",
      "headline": "Engineering QA",
      "summary": "Guards the merge bar on repos you pick, escalating only the real judgment calls",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "ops",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@andreleibovici",
        "url": "https://x.com/andreleibovici/status/2095035963978522719"
      },
      "share_url": "https://x.ai/bot/b2tS8BNj8BhoQNDcB081S",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T06:27:52.000Z",
      "updated_at": "2026-09-02T06:27:52.000Z"
    },
    {
      "type": "template",
      "slug": "dead-man-s-bot",
      "url": "https://grokbot.dev/marketplace/dead-man-s-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dead-man-s-bot.json",
      "headline": "Dead Man’s Bot",
      "summary": "A contingency trigger that fires only when you stop checking in",
      "categories": [
        "personal",
        "ops",
        "automation",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2094981472566288703"
      },
      "share_url": "https://x.ai/bot/XCaz2bKzsJ4J1DmkaYyc4",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-02T02:51:20.000Z",
      "updated_at": "2026-09-02T02:51:20.000Z"
    },
    {
      "type": "template",
      "slug": "code-red",
      "url": "https://grokbot.dev/marketplace/code-red/",
      "detail_url": "https://grokbot.dev/api/v1/templates/code-red.json",
      "headline": "Code Red",
      "summary": "A rehearsed emergency stop for systems you own, gated behind your own confirmation",
      "categories": [
        "developer",
        "ops",
        "engineering",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2094970870871585096"
      },
      "share_url": "https://x.ai/bot/4y3jlvwxFNqcP76eJgpuD",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T02:09:12.000Z",
      "updated_at": "2026-09-02T02:09:12.000Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-joseph",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-joseph/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-joseph.json",
      "headline": "Chief of Staff (Joseph)",
      "summary": "A single coordinator that routes work to a small, deliberately lean bot bench",
      "categories": [
        "personal",
        "ops",
        "productivity",
        "automation",
        "agent-team",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BTC_Yogi",
        "url": "https://x.com/BTC_Yogi/status/2094947816028381534"
      },
      "share_url": "https://x.ai/bot/5hqR_5PVUy7WMbNaXPJ8s",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-02T00:37:36.000Z",
      "updated_at": "2026-09-02T00:37:36.000Z"
    },
    {
      "type": "template",
      "slug": "memento",
      "url": "https://grokbot.dev/marketplace/memento/",
      "detail_url": "https://grokbot.dev/api/v1/templates/memento.json",
      "headline": "Memento",
      "summary": "Lasting recall for Grok Bot, backed by an external memory store",
      "categories": [
        "personal",
        "developer",
        "knowledge-base",
        "productivity",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MaheshtheDev",
        "url": "https://x.com/MaheshtheDev/status/2094947237373890593"
      },
      "share_url": "https://x.ai/bot/_xZZE41svJdcq2w6ZWJan",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-02T00:35:18.000Z",
      "updated_at": "2026-09-02T00:35:18.000Z"
    },
    {
      "type": "template",
      "slug": "redact",
      "url": "https://grokbot.dev/marketplace/redact/",
      "detail_url": "https://grokbot.dev/api/v1/templates/redact.json",
      "headline": "Redact",
      "summary": "Files your removal requests with the data brokers so you need not pay a service",
      "categories": [
        "personal",
        "automation",
        "saving-money",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@PyRo1121",
        "url": "https://x.com/PyRo1121/status/2094897839331549594"
      },
      "share_url": "https://x.ai/bot/Abz5txK3unOkm5ZxCGGX-",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T21:19:00.000Z",
      "updated_at": "2026-09-01T21:19:00.000Z"
    },
    {
      "type": "template",
      "slug": "maskoff",
      "url": "https://grokbot.dev/marketplace/maskoff/",
      "detail_url": "https://grokbot.dev/api/v1/templates/maskoff.json",
      "headline": "Maskoff",
      "summary": "Screens the stranger who just slid into your DMs and tells you whether to trust them",
      "categories": [
        "personal",
        "social-media",
        "research",
        "decision-support",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RyanGBsystems",
        "url": "https://x.com/RyanGBsystems/status/2094897077335802276"
      },
      "share_url": "https://x.ai/bot/39x_3B9P5HBl-MpK1xGzP",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T21:15:59.000Z",
      "updated_at": "2026-09-01T21:15:59.000Z"
    },
    {
      "type": "template",
      "slug": "daily-easy-apply-digest",
      "url": "https://grokbot.dev/marketplace/daily-easy-apply-digest/",
      "detail_url": "https://grokbot.dev/api/v1/templates/daily-easy-apply-digest.json",
      "headline": "Daily Easy Apply Digest",
      "summary": "A morning shortlist of backend roles you can apply to in one click, ranked against your CV",
      "categories": [
        "personal",
        "recruiting",
        "monitoring",
        "scheduled",
        "research"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@HaseebMir91",
        "url": "https://x.com/HaseebMir91/status/2094891095733710950"
      },
      "share_url": "https://x.ai/bot/uVNOsoe-iWf4ZOUdfgo5R",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-01T20:52:13.000Z",
      "updated_at": "2026-09-01T20:52:13.000Z"
    },
    {
      "type": "template",
      "slug": "easy-apply-queue",
      "url": "https://grokbot.dev/marketplace/easy-apply-queue/",
      "detail_url": "https://grokbot.dev/api/v1/templates/easy-apply-queue.json",
      "headline": "Easy Apply Queue",
      "summary": "Sits down for one focused hour of LinkedIn applications and never repeats a listing",
      "categories": [
        "personal",
        "recruiting",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@HaseebMir91",
        "url": "https://x.com/HaseebMir91/status/2094891095733710950"
      },
      "share_url": "https://x.ai/bot/5RXN9P3CxnIIwgcmvVWEp",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T20:52:13.000Z",
      "updated_at": "2026-09-01T20:52:13.000Z"
    },
    {
      "type": "template",
      "slug": "poteto-style-chief-of-staff",
      "url": "https://grokbot.dev/marketplace/poteto-style-chief-of-staff/",
      "detail_url": "https://grokbot.dev/api/v1/templates/poteto-style-chief-of-staff.json",
      "headline": "Poteto-style Chief of Staff",
      "summary": "Runs your bench of bots lean: few timers, short specialists, coding sent elsewhere",
      "categories": [
        "personal",
        "ops",
        "productivity",
        "meta-bot",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@HaseebMir91",
        "url": "https://x.com/HaseebMir91/status/2094891095733710950"
      },
      "share_url": "https://x.ai/bot/Nk-vzuWqTvqSed-G8-Za5",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-09-01T20:52:13.000Z",
      "updated_at": "2026-09-01T20:52:13.000Z"
    },
    {
      "type": "template",
      "slug": "tuner",
      "url": "https://grokbot.dev/marketplace/tuner/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tuner.json",
      "headline": "Tuner",
      "summary": "Reads what your other bots have been producing and drafts fixes for the ones drifting",
      "categories": [
        "developer",
        "meta-bot",
        "productivity",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@humanmeteorite",
        "url": "https://x.com/humanmeteorite/status/2094888371147424048"
      },
      "share_url": "https://x.ai/bot/3n26nkAkMjk5EZcKJlo9w",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T20:41:23.000Z",
      "updated_at": "2026-09-01T20:41:23.000Z"
    },
    {
      "type": "template",
      "slug": "private-desk",
      "url": "https://grokbot.dev/marketplace/private-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/private-desk.json",
      "headline": "Private Desk",
      "summary": "Analyses material too sensitive to hand to an ordinary chat window",
      "categories": [
        "business",
        "developer",
        "data",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@useprismnetwork",
        "url": "https://x.com/useprismnetwork/status/2094887291881734180"
      },
      "share_url": "https://x.ai/bot/Tgl3sxrTsuAYL7MN8S3UT",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T20:37:06.000Z",
      "updated_at": "2026-09-01T20:37:06.000Z"
    },
    {
      "type": "template",
      "slug": "tinkabot",
      "url": "https://grokbot.dev/marketplace/tinkabot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tinkabot.json",
      "headline": "tinkabot",
      "summary": "Turns an API into a plugin your other bots can just pick up and use",
      "categories": [
        "developer",
        "engineering",
        "meta-bot",
        "automation",
        "productivity"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DenisLabelle",
        "url": "https://x.com/DenisLabelle/status/2094886573711970614"
      },
      "share_url": "https://x.ai/bot/br5f3C4mc75QCMEHaszXd",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T20:34:14.000Z",
      "updated_at": "2026-09-01T20:34:14.000Z"
    },
    {
      "type": "template",
      "slug": "scout",
      "url": "https://grokbot.dev/marketplace/scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/scout.json",
      "headline": "Scout",
      "summary": "Builds the weekly intelligence pack behind a client's social strategy, sourced throughout",
      "categories": [
        "marketer",
        "social-media",
        "research",
        "analytics",
        "content",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@zeuuss_01",
        "url": "https://x.com/zeuuss_01/status/2094881934442979832"
      },
      "share_url": "https://x.ai/bot/ywADCWWZP0Bcq6bOeQpGt",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-01T20:15:48.000Z",
      "updated_at": "2026-09-01T20:15:48.000Z"
    },
    {
      "type": "template",
      "slug": "madmax-mode",
      "url": "https://grokbot.dev/marketplace/madmax-mode/",
      "detail_url": "https://grokbot.dev/api/v1/templates/madmax-mode.json",
      "headline": "MadMax Mode",
      "summary": "Invents new bots for you, with a tight brief and every job filed where it belongs",
      "categories": [
        "developer",
        "meta-bot",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JoePro",
        "url": "https://x.com/JoePro/status/2094879004083765674"
      },
      "share_url": "https://x.ai/bot/pTe8gpPc_5SuwKkEszn18",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T20:04:10.000Z",
      "updated_at": "2026-09-01T20:04:10.000Z"
    },
    {
      "type": "template",
      "slug": "token-accountant",
      "url": "https://grokbot.dev/marketplace/token-accountant/",
      "detail_url": "https://grokbot.dev/api/v1/templates/token-accountant.json",
      "headline": "Token Accountant",
      "summary": "Watches your weekly model spend and warns you well before the allowance runs out",
      "categories": [
        "developer",
        "ops",
        "monitoring",
        "analytics",
        "saving-money",
        "finance",
        "scheduled",
        "back-office"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2094877897399885905"
      },
      "share_url": "https://x.ai/bot/zdnVIfLkNmRwZqqogojuc",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-01T19:59:46.000Z",
      "updated_at": "2026-09-01T19:59:46.000Z"
    },
    {
      "type": "template",
      "slug": "the-bobs",
      "url": "https://grokbot.dev/marketplace/the-bobs/",
      "detail_url": "https://grokbot.dev/api/v1/templates/the-bobs.json",
      "headline": "The Bobs",
      "summary": "Interviews every bot you own and says which ones are not earning their keep",
      "categories": [
        "developer",
        "ops",
        "business",
        "productivity",
        "decision-support",
        "back-office",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Boilerfan1234",
        "url": "https://x.com/Boilerfan1234/status/2094865448626008223"
      },
      "share_url": "https://x.ai/bot/Z0Faxo9DTX0KL7j7OHTWJ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T19:10:18.000Z",
      "updated_at": "2026-09-01T19:10:18.000Z"
    },
    {
      "type": "template",
      "slug": "forge-dev-factory",
      "url": "https://grokbot.dev/marketplace/forge-dev-factory/",
      "detail_url": "https://grokbot.dev/api/v1/templates/forge-dev-factory.json",
      "headline": "Forge (dev factory)",
      "summary": "Hand it a spec you have signed off, and collect the pull request in the morning",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DanKillenberger",
        "url": "https://x.com/DanKillenberger/status/2094819020193022397"
      },
      "share_url": "https://x.ai/bot/7GgZtqkhyLzKKMNUa7dhd",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-01T16:05:48.000Z",
      "updated_at": "2026-09-01T16:05:48.000Z"
    },
    {
      "type": "template",
      "slug": "copay-compass",
      "url": "https://grokbot.dev/marketplace/copay-compass/",
      "detail_url": "https://grokbot.dev/api/v1/templates/copay-compass.json",
      "headline": "Copay Compass",
      "summary": "Chases down help with the price of a cancer prescription and preps the paperwork",
      "categories": [
        "personal",
        "health",
        "finance",
        "saving-money",
        "monitoring",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MSaintjour",
        "url": "https://x.com/MSaintjour/status/2094802093622133104"
      },
      "share_url": "https://x.ai/bot/ehxj2Wdxq9M04jvaAqyBD",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T14:58:33.000Z",
      "updated_at": "2026-09-01T14:58:33.000Z"
    },
    {
      "type": "template",
      "slug": "ae-deal-bot",
      "url": "https://grokbot.dev/marketplace/ae-deal-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ae-deal-bot.json",
      "headline": "AE deal bot",
      "summary": "Grades your open opportunities against MEDDPICC and names the next move to make",
      "categories": [
        "sales",
        "business",
        "decision-support",
        "research",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2094802082750673227"
      },
      "share_url": "https://x.ai/bot/yXsqmCaODNkTEwtIbiXxe",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T14:58:30.000Z",
      "updated_at": "2026-09-01T14:58:30.000Z"
    },
    {
      "type": "template",
      "slug": "chief-growth-coach",
      "url": "https://grokbot.dev/marketplace/chief-growth-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-growth-coach.json",
      "headline": "Chief (growth coach)",
      "summary": "A quiet daily check-in that keeps you to one habit at a time",
      "categories": [
        "personal",
        "wellbeing",
        "growth",
        "learning",
        "health",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@rafdotworks",
        "url": "https://x.com/rafdotworks/status/2094791003760730132"
      },
      "share_url": "https://x.ai/bot/PIr44vmOtvynPX5Iym5Hx",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-01T14:14:29.000Z",
      "updated_at": "2026-09-01T14:14:29.000Z"
    },
    {
      "type": "template",
      "slug": "testbench",
      "url": "https://grokbot.dev/marketplace/testbench/",
      "detail_url": "https://grokbot.dev/api/v1/templates/testbench.json",
      "headline": "Testbench",
      "summary": "Gives a job too heavy for shared hardware its own GPU, then bills you the runtime",
      "categories": [
        "developer",
        "engineering",
        "data",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@useprismnetwork",
        "url": "https://x.com/useprismnetwork/status/2094790128296239563"
      },
      "share_url": "https://x.ai/bot/jbcYU5l_7qsLl49AIzh5q",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T14:11:00.000Z",
      "updated_at": "2026-09-01T14:11:00.000Z"
    },
    {
      "type": "template",
      "slug": "beatrix-kiddo",
      "url": "https://grokbot.dev/marketplace/beatrix-kiddo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/beatrix-kiddo.json",
      "headline": "Beatrix Kiddo",
      "summary": "Watches your deliveries and speaks up the moment one stops moving",
      "categories": [
        "business",
        "ops",
        "monitoring",
        "back-office",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2094782517794529780"
      },
      "share_url": "https://x.ai/bot/z4Chp77wqP5ASkBKpxOOk",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T13:40:46.000Z",
      "updated_at": "2026-09-01T13:40:46.000Z"
    },
    {
      "type": "template",
      "slug": "gus-fring",
      "url": "https://grokbot.dev/marketplace/gus-fring/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gus-fring.json",
      "headline": "Gus Fring",
      "summary": "Sits between finished work and the customer, and gives it a straight verdict",
      "categories": [
        "business",
        "ops",
        "monitoring",
        "back-office",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2094782521095463198"
      },
      "share_url": "https://x.ai/bot/Dhk5c79MEj0MRM484ZM1k",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T13:40:46.000Z",
      "updated_at": "2026-09-01T13:40:46.000Z"
    },
    {
      "type": "template",
      "slug": "porter",
      "url": "https://grokbot.dev/marketplace/porter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/porter.json",
      "headline": "Porter",
      "summary": "Lifts your whole line-up of bots across to another app or account",
      "categories": [
        "developer",
        "ops",
        "automation",
        "back-office",
        "productivity",
        "data",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@darylbleach",
        "url": "https://x.com/darylbleach/status/2094747777343324629"
      },
      "share_url": "https://x.ai/bot/cl7kIRbcIuP6jj2Zt8z5K",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T11:22:43.000Z",
      "updated_at": "2026-09-01T11:22:43.000Z"
    },
    {
      "type": "template",
      "slug": "token-ops",
      "url": "https://grokbot.dev/marketplace/token-ops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/token-ops.json",
      "headline": "Token Ops",
      "summary": "Audits every recurring job in your bot fleet and reins in the wasteful ones",
      "categories": [
        "developer",
        "ops",
        "monitoring",
        "saving-money",
        "automation",
        "analytics",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@adgapar",
        "url": "https://x.com/adgapar/status/2094734518687080758"
      },
      "share_url": "https://x.ai/bot/4mCuSlW34n6l3aYxYJCdj",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T10:30:02.000Z",
      "updated_at": "2026-09-01T10:30:02.000Z"
    },
    {
      "type": "template",
      "slug": "the-accountant",
      "url": "https://grokbot.dev/marketplace/the-accountant/",
      "detail_url": "https://grokbot.dev/api/v1/templates/the-accountant.json",
      "headline": "The Accountant",
      "summary": "Finds the bots in your fleet quietly draining your token budget",
      "categories": [
        "developer",
        "ops",
        "monitoring",
        "saving-money",
        "analytics",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@brstorrie",
        "url": "https://x.com/brstorrie/status/2094654945488252959"
      },
      "share_url": "https://x.ai/bot/Y_R1Ya9SIzQZguGTV5NCX",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T05:13:50.000Z",
      "updated_at": "2026-09-01T05:13:50.000Z"
    },
    {
      "type": "template",
      "slug": "sumosign",
      "url": "https://grokbot.dev/marketplace/sumosign/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sumosign.json",
      "headline": "SumoSign",
      "summary": "Route a document to a live person for signing, straight from chat",
      "categories": [
        "business",
        "ops",
        "back-office",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SumoSign",
        "url": "https://x.com/SumoSign/status/2094633755004821890"
      },
      "share_url": "https://x.ai/bot/Uicr9Dc3FKOmsMfbN_NHB",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T03:49:38.000Z",
      "updated_at": "2026-09-01T03:49:38.000Z"
    },
    {
      "type": "template",
      "slug": "2nd-brain",
      "url": "https://grokbot.dev/marketplace/2nd-brain/",
      "detail_url": "https://grokbot.dev/api/v1/templates/2nd-brain.json",
      "headline": "2nd Brain",
      "summary": "Distils everything you read into a linked wiki that answers your questions",
      "categories": [
        "personal",
        "knowledge-base",
        "research",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@LeTerryBZH",
        "url": "https://x.com/LeTerryBZH/status/2094616823803314592"
      },
      "share_url": "https://x.ai/bot/c4fYduVVic2YtbcjXquD0",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T02:42:21.000Z",
      "updated_at": "2026-09-01T02:42:21.000Z"
    },
    {
      "type": "template",
      "slug": "steer",
      "url": "https://grokbot.dev/marketplace/steer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/steer.json",
      "headline": "STEER",
      "summary": "Mark up the flat, machine-sounding lines in a draft and get them rewritten",
      "categories": [
        "personal",
        "creator",
        "content",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@bfrench",
        "url": "https://x.com/bfrench/status/2094591383080403402"
      },
      "share_url": "https://x.ai/bot/mhzjt-Pa01Ds8EJ0zJrcz",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T01:01:16.000Z",
      "updated_at": "2026-09-01T01:01:16.000Z"
    },
    {
      "type": "template",
      "slug": "unifi-aq-trmnl-integration",
      "url": "https://grokbot.dev/marketplace/unifi-aq-trmnl-integration/",
      "detail_url": "https://grokbot.dev/api/v1/templates/unifi-aq-trmnl-integration.json",
      "headline": "unifi AQ trmnl integration",
      "summary": "Puts your UniFi air-quality readings on a TRMNL e-ink display",
      "categories": [
        "developer",
        "engineering",
        "home",
        "automation",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@rrrkren",
        "url": "https://x.com/rrrkren/status/2094584750040388071"
      },
      "share_url": "https://x.ai/bot/NU02qQ9iahZtAM0i0x1KT",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T00:34:54.000Z",
      "updated_at": "2026-09-01T00:34:54.000Z"
    },
    {
      "type": "template",
      "slug": "grok-bot-post-watcher",
      "url": "https://grokbot.dev/marketplace/grok-bot-post-watcher/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-bot-post-watcher.json",
      "headline": "最值得关注的Grok Bot 推文？",
      "summary": "A twice-daily Chinese-language sweep of top Grok Bot accounts",
      "categories": [
        "personal",
        "social-media",
        "monitoring",
        "news",
        "research",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MaiYangAI",
        "url": "https://x.com/MaiYangAI/status/2094583123392761968"
      },
      "share_url": "https://x.ai/bot/lFDR77qKaT3Iglzv9pUac",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-09-01T00:28:26.000Z",
      "updated_at": "2026-09-01T00:28:26.000Z"
    },
    {
      "type": "template",
      "slug": "librarian",
      "url": "https://grokbot.dev/marketplace/librarian/",
      "detail_url": "https://grokbot.dev/api/v1/templates/librarian.json",
      "headline": "Librarian",
      "summary": "Photograph your bookshelves and get a browsable personal library site",
      "categories": [
        "personal",
        "knowledge-base",
        "learning",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ShaneMac",
        "url": "https://x.com/ShaneMac/status/2094582528203997514"
      },
      "share_url": "https://x.ai/bot/suKVjDAR-hSr_PTBxgdRw",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-09-01T00:26:04.000Z",
      "updated_at": "2026-09-01T00:26:04.000Z"
    },
    {
      "type": "template",
      "slug": "homeroom",
      "url": "https://grokbot.dev/marketplace/homeroom/",
      "detail_url": "https://grokbot.dev/api/v1/templates/homeroom.json",
      "headline": "Homeroom",
      "summary": "A nightly school board for parents, run off your own portal login",
      "categories": [
        "personal",
        "family",
        "productivity",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ahalvor",
        "url": "https://x.com/ahalvor/status/2094564057575739567"
      },
      "share_url": "https://x.ai/bot/IciOb-9jMtlkc1RJj6MQe",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T23:12:41.000Z",
      "updated_at": "2026-08-31T23:12:41.000Z"
    },
    {
      "type": "template",
      "slug": "usage-pool-orchestrator",
      "url": "https://grokbot.dev/marketplace/usage-pool-orchestrator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/usage-pool-orchestrator.json",
      "headline": "Usage-pool orchestrator",
      "summary": "Routes big coding jobs to your CLI subscriptions, not Grok credits",
      "categories": [
        "developer",
        "automation",
        "saving-money",
        "engineering",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JordanHall_dev",
        "url": "https://x.com/JordanHall_dev/status/2094562218889080932"
      },
      "share_url": "https://x.ai/bot/Nx4wpKeM_NYx577xlJFMD",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T23:05:22.000Z",
      "updated_at": "2026-08-31T23:05:22.000Z"
    },
    {
      "type": "template",
      "slug": "cos",
      "url": "https://grokbot.dev/marketplace/cos/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cos.json",
      "headline": "CoS",
      "summary": "Keeps your agent bench, calendar and inbox on one weekday rhythm",
      "categories": [
        "personal",
        "productivity",
        "back-office",
        "calendar",
        "email",
        "agent-team",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@theaaron",
        "url": "https://x.com/theaaron/status/2094547674766929996"
      },
      "share_url": "https://x.ai/bot/eiVFbd0nIdH2gzSwHOs0D",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-31T22:07:35.000Z",
      "updated_at": "2026-08-31T22:07:35.000Z"
    },
    {
      "type": "template",
      "slug": "set-up",
      "url": "https://grokbot.dev/marketplace/set-up/",
      "detail_url": "https://grokbot.dev/api/v1/templates/set-up.json",
      "headline": "Set Up",
      "summary": "Interview-style onboarding that assembles your first bot roster",
      "categories": [
        "personal",
        "productivity",
        "automation",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@theaaron",
        "url": "https://x.com/theaaron/status/2094547674766929996"
      },
      "share_url": "https://x.ai/bot/BsExflSUXpW0hs21OTBzu",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T22:07:35.000Z",
      "updated_at": "2026-08-31T22:07:35.000Z"
    },
    {
      "type": "template",
      "slug": "grok-for-seo-geo-paid-ads-and-shopify",
      "url": "https://grokbot.dev/marketplace/grok-for-seo-geo-paid-ads-and-shopify/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-for-seo-geo-paid-ads-and-shopify.json",
      "headline": "Grok for SEO, GEO, paid ads and Shopify",
      "summary": "Reviews ads, search and Shopify performance from a single place",
      "categories": [
        "marketer",
        "business",
        "seo",
        "growth",
        "analytics",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@irabukht",
        "url": "https://x.com/irabukht/status/2094540233429619144"
      },
      "share_url": "https://x.ai/bot/dep-tU0gmIPgiqNsvS4N4",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T21:38:00.000Z",
      "updated_at": "2026-08-31T21:38:00.000Z"
    },
    {
      "type": "template",
      "slug": "grok-build",
      "url": "https://grokbot.dev/marketplace/grok-build/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-build.json",
      "headline": "Grok Build",
      "summary": "Gives the Grok Build CLI its own machine to work on",
      "categories": [
        "developer",
        "engineering",
        "research",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BillZanetti",
        "url": "https://x.com/BillZanetti/status/2094534653646356788"
      },
      "share_url": "https://x.ai/bot/eydijdzrfgtnmlnUyPSI-",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T21:15:50.000Z",
      "updated_at": "2026-08-31T21:15:50.000Z"
    },
    {
      "type": "template",
      "slug": "sous-chef",
      "url": "https://grokbot.dev/marketplace/sous-chef/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sous-chef.json",
      "headline": "Sous Chef",
      "summary": "Plans the week's dinners, writes the shopping list, and can order it",
      "categories": [
        "personal",
        "food",
        "shopping",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@amberdawn1786",
        "url": "https://x.com/amberdawn1786/status/2094527135608164462"
      },
      "share_url": "https://x.ai/bot/RuCu3IpKAvrx00H0MDI0t",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T20:45:58.000Z",
      "updated_at": "2026-08-31T20:45:58.000Z"
    },
    {
      "type": "template",
      "slug": "research-runner",
      "url": "https://grokbot.dev/marketplace/research-runner/",
      "detail_url": "https://grokbot.dev/api/v1/templates/research-runner.json",
      "headline": "Research Runner",
      "summary": "Runs heavy research workloads on GPU capacity rented from Prism Network",
      "categories": [
        "developer",
        "research",
        "data",
        "crypto",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@useprismnetwork",
        "url": "https://x.com/useprismnetwork/status/2094504419480015231"
      },
      "share_url": "https://x.ai/bot/P2qgQokuPHVJhrkmRDmLv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T19:15:42.000Z",
      "updated_at": "2026-08-31T19:15:42.000Z"
    },
    {
      "type": "template",
      "slug": "latch",
      "url": "https://grokbot.dev/marketplace/latch/",
      "detail_url": "https://grokbot.dev/api/v1/templates/latch.json",
      "headline": "Latch",
      "summary": "Gets a first-time Grok Bot user set up and actually working in one sitting",
      "categories": [
        "personal",
        "developer",
        "productivity",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@OliverKorzen",
        "url": "https://x.com/OliverKorzen/status/2094492533439230267"
      },
      "share_url": "https://x.ai/bot/9nbLm_04EvjnolE9oevTT",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T18:28:28.000Z",
      "updated_at": "2026-08-31T18:28:28.000Z"
    },
    {
      "type": "template",
      "slug": "lingxi-s-engineer-bot",
      "url": "https://grokbot.dev/marketplace/lingxi-s-engineer-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lingxi-s-engineer-bot.json",
      "headline": "Lingxi's Engineer Bot",
      "summary": "A hands-off engineering lead that spins up cloud coding agents and drives your PRs",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "monitoring",
        "agent-team",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lingxi",
        "url": "https://x.com/lingxi/status/2094489411245461677"
      },
      "share_url": "https://x.ai/bot/fY1xWwCLzDDGVe3GwH78j",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-31T18:16:04.000Z",
      "updated_at": "2026-08-31T18:16:04.000Z"
    },
    {
      "type": "template",
      "slug": "nightly-audit-engineer",
      "url": "https://grokbot.dev/marketplace/nightly-audit-engineer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/nightly-audit-engineer.json",
      "headline": "Nightly Audit Engineer",
      "summary": "Reads your repository overnight and lands one small cleanup per area",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "research",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lingxi",
        "url": "https://x.com/lingxi/status/2094489412537327828"
      },
      "share_url": "https://x.ai/bot/hkGSHcqKjGc5dm3ugNc2U",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T18:16:04.000Z",
      "updated_at": "2026-08-31T18:16:04.000Z"
    },
    {
      "type": "template",
      "slug": "substreams",
      "url": "https://grokbot.dev/marketplace/substreams/",
      "detail_url": "https://grokbot.dev/api/v1/templates/substreams.json",
      "headline": "substreams",
      "summary": "Build and run Substreams blockchain data pipelines from chat",
      "categories": [
        "developer",
        "engineering",
        "data",
        "crypto",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@graphtronauts_c",
        "url": "https://x.com/graphtronauts_c/status/2094476749052555631"
      },
      "share_url": "https://x.ai/bot/4ZzeuafN9Z1boU8smYIXv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T17:25:45.000Z",
      "updated_at": "2026-08-31T17:25:45.000Z"
    },
    {
      "type": "template",
      "slug": "steve-j",
      "url": "https://grokbot.dev/marketplace/steve-j/",
      "detail_url": "https://grokbot.dev/api/v1/templates/steve-j.json",
      "headline": "Steve J",
      "summary": "A demanding boss for the rest of your bot roster",
      "categories": [
        "developer",
        "personal",
        "meta-bot",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AhuraDeus",
        "url": "https://x.com/AhuraDeus/status/2094468731934003649"
      },
      "share_url": "https://x.ai/bot/cuEYUcYmz-497oKWVfWX2",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T16:53:53.000Z",
      "updated_at": "2026-08-31T16:53:53.000Z"
    },
    {
      "type": "template",
      "slug": "cookie-monster",
      "url": "https://grokbot.dev/marketplace/cookie-monster/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cookie-monster.json",
      "headline": "Cookie Monster",
      "summary": "Stops your browser-driven bots from stalling at login walls",
      "categories": [
        "developer",
        "ops",
        "automation",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2094457258025631943"
      },
      "share_url": "https://x.ai/bot/55t0IuxxlT7BWffNVOKai",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T16:08:18.000Z",
      "updated_at": "2026-08-31T16:08:18.000Z"
    },
    {
      "type": "template",
      "slug": "figma-bro",
      "url": "https://grokbot.dev/marketplace/figma-bro/",
      "detail_url": "https://grokbot.dev/api/v1/templates/figma-bro.json",
      "headline": "figma bro",
      "summary": "A design partner that works inside Figma, not around it",
      "categories": [
        "creator",
        "developer",
        "design",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@johnbai",
        "url": "https://x.com/johnbai/status/2094456490115408172"
      },
      "share_url": "https://x.ai/bot/VHMdjIGjGpgDSJR7dW6Gz",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T16:05:15.000Z",
      "updated_at": "2026-08-31T16:05:15.000Z"
    },
    {
      "type": "template",
      "slug": "demo-video",
      "url": "https://grokbot.dev/marketplace/demo-video/",
      "detail_url": "https://grokbot.dev/api/v1/templates/demo-video.json",
      "headline": "Demo Video",
      "summary": "Turns a walkthrough of your web app into a narrated, captioned demo video",
      "categories": [
        "creator",
        "content",
        "video",
        "productivity",
        "marketer",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KdJadeja911",
        "url": "https://x.com/KdJadeja911/status/2094455116925657592"
      },
      "share_url": "https://x.ai/bot/htSXUJUQlVr60m9L_unBa",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T15:59:47.000Z",
      "updated_at": "2026-08-31T15:59:47.000Z"
    },
    {
      "type": "template",
      "slug": "usage-auditor",
      "url": "https://grokbot.dev/marketplace/usage-auditor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/usage-auditor.json",
      "headline": "Usage Auditor",
      "summary": "Weekly audit of every routine your team runs, ranked by what it costs you",
      "categories": [
        "developer",
        "ops",
        "saving-money",
        "monitoring",
        "analytics",
        "meta-bot",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@maxjean__",
        "url": "https://x.com/maxjean__/status/2094450310232055860"
      },
      "share_url": "https://x.ai/bot/M5vd5Dp9Et4EZQ3Ik3Hn2",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T15:40:41.000Z",
      "updated_at": "2026-08-31T15:40:41.000Z"
    },
    {
      "type": "template",
      "slug": "fantasy-gm",
      "url": "https://grokbot.dev/marketplace/fantasy-gm/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fantasy-gm.json",
      "headline": "Fantasy GM",
      "summary": "Answers roster and matchup questions through the assistant you already talk to",
      "categories": [
        "personal",
        "agent-team",
        "news",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TylerNishida",
        "url": "https://x.com/TylerNishida/status/2094446128771342374"
      },
      "share_url": "https://x.ai/bot/vmQChAUGO26cUDqdSqYlH",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-31T15:24:04.000Z",
      "updated_at": "2026-08-31T15:24:04.000Z"
    },
    {
      "type": "template",
      "slug": "twitter-automations",
      "url": "https://grokbot.dev/marketplace/twitter-automations/",
      "detail_url": "https://grokbot.dev/api/v1/templates/twitter-automations.json",
      "headline": "Twitter Automations",
      "summary": "Three creator automations for X: reply-triggered DMs, follower screening and a watchlist",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "automation",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@theadvisorbtc",
        "url": "https://x.com/theadvisorbtc/status/2094434891622457825"
      },
      "share_url": "https://x.ai/bot/e5dNa8n9x4U93UHaCb5nS",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T14:39:25.000Z",
      "updated_at": "2026-08-31T14:39:25.000Z"
    },
    {
      "type": "template",
      "slug": "palette",
      "url": "https://grokbot.dev/marketplace/palette/",
      "detail_url": "https://grokbot.dev/api/v1/templates/palette.json",
      "headline": "Palette",
      "summary": "Pulls a usable four-part colour scheme out of any reference photo",
      "categories": [
        "creator",
        "design",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@subforti",
        "url": "https://x.com/subforti/status/2094413257482080263"
      },
      "share_url": "https://x.ai/bot/yfrTgGSwB_DZNUxx0g05V",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T13:13:27.000Z",
      "updated_at": "2026-08-31T13:13:27.000Z"
    },
    {
      "type": "template",
      "slug": "blunt",
      "url": "https://grokbot.dev/marketplace/blunt/",
      "detail_url": "https://grokbot.dev/api/v1/templates/blunt.json",
      "headline": "Blunt",
      "summary": "Paste a landing page address and get a senior marketer's unvarnished critique",
      "categories": [
        "marketer",
        "business",
        "growth",
        "decision-support",
        "content",
        "design",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Talsiach",
        "url": "https://x.com/Talsiach/status/2094408059657326944"
      },
      "share_url": "https://x.ai/bot/N0J32FbnVRuetJi1oJggh",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T12:52:48.000Z",
      "updated_at": "2026-08-31T12:52:48.000Z"
    },
    {
      "type": "template",
      "slug": "brake",
      "url": "https://grokbot.dev/marketplace/brake/",
      "detail_url": "https://grokbot.dev/api/v1/templates/brake.json",
      "headline": "Brake",
      "summary": "Names the recurring job quietly draining your Grok Bot allowance and tells you to kill it",
      "categories": [
        "developer",
        "ops",
        "saving-money",
        "productivity",
        "monitoring",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@FantomBuildz",
        "url": "https://x.com/FantomBuildz/status/2094396074542662068"
      },
      "share_url": "https://x.ai/bot/ig-dwKjUc7doBIDhiMi9Z",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T12:05:10.000Z",
      "updated_at": "2026-08-31T12:05:10.000Z"
    },
    {
      "type": "template",
      "slug": "podcast-summary-bot",
      "url": "https://grokbot.dev/marketplace/podcast-summary-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/podcast-summary-bot.json",
      "headline": "Podcast Summary Bot",
      "summary": "Paste a podcast link and get a TLDR plus the takeaways worth keeping",
      "categories": [
        "personal",
        "creator",
        "research",
        "productivity",
        "learning",
        "content",
        "knowledge-base",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@theadvisorbtc",
        "url": "https://x.com/theadvisorbtc/status/2094388925523775694"
      },
      "share_url": "https://x.ai/bot/CsyAhw5YQaVLeMSnMYwgA",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T11:36:46.000Z",
      "updated_at": "2026-08-31T11:36:46.000Z"
    },
    {
      "type": "template",
      "slug": "senior-analyst",
      "url": "https://grokbot.dev/marketplace/senior-analyst/",
      "detail_url": "https://grokbot.dev/api/v1/templates/senior-analyst.json",
      "headline": "Senior Analyst",
      "summary": "Reads financial paperwork into a spreadsheet and drafts a cited memo",
      "categories": [
        "business",
        "investor",
        "finance",
        "data",
        "analytics",
        "automation",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tobias_pfuetze",
        "url": "https://x.com/tobias_pfuetze/status/2094386098201911719"
      },
      "share_url": "https://x.ai/bot/Q2xW8BIDffTjbDVXZYZhV",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T11:25:32.000Z",
      "updated_at": "2026-08-31T11:25:32.000Z"
    },
    {
      "type": "template",
      "slug": "grok-vm-maintenance",
      "url": "https://grokbot.dev/marketplace/grok-vm-maintenance/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-vm-maintenance.json",
      "headline": "Grok VM maintenance",
      "summary": "Sysadmin sidekick for the Linux VM behind your bot: health, disk, services, packages",
      "categories": [
        "developer",
        "ops",
        "engineering",
        "monitoring",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@old_pgmrs_will",
        "url": "https://x.com/old_pgmrs_will/status/2094360885884322286"
      },
      "share_url": "https://x.ai/bot/9UZp5k0Fp0LYmkyos5swQ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T09:45:21.000Z",
      "updated_at": "2026-08-31T09:45:21.000Z"
    },
    {
      "type": "template",
      "slug": "developer",
      "url": "https://grokbot.dev/marketplace/developer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/developer.json",
      "headline": "Developer",
      "summary": "Farms coding work out to build labs and mirrors every task on a Linear board",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "productivity",
        "monitoring",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@m_check1B",
        "url": "https://x.com/m_check1B/status/2094337521123508268"
      },
      "share_url": "https://x.ai/bot/0fYZ_kKkiXNbLn_KBD3f3",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-31T08:12:30.000Z",
      "updated_at": "2026-08-31T08:12:30.000Z"
    },
    {
      "type": "template",
      "slug": "grok-deck",
      "url": "https://grokbot.dev/marketplace/grok-deck/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-deck.json",
      "headline": "Grok Deck",
      "summary": "Turns your talking points into a browser-ready HTML slide deck",
      "categories": [
        "creator",
        "design",
        "content",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MaiYangAI",
        "url": "https://x.com/MaiYangAI/status/2094305288266666452"
      },
      "share_url": "https://x.ai/bot/Ja9NzNTRz2ozzQLNfrJwI",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T06:04:25.000Z",
      "updated_at": "2026-08-31T06:04:25.000Z"
    },
    {
      "type": "template",
      "slug": "revenuedog",
      "url": "https://grokbot.dev/marketplace/revenuedog/",
      "detail_url": "https://grokbot.dev/api/v1/templates/revenuedog.json",
      "headline": "RevenueDog",
      "summary": "Wake up to yesterday's subscription numbers and one fix worth trying",
      "categories": [
        "developer",
        "business",
        "analytics",
        "finance",
        "data",
        "decision-support",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lexrus",
        "url": "https://x.com/lexrus/status/2094285817221111992"
      },
      "share_url": "https://x.ai/bot/IDFtkYcsl7MpfdfTx09RT",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T04:47:03.000Z",
      "updated_at": "2026-08-31T04:47:03.000Z"
    },
    {
      "type": "template",
      "slug": "errol",
      "url": "https://grokbot.dev/marketplace/errol/",
      "detail_url": "https://grokbot.dev/api/v1/templates/errol.json",
      "headline": "Errol",
      "summary": "Drills a children's catechism twice a day for family worship",
      "categories": [
        "personal",
        "family",
        "learning",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@zachmllr",
        "url": "https://x.com/zachmllr/status/2094270994777030966"
      },
      "share_url": "https://x.ai/bot/mQoLg90Pj5Cn2Gso4AkoQ",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T03:48:09.000Z",
      "updated_at": "2026-08-31T03:48:09.000Z"
    },
    {
      "type": "template",
      "slug": "flora",
      "url": "https://grokbot.dev/marketplace/flora/",
      "detail_url": "https://grokbot.dev/api/v1/templates/flora.json",
      "headline": "Flora",
      "summary": "Tracks every houseplant you own and nudges you before one goes thirsty",
      "categories": [
        "personal",
        "home",
        "monitoring",
        "life-hacks",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RichSilver",
        "url": "https://x.com/RichSilver/status/2094267086591680962"
      },
      "share_url": "https://x.ai/bot/HC7kphHSxDzb639YlmI6O",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T03:32:37.000Z",
      "updated_at": "2026-08-31T03:32:37.000Z"
    },
    {
      "type": "template",
      "slug": "blockchain-data-expert",
      "url": "https://grokbot.dev/marketplace/blockchain-data-expert/",
      "detail_url": "https://grokbot.dev/api/v1/templates/blockchain-data-expert.json",
      "headline": "Blockchain Data Expert",
      "summary": "Answers on-chain questions by querying The Graph's subgraphs directly",
      "categories": [
        "developer",
        "crypto",
        "data",
        "research",
        "analytics",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@data_nexus",
        "url": "https://x.com/data_nexus/status/2094265024227192946"
      },
      "share_url": "https://x.ai/bot/eyFr_G8h9UmrQHNpZpNfx",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T03:24:25.000Z",
      "updated_at": "2026-08-31T03:24:25.000Z"
    },
    {
      "type": "template",
      "slug": "bouncer",
      "url": "https://grokbot.dev/marketplace/bouncer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bouncer.json",
      "headline": "Bouncer",
      "summary": "Vets another bot's share link before you let it into your fleet",
      "categories": [
        "personal",
        "developer",
        "decision-support",
        "on-demand",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@bradshannon",
        "url": "https://x.com/bradshannon/status/2094260531305578886"
      },
      "share_url": "https://x.ai/bot/cGcG0msqfz7o7J3QMLhbE",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T03:06:34.000Z",
      "updated_at": "2026-08-31T03:06:34.000Z"
    },
    {
      "type": "template",
      "slug": "collins",
      "url": "https://grokbot.dev/marketplace/collins/",
      "detail_url": "https://grokbot.dev/api/v1/templates/collins.json",
      "headline": "Collins",
      "summary": "Works through Hercules Collins's 1680 catechism, one question a day",
      "categories": [
        "personal",
        "family",
        "learning",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@zachmllr",
        "url": "https://x.com/zachmllr/status/2094258928922116418"
      },
      "share_url": "https://x.ai/bot/D6lddHs6lfM0k7Cj3P6j3",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T03:00:12.000Z",
      "updated_at": "2026-08-31T03:00:12.000Z"
    },
    {
      "type": "template",
      "slug": "keach",
      "url": "https://grokbot.dev/marketplace/keach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/keach.json",
      "headline": "Keach",
      "summary": "A morning drill through Keach's 1693 catechism, one question at a time",
      "categories": [
        "personal",
        "family",
        "learning",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@zachmllr",
        "url": "https://x.com/zachmllr/status/2094258800492429614"
      },
      "share_url": "https://x.ai/bot/sAxCT93K8i7gwctmtAroD",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T02:59:42.000Z",
      "updated_at": "2026-08-31T02:59:42.000Z"
    },
    {
      "type": "template",
      "slug": "sterling",
      "url": "https://grokbot.dev/marketplace/sterling/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sterling.json",
      "headline": "Sterling",
      "summary": "An understated money sidekick that watches the balances and stays hands-off",
      "categories": [
        "personal",
        "finance",
        "decision-support",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jchybow",
        "url": "https://x.com/jchybow/status/2094256023498326357"
      },
      "share_url": "https://x.ai/bot/WNJl5y33yqdOp3CnhR4-k",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T02:48:40.000Z",
      "updated_at": "2026-08-31T02:48:40.000Z"
    },
    {
      "type": "template",
      "slug": "watch-later-deck",
      "url": "https://grokbot.dev/marketplace/watch-later-deck/",
      "detail_url": "https://grokbot.dev/api/v1/templates/watch-later-deck.json",
      "headline": "Watch Later Deck",
      "summary": "Splits a bloated YouTube Watch Later list into four swipeable decks",
      "categories": [
        "personal",
        "youtube",
        "video",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jordanwcjackson",
        "url": "https://x.com/jordanwcjackson/status/2094246245199995176"
      },
      "share_url": "https://x.ai/bot/9-kjE0PVBDhmW-7Fck_R9",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T02:09:48.000Z",
      "updated_at": "2026-08-31T02:09:48.000Z"
    },
    {
      "type": "template",
      "slug": "github-trending-scout",
      "url": "https://grokbot.dev/marketplace/github-trending-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/github-trending-scout.json",
      "headline": "github 优秀仓库",
      "summary": "Sweeps GitHub's trending page each morning and writes up the repos that matter",
      "categories": [
        "developer",
        "monitoring",
        "research",
        "engineering",
        "knowledge-base",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ios_1261142602",
        "url": "https://x.com/ios_1261142602/status/2094243852932776384"
      },
      "share_url": "https://x.ai/bot/D9HYH2jAmGiKw7e499mrE",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-31T02:00:18.000Z",
      "updated_at": "2026-08-31T02:00:18.000Z"
    },
    {
      "type": "template",
      "slug": "claudey",
      "url": "https://grokbot.dev/marketplace/claudey/",
      "detail_url": "https://grokbot.dev/api/v1/templates/claudey.json",
      "headline": "Claudey",
      "summary": "Hands frontend and architecture jobs to the Claude Code CLI, then opens the PR",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@farzyness",
        "url": "https://x.com/farzyness/status/2094240859243913669"
      },
      "share_url": "https://x.ai/bot/OR72i4SNc0_F1IzbCfg-D",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T01:48:24.000Z",
      "updated_at": "2026-08-31T01:48:24.000Z"
    },
    {
      "type": "template",
      "slug": "feedback",
      "url": "https://grokbot.dev/marketplace/feedback/",
      "detail_url": "https://grokbot.dev/api/v1/templates/feedback.json",
      "headline": "Feedback",
      "summary": "Turns a bug you have already confirmed into a clean report, filed with the right team",
      "categories": [
        "developer",
        "support",
        "automation",
        "productivity",
        "engineering",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nytemodeonly",
        "url": "https://x.com/nytemodeonly/status/2094225527984820492"
      },
      "share_url": "https://x.ai/bot/_-3KKbHbnSRzrS_8KFugU",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-31T00:47:29.000Z",
      "updated_at": "2026-08-31T00:47:29.000Z"
    },
    {
      "type": "template",
      "slug": "mercury",
      "url": "https://grokbot.dev/marketplace/mercury/",
      "detail_url": "https://grokbot.dev/api/v1/templates/mercury.json",
      "headline": "Mercury",
      "summary": "A standing tech lead that holds the system picture and delegates the coding out",
      "categories": [
        "developer",
        "engineering",
        "agent-team",
        "decision-support",
        "productivity"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@chiefjeeb",
        "url": "https://x.com/chiefjeeb/status/2094223658151502326"
      },
      "share_url": "https://x.ai/bot/lk1yHfim5Ayra0Q0QlN3L",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-31T00:40:03.000Z",
      "updated_at": "2026-08-31T00:40:03.000Z"
    },
    {
      "type": "plugin",
      "slug": "prism-network",
      "url": "https://grokbot.dev/plugins/prism-network/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/prism-network.json",
      "headline": "Prism Network",
      "summary": "Live GPU capacity, per-second prices, and a public receipt for every run.",
      "categories": [
        "engineering"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "prismnetwork.tech",
        "url": "https://prismnetwork.tech"
      },
      "added_at": "2026-08-31T00:00:00Z",
      "updated_at": "2026-08-31T00:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "treg-to",
      "url": "https://grokbot.dev/plugins/treg-to/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/treg-to.json",
      "headline": "treg.to",
      "summary": "2,745 external APIs your Grok Bot can call with no provider keys, at the provider's rate",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "treg.to",
        "url": "https://treg.to/agents/grok-bot"
      },
      "added_at": "2026-08-31T00:00:00Z",
      "updated_at": "2026-08-31T00:00:00Z"
    },
    {
      "type": "template",
      "slug": "home-front",
      "url": "https://grokbot.dev/marketplace/home-front/",
      "detail_url": "https://grokbot.dev/api/v1/templates/home-front.json",
      "headline": "Home Front",
      "summary": "Keeps a veteran household on top of VA claims, visits and earned perks",
      "categories": [
        "personal",
        "family",
        "monitoring",
        "saving-money",
        "health",
        "calendar",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Diego_F_Aguirre",
        "url": "https://x.com/Diego_F_Aguirre/status/2094203554504319211"
      },
      "share_url": "https://x.ai/bot/eREHCFAQlq8jS3P6bnNSL",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-30T23:20:10.000Z",
      "updated_at": "2026-08-30T23:20:10.000Z"
    },
    {
      "type": "template",
      "slug": "subcut",
      "url": "https://grokbot.dev/marketplace/subcut/",
      "detail_url": "https://grokbot.dev/api/v1/templates/subcut.json",
      "headline": "SubCut",
      "summary": "Audits your email for silent subscription drain and names what to cut",
      "categories": [
        "personal",
        "saving-money",
        "email",
        "finance",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tahaabuilds",
        "url": "https://x.com/tahaabuilds/status/2094199255561089356"
      },
      "share_url": "https://x.ai/bot/MzuJZpvaIK2KpexUVY-V0",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T23:03:05.000Z",
      "updated_at": "2026-08-30T23:03:05.000Z"
    },
    {
      "type": "template",
      "slug": "copywriter",
      "url": "https://grokbot.dev/marketplace/copywriter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/copywriter.json",
      "headline": "Copywriter",
      "summary": "Turns a ranked story into slide-by-slide carousel copy and a caption",
      "categories": [
        "creator",
        "marketer",
        "content",
        "social-media",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@adamuchigabriel",
        "url": "https://x.com/adamuchigabriel/status/2094182045782073384"
      },
      "share_url": "https://x.ai/bot/DlOMT_kOepSKYdB3P0YEv",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-30T21:54:42.000Z",
      "updated_at": "2026-08-30T21:54:42.000Z"
    },
    {
      "type": "template",
      "slug": "engenheiro-audiovisual",
      "url": "https://grokbot.dev/marketplace/engenheiro-audiovisual/",
      "detail_url": "https://grokbot.dev/api/v1/templates/engenheiro-audiovisual.json",
      "headline": "Engenheiro Audiovisual",
      "summary": "Builds the carousel and single-post artwork from a finished copy brief",
      "categories": [
        "creator",
        "design",
        "content",
        "social-media",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@adamuchigabriel",
        "url": "https://x.com/adamuchigabriel/status/2094182045782073384"
      },
      "share_url": "https://x.ai/bot/w1pUFhCx2VCJgv8Yhvzu6",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-30T21:54:42.000Z",
      "updated_at": "2026-08-30T21:54:42.000Z"
    },
    {
      "type": "template",
      "slug": "minerador-de-conteudo",
      "url": "https://grokbot.dev/marketplace/minerador-de-conteudo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/minerador-de-conteudo.json",
      "headline": "Minerador de conteúdo",
      "summary": "Mines a day of AI news and ranks what actually deserves a post",
      "categories": [
        "creator",
        "marketer",
        "research",
        "content",
        "news",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@adamuchigabriel",
        "url": "https://x.com/adamuchigabriel/status/2094182045782073384"
      },
      "share_url": "https://x.ai/bot/ut8BUqwZlAthhIt8s7YNX",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-30T21:54:42.000Z",
      "updated_at": "2026-08-30T21:54:42.000Z"
    },
    {
      "type": "template",
      "slug": "social-media",
      "url": "https://grokbot.dev/marketplace/social-media/",
      "detail_url": "https://grokbot.dev/api/v1/templates/social-media.json",
      "headline": "Social Media",
      "summary": "Queues the finished posts and pushes each one live at the right local hour",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "content",
        "automation",
        "scheduled",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@adamuchigabriel",
        "url": "https://x.com/adamuchigabriel/status/2094182045782073384"
      },
      "share_url": "https://x.ai/bot/4vmlCUGEy8sWSWsj2j5tz",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-30T21:54:42.000Z",
      "updated_at": "2026-08-30T21:54:42.000Z"
    },
    {
      "type": "template",
      "slug": "4-panez",
      "url": "https://grokbot.dev/marketplace/4-panez/",
      "detail_url": "https://grokbot.dev/api/v1/templates/4-panez.json",
      "headline": "4 Panez",
      "summary": "Turns one scene idea into a wide panorama sliced into four swipeable panels",
      "categories": [
        "creator",
        "content",
        "design",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2094179990782759104"
      },
      "share_url": "https://x.ai/bot/91R37-rUOh9sS1tZkIF9d",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T21:46:32.000Z",
      "updated_at": "2026-08-30T21:46:32.000Z"
    },
    {
      "type": "template",
      "slug": "austin-parent",
      "url": "https://grokbot.dev/marketplace/austin-parent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/austin-parent.json",
      "headline": "Austin Parent",
      "summary": "A household chief of staff for families raising kids in Austin",
      "categories": [
        "personal",
        "productivity",
        "family",
        "calendar",
        "events",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ChadWittman",
        "url": "https://x.com/ChadWittman/status/2094168314842935637"
      },
      "share_url": "https://x.ai/bot/7yCzCeGQTMD6oNKSPcFqj",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T21:00:08.000Z",
      "updated_at": "2026-08-30T21:00:08.000Z"
    },
    {
      "type": "template",
      "slug": "clipmaker",
      "url": "https://grokbot.dev/marketplace/clipmaker/",
      "detail_url": "https://grokbot.dev/api/v1/templates/clipmaker.json",
      "headline": "ClipMaker",
      "summary": "Cuts the section you want out of a YouTube video and transcribes it",
      "categories": [
        "creator",
        "content",
        "youtube",
        "video",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@r40_io",
        "url": "https://x.com/r40_io/status/2094165107886395638"
      },
      "share_url": "https://x.ai/bot/b986_CbfzB8jKLcU14LTi",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T20:47:24.000Z",
      "updated_at": "2026-08-30T20:47:24.000Z"
    },
    {
      "type": "collection",
      "slug": "team-you-didnt-hire",
      "url": "https://grokbot.dev/collections/team-you-didnt-hire/",
      "detail_url": "https://grokbot.dev/api/v1/collections/team-you-didnt-hire.json",
      "headline": "The Team You Didn't Hire",
      "summary": "Five bots doing the jobs a startup used to hire a whole team for.",
      "categories": [
        "work"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T20:00:00Z",
      "updated_at": "2026-08-30T20:00:00Z"
    },
    {
      "type": "template",
      "slug": "nyc-parent",
      "url": "https://grokbot.dev/marketplace/nyc-parent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/nyc-parent.json",
      "headline": "NYC Parent",
      "summary": "Runs the school-and-activities logistics of raising kids in New York",
      "categories": [
        "personal",
        "productivity",
        "family",
        "calendar",
        "events",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DennisonBertram",
        "url": "https://x.com/DennisonBertram/status/2094150767338832025"
      },
      "share_url": "https://x.ai/bot/DiNI489Qte5ryNvZjOROb",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T19:50:25.000Z",
      "updated_at": "2026-08-30T19:50:25.000Z"
    },
    {
      "type": "template",
      "slug": "wholefoods",
      "url": "https://grokbot.dev/marketplace/wholefoods/",
      "detail_url": "https://grokbot.dev/api/v1/templates/wholefoods.json",
      "headline": "Wholefoods",
      "summary": "Plans the week's groceries around whatever Whole Foods has marked down",
      "categories": [
        "personal",
        "saving-money",
        "shopping",
        "food",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DennisonBertram",
        "url": "https://x.com/DennisonBertram/status/2094150768550945000"
      },
      "share_url": "https://x.ai/bot/7ZTQWd31OnZYDVJRzxzrU",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T19:50:25.000Z",
      "updated_at": "2026-08-30T19:50:25.000Z"
    },
    {
      "type": "template",
      "slug": "theta-vantage-desk",
      "url": "https://grokbot.dev/marketplace/theta-vantage-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/theta-vantage-desk.json",
      "headline": "Theta Vantage Desk",
      "summary": "An options briefing desk: gamma, flow and volatility on one ticker",
      "categories": [
        "investor",
        "finance",
        "analytics",
        "decision-support",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ThetaVantage",
        "url": "https://x.com/ThetaVantage/status/2094150193042386996"
      },
      "share_url": "https://x.ai/bot/YbX8HTAePBjwpwP05CVJS",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T19:48:08.000Z",
      "updated_at": "2026-08-30T19:48:08.000Z"
    },
    {
      "type": "template",
      "slug": "researchy",
      "url": "https://grokbot.dev/marketplace/researchy/",
      "detail_url": "https://grokbot.dev/api/v1/templates/researchy.json",
      "headline": "Researchy",
      "summary": "Checks claims against the live web and returns citations with dates",
      "categories": [
        "personal",
        "developer",
        "research",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@farzyness",
        "url": "https://x.com/farzyness/status/2094148803494391903"
      },
      "share_url": "https://x.ai/bot/rQt4W2zO2Gx9lfcBjd1lj",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T19:42:36.000Z",
      "updated_at": "2026-08-30T19:42:36.000Z"
    },
    {
      "type": "template",
      "slug": "chief-health",
      "url": "https://grokbot.dev/marketplace/chief-health/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-health.json",
      "headline": "Chief Health",
      "summary": "A daily check-in that keeps a training week on track when a session slips",
      "categories": [
        "personal",
        "health",
        "wellbeing",
        "monitoring",
        "decision-support",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AJA_Cortes",
        "url": "https://x.com/AJA_Cortes/status/2094144047073907019"
      },
      "share_url": "https://x.ai/bot/6MHDA-LzErngNoRBaktLZ",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-30T19:23:42.000Z",
      "updated_at": "2026-08-30T19:23:42.000Z"
    },
    {
      "type": "use-case",
      "slug": "herd-your-bots",
      "url": "https://grokbot.dev/use-cases/herd-your-bots/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/herd-your-bots.json",
      "headline": "Herd your whole fleet of Grok bots from one chat",
      "summary": "Once you run more than one Grok bot, keeping tabs on all of them is its own job. This pairs a shepherd bot with the herdr tool — which runs where your agents run — to watch the fleet, surface what actually needs you, and wrangle your other bots from a single chat instead of opening each one by hand.",
      "categories": [
        "engineering"
      ],
      "awesome_score": null,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@herdrdev",
        "url": "https://x.com/herdrdev/status/2094129284885467399"
      },
      "added_at": "2026-08-30T18:25:03Z",
      "updated_at": "2026-08-30T18:25:03Z"
    },
    {
      "type": "template",
      "slug": "shepherd",
      "url": "https://grokbot.dev/marketplace/shepherd/",
      "detail_url": "https://grokbot.dev/api/v1/templates/shepherd.json",
      "headline": "Shepherd",
      "summary": "A meta-bot that herds your whole fleet of Grok bots, paired with the herdr tool",
      "categories": [
        "developer",
        "ops",
        "monitoring",
        "automation",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@herdrdev",
        "url": "https://x.com/herdrdev/status/2094129284885467399"
      },
      "share_url": "https://x.ai/bot/i5YF8f-zdcR76uKPrqg3J",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T18:25:03.000Z",
      "updated_at": "2026-08-30T18:25:03.000Z"
    },
    {
      "type": "template",
      "slug": "whatsapp-digest",
      "url": "https://grokbot.dev/marketplace/whatsapp-digest/",
      "detail_url": "https://grokbot.dev/api/v1/templates/whatsapp-digest.json",
      "headline": "WhatsApp Digest",
      "summary": "A daily summary of your busiest WhatsApp groups, without opening them",
      "categories": [
        "personal",
        "productivity",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@PetrusJvR",
        "url": "https://x.com/PetrusJvR/status/2094114763982701049"
      },
      "share_url": "https://x.ai/bot/k8sSgsXHhRTEZi9Sqt_J-",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-30T17:27:21.000Z",
      "updated_at": "2026-08-30T17:27:21.000Z"
    },
    {
      "type": "template",
      "slug": "action-loop",
      "url": "https://grokbot.dev/marketplace/action-loop/",
      "detail_url": "https://grokbot.dev/api/v1/templates/action-loop.json",
      "headline": "Action Loop",
      "summary": "For anyone who ships once and then stalls, waiting to feel ready",
      "categories": [
        "personal",
        "productivity",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2094103820687303057"
      },
      "share_url": "https://x.ai/bot/py5cXgcAKPdEYsYK_AmcM",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:43:52.000Z",
      "updated_at": "2026-08-30T16:43:52.000Z"
    },
    {
      "type": "template",
      "slug": "stuck-cycle",
      "url": "https://grokbot.dev/marketplace/stuck-cycle/",
      "detail_url": "https://grokbot.dev/api/v1/templates/stuck-cycle.json",
      "headline": "Stuck Cycle",
      "summary": "Runs one skill through repeated laps of attempt, snag, and targeted study",
      "categories": [
        "personal",
        "student",
        "learning",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2094103808985141546"
      },
      "share_url": "https://x.ai/bot/fihe4nAy0jFWoygo4JCAW",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:43:49.000Z",
      "updated_at": "2026-08-30T16:43:49.000Z"
    },
    {
      "type": "template",
      "slug": "connection-audit",
      "url": "https://grokbot.dev/marketplace/connection-audit/",
      "detail_url": "https://grokbot.dev/api/v1/templates/connection-audit.json",
      "headline": "Connection Audit",
      "summary": "Triages the saved-reading pile and ties each keeper to a live problem",
      "categories": [
        "personal",
        "productivity",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2094103797270503600"
      },
      "share_url": "https://x.ai/bot/qllnuXO-FDFBHZU4MSamY",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:43:46.000Z",
      "updated_at": "2026-08-30T16:43:46.000Z"
    },
    {
      "type": "template",
      "slug": "retrieval-exam",
      "url": "https://grokbot.dev/marketplace/retrieval-exam/",
      "detail_url": "https://grokbot.dev/api/v1/templates/retrieval-exam.json",
      "headline": "Retrieval Exam",
      "summary": "Closed-book questioning that separates real recall from mere familiarity",
      "categories": [
        "personal",
        "student",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2094103773832737075"
      },
      "share_url": "https://x.ai/bot/OAlX-diXtFDIT6sTZ0NbI",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:43:40.000Z",
      "updated_at": "2026-08-30T16:43:40.000Z"
    },
    {
      "type": "template",
      "slug": "just-in-time-curriculum",
      "url": "https://grokbot.dev/marketplace/just-in-time-curriculum/",
      "detail_url": "https://grokbot.dev/api/v1/templates/just-in-time-curriculum.json",
      "headline": "Just-in-Time Curriculum",
      "summary": "Drops the study backlog and teaches only what your next task needs",
      "categories": [
        "personal",
        "student",
        "learning",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2094103762126455245"
      },
      "share_url": "https://x.ai/bot/rpkZERbKrIN_NlDl8ErVZ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:43:38.000Z",
      "updated_at": "2026-08-30T16:43:38.000Z"
    },
    {
      "type": "template",
      "slug": "struggle-gate",
      "url": "https://grokbot.dev/marketplace/struggle-gate/",
      "detail_url": "https://grokbot.dev/api/v1/templates/struggle-gate.json",
      "headline": "Struggle Gate",
      "summary": "Withholds the answer for ten minutes so you have to attempt it first",
      "categories": [
        "personal",
        "student",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2094103750399193493"
      },
      "share_url": "https://x.ai/bot/tjN1LsaYsuR7u0dQQvOGV",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:43:35.000Z",
      "updated_at": "2026-08-30T16:43:35.000Z"
    },
    {
      "type": "template",
      "slug": "feedback-clock",
      "url": "https://grokbot.dev/marketplace/feedback-clock/",
      "detail_url": "https://grokbot.dev/api/v1/templates/feedback-clock.json",
      "headline": "Feedback Clock",
      "summary": "Closes the lag between an attempt and the verdict on it",
      "categories": [
        "personal",
        "student",
        "learning",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2094103738499969334"
      },
      "share_url": "https://x.ai/bot/ySceLccAh5J8IVnq62mQl",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:43:32.000Z",
      "updated_at": "2026-08-30T16:43:32.000Z"
    },
    {
      "type": "template",
      "slug": "doing-gap",
      "url": "https://grokbot.dev/marketplace/doing-gap/",
      "detail_url": "https://grokbot.dev/api/v1/templates/doing-gap.json",
      "headline": "Doing Gap",
      "summary": "Counts what you have watched against what you have shipped, then makes you build",
      "categories": [
        "personal",
        "student",
        "learning",
        "productivity",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2094103726764273916"
      },
      "share_url": "https://x.ai/bot/9WPtKWMppOYW9wwGPwOaE",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:43:29.000Z",
      "updated_at": "2026-08-30T16:43:29.000Z"
    },
    {
      "type": "template",
      "slug": "consumption-autopsy",
      "url": "https://grokbot.dev/marketplace/consumption-autopsy/",
      "detail_url": "https://grokbot.dev/api/v1/templates/consumption-autopsy.json",
      "headline": "Consumption Autopsy",
      "summary": "Post-mortems your study habits and swaps one passive input for practice",
      "categories": [
        "personal",
        "student",
        "learning",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2094103715070558493"
      },
      "share_url": "https://x.ai/bot/WBo-ahaIrvCKXUH_3iEFy",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:43:26.000Z",
      "updated_at": "2026-08-30T16:43:26.000Z"
    },
    {
      "type": "template",
      "slug": "steward",
      "url": "https://grokbot.dev/marketplace/steward/",
      "detail_url": "https://grokbot.dev/api/v1/templates/steward.json",
      "headline": "Steward",
      "summary": "Tracks Cursor spend across your bot fleet and finds the cheap wins",
      "categories": [
        "developer",
        "ops",
        "monitoring",
        "analytics",
        "saving-money",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@cjblev",
        "url": "https://x.com/cjblev/status/2094100993923252291"
      },
      "share_url": "https://x.ai/bot/VMwfgQlHkYfFkbPYDWzAA",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:32:38.000Z",
      "updated_at": "2026-08-30T16:32:38.000Z"
    },
    {
      "type": "template",
      "slug": "product-idea-stress-test",
      "url": "https://grokbot.dev/marketplace/product-idea-stress-test/",
      "detail_url": "https://grokbot.dev/api/v1/templates/product-idea-stress-test.json",
      "headline": "Product Idea Stress Test",
      "summary": "Finds the one belief your startup idea cannot afford to have wrong",
      "categories": [
        "business",
        "developer",
        "decision-support",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@hnshah",
        "url": "https://x.com/hnshah/status/2094100862247502019"
      },
      "share_url": "https://x.ai/bot/JeFTvcDX-7QT2evKGIb52",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:32:06.000Z",
      "updated_at": "2026-08-30T16:32:06.000Z"
    },
    {
      "type": "template",
      "slug": "commercial-taste",
      "url": "https://grokbot.dev/marketplace/commercial-taste/",
      "detail_url": "https://grokbot.dev/api/v1/templates/commercial-taste.json",
      "headline": "Commercial Taste",
      "summary": "Commercial judgment for technical founders deciding without complete data",
      "categories": [
        "business",
        "developer",
        "decision-support",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thesmitpatel",
        "url": "https://x.com/thesmitpatel/status/2094100307340857707"
      },
      "share_url": "https://x.ai/bot/vekulzIMXM8hDjkp-mDkX",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T16:29:54.000Z",
      "updated_at": "2026-08-30T16:29:54.000Z"
    },
    {
      "type": "use-case",
      "slug": "reply-guard",
      "url": "https://grokbot.dev/use-cases/reply-guard/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/reply-guard.json",
      "headline": "Screen your X replies for burners and insults",
      "summary": "Reviews the replies to your posts and splits the signal from the noise: it flags accounts under 100 followers or under a year old, plus anyone slinging insults, so real conversation stays visible and throwaway replies get moderated. Jason Calacanis built it to keep his mentions classy.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Jason",
        "url": "https://x.com/Jason/status/2094095953812717647"
      },
      "added_at": "2026-08-30T16:12:36Z",
      "updated_at": "2026-08-30T16:12:36Z"
    },
    {
      "type": "template",
      "slug": "grok-bot-knower",
      "url": "https://grokbot.dev/marketplace/grok-bot-knower/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-bot-knower.json",
      "headline": "Grok Bot Knower",
      "summary": "Answers what Grok Bot can actually do, checked rather than remembered",
      "categories": [
        "developer",
        "knowledge-base",
        "research",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ngundotra",
        "url": "https://x.com/ngundotra/status/2094085203685785840"
      },
      "share_url": "https://x.ai/bot/v13QjVZ83GcaitG_3j4su",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T15:29:53.000Z",
      "updated_at": "2026-08-30T15:29:53.000Z"
    },
    {
      "type": "template",
      "slug": "lina",
      "url": "https://grokbot.dev/marketplace/lina/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lina.json",
      "headline": "Lina",
      "summary": "Plans each YouTube upload as one promise the video has to keep",
      "categories": [
        "creator",
        "youtube",
        "content",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@gabe_onchain",
        "url": "https://x.com/gabe_onchain/status/2094082997750284769"
      },
      "share_url": "https://x.ai/bot/PZQY6T6sKxrzhuYsclwap",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T15:21:07.000Z",
      "updated_at": "2026-08-30T15:21:07.000Z"
    },
    {
      "type": "template",
      "slug": "grokart",
      "url": "https://grokbot.dev/marketplace/grokart/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grokart.json",
      "headline": "Grokart",
      "summary": "Describe a purchase and get a shortlist plus a checkout link",
      "categories": [
        "personal",
        "shopping",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lamorim_net",
        "url": "https://x.com/lamorim_net/status/2094079296705090017"
      },
      "share_url": "https://x.ai/bot/uhGYPStIOzvxNm8oWh3sG",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T15:06:25.000Z",
      "updated_at": "2026-08-30T15:06:25.000Z"
    },
    {
      "type": "collection",
      "slug": "award-travel",
      "url": "https://grokbot.dev/collections/award-travel/",
      "detail_url": "https://grokbot.dev/api/v1/collections/award-travel.json",
      "headline": "Award Travel",
      "summary": "Book the trip on points, for the deepest real value.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "content-machine",
      "url": "https://grokbot.dev/collections/content-machine/",
      "detail_url": "https://grokbot.dev/api/v1/collections/content-machine.json",
      "headline": "One Video, a Week of Content",
      "summary": "Turn one recording into clips, shorts and posts everywhere.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "fill-the-pipeline",
      "url": "https://grokbot.dev/collections/fill-the-pipeline/",
      "detail_url": "https://grokbot.dev/api/v1/collections/fill-the-pipeline.json",
      "headline": "Fill the Pipeline",
      "summary": "From a fresh lead list to the meeting booked.",
      "categories": [
        "sales"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "founder-os",
      "url": "https://grokbot.dev/collections/founder-os/",
      "detail_url": "https://grokbot.dev/api/v1/collections/founder-os.json",
      "headline": "Founder OS",
      "summary": "Stand up the company, then run it from one desk.",
      "categories": [
        "work"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "get-found",
      "url": "https://grokbot.dev/collections/get-found/",
      "detail_url": "https://grokbot.dev/api/v1/collections/get-found.json",
      "headline": "Get Found",
      "summary": "Rank in Google — and get named in the AI answers.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "household-hq",
      "url": "https://grokbot.dev/collections/household-hq/",
      "detail_url": "https://grokbot.dev/api/v1/collections/household-hq.json",
      "headline": "Household HQ",
      "summary": "Run the family: meals, school, home and the thoughtful stuff.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "look-after-yourself",
      "url": "https://grokbot.dev/collections/look-after-yourself/",
      "detail_url": "https://grokbot.dev/api/v1/collections/look-after-yourself.json",
      "headline": "Look After Yourself",
      "summary": "The nudges and coaching to actually take care of you.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "never-overpay",
      "url": "https://grokbot.dev/collections/never-overpay/",
      "detail_url": "https://grokbot.dev/api/v1/collections/never-overpay.json",
      "headline": "Never Overpay Again",
      "summary": "Shop smart, pick the right card, claw back what you're owed.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "reclaim-your-inbox",
      "url": "https://grokbot.dev/collections/reclaim-your-inbox/",
      "detail_url": "https://grokbot.dev/api/v1/collections/reclaim-your-inbox.json",
      "headline": "Inbox Zero, For Real",
      "summary": "Empty the inbox — and keep it empty.",
      "categories": [
        "work"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "second-brain",
      "url": "https://grokbot.dev/collections/second-brain/",
      "detail_url": "https://grokbot.dev/api/v1/collections/second-brain.json",
      "headline": "Build a Second Brain",
      "summary": "Research that's sourced, filed, and findable months later.",
      "categories": [
        "work"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "ship-while-you-sleep",
      "url": "https://grokbot.dev/collections/ship-while-you-sleep/",
      "detail_url": "https://grokbot.dev/api/v1/collections/ship-while-you-sleep.json",
      "headline": "Ship While You Sleep",
      "summary": "Drop an idea at night, review the PR in the morning.",
      "categories": [
        "engineering"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "collection",
      "slug": "start-here",
      "url": "https://grokbot.dev/collections/start-here/",
      "detail_url": "https://grokbot.dev/api/v1/collections/start-here.json",
      "headline": "New to Grok Bot? Start Here",
      "summary": "Set up your first bots — and learn to build your own.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T15:00:00Z",
      "updated_at": "2026-08-30T15:00:00Z"
    },
    {
      "type": "template",
      "slug": "patch",
      "url": "https://grokbot.dev/marketplace/patch/",
      "detail_url": "https://grokbot.dev/api/v1/templates/patch.json",
      "headline": "Patch",
      "summary": "Seasonal lawn and border care matched to your British plot",
      "categories": [
        "personal",
        "home",
        "decision-support",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@benngarnish",
        "url": "https://x.com/benngarnish/status/2094068114929393746"
      },
      "share_url": "https://x.ai/bot/mZM210IvFxqswc9eaLjQa",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T14:21:59.000Z",
      "updated_at": "2026-08-30T14:21:59.000Z"
    },
    {
      "type": "template",
      "slug": "se-call-bot",
      "url": "https://grokbot.dev/marketplace/se-call-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/se-call-bot.json",
      "headline": "SE call bot",
      "summary": "Live backup for solutions engineers during customer calls",
      "categories": [
        "sales",
        "business",
        "meetings",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2094066260376166500"
      },
      "share_url": "https://x.ai/bot/9wmmsO_xoeLPeGEqjWLzE",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T14:14:37.000Z",
      "updated_at": "2026-08-30T14:14:37.000Z"
    },
    {
      "type": "template",
      "slug": "review-this",
      "url": "https://grokbot.dev/marketplace/review-this/",
      "detail_url": "https://grokbot.dev/api/v1/templates/review-this.json",
      "headline": "Review This",
      "summary": "Name a product and get a straight buy, skip, or pick-this-instead verdict",
      "categories": [
        "personal",
        "shopping",
        "decision-support",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DogecoinNorway",
        "url": "https://x.com/DogecoinNorway/status/2094042874283471230"
      },
      "share_url": "https://x.ai/bot/g4hvAEhebCPzqwsdPBGu4",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T12:41:41.000Z",
      "updated_at": "2026-08-30T12:41:41.000Z"
    },
    {
      "type": "template",
      "slug": "workshop-facilitator",
      "url": "https://grokbot.dev/marketplace/workshop-facilitator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/workshop-facilitator.json",
      "headline": "Workshop Facilitator",
      "summary": "Chairs a working session and refuses to close it while any question lacks an owner",
      "categories": [
        "business",
        "ops",
        "meetings",
        "productivity",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@OTNworld",
        "url": "https://x.com/OTNworld/status/2094033417646006646"
      },
      "share_url": "https://x.ai/bot/EJTJEGbRPXlSppzFk8ETH",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-30T12:04:06.000Z",
      "updated_at": "2026-08-30T12:04:06.000Z"
    },
    {
      "type": "template",
      "slug": "pulse",
      "url": "https://grokbot.dev/marketplace/pulse/",
      "detail_url": "https://grokbot.dev/api/v1/templates/pulse.json",
      "headline": "Pulse — Your X Concierge",
      "summary": "A read-only X concierge that turns a day of feed into one skimmable 7am brief",
      "categories": [
        "research",
        "news",
        "monitoring",
        "scheduled",
        "productivity"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GrokBotDev",
        "url": "https://x.com/GrokBotDev/status/2094029086490308904"
      },
      "share_url": "https://x.ai/bot/oUYHu9LEXP5RVPFvoG4Ms",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-30T11:46:54.000Z",
      "updated_at": "2026-08-30T11:46:54.000Z"
    },
    {
      "type": "template",
      "slug": "tech-lead",
      "url": "https://grokbot.dev/marketplace/tech-lead/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tech-lead.json",
      "headline": "Tech Lead",
      "summary": "Gates the merge on what the diff and the tests actually show",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@inqusit",
        "url": "https://x.com/inqusit/status/2094021157213348277"
      },
      "share_url": "https://x.ai/bot/RfFPxQ_rfEGcUncrJ6g_W",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T11:15:23.000Z",
      "updated_at": "2026-08-30T11:15:23.000Z"
    },
    {
      "type": "plugin",
      "slug": "x-for-grok-bot",
      "url": "https://grokbot.dev/plugins/x-for-grok-bot/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/x-for-grok-bot.json",
      "headline": "X for Grok Bot",
      "summary": "The official X plugin: search posts, read timelines, pull trends, manage bookmarks.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "x.ai",
        "url": "https://x.ai/bot/plugin/49086599"
      },
      "added_at": "2026-08-30T10:00:00Z",
      "updated_at": "2026-08-30T10:00:00Z"
    },
    {
      "type": "collection",
      "slug": "x-account-management",
      "url": "https://grokbot.dev/collections/x-account-management/",
      "detail_url": "https://grokbot.dev/api/v1/collections/x-account-management.json",
      "headline": "X Account Management",
      "summary": "Six shared Bots to run — and quietly read — your whole X account.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-30T09:00:00Z",
      "updated_at": "2026-08-30T12:00:00Z"
    },
    {
      "type": "template",
      "slug": "rewardsmaxxing",
      "url": "https://grokbot.dev/marketplace/rewardsmaxxing/",
      "detail_url": "https://grokbot.dev/api/v1/templates/rewardsmaxxing.json",
      "headline": "RewardsMaxxing",
      "summary": "Puts each purchase on whichever of your cards pays back most",
      "categories": [
        "finance",
        "saving-money",
        "personal",
        "shopping",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ishuagra02",
        "url": "https://x.com/ishuagra02/status/2093910521435103509"
      },
      "share_url": "https://x.ai/bot/upsD2c_qFmh6n4biksRvi",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T03:55:45.000Z",
      "updated_at": "2026-08-30T03:55:45.000Z"
    },
    {
      "type": "template",
      "slug": "rentals",
      "url": "https://grokbot.dev/marketplace/rentals/",
      "detail_url": "https://grokbot.dev/api/v1/templates/rentals.json",
      "headline": "RENTALS",
      "summary": "Works your Facebook Marketplace rental leads from enquiry to showing",
      "categories": [
        "real-estate",
        "business",
        "automation",
        "social-media",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@HandsomeHenry6",
        "url": "https://x.com/HandsomeHenry6/status/2093905948637114427"
      },
      "share_url": "https://x.ai/bot/JrnQAM0z-7SNI9UtIO3-Z",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T03:37:35.000Z",
      "updated_at": "2026-08-30T03:37:35.000Z"
    },
    {
      "type": "template",
      "slug": "teslascope",
      "url": "https://grokbot.dev/marketplace/teslascope/",
      "detail_url": "https://grokbot.dev/api/v1/templates/teslascope.json",
      "headline": "Teslascope",
      "summary": "Ask plain questions about your Tesla's trips, charging and status",
      "categories": [
        "personal",
        "data",
        "analytics",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@teslascope",
        "url": "https://x.com/teslascope/status/2093904429762433255"
      },
      "share_url": "https://x.ai/bot/brwSBnhe7jg20IBJS0TVK",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T03:31:33.000Z",
      "updated_at": "2026-08-30T03:31:33.000Z"
    },
    {
      "type": "template",
      "slug": "raily",
      "url": "https://grokbot.dev/marketplace/raily/",
      "detail_url": "https://grokbot.dev/api/v1/templates/raily.json",
      "headline": "Raily",
      "summary": "Reviews possible new connections without touching your account",
      "categories": [
        "social-media",
        "personal",
        "decision-support",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@raily",
        "url": "https://x.com/raily/status/2093903845436895454"
      },
      "share_url": "https://x.ai/bot/Yf3pOvZQ0B_9DDcCzuhDG",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T03:29:14.000Z",
      "updated_at": "2026-08-30T03:29:14.000Z"
    },
    {
      "type": "template",
      "slug": "receipt-scanner-expense-tracking",
      "url": "https://grokbot.dev/marketplace/receipt-scanner-expense-tracking/",
      "detail_url": "https://grokbot.dev/api/v1/templates/receipt-scanner-expense-tracking.json",
      "headline": "Receipt Scanner / Expense Tracking",
      "summary": "Forward a receipt and it becomes a row in your expense sheet",
      "categories": [
        "business",
        "personal",
        "finance",
        "email",
        "back-office",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@limeunfiltered",
        "url": "https://x.com/limeunfiltered/status/2093899797967278545"
      },
      "share_url": "https://x.ai/bot/qod4CrNQBlDIMm5wFYVQp",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T03:13:09.000Z",
      "updated_at": "2026-08-30T03:13:09.000Z"
    },
    {
      "type": "template",
      "slug": "alexis-grail-scout",
      "url": "https://grokbot.dev/marketplace/alexis-grail-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/alexis-grail-scout.json",
      "headline": "Alexis’ Grail Scout",
      "summary": "Hunts top-grade sealed retro cartridges across the big auction houses",
      "categories": [
        "shopping",
        "personal",
        "monitoring",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093899347406831738"
      },
      "share_url": "https://x.ai/bot/2asdeMXYDwlPREURnfCxn",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-30T03:11:21.000Z",
      "updated_at": "2026-08-30T03:11:21.000Z"
    },
    {
      "type": "template",
      "slug": "situation-monitor",
      "url": "https://grokbot.dev/marketplace/situation-monitor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/situation-monitor.json",
      "headline": "Situation monitor",
      "summary": "Turns a week of your X bookmarks into a drafted recap thread",
      "categories": [
        "creator",
        "content",
        "social-media",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ChaseMc67",
        "url": "https://x.com/ChaseMc67/status/2093878821078573520"
      },
      "share_url": "https://x.ai/bot/lkHayxdQjNzVVJIDh7qaF",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-30T01:49:47.000Z",
      "updated_at": "2026-08-30T01:49:47.000Z"
    },
    {
      "type": "template",
      "slug": "funhouse",
      "url": "https://grokbot.dev/marketplace/funhouse/",
      "detail_url": "https://grokbot.dev/api/v1/templates/funhouse.json",
      "headline": "Funhouse",
      "summary": "Restyles the Grok Bot app itself with themes, pets and overlays",
      "categories": [
        "creator",
        "design",
        "content",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AdemVessell",
        "url": "https://x.com/AdemVessell/status/2093869927753224689"
      },
      "share_url": "https://x.ai/bot/kP7i2Po6_T_Rj9h9VVlk5",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T01:14:27.000Z",
      "updated_at": "2026-08-30T01:14:27.000Z"
    },
    {
      "type": "template",
      "slug": "agent-looper",
      "url": "https://grokbot.dev/marketplace/agent-looper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/agent-looper.json",
      "headline": "Agent Looper",
      "summary": "Keeps a local coding agent iterating until your acceptance test passes",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@dancingteeth",
        "url": "https://x.com/dancingteeth/status/2093868415542845628"
      },
      "share_url": "https://x.ai/bot/AETdGbRRNWfckrRGv22LD",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-30T01:08:27.000Z",
      "updated_at": "2026-08-30T01:08:27.000Z"
    },
    {
      "type": "template",
      "slug": "dewey",
      "url": "https://grokbot.dev/marketplace/dewey/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dewey.json",
      "headline": "Dewey",
      "summary": "Keeps an eye on Gmail and surfaces the mail that actually needs you",
      "categories": [
        "personal",
        "productivity",
        "monitoring",
        "email",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Vixlio",
        "url": "https://x.com/Vixlio/status/2093843651856081165"
      },
      "share_url": "https://x.ai/bot/rfAHsaFrz6xHBMtUpxDi5",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T23:30:02.000Z",
      "updated_at": "2026-08-29T23:30:02.000Z"
    },
    {
      "type": "template",
      "slug": "eg4-monitor",
      "url": "https://grokbot.dev/marketplace/eg4-monitor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/eg4-monitor.json",
      "headline": "EG4 Monitor",
      "summary": "Tracks a home EG4 solar and battery system and raises faults early",
      "categories": [
        "personal",
        "monitoring",
        "analytics",
        "home",
        "data",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@look4terry",
        "url": "https://x.com/look4terry/status/2093839716370309156"
      },
      "share_url": "https://x.ai/bot/9rxPP70OSzuTtTaOrzeqz",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T23:14:24.000Z",
      "updated_at": "2026-08-29T23:14:24.000Z"
    },
    {
      "type": "template",
      "slug": "george",
      "url": "https://grokbot.dev/marketplace/george/",
      "detail_url": "https://grokbot.dev/api/v1/templates/george.json",
      "headline": "George",
      "summary": "Turns one brief into a full set of on-brand creative assets",
      "categories": [
        "creator",
        "automation",
        "design",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@arni0x9053",
        "url": "https://x.com/arni0x9053/status/2093838719510053326"
      },
      "share_url": "https://x.ai/bot/8vjjlI7z5W0HtpRcFQgJ4",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T23:10:27.000Z",
      "updated_at": "2026-08-29T23:10:27.000Z"
    },
    {
      "type": "template",
      "slug": "fantasy-football-advisor",
      "url": "https://grokbot.dev/marketplace/fantasy-football-advisor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fantasy-football-advisor.json",
      "headline": "Fantasy Football Advisor",
      "summary": "Runs your ESPN fantasy team like a GM, with you signing off on moves",
      "categories": [
        "personal",
        "decision-support",
        "research",
        "monitoring",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Colehollander10",
        "url": "https://x.com/Colehollander10/status/2093837029674987662"
      },
      "share_url": "https://x.ai/bot/E273ZIwirOOdwMfeCp97t",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T23:03:44.000Z",
      "updated_at": "2026-08-29T23:03:44.000Z"
    },
    {
      "type": "template",
      "slug": "apps",
      "url": "https://grokbot.dev/marketplace/apps/",
      "detail_url": "https://grokbot.dev/api/v1/templates/apps.json",
      "headline": "Apps",
      "summary": "Describe an app in one sentence and get a running build back",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@waynesutton",
        "url": "https://x.com/waynesutton/status/2093835122231722366"
      },
      "share_url": "https://x.ai/bot/OPLop__-mqSsyQheR5JYv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T22:56:09.000Z",
      "updated_at": "2026-08-29T22:56:09.000Z"
    },
    {
      "type": "template",
      "slug": "bot-inbox",
      "url": "https://grokbot.dev/marketplace/bot-inbox/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bot-inbox.json",
      "headline": "Bot inbox",
      "summary": "A one-line digest of every bot and group chat with something new",
      "categories": [
        "personal",
        "productivity",
        "monitoring",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@waynesutton",
        "url": "https://x.com/waynesutton/status/2093835123498340611"
      },
      "share_url": "https://x.ai/bot/RHSd-aq6KC84xxUnvBXSl",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T22:56:09.000Z",
      "updated_at": "2026-08-29T22:56:09.000Z"
    },
    {
      "type": "template",
      "slug": "ralph",
      "url": "https://grokbot.dev/marketplace/ralph/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ralph.json",
      "headline": "Ralph",
      "summary": "Rebuilds a resume into a live portfolio of clickable work demos",
      "categories": [
        "personal",
        "recruiting",
        "content",
        "design",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@HouseHackerJon",
        "url": "https://x.com/HouseHackerJon/status/2093832798528577920"
      },
      "share_url": "https://x.ai/bot/NQQjXITgX9V7WjaDh9Vzb",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T22:46:55.000Z",
      "updated_at": "2026-08-29T22:46:55.000Z"
    },
    {
      "type": "template",
      "slug": "watchdog",
      "url": "https://grokbot.dev/marketplace/watchdog/",
      "detail_url": "https://grokbot.dev/api/v1/templates/watchdog.json",
      "headline": "Watchdog",
      "summary": "Sweeps your inbox weekly for renewals, receipts and expiring trials",
      "categories": [
        "personal",
        "saving-money",
        "finance",
        "email",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jxckvibe",
        "url": "https://x.com/jxckvibe/status/2093828719374705066"
      },
      "share_url": "https://x.ai/bot/PuAEE57P58Df5zskFY3pg",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T22:30:42.000Z",
      "updated_at": "2026-08-29T22:30:42.000Z"
    },
    {
      "type": "template",
      "slug": "linkedin-leads",
      "url": "https://grokbot.dev/marketplace/linkedin-leads/",
      "detail_url": "https://grokbot.dev/api/v1/templates/linkedin-leads.json",
      "headline": "Linkedin Leads",
      "summary": "Daily LinkedIn lead sweep across posts and comments from your keywords",
      "categories": [
        "sales",
        "growth",
        "social-media",
        "research",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@angelesp",
        "url": "https://x.com/angelesp/status/2093826046231511549"
      },
      "share_url": "https://x.ai/bot/-BdTEtBnZEq9K1ef-bn6W",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T22:20:05.000Z",
      "updated_at": "2026-08-29T22:20:05.000Z"
    },
    {
      "type": "template",
      "slug": "chief",
      "url": "https://grokbot.dev/marketplace/chief/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief.json",
      "headline": "Chief",
      "summary": "Weekday-morning triage of your inbox, your calendar and your replies",
      "categories": [
        "personal",
        "business",
        "productivity",
        "automation",
        "email",
        "calendar",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jxckvibe",
        "url": "https://x.com/jxckvibe/status/2093821098315882620"
      },
      "share_url": "https://x.ai/bot/QIfSY8pPwjqBSIdal-5CI",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T22:00:25.000Z",
      "updated_at": "2026-08-29T22:00:25.000Z"
    },
    {
      "type": "plugin",
      "slug": "imessage",
      "url": "https://grokbot.dev/plugins/imessage/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/imessage.json",
      "headline": "iMessage for Grok Bot",
      "summary": "Read, triage, search, and send iMessages from a local macOS helper.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "github.com",
        "url": "https://github.com/jeffhuber/grokbot-imessage-skill"
      },
      "added_at": "2026-08-29T21:48:00Z",
      "updated_at": "2026-08-29T21:48:00Z"
    },
    {
      "type": "template",
      "slug": "gym-bod",
      "url": "https://grokbot.dev/marketplace/gym-bod/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gym-bod.json",
      "headline": "Gym Bod",
      "summary": "Claims your spot in busy gym classes as registration opens",
      "categories": [
        "personal",
        "automation",
        "life-hacks",
        "wellbeing",
        "health",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DrPB",
        "url": "https://x.com/DrPB/status/2093815967360991485"
      },
      "share_url": "https://x.ai/bot/3mtiwFoZcEMq59w-49DMS",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T21:40:02.000Z",
      "updated_at": "2026-08-29T21:40:02.000Z"
    },
    {
      "type": "template",
      "slug": "ship-note",
      "url": "https://grokbot.dev/marketplace/ship-note/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ship-note.json",
      "headline": "Ship Note",
      "summary": "Turns a finished release into a changelog entry and an email",
      "categories": [
        "business",
        "marketer",
        "content",
        "email",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sol_wright7",
        "url": "https://x.com/sol_wright7/status/2093809370958098813"
      },
      "share_url": "https://x.ai/bot/xMCiRCmOCYLeRzW8nS6EL",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T21:13:49.000Z",
      "updated_at": "2026-08-29T21:13:49.000Z"
    },
    {
      "type": "template",
      "slug": "milybot",
      "url": "https://grokbot.dev/marketplace/milybot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/milybot.json",
      "headline": "Milybot",
      "summary": "Looks up Australian company records and helps you wire up Milypay",
      "categories": [
        "developer",
        "business",
        "finance",
        "data",
        "engineering",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@1Milysec",
        "url": "https://x.com/1Milysec/status/2093806488586502490"
      },
      "share_url": "https://x.ai/bot/vcOZX9RVPatQMVCinCVY_",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T21:02:22.000Z",
      "updated_at": "2026-08-29T21:02:22.000Z"
    },
    {
      "type": "template",
      "slug": "runtimewire",
      "url": "https://grokbot.dev/marketplace/runtimewire/",
      "detail_url": "https://grokbot.dev/api/v1/templates/runtimewire.json",
      "headline": "RuntimeWire",
      "summary": "A sourced daily read on AI funding, launches and founder moves",
      "categories": [
        "business",
        "investor",
        "research",
        "monitoring",
        "news",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@merket",
        "url": "https://x.com/merket/status/2093804393229410713"
      },
      "share_url": "https://x.ai/bot/k4iwGejDGoy-oT7qohxXb",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T20:54:03.000Z",
      "updated_at": "2026-08-29T20:54:03.000Z"
    },
    {
      "type": "template",
      "slug": "shop",
      "url": "https://grokbot.dev/marketplace/shop/",
      "detail_url": "https://grokbot.dev/api/v1/templates/shop.json",
      "headline": "Shop",
      "summary": "Searches Shopify stores and hands back a short list, approval required",
      "categories": [
        "personal",
        "shopping",
        "decision-support",
        "saving-money",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@alex_chehimi",
        "url": "https://x.com/alex_chehimi/status/2093803794572197995"
      },
      "share_url": "https://x.ai/bot/nlIApzau1qw0MNiRkqbPH",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T20:51:40.000Z",
      "updated_at": "2026-08-29T20:51:40.000Z"
    },
    {
      "type": "template",
      "slug": "tally-desk",
      "url": "https://grokbot.dev/marketplace/tally-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tally-desk.json",
      "headline": "Tally Desk",
      "summary": "Builds Tally forms, reads the responses, fills one on request",
      "categories": [
        "business",
        "ops",
        "developer",
        "automation",
        "back-office",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093795274598817946"
      },
      "share_url": "https://x.ai/bot/m-qZ-OIA6Nt2LZeb2bKg5",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T20:17:48.000Z",
      "updated_at": "2026-08-29T20:17:48.000Z"
    },
    {
      "type": "template",
      "slug": "sap-technical-consultant",
      "url": "https://grokbot.dev/marketplace/sap-technical-consultant/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sap-technical-consultant.json",
      "headline": "SAP Technical Consultant",
      "summary": "An S/4HANA advisor for clean-core design decisions",
      "categories": [
        "business",
        "developer",
        "engineering",
        "data",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@beinglalit21",
        "url": "https://x.com/beinglalit21/status/2093783196488061076"
      },
      "share_url": "https://x.ai/bot/O08yUdBz6vFFqYITvWPPi",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T19:29:49.000Z",
      "updated_at": "2026-08-29T19:29:49.000Z"
    },
    {
      "type": "template",
      "slug": "aoty",
      "url": "https://grokbot.dev/marketplace/aoty/",
      "detail_url": "https://grokbot.dev/api/v1/templates/aoty.json",
      "headline": "aoty",
      "summary": "Three new albums a week, picked from aggregated scores",
      "categories": [
        "personal",
        "research",
        "content",
        "scheduled",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@emrecolakoglu",
        "url": "https://x.com/emrecolakoglu/status/2093780158180175982"
      },
      "share_url": "https://x.ai/bot/Wt4IQj3R1eePOyOOnox7H",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T19:17:44.000Z",
      "updated_at": "2026-08-29T19:17:44.000Z"
    },
    {
      "type": "template",
      "slug": "vet",
      "url": "https://grokbot.dev/marketplace/vet/",
      "detail_url": "https://grokbot.dev/api/v1/templates/vet.json",
      "headline": "Vet",
      "summary": "Audits a bot before you let it near your account",
      "categories": [
        "developer",
        "business",
        "monitoring",
        "decision-support",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GaurangKaria",
        "url": "https://x.com/GaurangKaria/status/2093779467554419008"
      },
      "share_url": "https://x.ai/bot/9Vmfeck_zr6jo9dO-xEBT",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T19:15:00.000Z",
      "updated_at": "2026-08-29T19:15:00.000Z"
    },
    {
      "type": "template",
      "slug": "betree",
      "url": "https://grokbot.dev/marketplace/betree/",
      "detail_url": "https://grokbot.dev/api/v1/templates/betree.json",
      "headline": "BeTree",
      "summary": "Turns a plan spread across several bots into one live graph",
      "categories": [
        "developer",
        "ops",
        "monitoring",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@NicoChauvin74",
        "url": "https://x.com/NicoChauvin74/status/2093778235054031136"
      },
      "share_url": "https://x.ai/bot/2PSNlIROOJPj9qZlfRy0w",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-29T19:10:06.000Z",
      "updated_at": "2026-08-29T19:10:06.000Z"
    },
    {
      "type": "template",
      "slug": "time-keeper",
      "url": "https://grokbot.dev/marketplace/time-keeper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/time-keeper.json",
      "headline": "Time Keeper",
      "summary": "Bookends your day with a morning agenda and a night preview",
      "categories": [
        "personal",
        "productivity",
        "calendar",
        "scheduled",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ironted21",
        "url": "https://x.com/ironted21/status/2093771512331252046"
      },
      "share_url": "https://x.ai/bot/IAEp851k9orM1LguTm2F8",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T18:43:23.000Z",
      "updated_at": "2026-08-29T18:43:23.000Z"
    },
    {
      "type": "template",
      "slug": "content-growth-coach",
      "url": "https://grokbot.dev/marketplace/content-growth-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/content-growth-coach.json",
      "headline": "Content Growth Coach",
      "summary": "Tells creators which fix will move their numbers first",
      "categories": [
        "creator",
        "growth",
        "social-media",
        "youtube",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jxckvibe",
        "url": "https://x.com/jxckvibe/status/2093771166598975669"
      },
      "share_url": "https://x.ai/bot/sMmoqCElqRPj1RYbtngMr",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T18:42:01.000Z",
      "updated_at": "2026-08-29T18:42:01.000Z"
    },
    {
      "type": "template",
      "slug": "design-expert",
      "url": "https://grokbot.dev/marketplace/design-expert/",
      "detail_url": "https://grokbot.dev/api/v1/templates/design-expert.json",
      "headline": "Design Expert",
      "summary": "Reviews AI-made interfaces the way a design lead would",
      "categories": [
        "business",
        "developer",
        "design",
        "content",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@inqusit",
        "url": "https://x.com/inqusit/status/2093765735197851709"
      },
      "share_url": "https://x.ai/bot/H2WEoHRGKv_6a3j6lsHiG",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T18:20:26.000Z",
      "updated_at": "2026-08-29T18:20:26.000Z"
    },
    {
      "type": "template",
      "slug": "shane-hunter",
      "url": "https://grokbot.dev/marketplace/shane-hunter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/shane-hunter.json",
      "headline": "shane hunter",
      "summary": "Clears bots you no longer want out of the desktop app",
      "categories": [
        "personal",
        "developer",
        "automation",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@rightish19",
        "url": "https://x.com/rightish19/status/2093761406545834296"
      },
      "share_url": "https://x.ai/bot/o0yoY_AhWPpIySJR5TaM-",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T18:03:14.000Z",
      "updated_at": "2026-08-29T18:03:14.000Z"
    },
    {
      "type": "template",
      "slug": "vinted-seller",
      "url": "https://grokbot.dev/marketplace/vinted-seller/",
      "detail_url": "https://grokbot.dev/api/v1/templates/vinted-seller.json",
      "headline": "Vinted Seller",
      "summary": "Turns a pile of wardrobe photos into finished Vinted listings",
      "categories": [
        "personal",
        "shopping",
        "automation",
        "support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@trytocatchme98",
        "url": "https://x.com/trytocatchme98/status/2093760516875333635"
      },
      "share_url": "https://x.ai/bot/nqMcywYF0Bg35egak7dSh",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T17:59:42.000Z",
      "updated_at": "2026-08-29T17:59:42.000Z"
    },
    {
      "type": "template",
      "slug": "bandit",
      "url": "https://grokbot.dev/marketplace/bandit/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bandit.json",
      "headline": "Bandit",
      "summary": "A wisecracking front end for coordinating the bots you already run",
      "categories": [
        "personal",
        "productivity",
        "automation",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BitsOfJT",
        "url": "https://x.com/BitsOfJT/status/2093757984203583651"
      },
      "share_url": "https://x.ai/bot/xRyaLCqAzIr_paD5tC8PK",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T17:49:38.000Z",
      "updated_at": "2026-08-29T17:49:38.000Z"
    },
    {
      "type": "template",
      "slug": "qubits-toy-bot",
      "url": "https://grokbot.dev/marketplace/qubits-toy-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/qubits-toy-bot.json",
      "headline": "Qubits Toy Bot",
      "summary": "Assembles looping 3D structures out of Qubits toy pieces",
      "categories": [
        "personal",
        "creator",
        "design",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Toy_Maestro",
        "url": "https://x.com/Toy_Maestro/status/2093752472472887476"
      },
      "share_url": "https://x.ai/bot/USVlMLTxHCex8XgcUQGfv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T17:27:44.000Z",
      "updated_at": "2026-08-29T17:27:44.000Z"
    },
    {
      "type": "template",
      "slug": "rockman",
      "url": "https://grokbot.dev/marketplace/rockman/",
      "detail_url": "https://grokbot.dev/api/v1/templates/rockman.json",
      "headline": "Rockman",
      "summary": "Checks the gear specs before it tells you what to buy",
      "categories": [
        "personal",
        "shopping",
        "research",
        "saving-money",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@0xJONZE",
        "url": "https://x.com/0xJONZE/status/2093745950858625095"
      },
      "share_url": "https://x.ai/bot/g3NyqeycJ7qhTlcBNV8Mo",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T17:01:49.000Z",
      "updated_at": "2026-08-29T17:01:49.000Z"
    },
    {
      "type": "template",
      "slug": "gtm-chief-of-staff",
      "url": "https://grokbot.dev/marketplace/gtm-chief-of-staff/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gtm-chief-of-staff.json",
      "headline": "GTM Chief Of Staff",
      "summary": "Carries the admin around enterprise deals so you can sell",
      "categories": [
        "sales",
        "business",
        "back-office",
        "meetings",
        "meta-bot",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2093742276564459867"
      },
      "share_url": "https://x.ai/bot/r9Svkbs3dN6CY1Iy_Au4b",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-29T16:47:13.000Z",
      "updated_at": "2026-08-29T16:47:13.000Z"
    },
    {
      "type": "template",
      "slug": "prospecting-sheet-builder",
      "url": "https://grokbot.dev/marketplace/prospecting-sheet-builder/",
      "detail_url": "https://grokbot.dev/api/v1/templates/prospecting-sheet-builder.json",
      "headline": "Prospecting Sheet Builder",
      "summary": "Wakes you up to a fresh sheet of qualified B2B accounts",
      "categories": [
        "sales",
        "business",
        "research",
        "automation",
        "email",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2093742276564459867"
      },
      "share_url": "https://x.ai/bot/3Peagz3nzagjBRFhjrENd",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T16:47:13.000Z",
      "updated_at": "2026-08-29T16:47:13.000Z"
    },
    {
      "type": "template",
      "slug": "x-account-crew",
      "url": "https://grokbot.dev/marketplace/x-account-crew/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-account-crew.json",
      "headline": "X Account Crew",
      "summary": "Five specialists sharing the work of running your X account",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "content",
        "agent-team",
        "monitoring"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2093742276564459867"
      },
      "share_url": "https://x.ai/bot/CrFqfXIZibJ5DwLuJ89sp",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-29T16:47:13.000Z",
      "updated_at": "2026-08-29T16:47:13.000Z"
    },
    {
      "type": "template",
      "slug": "x-strategist",
      "url": "https://grokbot.dev/marketplace/x-strategist/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-strategist.json",
      "headline": "X Strategist",
      "summary": "Plays the long game on who is worth knowing on X",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "growth",
        "monitoring",
        "decision-support",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thekuchh",
        "url": "https://x.com/thekuchh/status/2093742276564459867"
      },
      "share_url": "https://x.ai/bot/pjCwyZNSLk0ch8DUVoeKH",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T16:47:13.000Z",
      "updated_at": "2026-08-29T16:47:13.000Z"
    },
    {
      "type": "template",
      "slug": "onboarding-coach",
      "url": "https://grokbot.dev/marketplace/onboarding-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/onboarding-coach.json",
      "headline": "Onboarding Coach",
      "summary": "A guided first hour for anyone new to Grok Bot",
      "categories": [
        "personal",
        "learning",
        "productivity",
        "decision-support",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tpgoebel",
        "url": "https://x.com/tpgoebel/status/2093738394899599806"
      },
      "share_url": "https://x.ai/bot/OfZitBsJprif-DfsQKBUY",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T16:31:47.000Z",
      "updated_at": "2026-08-29T16:31:47.000Z"
    },
    {
      "type": "template",
      "slug": "pain-in-the-task",
      "url": "https://grokbot.dev/marketplace/pain-in-the-task/",
      "detail_url": "https://grokbot.dev/api/v1/templates/pain-in-the-task.json",
      "headline": "Pain in the Task",
      "summary": "Finds the dull work eating your week and gets it handed off",
      "categories": [
        "personal",
        "business",
        "productivity",
        "automation",
        "decision-support",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@gambrill",
        "url": "https://x.com/gambrill/status/2093736661372817456"
      },
      "share_url": "https://x.ai/bot/yztAMds3EQ2J5OjG_tBgw",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T16:24:54.000Z",
      "updated_at": "2026-08-29T16:24:54.000Z"
    },
    {
      "type": "template",
      "slug": "love",
      "url": "https://grokbot.dev/marketplace/love/",
      "detail_url": "https://grokbot.dev/api/v1/templates/love.json",
      "headline": "Love ❤️",
      "summary": "Keeps the thoughtful part of a relationship from slipping",
      "categories": [
        "personal",
        "family",
        "productivity",
        "calendar",
        "events",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@dannybuck",
        "url": "https://x.com/dannybuck/status/2093732626544628001"
      },
      "share_url": "https://x.ai/bot/Xg8tws0lVEouCHOVMcnLg",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T16:08:52.000Z",
      "updated_at": "2026-08-29T16:08:52.000Z"
    },
    {
      "type": "template",
      "slug": "flowsery",
      "url": "https://grokbot.dev/marketplace/flowsery/",
      "detail_url": "https://grokbot.dev/api/v1/templates/flowsery.json",
      "headline": "Flowsery",
      "summary": "Turns session recordings into a ranked list of things to fix",
      "categories": [
        "developer",
        "business",
        "analytics",
        "monitoring",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tarasshyn",
        "url": "https://x.com/tarasshyn/status/2093730218145976437"
      },
      "share_url": "https://x.ai/bot/tOP05p0n0XVUcpJDfPH0k",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T15:59:18.000Z",
      "updated_at": "2026-08-29T15:59:18.000Z"
    },
    {
      "type": "template",
      "slug": "redreplier",
      "url": "https://grokbot.dev/marketplace/redreplier/",
      "detail_url": "https://grokbot.dev/api/v1/templates/redreplier.json",
      "headline": "RedReplier",
      "summary": "Finds people talking about your product, ranked by buying intent",
      "categories": [
        "marketer",
        "sales",
        "social-media",
        "monitoring",
        "research",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tarasshyn",
        "url": "https://x.com/tarasshyn/status/2093730218145976437"
      },
      "share_url": "https://x.ai/bot/8aU6ly_uunnMabpybs3hB",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T15:59:18.000Z",
      "updated_at": "2026-08-29T15:59:18.000Z"
    },
    {
      "type": "template",
      "slug": "adm-account-bot",
      "url": "https://grokbot.dev/marketplace/adm-account-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/adm-account-bot.json",
      "headline": "ADM account bot",
      "summary": "A weekly account plan for keeping and growing customers",
      "categories": [
        "sales",
        "business",
        "growth",
        "back-office",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2093727476405170365"
      },
      "share_url": "https://x.ai/bot/4Gc1tZsJu7C8YH-EnTfaN",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T15:48:24.000Z",
      "updated_at": "2026-08-29T15:48:24.000Z"
    },
    {
      "type": "template",
      "slug": "adaptlypost",
      "url": "https://grokbot.dev/marketplace/adaptlypost/",
      "detail_url": "https://grokbot.dev/api/v1/templates/adaptlypost.json",
      "headline": "AdaptlyPost",
      "summary": "One bot that writes, queues and posts to nine social networks",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "content",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tarasshyn",
        "url": "https://x.com/tarasshyn/status/2093726077906493508"
      },
      "share_url": "https://x.ai/bot/1GpK7CoPs4e_M__9rb3uR",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T15:42:51.000Z",
      "updated_at": "2026-08-29T15:42:51.000Z"
    },
    {
      "type": "template",
      "slug": "alchemist",
      "url": "https://grokbot.dev/marketplace/alchemist/",
      "detail_url": "https://grokbot.dev/api/v1/templates/alchemist.json",
      "headline": "Alchemist",
      "summary": "Experiments its way to a method for undocumented problems",
      "categories": [
        "developer",
        "engineering",
        "research",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@2onism",
        "url": "https://x.com/2onism/status/2093723713279803515"
      },
      "share_url": "https://x.ai/bot/JjO20_oGKrE_Ys5Uz4efj",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T15:33:27.000Z",
      "updated_at": "2026-08-29T15:33:27.000Z"
    },
    {
      "type": "template",
      "slug": "icebreaker",
      "url": "https://grokbot.dev/marketplace/icebreaker/",
      "detail_url": "https://grokbot.dev/api/v1/templates/icebreaker.json",
      "headline": "Icebreaker",
      "summary": "A job-hunt wingman for AI trust-and-safety roles",
      "categories": [
        "personal",
        "recruiting",
        "research",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@amberdawn1786",
        "url": "https://x.com/amberdawn1786/status/2093722772396536068"
      },
      "share_url": "https://x.ai/bot/62_FP-LQ4OOq4uTevKlUP",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T15:29:43.000Z",
      "updated_at": "2026-08-29T15:29:43.000Z"
    },
    {
      "type": "template",
      "slug": "repost-x-posts-everywhere",
      "url": "https://grokbot.dev/marketplace/repost-x-posts-everywhere/",
      "detail_url": "https://grokbot.dev/api/v1/templates/repost-x-posts-everywhere.json",
      "headline": "repost X posts everywhere",
      "summary": "Copies every new X post out to your other four accounts",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "automation",
        "content",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jackfriks",
        "url": "https://x.com/jackfriks/status/2093719119984001073"
      },
      "share_url": "https://x.ai/bot/fu6JIwhLoBvrxtaZik0RP",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T15:15:12.000Z",
      "updated_at": "2026-08-29T15:15:12.000Z"
    },
    {
      "type": "template",
      "slug": "ai-pm-os",
      "url": "https://grokbot.dev/marketplace/ai-pm-os/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ai-pm-os.json",
      "headline": "AI PM OS",
      "summary": "A product-management operating system packaged as one reusable setup",
      "categories": [
        "business",
        "developer",
        "productivity",
        "back-office",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nurijanian",
        "url": "https://x.com/nurijanian/status/2093716302884147646"
      },
      "share_url": "https://x.ai/bot/9dtfHw4LHmwc5uBC-a9vj",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T15:04:00.000Z",
      "updated_at": "2026-08-29T15:04:00.000Z"
    },
    {
      "type": "template",
      "slug": "rutin",
      "url": "https://grokbot.dev/marketplace/rutin/",
      "detail_url": "https://grokbot.dev/api/v1/templates/rutin.json",
      "headline": "Rutin",
      "summary": "A Monday tune-up for every routine across your fleet of bots",
      "categories": [
        "developer",
        "ops",
        "automation",
        "productivity",
        "monitoring",
        "meta-bot",
        "scheduled",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@naoufal_elh",
        "url": "https://x.com/naoufal_elh/status/2093710581354135607"
      },
      "share_url": "https://x.ai/bot/o4gWkNGmffEaVtOhaEsA7",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-29T14:41:16.000Z",
      "updated_at": "2026-08-29T14:41:16.000Z"
    },
    {
      "type": "template",
      "slug": "adler",
      "url": "https://grokbot.dev/marketplace/adler/",
      "detail_url": "https://grokbot.dev/api/v1/templates/adler.json",
      "headline": "Adler",
      "summary": "A decisions mentor grounded in Adlerian psychology",
      "categories": [
        "personal",
        "decision-support",
        "wellbeing",
        "learning",
        "health",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@pardzz_",
        "url": "https://x.com/pardzz_/status/2093708336025698586"
      },
      "share_url": "https://x.ai/bot/5HCe3lRaa5-c4c2RbA-LT",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T14:32:21.000Z",
      "updated_at": "2026-08-29T14:32:21.000Z"
    },
    {
      "type": "template",
      "slug": "steal-this-business",
      "url": "https://grokbot.dev/marketplace/steal-this-business/",
      "detail_url": "https://grokbot.dev/api/v1/templates/steal-this-business.json",
      "headline": "Steal This Business",
      "summary": "Reverse-engineers a company you admire into one you could build",
      "categories": [
        "business",
        "research",
        "decision-support",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@adxtyahq",
        "url": "https://x.com/adxtyahq/status/2093705315607065020"
      },
      "share_url": "https://x.ai/bot/Ojrv95GLUG1nO1p1RWzVK",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T14:20:21.000Z",
      "updated_at": "2026-08-29T14:20:21.000Z"
    },
    {
      "type": "template",
      "slug": "skill-bot",
      "url": "https://grokbot.dev/marketplace/skill-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/skill-bot.json",
      "headline": "Skill Bot",
      "summary": "A librarian for your bot's skills that dedupes and keeps them current",
      "categories": [
        "developer",
        "automation",
        "productivity",
        "knowledge-base",
        "meta-bot",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@davespeers",
        "url": "https://x.com/davespeers/status/2093703778872496292"
      },
      "share_url": "https://x.ai/bot/WdKtVYWvxVEDmc7xp8zO2",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T14:14:14.000Z",
      "updated_at": "2026-08-29T14:14:14.000Z"
    },
    {
      "type": "template",
      "slug": "saasbot",
      "url": "https://grokbot.dev/marketplace/saasbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/saasbot.json",
      "headline": "SaaSbot",
      "summary": "A weekday operator that runs GTM, outbound, QA and onboarding",
      "categories": [
        "business",
        "sales",
        "marketer",
        "ops",
        "automation",
        "growth",
        "back-office",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@danielfoch",
        "url": "https://x.com/danielfoch/status/2093697807542526325"
      },
      "share_url": "https://x.ai/bot/X6RbSbeyLvQ_I5k3zU4IM",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T13:50:30.000Z",
      "updated_at": "2026-08-29T13:50:30.000Z"
    },
    {
      "type": "template",
      "slug": "youtube",
      "url": "https://grokbot.dev/marketplace/youtube/",
      "detail_url": "https://grokbot.dev/api/v1/templates/youtube.json",
      "headline": "Youtube分析官",
      "summary": "Ranks the best YouTube videos on a topic and writes the brief",
      "categories": [
        "research",
        "youtube",
        "content",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@madogiwacowork",
        "url": "https://x.com/madogiwacowork/status/2093685473411805533"
      },
      "share_url": "https://x.ai/bot/Ja29gpInav-alRhXhzyNL",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T13:01:30.000Z",
      "updated_at": "2026-08-29T13:01:30.000Z"
    },
    {
      "type": "template",
      "slug": "segundo-c-rebro",
      "url": "https://grokbot.dev/marketplace/segundo-c-rebro/",
      "detail_url": "https://grokbot.dev/api/v1/templates/segundo-c-rebro.json",
      "headline": "Segundo Cérebro",
      "summary": "An Obsidian second brain with a morning brief and a nightly check-in",
      "categories": [
        "personal",
        "productivity",
        "knowledge-base",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liderzio",
        "url": "https://x.com/liderzio/status/2093672211844337867"
      },
      "share_url": "https://x.ai/bot/OaRwBX_QPos9EDlhLEV1J",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T12:08:48.000Z",
      "updated_at": "2026-08-29T12:08:48.000Z"
    },
    {
      "type": "template",
      "slug": "paddy",
      "url": "https://grokbot.dev/marketplace/paddy/",
      "detail_url": "https://grokbot.dev/api/v1/templates/paddy.json",
      "headline": "Paddy",
      "summary": "Judges a whole YouTube video as one promise, not just the title",
      "categories": [
        "creator",
        "growth",
        "decision-support",
        "content",
        "youtube",
        "video",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DavidCarbutt_",
        "url": "https://x.com/DavidCarbutt_/status/2093669914926072133"
      },
      "share_url": "https://x.ai/bot/A42rzhad6J8lhYMOaQ20o",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T11:59:40.000Z",
      "updated_at": "2026-08-29T11:59:40.000Z"
    },
    {
      "type": "template",
      "slug": "dbs",
      "url": "https://grokbot.dev/marketplace/dbs/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dbs.json",
      "headline": "dbs",
      "summary": "A slash-command toolbox for business, content and what to do next",
      "categories": [
        "business",
        "marketer",
        "content",
        "social-media",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Leechael",
        "url": "https://x.com/Leechael/status/2093655085935165706"
      },
      "share_url": "https://x.ai/bot/l6H6WL7HF-CAwcvr1hBey",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T11:00:45.000Z",
      "updated_at": "2026-08-29T11:00:45.000Z"
    },
    {
      "type": "template",
      "slug": "ads-operator",
      "url": "https://grokbot.dev/marketplace/ads-operator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ads-operator.json",
      "headline": "Ads Operator",
      "summary": "Builds ready-to-run search and social ad plans for local trades",
      "categories": [
        "marketer",
        "business",
        "growth",
        "social-media",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@wells1226",
        "url": "https://x.com/wells1226/status/2093640876857999710"
      },
      "share_url": "https://x.ai/bot/zj8VKu1CnqkHCM4Na1zex",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T10:04:17.000Z",
      "updated_at": "2026-08-29T10:04:17.000Z"
    },
    {
      "type": "template",
      "slug": "paperwork",
      "url": "https://grokbot.dev/marketplace/paperwork/",
      "detail_url": "https://grokbot.dev/api/v1/templates/paperwork.json",
      "headline": "Paperwork",
      "summary": "Works out what a boring document is and what you have to do about it",
      "categories": [
        "personal",
        "productivity",
        "automation",
        "back-office",
        "knowledge-base",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093635779176051134"
      },
      "share_url": "https://x.ai/bot/mNN576TxXnc_XZu9aCsfr",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T09:44:02.000Z",
      "updated_at": "2026-08-29T09:44:02.000Z"
    },
    {
      "type": "template",
      "slug": "appointment-finder",
      "url": "https://grokbot.dev/marketplace/appointment-finder/",
      "detail_url": "https://grokbot.dev/api/v1/templates/appointment-finder.json",
      "headline": "Appointment Finder",
      "summary": "Finds the best appointment slot so you never phone around again",
      "categories": [
        "personal",
        "productivity",
        "life-hacks",
        "calendar",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093635774079971693"
      },
      "share_url": "https://x.ai/bot/75K-dB4m30goo_PamA9nM",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T09:44:01.000Z",
      "updated_at": "2026-08-29T09:44:01.000Z"
    },
    {
      "type": "template",
      "slug": "returns-warranties",
      "url": "https://grokbot.dev/marketplace/returns-warranties/",
      "detail_url": "https://grokbot.dev/api/v1/templates/returns-warranties.json",
      "headline": "Returns & Warranties",
      "summary": "Warns you before a return, refund or warranty window closes",
      "categories": [
        "personal",
        "monitoring",
        "saving-money",
        "shopping",
        "email",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093635776659554701"
      },
      "share_url": "https://x.ai/bot/HmUpwJbVbgLEGisEj0FPt",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T09:44:01.000Z",
      "updated_at": "2026-08-29T09:44:01.000Z"
    },
    {
      "type": "template",
      "slug": "quote-collector",
      "url": "https://grokbot.dev/marketplace/quote-collector/",
      "detail_url": "https://grokbot.dev/api/v1/templates/quote-collector.json",
      "headline": "Quote Collector",
      "summary": "Gathers comparable quotes from local trades for one named job",
      "categories": [
        "personal",
        "saving-money",
        "decision-support",
        "home",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093635771559194908"
      },
      "share_url": "https://x.ai/bot/FI36ngq3zTUOFQrYc-XQX",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T09:44:00.000Z",
      "updated_at": "2026-08-29T09:44:00.000Z"
    },
    {
      "type": "template",
      "slug": "foundry",
      "url": "https://grokbot.dev/marketplace/foundry/",
      "detail_url": "https://grokbot.dev/api/v1/templates/foundry.json",
      "headline": "Foundry",
      "summary": "Interviews you about a new venture and writes the operating files",
      "categories": [
        "business",
        "developer",
        "productivity",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@gtOSnz",
        "url": "https://x.com/gtOSnz/status/2093633012722512228"
      },
      "share_url": "https://x.ai/bot/ScfBcREQMQex9JUf2Se63",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T09:33:02.000Z",
      "updated_at": "2026-08-29T09:33:02.000Z"
    },
    {
      "type": "template",
      "slug": "thefounder",
      "url": "https://grokbot.dev/marketplace/thefounder/",
      "detail_url": "https://grokbot.dev/api/v1/templates/thefounder.json",
      "headline": "TheFounder",
      "summary": "Holds logins and the shared machine. Loads only after you tap send.",
      "categories": [
        "business",
        "ops",
        "productivity",
        "back-office",
        "agent-team",
        "on-demand",
        "scheduled",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DaniAcostaAI",
        "url": "https://x.com/DaniAcostaAI/status/2093628837867241883"
      },
      "share_url": "https://x.ai/bot/Bt48h63v32_q_shWVlEBb",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-29T09:16:27.000Z",
      "updated_at": "2026-08-29T09:16:27.000Z"
    },
    {
      "type": "template",
      "slug": "tutor",
      "url": "https://grokbot.dev/marketplace/tutor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tutor.json",
      "headline": "Tutor",
      "summary": "Any subject, taught in small lessons anchored to one everyday picture",
      "categories": [
        "personal",
        "student",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@anandVragav",
        "url": "https://x.com/anandVragav/status/2093622965053059198"
      },
      "share_url": "https://x.ai/bot/Rj9uN1lhqYP-kLpRVShG0",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T08:53:07.000Z",
      "updated_at": "2026-08-29T08:53:07.000Z"
    },
    {
      "type": "template",
      "slug": "japanese-travel-booking-agent",
      "url": "https://grokbot.dev/marketplace/japanese-travel-booking-agent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/japanese-travel-booking-agent.json",
      "headline": "旅行手配エージェント",
      "summary": "Compares cheap and easy routes, then books flights, rail and hotels",
      "categories": [
        "personal",
        "travel",
        "decision-support",
        "saving-money",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kinopee_ai",
        "url": "https://x.com/kinopee_ai/status/2093618570253222126"
      },
      "share_url": "https://x.ai/bot/uvX1KHZ67D_AZQogYxR8-",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T08:35:39.000Z",
      "updated_at": "2026-08-29T08:35:39.000Z"
    },
    {
      "type": "template",
      "slug": "ezra",
      "url": "https://grokbot.dev/marketplace/ezra/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ezra.json",
      "headline": "Ezra",
      "summary": "Turns a sermon into small-group and full teaching notes in Bahasa",
      "categories": [
        "personal",
        "creator",
        "content",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lapaksquare",
        "url": "https://x.com/lapaksquare/status/2093614088526131246"
      },
      "share_url": "https://x.ai/bot/YlbxRlO-HM1TEC6l2YSM6",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T08:17:50.000Z",
      "updated_at": "2026-08-29T08:17:50.000Z"
    },
    {
      "type": "template",
      "slug": "brief",
      "url": "https://grokbot.dev/marketplace/brief/",
      "detail_url": "https://grokbot.dev/api/v1/templates/brief.json",
      "headline": "Brief",
      "summary": "Coaches a first-time builder through writing their first bot brief",
      "categories": [
        "personal",
        "learning",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@anandVragav",
        "url": "https://x.com/anandVragav/status/2093613851048661141"
      },
      "share_url": "https://x.ai/bot/Z7mWuQwWmnR-im3F7Hyh1",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T08:16:54.000Z",
      "updated_at": "2026-08-29T08:16:54.000Z"
    },
    {
      "type": "template",
      "slug": "x-high-coach",
      "url": "https://grokbot.dev/marketplace/x-high-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-high-coach.json",
      "headline": "X High Coach",
      "summary": "Audits any public X account and tells you exactly what to change",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "analytics",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Hightv",
        "url": "https://x.com/Hightv/status/2093611453010084257"
      },
      "share_url": "https://x.ai/bot/xSfBSprfKv5h909uzrv7W",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T08:07:22.000Z",
      "updated_at": "2026-08-29T08:07:22.000Z"
    },
    {
      "type": "template",
      "slug": "fantasy-football",
      "url": "https://grokbot.dev/marketplace/fantasy-football/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fantasy-football.json",
      "headline": "Fantasy Football",
      "summary": "A year-round fantasy football desk for start, sit and trade calls",
      "categories": [
        "personal",
        "decision-support",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@notswizz",
        "url": "https://x.com/notswizz/status/2093605993372381379"
      },
      "share_url": "https://x.ai/bot/VWAXuVB5VI6ScHdO97Bh0",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T07:45:40.000Z",
      "updated_at": "2026-08-29T07:45:40.000Z"
    },
    {
      "type": "template",
      "slug": "negotiator",
      "url": "https://grokbot.dev/marketplace/negotiator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/negotiator.json",
      "headline": "Negotiator",
      "summary": "Coaches you through a negotiation before you walk into it",
      "categories": [
        "personal",
        "decision-support",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@danizhu",
        "url": "https://x.com/danizhu/status/2093604446098047488"
      },
      "share_url": "https://x.ai/bot/gsA3R-R-IIA7x3qUkojCu",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T07:39:31.000Z",
      "updated_at": "2026-08-29T07:39:31.000Z"
    },
    {
      "type": "plugin",
      "slug": "postonce",
      "url": "https://grokbot.dev/plugins/postonce/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/postonce.json",
      "headline": "PostOnce",
      "summary": "Connect a Grok bot to the socials you already run and draft posts from chat.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "postonce.app",
        "url": "https://postonce.app"
      },
      "added_at": "2026-08-29T07:37:00Z",
      "updated_at": "2026-08-29T07:37:00Z"
    },
    {
      "type": "plugin",
      "slug": "contentdrips",
      "url": "https://grokbot.dev/plugins/contentdrips/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/contentdrips.json",
      "headline": "ContentDrips",
      "summary": "Let your agent design on-brand LinkedIn and Instagram carousels from chat.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "contentdrips.com",
        "url": "https://contentdrips.com"
      },
      "added_at": "2026-08-29T07:14:51Z",
      "updated_at": "2026-08-29T07:14:51Z"
    },
    {
      "type": "use-case",
      "slug": "topic-to-branded-carousel",
      "url": "https://grokbot.dev/use-cases/topic-to-branded-carousel/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/topic-to-branded-carousel.json",
      "headline": "Create a branded carousel from a single topic",
      "summary": "Give Grok Bot a topic such as how to price freelance work. With ContentDrips MCP connected, it builds a multi-slide carousel in your saved brand style (or a named template), returns the editor link, and waits for you before any LinkedIn or Instagram publish.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CONTENTDRIPS",
        "url": "https://github.com/CONTENTDRIPS/Contentdrips-MCP"
      },
      "added_at": "2026-08-29T07:14:51Z",
      "updated_at": "2026-08-29T07:14:51Z"
    },
    {
      "type": "template",
      "slug": "freebots-lol",
      "url": "https://grokbot.dev/marketplace/freebots-lol/",
      "detail_url": "https://grokbot.dev/api/v1/templates/freebots-lol.json",
      "headline": "freebots.lol",
      "summary": "Enrols your bot in a public mesh with its own key and page",
      "categories": [
        "developer",
        "social-media",
        "automation",
        "meta-bot",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Daniel_Farinax",
        "url": "https://x.com/Daniel_Farinax/status/2093592700587331679"
      },
      "share_url": "https://x.ai/bot/ndOGeXyjkQLdceRlk7JP4",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T06:52:51.000Z",
      "updated_at": "2026-08-29T06:52:51.000Z"
    },
    {
      "type": "template",
      "slug": "website-agency-lead-scout",
      "url": "https://grokbot.dev/marketplace/website-agency-lead-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/website-agency-lead-scout.json",
      "headline": "website agency lead scout",
      "summary": "Delivers five vetted businesses that need a new website each morning",
      "categories": [
        "business",
        "sales",
        "research",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093586339086352806"
      },
      "share_url": "https://x.ai/bot/FBSTEPfTxj7ekvSml-nUJ",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T06:27:34.000Z",
      "updated_at": "2026-08-29T06:27:34.000Z"
    },
    {
      "type": "template",
      "slug": "job-interview-hunter",
      "url": "https://grokbot.dev/marketplace/job-interview-hunter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/job-interview-hunter.json",
      "headline": "job interview hunter",
      "summary": "Drafts tailored applications and referral notes on a weekday cadence",
      "categories": [
        "personal",
        "recruiting",
        "productivity",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093585412384244060"
      },
      "share_url": "https://x.ai/bot/B_8a8ApckqZFiJwWRBf5u",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T06:23:53.000Z",
      "updated_at": "2026-08-29T06:23:53.000Z"
    },
    {
      "type": "template",
      "slug": "dadprotech-brand-manager",
      "url": "https://grokbot.dev/marketplace/dadprotech-brand-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dadprotech-brand-manager.json",
      "headline": "dadprotech brand manager",
      "summary": "Suggests one post a day plus replies, in the owner's own voice",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "content",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093583874530156635"
      },
      "share_url": "https://x.ai/bot/F7rovUv9EumNAoj9vEAWm",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T06:17:47.000Z",
      "updated_at": "2026-08-29T06:17:47.000Z"
    },
    {
      "type": "template",
      "slug": "family-wordpress-helpdesk",
      "url": "https://grokbot.dev/marketplace/family-wordpress-helpdesk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/family-wordpress-helpdesk.json",
      "headline": "family wordpress helpdesk",
      "summary": "A help desk for the relative who runs the family WordPress site",
      "categories": [
        "personal",
        "family",
        "support",
        "knowledge-base",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093583573915963624"
      },
      "share_url": "https://x.ai/bot/7ySyCp6OurH0hlcKMAm_b",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T06:16:35.000Z",
      "updated_at": "2026-08-29T06:16:35.000Z"
    },
    {
      "type": "template",
      "slug": "overnight-shipper",
      "url": "https://grokbot.dev/marketplace/overnight-shipper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/overnight-shipper.json",
      "headline": "overnight shipper",
      "summary": "Drop an idea before bed and review the pull request in the morning",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093582410638311676"
      },
      "share_url": "https://x.ai/bot/aaqCOb-3SE48_7qAEAzAf",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T06:11:58.000Z",
      "updated_at": "2026-08-29T06:11:58.000Z"
    },
    {
      "type": "template",
      "slug": "facebook-group-scout",
      "url": "https://grokbot.dev/marketplace/facebook-group-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/facebook-group-scout.json",
      "headline": "facebook group scout",
      "summary": "Watches the Facebook groups you name for posts worth replying to",
      "categories": [
        "business",
        "social-media",
        "monitoring",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093581726287335447"
      },
      "share_url": "https://x.ai/bot/C7ZoMLPxEbFmu0-iAieFj",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T06:09:15.000Z",
      "updated_at": "2026-08-29T06:09:15.000Z"
    },
    {
      "type": "template",
      "slug": "freelance-manager",
      "url": "https://grokbot.dev/marketplace/freelance-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/freelance-manager.json",
      "headline": "freelance manager",
      "summary": "Chases proposals, invoices and milestones for a solo freelancer",
      "categories": [
        "business",
        "ops",
        "back-office",
        "finance",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093580839833809285"
      },
      "share_url": "https://x.ai/bot/nVbIdGSLO4i-QU183t7Sg",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T06:05:43.000Z",
      "updated_at": "2026-08-29T06:05:43.000Z"
    },
    {
      "type": "template",
      "slug": "gonzalo-s-smb-manager",
      "url": "https://grokbot.dev/marketplace/gonzalo-s-smb-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gonzalo-s-smb-manager.json",
      "headline": "gonzalo's smb manager",
      "summary": "Wins back customers and fills tomorrow, with the owner approving each step",
      "categories": [
        "business",
        "ops",
        "back-office",
        "automation",
        "social-media"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093579852955975761"
      },
      "share_url": "https://x.ai/bot/G0GVoN9xUbXFucwWz539v",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T06:01:48.000Z",
      "updated_at": "2026-08-29T06:01:48.000Z"
    },
    {
      "type": "template",
      "slug": "construction-office-manager",
      "url": "https://grokbot.dev/marketplace/construction-office-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/construction-office-manager.json",
      "headline": "construction office manager",
      "summary": "A back-office manager for one growing construction company",
      "categories": [
        "business",
        "ops",
        "back-office",
        "automation",
        "finance"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@joshkim",
        "url": "https://x.com/joshkim/status/2093579076623876386"
      },
      "share_url": "https://x.ai/bot/Uytjr0oAalw0OuzCLdWPd",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T05:58:43.000Z",
      "updated_at": "2026-08-29T05:58:43.000Z"
    },
    {
      "type": "template",
      "slug": "remind-bot",
      "url": "https://grokbot.dev/marketplace/remind-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/remind-bot.json",
      "headline": "remind bot",
      "summary": "Holds the small reminders that never make it onto your calendar",
      "categories": [
        "personal",
        "productivity",
        "life-hacks",
        "calendar",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@damonchen",
        "url": "https://x.com/damonchen/status/2093559687354671335"
      },
      "share_url": "https://x.ai/bot/peJxDrQRS4t2DHuHfzhfW",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T04:41:40.000Z",
      "updated_at": "2026-08-29T04:41:40.000Z"
    },
    {
      "type": "template",
      "slug": "critiquito",
      "url": "https://grokbot.dev/marketplace/critiquito/",
      "detail_url": "https://grokbot.dev/api/v1/templates/critiquito.json",
      "headline": "critiquito",
      "summary": "A design critic that reviews your UI screenshots and only has notes",
      "categories": [
        "developer",
        "creator",
        "design",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mamuso",
        "url": "https://x.com/mamuso/status/2093549356364501338"
      },
      "share_url": "https://x.ai/bot/rt9m-FTkJoGsZzAjsKLPM",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T04:00:37.000Z",
      "updated_at": "2026-08-29T04:00:37.000Z"
    },
    {
      "type": "template",
      "slug": "helidon-engineer",
      "url": "https://grokbot.dev/marketplace/helidon-engineer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/helidon-engineer.json",
      "headline": "helidon engineer",
      "summary": "Writes and reviews Helidon 4 code on modern Java",
      "categories": [
        "developer",
        "engineering",
        "productivity",
        "automation",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TheSurenk",
        "url": "https://x.com/TheSurenk/status/2093548918806122764"
      },
      "share_url": "https://x.ai/bot/5mReUHPYTBA6nJ2aNvlqn",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T03:58:53.000Z",
      "updated_at": "2026-08-29T03:58:53.000Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-igor",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-igor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-igor.json",
      "headline": "chief of staff (igor)",
      "summary": "Routes work across six bots and only wakes you for decisions",
      "categories": [
        "business",
        "ops",
        "productivity",
        "automation",
        "agent-team",
        "meta-bot"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@iamigorekk",
        "url": "https://x.com/iamigorekk/status/2093546304081162412"
      },
      "share_url": "https://x.ai/bot/we_JMJA8IuOvy1eUX6EQz",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-29T03:48:29.000Z",
      "updated_at": "2026-08-29T03:48:29.000Z"
    },
    {
      "type": "template",
      "slug": "kerf",
      "url": "https://grokbot.dev/marketplace/kerf/",
      "detail_url": "https://grokbot.dev/api/v1/templates/kerf.json",
      "headline": "kerf",
      "summary": "An engagement PM that slices sold work into tickets and drives it",
      "categories": [
        "business",
        "developer",
        "productivity",
        "automation",
        "back-office",
        "engineering",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@theoscarvibes",
        "url": "https://x.com/theoscarvibes/status/2093543065055056124"
      },
      "share_url": "https://x.ai/bot/3iNSp9IoRCnSjh0Z6MtWZ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T03:35:37.000Z",
      "updated_at": "2026-08-29T03:35:37.000Z"
    },
    {
      "type": "template",
      "slug": "travel-guru",
      "url": "https://grokbot.dev/marketplace/travel-guru/",
      "detail_url": "https://grokbot.dev/api/v1/templates/travel-guru.json",
      "headline": "travel guru",
      "summary": "Plans award travel around your home airport, points and status",
      "categories": [
        "personal",
        "travel",
        "saving-money",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@congressdj",
        "url": "https://x.com/congressdj/status/2093539459719434306"
      },
      "share_url": "https://x.ai/bot/r5R9X50NdzRZBPcBQAnhP",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T03:21:17.000Z",
      "updated_at": "2026-08-29T03:21:17.000Z"
    },
    {
      "type": "template",
      "slug": "growth-desk",
      "url": "https://grokbot.dev/marketplace/growth-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/growth-desk.json",
      "headline": "growth desk",
      "summary": "Drafts posts and growth tactics for one X account, never posts",
      "categories": [
        "marketer",
        "creator",
        "growth",
        "social-media",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Av1dlive",
        "url": "https://x.com/Av1dlive/status/2093537873823957415"
      },
      "share_url": "https://x.ai/bot/YYCOE-YeGxnGLb4Mbv7dO",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T03:14:59.000Z",
      "updated_at": "2026-08-29T03:14:59.000Z"
    },
    {
      "type": "template",
      "slug": "friend-finders",
      "url": "https://grokbot.dev/marketplace/friend-finders/",
      "detail_url": "https://grokbot.dev/api/v1/templates/friend-finders.json",
      "headline": "friend finders",
      "summary": "Scans your own X DMs and tells you which threads to answer now",
      "categories": [
        "social-media",
        "personal",
        "research",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@pukerrainbrow",
        "url": "https://x.com/pukerrainbrow/status/2093531901730676792"
      },
      "share_url": "https://x.ai/bot/FGBuaEH72GHuC9ZrVj7XA",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T02:51:15.000Z",
      "updated_at": "2026-08-29T02:51:15.000Z"
    },
    {
      "type": "template",
      "slug": "openrobot",
      "url": "https://grokbot.dev/marketplace/openrobot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/openrobot.json",
      "headline": "openrobot",
      "summary": "A collaboration intake desk that turns interest into an intro email",
      "categories": [
        "business",
        "recruiting",
        "email",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@noborderhuman",
        "url": "https://x.com/noborderhuman/status/2093529993972432967"
      },
      "share_url": "https://x.ai/bot/ndO6BI7E2ur5X-bhWM_1R",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T02:43:41.000Z",
      "updated_at": "2026-08-29T02:43:41.000Z"
    },
    {
      "type": "template",
      "slug": "keywire-would-you-rather-collector",
      "url": "https://grokbot.dev/marketplace/keywire-would-you-rather-collector/",
      "detail_url": "https://grokbot.dev/api/v1/templates/keywire-would-you-rather-collector.json",
      "headline": "KeyWire: Would You Rather: Collector",
      "summary": "Ten rounds of collector-fandom would-you-rather, answered with a tap",
      "categories": [
        "personal",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CryptoVonDoom",
        "url": "https://x.com/CryptoVonDoom/status/2093528067650281687"
      },
      "share_url": "https://x.ai/bot/_qeZe0Y7621Wr8y6d7KBU",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T02:36:01.000Z",
      "updated_at": "2026-08-29T02:36:01.000Z"
    },
    {
      "type": "template",
      "slug": "den",
      "url": "https://grokbot.dev/marketplace/den/",
      "detail_url": "https://grokbot.dev/api/v1/templates/den.json",
      "headline": "den",
      "summary": "Sits between a parent and the rest of the family's bots",
      "categories": [
        "personal",
        "family",
        "agent-team",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093528015900930387"
      },
      "share_url": "https://x.ai/bot/0aEcF7mtG_zsDWXEUeOGx",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-29T02:35:49.000Z",
      "updated_at": "2026-08-29T02:35:49.000Z"
    },
    {
      "type": "template",
      "slug": "bookworm",
      "url": "https://grokbot.dev/marketplace/bookworm/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bookworm.json",
      "headline": "bookworm",
      "summary": "Drafts and sends founder-voiced beta invites for a reading app",
      "categories": [
        "marketer",
        "growth",
        "email",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@NavyaM89482",
        "url": "https://x.com/NavyaM89482/status/2093524788761248166"
      },
      "share_url": "https://x.ai/bot/KPpT1F6tP4Q5GZ2BH2hBH",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T02:23:00.000Z",
      "updated_at": "2026-08-29T02:23:00.000Z"
    },
    {
      "type": "template",
      "slug": "club-sponsor-bot",
      "url": "https://grokbot.dev/marketplace/club-sponsor-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/club-sponsor-bot.json",
      "headline": "Club Sponsor Bot",
      "summary": "Runs sponsor, recruiter and speaker outreach for a student club",
      "categories": [
        "student",
        "sales",
        "growth",
        "recruiting",
        "events",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@NavyaM89482",
        "url": "https://x.com/NavyaM89482/status/2093524788761248166"
      },
      "share_url": "https://x.ai/bot/thQfSs8ZqbzB1w2cAmSzA",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T02:23:00.000Z",
      "updated_at": "2026-08-29T02:23:00.000Z"
    },
    {
      "type": "template",
      "slug": "koala",
      "url": "https://grokbot.dev/marketplace/koala/",
      "detail_url": "https://grokbot.dev/api/v1/templates/koala.json",
      "headline": "koala",
      "summary": "A launch assistant for a developer product's go-to-market push",
      "categories": [
        "developer",
        "marketer",
        "growth",
        "content",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093522645501551014"
      },
      "share_url": "https://x.ai/bot/55VuCAFXxFDHyaGPU3Bxt",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T02:14:29.000Z",
      "updated_at": "2026-08-29T02:14:29.000Z"
    },
    {
      "type": "template",
      "slug": "bond",
      "url": "https://grokbot.dev/marketplace/bond/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bond.json",
      "headline": "bond",
      "summary": "Takes one confidential job, does it, and logs what it did",
      "categories": [
        "business",
        "back-office",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093521385541005369"
      },
      "share_url": "https://x.ai/bot/iZvo8_lHfF0csZ-YmcZpv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T02:09:28.000Z",
      "updated_at": "2026-08-29T02:09:28.000Z"
    },
    {
      "type": "template",
      "slug": "loom",
      "url": "https://grokbot.dev/marketplace/loom/",
      "detail_url": "https://grokbot.dev/api/v1/templates/loom.json",
      "headline": "loom",
      "summary": "Reads across Gmail threads and drafts the reply, never sends it",
      "categories": [
        "email",
        "productivity",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093520466032136644"
      },
      "share_url": "https://x.ai/bot/cElGnAaR55iPHK2DGdPdu",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T02:05:49.000Z",
      "updated_at": "2026-08-29T02:05:49.000Z"
    },
    {
      "type": "news",
      "slug": "grok-bot-templates-explained",
      "url": "https://grokbot.dev/news/grok-bot-templates-explained/",
      "detail_url": "https://grokbot.dev/api/v1/news/grok-bot-templates-explained.json",
      "title": "Everything you need to know about Grok Bot templates",
      "headline": "Everything you need to know about Grok Bot templates",
      "summary": "A Grok Bot template is a shareable blueprint for a Bot. Open one link and Grok Bot creates a new copy with the original role, skills, routines, and supported integrations. Your chats, logins, and secrets stay private.",
      "kind": "announcement",
      "important": true,
      "external_url": null,
      "cta_label": null,
      "source": null,
      "categories": [],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "added_at": "2026-08-29T02:00:00Z",
      "published_at": "2026-08-29T02:00:00Z",
      "updated_at": "2026-08-29T02:00:00Z"
    },
    {
      "type": "template",
      "slug": "travel-agent",
      "url": "https://grokbot.dev/marketplace/travel-agent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/travel-agent.json",
      "headline": "Travel Agent",
      "summary": "Keeps a Notion travel log and answers questions from your own trips",
      "categories": [
        "personal",
        "travel",
        "productivity",
        "knowledge-base",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jjeremycai",
        "url": "https://x.com/jjeremycai/status/2093518862868426938"
      },
      "share_url": "https://x.ai/bot/_yHS4eeajJMAXY1EHAdoO",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T01:59:27.000Z",
      "updated_at": "2026-08-29T01:59:27.000Z"
    },
    {
      "type": "template",
      "slug": "porshe",
      "url": "https://grokbot.dev/marketplace/porshe/",
      "detail_url": "https://grokbot.dev/api/v1/templates/porshe.json",
      "headline": "porshe",
      "summary": "Finds money you are already owed but have not collected",
      "categories": [
        "business",
        "finance",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093518231235686589"
      },
      "share_url": "https://x.ai/bot/BXDRX1jaURkI4Tx70zLg6",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T01:56:56.000Z",
      "updated_at": "2026-08-29T01:56:56.000Z"
    },
    {
      "type": "template",
      "slug": "stank",
      "url": "https://grokbot.dev/marketplace/stank/",
      "detail_url": "https://grokbot.dev/api/v1/templates/stank.json",
      "headline": "stank",
      "summary": "A deadpan reminder to go take a shower",
      "categories": [
        "personal",
        "wellbeing",
        "life-hacks",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093517486117499387"
      },
      "share_url": "https://x.ai/bot/FuUabKAg1U5Hyi39TvpTi",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T01:53:59.000Z",
      "updated_at": "2026-08-29T01:53:59.000Z"
    },
    {
      "type": "template",
      "slug": "jobs",
      "url": "https://grokbot.dev/marketplace/jobs/",
      "detail_url": "https://grokbot.dev/api/v1/templates/jobs.json",
      "headline": "jobs",
      "summary": "A feature editor that pitches a few sharp ideas and the cuts",
      "categories": [
        "developer",
        "business",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093516772255396203"
      },
      "share_url": "https://x.ai/bot/LqFDQ8zlNLQqlFP_vvzs_",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T01:51:08.000Z",
      "updated_at": "2026-08-29T01:51:08.000Z"
    },
    {
      "type": "template",
      "slug": "wing",
      "url": "https://grokbot.dev/marketplace/wing/",
      "detail_url": "https://grokbot.dev/api/v1/templates/wing.json",
      "headline": "wing",
      "summary": "A dating-app wingman that drafts openers and replies in your voice",
      "categories": [
        "personal",
        "life-hacks",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093516142019318262"
      },
      "share_url": "https://x.ai/bot/7tQzGIL3WcHG8_Nt7CVwv",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T01:48:38.000Z",
      "updated_at": "2026-08-29T01:48:38.000Z"
    },
    {
      "type": "template",
      "slug": "product-ops",
      "url": "https://grokbot.dev/marketplace/product-ops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/product-ops.json",
      "headline": "Product Ops",
      "summary": "Turns a freeze list into a weekly ship checklist for the team",
      "categories": [
        "business",
        "developer",
        "engineering",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@inqusit",
        "url": "https://x.com/inqusit/status/2093513553613656106"
      },
      "share_url": "https://x.ai/bot/gJKPDjN3yS95ZpZBTWruv",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T01:38:21.000Z",
      "updated_at": "2026-08-29T01:38:21.000Z"
    },
    {
      "type": "template",
      "slug": "off-balance-atlas",
      "url": "https://grokbot.dev/marketplace/off-balance-atlas/",
      "detail_url": "https://grokbot.dev/api/v1/templates/off-balance-atlas.json",
      "headline": "Off-Balance Atlas",
      "summary": "Writes source-linked deep dives on tech, ML and security",
      "categories": [
        "developer",
        "research",
        "content",
        "engineering",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AdemVessell",
        "url": "https://x.com/AdemVessell/status/2093511313158983798"
      },
      "share_url": "https://x.ai/bot/tSUFdzcg2WDFLFsFLHzIb",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T01:29:27.000Z",
      "updated_at": "2026-08-29T01:29:27.000Z"
    },
    {
      "type": "template",
      "slug": "icon",
      "url": "https://grokbot.dev/marketplace/icon/",
      "detail_url": "https://grokbot.dev/api/v1/templates/icon.json",
      "headline": "Icon",
      "summary": "Turns any subject into a 3D clay-style bot avatar",
      "categories": [
        "creator",
        "design",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@yriica",
        "url": "https://x.com/yriica/status/2093511043691810874"
      },
      "share_url": "https://x.ai/bot/inke26gsycrB-4N4Z3vVE",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T01:28:23.000Z",
      "updated_at": "2026-08-29T01:28:23.000Z"
    },
    {
      "type": "template",
      "slug": "ceo",
      "url": "https://grokbot.dev/marketplace/ceo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ceo.json",
      "headline": "CEO",
      "summary": "A virtual CEO that sets the agenda and directs your other bots",
      "categories": [
        "business",
        "ops",
        "decision-support",
        "agent-team"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@inqusit",
        "url": "https://x.com/inqusit/status/2093510161524810062"
      },
      "share_url": "https://x.ai/bot/GHLPyes3hiP9A6kES7UHg",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-29T01:24:52.000Z",
      "updated_at": "2026-08-29T01:24:52.000Z"
    },
    {
      "type": "template",
      "slug": "yolk",
      "url": "https://grokbot.dev/marketplace/yolk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/yolk.json",
      "headline": "Yolk",
      "summary": "A Tamagotchi egg in your sidebar that wants feeding four times a day",
      "categories": [
        "personal",
        "food",
        "life-hacks",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jp_costa",
        "url": "https://x.com/jp_costa/status/2093508536718500211"
      },
      "share_url": "https://x.ai/bot/Rk8tYkT8dM9QbhsAci5lh",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T01:18:25.000Z",
      "updated_at": "2026-08-29T01:18:25.000Z"
    },
    {
      "type": "template",
      "slug": "sanity",
      "url": "https://grokbot.dev/marketplace/sanity/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sanity.json",
      "headline": "Sanity",
      "summary": "A specialist for Sanity content models, schemas and GROQ",
      "categories": [
        "developer",
        "engineering",
        "content",
        "knowledge-base",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ahdumgray",
        "url": "https://x.com/ahdumgray/status/2093504459741794550"
      },
      "share_url": "https://x.ai/bot/qR7nq7v3w0bwpojx2LgQx",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T01:02:13.000Z",
      "updated_at": "2026-08-29T01:02:13.000Z"
    },
    {
      "type": "template",
      "slug": "agent-smith",
      "url": "https://grokbot.dev/marketplace/agent-smith/",
      "detail_url": "https://grokbot.dev/api/v1/templates/agent-smith.json",
      "headline": "Agent Smith",
      "summary": "A janitor for multi-bot workspaces that stops cruft piling up",
      "categories": [
        "developer",
        "ops",
        "automation",
        "back-office",
        "meta-bot",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@chiplay",
        "url": "https://x.com/chiplay/status/2093502053037293650"
      },
      "share_url": "https://x.ai/bot/JcFj23aaufNWkuiiJTX0j",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T00:52:39.000Z",
      "updated_at": "2026-08-29T00:52:39.000Z"
    },
    {
      "type": "template",
      "slug": "box-inspector",
      "url": "https://grokbot.dev/marketplace/box-inspector/",
      "detail_url": "https://grokbot.dev/api/v1/templates/box-inspector.json",
      "headline": "Box Inspector",
      "summary": "Inspects a Grok bot's share link before you let it into your account",
      "categories": [
        "personal",
        "developer",
        "decision-support",
        "research",
        "meta-bot",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SuddenlyJon",
        "url": "https://x.com/SuddenlyJon/status/2093499564988703231"
      },
      "share_url": "https://x.ai/bot/q7GLbLhMZDpJXBGuuci1J",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T00:42:46.000Z",
      "updated_at": "2026-08-29T00:42:46.000Z"
    },
    {
      "type": "template",
      "slug": "marketboxscan",
      "url": "https://grokbot.dev/marketplace/marketboxscan/",
      "detail_url": "https://grokbot.dev/api/v1/templates/marketboxscan.json",
      "headline": "MarketBoxScan",
      "summary": "A pre-work tech news and inbox briefing for writers",
      "categories": [
        "creator",
        "news",
        "email",
        "monitoring",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@techAU",
        "url": "https://x.com/techAU/status/2093498668297101491"
      },
      "share_url": "https://x.ai/bot/-LYLlgknV3IgZcFEmhcLs",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T00:39:12.000Z",
      "updated_at": "2026-08-29T00:39:12.000Z"
    },
    {
      "type": "template",
      "slug": "sylvia-style",
      "url": "https://grokbot.dev/marketplace/sylvia-style/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sylvia-style.json",
      "headline": "Sylvia Style",
      "summary": "A personal stylist that shops live pieces and builds you a lookbook",
      "categories": [
        "personal",
        "shopping",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@clairevo",
        "url": "https://x.com/clairevo/status/2093497798717260229"
      },
      "share_url": "https://x.ai/bot/uVBVr5NSR6VirgJrgikIl",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T00:35:45.000Z",
      "updated_at": "2026-08-29T00:35:45.000Z"
    },
    {
      "type": "template",
      "slug": "chatprd",
      "url": "https://grokbot.dev/marketplace/chatprd/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chatprd.json",
      "headline": "ChatPRD",
      "summary": "A product manager that keeps every spec and discovery doc inside ChatPRD",
      "categories": [
        "business",
        "productivity",
        "automation",
        "content",
        "meetings",
        "knowledge-base"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@clairevo",
        "url": "https://x.com/clairevo/status/2093496614099042450"
      },
      "share_url": "https://x.ai/bot/36vKs2HSysdaJDe6OLD4w",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T00:31:02.000Z",
      "updated_at": "2026-08-29T00:31:02.000Z"
    },
    {
      "type": "template",
      "slug": "holly-helpdesk",
      "url": "https://grokbot.dev/marketplace/holly-helpdesk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/holly-helpdesk.json",
      "headline": "Holly Helpdesk",
      "summary": "Runs the support inbox and help desk as a frontline agent",
      "categories": [
        "business",
        "support",
        "email",
        "automation",
        "back-office"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@clairevo",
        "url": "https://x.com/clairevo/status/2093496607870423227"
      },
      "share_url": "https://x.ai/bot/sIoeE87fILU5CzptPF29K",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T00:31:01.000Z",
      "updated_at": "2026-08-29T00:31:01.000Z"
    },
    {
      "type": "template",
      "slug": "lockdown",
      "url": "https://grokbot.dev/marketplace/lockdown/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lockdown.json",
      "headline": "Lockdown",
      "summary": "A weekday SOC 2 watchdog that only speaks up when something fails",
      "categories": [
        "business",
        "ops",
        "monitoring",
        "automation",
        "back-office"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@clairevo",
        "url": "https://x.com/clairevo/status/2093496609955021275"
      },
      "share_url": "https://x.ai/bot/P1LmE76VG38Ui-XCmzAZE",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T00:31:01.000Z",
      "updated_at": "2026-08-29T00:31:01.000Z"
    },
    {
      "type": "template",
      "slug": "lgtm-the-pr-closer",
      "url": "https://grokbot.dev/marketplace/lgtm-the-pr-closer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lgtm-the-pr-closer.json",
      "headline": "lgtm the pr closer",
      "summary": "Wakes up each morning and burns down your open pull requests",
      "categories": [
        "developer",
        "engineering",
        "productivity",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@clairevo",
        "url": "https://x.com/clairevo/status/2093496605488083203"
      },
      "share_url": "https://x.ai/bot/vGk7yV-vF92ZegpNF3NPo",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T00:31:00.000Z",
      "updated_at": "2026-08-29T00:31:00.000Z"
    },
    {
      "type": "template",
      "slug": "echo",
      "url": "https://grokbot.dev/marketplace/echo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/echo.json",
      "headline": "Echo",
      "summary": "Builds the deck after a customer call, from what was actually said",
      "categories": [
        "business",
        "sales",
        "meetings",
        "content",
        "design",
        "productivity",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kristaletz",
        "url": "https://x.com/kristaletz/status/2093494509682217308"
      },
      "share_url": "https://x.ai/bot/ph5mcXqVy2p176Br7BJYi",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T00:22:41.000Z",
      "updated_at": "2026-08-29T00:22:41.000Z"
    },
    {
      "type": "template",
      "slug": "speed-lab",
      "url": "https://grokbot.dev/marketplace/speed-lab/",
      "detail_url": "https://grokbot.dev/api/v1/templates/speed-lab.json",
      "headline": "Speed Lab",
      "summary": "Runs a research loop on your site's render speed and keeps the wins",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@pwnies",
        "url": "https://x.com/pwnies/status/2093494257105379569"
      },
      "share_url": "https://x.ai/bot/LEbVr_WZ-cym7XwIm7xf5",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T00:21:40.000Z",
      "updated_at": "2026-08-29T00:21:40.000Z"
    },
    {
      "type": "template",
      "slug": "inbox-zero",
      "url": "https://grokbot.dev/marketplace/inbox-zero/",
      "detail_url": "https://grokbot.dev/api/v1/templates/inbox-zero.json",
      "headline": "Inbox Zero",
      "summary": "Keeps Gmail at zero by filing the noise every weekday",
      "categories": [
        "personal",
        "email",
        "productivity",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@zapnocode",
        "url": "https://x.com/zapnocode/status/2093493728660865073"
      },
      "share_url": "https://x.ai/bot/h5i1TCuYEL2mVtMbQtW98",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T00:19:34.000Z",
      "updated_at": "2026-08-29T00:19:34.000Z"
    },
    {
      "type": "template",
      "slug": "pika-bot",
      "url": "https://grokbot.dev/marketplace/pika-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/pika-bot.json",
      "headline": "Pika Bot",
      "summary": "Watches the Pokemon Center US store for new drops",
      "categories": [
        "personal",
        "shopping",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CardCaptain",
        "url": "https://x.com/CardCaptain/status/2093493396510068900"
      },
      "share_url": "https://x.ai/bot/FfGFlZLAQDyxhJwg2ZJlL",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-29T00:18:15.000Z",
      "updated_at": "2026-08-29T00:18:15.000Z"
    },
    {
      "type": "template",
      "slug": "jester",
      "url": "https://grokbot.dev/marketplace/jester/",
      "detail_url": "https://grokbot.dev/api/v1/templates/jester.json",
      "headline": "Jester",
      "summary": "Spins up image and video memes on request",
      "categories": [
        "creator",
        "content",
        "video",
        "social-media",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@memelord",
        "url": "https://x.com/memelord/status/2093490807600763217"
      },
      "share_url": "https://x.ai/bot/9MGTLhR6dzLrr6AWd8U1f",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-29T00:07:58.000Z",
      "updated_at": "2026-08-29T00:07:58.000Z"
    },
    {
      "type": "plugin",
      "slug": "bulkpublish",
      "url": "https://grokbot.dev/plugins/bulkpublish/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/bulkpublish.json",
      "headline": "BulkPublish",
      "summary": "Let your agent schedule and publish social posts across 15 networks.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "bulkpublish.com",
        "url": "https://www.bulkpublish.com"
      },
      "added_at": "2026-08-29T00:00:00Z",
      "updated_at": "2026-08-29T00:00:00Z"
    },
    {
      "type": "template",
      "slug": "canvas",
      "url": "https://grokbot.dev/marketplace/canvas/",
      "detail_url": "https://grokbot.dev/api/v1/templates/canvas.json",
      "headline": "Canvas",
      "summary": "Pulls your university units and deadlines out of Canvas",
      "categories": [
        "student",
        "learning",
        "calendar",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@daxperera",
        "url": "https://x.com/daxperera/status/2093488563388330458"
      },
      "share_url": "https://x.ai/bot/YihRBqrXaDwRdjN79Uofl",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T23:59:03.000Z",
      "updated_at": "2026-08-28T23:59:03.000Z"
    },
    {
      "type": "template",
      "slug": "tradbot",
      "url": "https://grokbot.dev/marketplace/tradbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/tradbot.json",
      "headline": "Tradbot",
      "summary": "A household chief of staff for family plans, school and home admin",
      "categories": [
        "personal",
        "family",
        "email",
        "calendar",
        "productivity",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@clairevo",
        "url": "https://x.com/clairevo/status/2093487955205923031"
      },
      "share_url": "https://x.ai/bot/uY_7s1TZILVzUeJ9lLOx9",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T23:56:38.000Z",
      "updated_at": "2026-08-28T23:56:38.000Z"
    },
    {
      "type": "template",
      "slug": "shopper",
      "url": "https://grokbot.dev/marketplace/shopper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/shopper.json",
      "headline": "Shopper",
      "summary": "Hunts genuine products across official stores and walks the cart to checkout",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@FranciscoKemeny",
        "url": "https://x.com/FranciscoKemeny/status/2093486505163735509"
      },
      "share_url": "https://x.ai/bot/h5CE1r5-LDWHacnuRuuOW",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T23:50:52.000Z",
      "updated_at": "2026-08-28T23:50:52.000Z"
    },
    {
      "type": "template",
      "slug": "shorty",
      "url": "https://grokbot.dev/marketplace/shorty/",
      "detail_url": "https://grokbot.dev/api/v1/templates/shorty.json",
      "headline": "Shorty",
      "summary": "Cuts YouTube Shorts from the long-form videos that already worked",
      "categories": [
        "creator",
        "youtube",
        "video",
        "content",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@farzyness",
        "url": "https://x.com/farzyness/status/2093485851606929592"
      },
      "share_url": "https://x.ai/bot/32fHIBw9Yz-s_o35KycGX",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T23:48:16.000Z",
      "updated_at": "2026-08-28T23:48:16.000Z"
    },
    {
      "type": "template",
      "slug": "neuroscience",
      "url": "https://grokbot.dev/marketplace/neuroscience/",
      "detail_url": "https://grokbot.dev/api/v1/templates/neuroscience.json",
      "headline": "Neuroscience",
      "summary": "A neuroscience and brain-computer-interface specialist",
      "categories": [
        "research",
        "learning",
        "knowledge-base",
        "health",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@monomyth",
        "url": "https://x.com/monomyth/status/2093485744405065866"
      },
      "share_url": "https://x.ai/bot/l_MfrDAGFed5t2A9Wrzqz",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T23:47:51.000Z",
      "updated_at": "2026-08-28T23:47:51.000Z"
    },
    {
      "type": "template",
      "slug": "webby",
      "url": "https://grokbot.dev/marketplace/webby/",
      "detail_url": "https://grokbot.dev/api/v1/templates/webby.json",
      "headline": "Webby",
      "summary": "A website admin that rebuilds, dashboards and keeps the newsletter going",
      "categories": [
        "developer",
        "engineering",
        "content",
        "automation",
        "back-office",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@farzyness",
        "url": "https://x.com/farzyness/status/2093485215150744014"
      },
      "share_url": "https://x.ai/bot/Q2shbC8RRmoRleIyr5J33",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T23:45:45.000Z",
      "updated_at": "2026-08-28T23:45:45.000Z"
    },
    {
      "type": "template",
      "slug": "gardener",
      "url": "https://grokbot.dev/marketplace/gardener/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gardener.json",
      "headline": "Gardener",
      "summary": "Pulls provable dead code in tiny behaviour-preserving pull requests",
      "categories": [
        "developer",
        "engineering",
        "automation",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tylerklose",
        "url": "https://x.com/tylerklose/status/2093483701480866210"
      },
      "share_url": "https://x.ai/bot/oH3eR4YWtsljcz0W4HUBp",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T23:39:44.000Z",
      "updated_at": "2026-08-28T23:39:44.000Z"
    },
    {
      "type": "template",
      "slug": "point-peddler",
      "url": "https://grokbot.dev/marketplace/point-peddler/",
      "detail_url": "https://grokbot.dev/api/v1/templates/point-peddler.json",
      "headline": "point peddler",
      "summary": "An award-travel brain that makes points optimisation effortless",
      "categories": [
        "personal",
        "finance",
        "travel",
        "saving-money",
        "decision-support",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093483181588779415"
      },
      "share_url": "https://x.ai/bot/PFD95widaEeqjkYLLUZmD",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T23:37:40.000Z",
      "updated_at": "2026-08-28T23:37:40.000Z"
    },
    {
      "type": "template",
      "slug": "yc-podcast-notes",
      "url": "https://grokbot.dev/marketplace/yc-podcast-notes/",
      "detail_url": "https://grokbot.dev/api/v1/templates/yc-podcast-notes.json",
      "headline": "YC Podcast Notes",
      "summary": "Hourly watch on Y Combinator's podcasts with founder-useful notes",
      "categories": [
        "business",
        "research",
        "monitoring",
        "news",
        "content",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@buuxbt",
        "url": "https://x.com/buuxbt/status/2093483175729361069"
      },
      "share_url": "https://x.ai/bot/0y-dcpVFqFkjibKs2M48D",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T23:37:38.000Z",
      "updated_at": "2026-08-28T23:37:38.000Z"
    },
    {
      "type": "template",
      "slug": "walt",
      "url": "https://grokbot.dev/marketplace/walt/",
      "detail_url": "https://grokbot.dev/api/v1/templates/walt.json",
      "headline": "Walt",
      "summary": "An executive producer that QCs another filmmaker bot until the cut is done",
      "categories": [
        "creator",
        "content",
        "video",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@FatDon420",
        "url": "https://x.com/FatDon420/status/2093481701930410183"
      },
      "share_url": "https://x.ai/bot/BsTA9W4uysdokbBQiriuQ",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T23:31:47.000Z",
      "updated_at": "2026-08-28T23:31:47.000Z"
    },
    {
      "type": "template",
      "slug": "pitch-deck-coach",
      "url": "https://grokbot.dev/marketplace/pitch-deck-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/pitch-deck-coach.json",
      "headline": "Pitch Deck Coach",
      "summary": "Tells you what an investor will actually understand and remember",
      "categories": [
        "business",
        "decision-support",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@hnshah",
        "url": "https://x.com/hnshah/status/2093478735718789453"
      },
      "share_url": "https://x.ai/bot/mqVPHm0oB3WPsnxbU1qB9",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T23:20:00.000Z",
      "updated_at": "2026-08-28T23:20:00.000Z"
    },
    {
      "type": "template",
      "slug": "outbid-mania",
      "url": "https://grokbot.dev/marketplace/outbid-mania/",
      "detail_url": "https://grokbot.dev/api/v1/templates/outbid-mania.json",
      "headline": "OutBid Mania",
      "summary": "Tracks a viral bidding-site trend and its clones on a daily dashboard",
      "categories": [
        "business",
        "monitoring",
        "analytics",
        "research",
        "news",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@dragosroua",
        "url": "https://x.com/dragosroua/status/2093474725976736130"
      },
      "share_url": "https://x.ai/bot/Sj_LPMP7hKOOSzF8YDiNr",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T23:04:04.000Z",
      "updated_at": "2026-08-28T23:04:04.000Z"
    },
    {
      "type": "template",
      "slug": "mystery-snack-agent",
      "url": "https://grokbot.dev/marketplace/mystery-snack-agent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/mystery-snack-agent.json",
      "headline": "Mystery Snack Agent",
      "summary": "A surprise dessert at your door every Friday at seven",
      "categories": [
        "personal",
        "life-hacks",
        "shopping",
        "scheduled",
        "food"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nayli_ai",
        "url": "https://x.com/nayli_ai/status/2093474108457537959"
      },
      "share_url": "https://x.ai/bot/jEv8xhxlnSNp2KnQ9ciyP",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T23:01:36.000Z",
      "updated_at": "2026-08-28T23:01:36.000Z"
    },
    {
      "type": "template",
      "slug": "sharenow-feed-bot",
      "url": "https://grokbot.dev/marketplace/sharenow-feed-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sharenow-feed-bot.json",
      "headline": "Sharenow Feed Bot",
      "summary": "Watches five social platforms hourly and publishes a live board",
      "categories": [
        "creator",
        "marketer",
        "monitoring",
        "social-media",
        "content",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@sharenow_today",
        "url": "https://x.com/sharenow_today/status/2093472078741615000"
      },
      "share_url": "https://x.ai/bot/oMU6GmI59Z1jtPUooMLLJ",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T22:53:33.000Z",
      "updated_at": "2026-08-28T22:53:33.000Z"
    },
    {
      "type": "template",
      "slug": "keywire-comic-week-brief",
      "url": "https://grokbot.dev/marketplace/keywire-comic-week-brief/",
      "detail_url": "https://grokbot.dev/api/v1/templates/keywire-comic-week-brief.json",
      "headline": "KeyWire Comic Week Brief",
      "summary": "Weekly pull-list reminder and a comics digest tuned to your taste",
      "categories": [
        "personal",
        "creator",
        "monitoring",
        "research",
        "content",
        "news",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@CryptoVonDoom",
        "url": "https://x.com/CryptoVonDoom/status/2093469613623583219"
      },
      "share_url": "https://x.ai/bot/1hyNK6vXzs_8QamyfhvCV",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T22:43:45.000Z",
      "updated_at": "2026-08-28T22:43:45.000Z"
    },
    {
      "type": "template",
      "slug": "last30days",
      "url": "https://grokbot.dev/marketplace/last30days/",
      "detail_url": "https://grokbot.dev/api/v1/templates/last30days.json",
      "headline": "last30days",
      "summary": "Surfaces what people have actually said about a topic in the last 30 days",
      "categories": [
        "marketer",
        "business",
        "research",
        "analytics",
        "social-media",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mvanhorn",
        "url": "https://x.com/mvanhorn/status/2093466618718245198"
      },
      "share_url": "https://x.ai/bot/ANv3NrqPfRcS9PdXku7h8",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T22:31:51.000Z",
      "updated_at": "2026-08-28T22:31:51.000Z"
    },
    {
      "type": "template",
      "slug": "clip-bot",
      "url": "https://grokbot.dev/marketplace/clip-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/clip-bot.json",
      "headline": "Clip Bot",
      "summary": "Cuts captioned 16:9 highlights from any YouTube podcast",
      "categories": [
        "creator",
        "youtube",
        "video",
        "content",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ThisWeeknAI",
        "url": "https://x.com/ThisWeeknAI/status/2093465404303720846"
      },
      "share_url": "https://x.ai/bot/Vk0cnF2c364QxNv-Xip1M",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T22:27:01.000Z",
      "updated_at": "2026-08-28T22:27:01.000Z"
    },
    {
      "type": "template",
      "slug": "publish-work-as-a-private-link",
      "url": "https://grokbot.dev/marketplace/publish-work-as-a-private-link/",
      "detail_url": "https://grokbot.dev/api/v1/templates/publish-work-as-a-private-link.json",
      "headline": "Publish work as a private link",
      "summary": "Turns anything your bot makes into a live page on a private link",
      "categories": [
        "business",
        "ops",
        "productivity",
        "automation",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@stevy_smith",
        "url": "https://x.com/stevy_smith/status/2093464213268127932"
      },
      "share_url": "https://x.ai/bot/n9zq64kTeEEc5NwrkAOi8",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T22:22:17.000Z",
      "updated_at": "2026-08-28T22:22:17.000Z"
    },
    {
      "type": "template",
      "slug": "cold-open",
      "url": "https://grokbot.dev/marketplace/cold-open/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cold-open.json",
      "headline": "Cold Open",
      "summary": "Turns an idea into a short sitcom-style clip, script first",
      "categories": [
        "creator",
        "content",
        "video",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@altryne",
        "url": "https://x.com/altryne/status/2093459037484622297"
      },
      "share_url": "https://x.ai/bot/h4suD8jA37Wsb7tS4giUO",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T22:01:43.000Z",
      "updated_at": "2026-08-28T22:01:43.000Z"
    },
    {
      "type": "template",
      "slug": "ai-resource-sift",
      "url": "https://grokbot.dev/marketplace/ai-resource-sift/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ai-resource-sift.json",
      "headline": "AI Resource Sift",
      "summary": "Sweeps papers, code, lectures and forums into one reading stack",
      "categories": [
        "developer",
        "student",
        "research",
        "learning",
        "knowledge-base",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@beamnxw",
        "url": "https://x.com/beamnxw/status/2093456831481885041"
      },
      "share_url": "https://x.ai/bot/3XvYxSCGJRY6x1woq-hdL",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T21:52:57.000Z",
      "updated_at": "2026-08-28T21:52:57.000Z"
    },
    {
      "type": "template",
      "slug": "teslrbot",
      "url": "https://grokbot.dev/marketplace/teslrbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/teslrbot.json",
      "headline": "TeslrBot",
      "summary": "Run your Tesla's charging, climate, locks and navigation from a chat",
      "categories": [
        "personal",
        "automation",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@HeresMyEth",
        "url": "https://x.com/HeresMyEth/status/2093448648944496995"
      },
      "share_url": "https://x.ai/bot/_S9OOSBgXixedyANQSYjQ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T21:20:26.000Z",
      "updated_at": "2026-08-28T21:20:26.000Z"
    },
    {
      "type": "template",
      "slug": "marketing-bot-cmo",
      "url": "https://grokbot.dev/marketplace/marketing-bot-cmo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/marketing-bot-cmo.json",
      "headline": "Marketing Bot (CMO)",
      "summary": "A CMO bot that turns your product into the marketing around it",
      "categories": [
        "business",
        "marketer",
        "content",
        "growth",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tymarsha",
        "url": "https://x.com/tymarsha/status/2093448136396095754"
      },
      "share_url": "https://x.ai/bot/37ZOM10GzlSOQpMjRp7KB",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T21:18:24.000Z",
      "updated_at": "2026-08-28T21:18:24.000Z"
    },
    {
      "type": "template",
      "slug": "human-copywriter",
      "url": "https://grokbot.dev/marketplace/human-copywriter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/human-copywriter.json",
      "headline": "Human Copywriter",
      "summary": "Rewrites AI-sounding drafts into copy that reads like a person",
      "categories": [
        "creator",
        "marketer",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@massimodeluisa",
        "url": "https://x.com/massimodeluisa/status/2093446449446986145"
      },
      "share_url": "https://x.ai/bot/JZAccYtlRFvDSU2CnMnkZ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T21:11:42.000Z",
      "updated_at": "2026-08-28T21:11:42.000Z"
    },
    {
      "type": "template",
      "slug": "aio-specialist-aeo-geo",
      "url": "https://grokbot.dev/marketplace/aio-specialist-aeo-geo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/aio-specialist-aeo-geo.json",
      "headline": "AIO Specialist (AEO/GEO)",
      "summary": "Treats AI Overviews and answer-engine optimisation as a standing program",
      "categories": [
        "business",
        "marketer",
        "seo",
        "content",
        "growth",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mathiasnoyez",
        "url": "https://x.com/mathiasnoyez/status/2093445450388893813"
      },
      "share_url": "https://x.ai/bot/wOvqAFpr3o8VB3g4Tmpxr",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T21:07:44.000Z",
      "updated_at": "2026-08-28T21:07:44.000Z"
    },
    {
      "type": "template",
      "slug": "kirk-enterprise-crew",
      "url": "https://grokbot.dev/marketplace/kirk-enterprise-crew/",
      "detail_url": "https://grokbot.dev/api/v1/templates/kirk-enterprise-crew.json",
      "headline": "Kirk (Enterprise Crew)",
      "summary": "Install Kirk, type START, and a bridge crew of specialist bots appears",
      "categories": [
        "personal",
        "creator",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@The_Mr_Wizard",
        "url": "https://x.com/The_Mr_Wizard/status/2093442495447191944"
      },
      "share_url": "https://x.ai/bot/FaRchqvTT6ZCRVPf0JABl",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T20:55:59.000Z",
      "updated_at": "2026-08-28T20:55:59.000Z"
    },
    {
      "type": "template",
      "slug": "disney-ride-strategist",
      "url": "https://grokbot.dev/marketplace/disney-ride-strategist/",
      "detail_url": "https://grokbot.dev/api/v1/templates/disney-ride-strategist.json",
      "headline": "Disney Ride Strategist",
      "summary": "Builds a day-by-day Walt Disney World plan around the rides you want",
      "categories": [
        "personal",
        "travel",
        "events",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@matthopkins_",
        "url": "https://x.com/matthopkins_/status/2093442356313833740"
      },
      "share_url": "https://x.ai/bot/izE8-5f78ykATd43I5ROC",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T20:55:26.000Z",
      "updated_at": "2026-08-28T20:55:26.000Z"
    },
    {
      "type": "template",
      "slug": "best-video-editor",
      "url": "https://grokbot.dev/marketplace/best-video-editor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/best-video-editor.json",
      "headline": "Best Video Editor",
      "summary": "Plans the whole edit from your footage and returns a review-ready cut",
      "categories": [
        "creator",
        "video",
        "content",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@XFreeze",
        "url": "https://x.com/XFreeze/status/2093442263200235974"
      },
      "share_url": "https://x.ai/bot/Do4CujP_kqnnc1KYnpOfI",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T20:55:04.000Z",
      "updated_at": "2026-08-28T20:55:04.000Z"
    },
    {
      "type": "template",
      "slug": "grant-general-manager",
      "url": "https://grokbot.dev/marketplace/grant-general-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grant-general-manager.json",
      "headline": "Grant (General Manager)",
      "summary": "A general manager for a trades company that stands up the back office",
      "categories": [
        "business",
        "ops",
        "back-office",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@HouseHackerJon",
        "url": "https://x.com/HouseHackerJon/status/2093435306255220830"
      },
      "share_url": "https://x.ai/bot/fkM4b8n4RqZTbrq5fw5L_",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T20:27:25.000Z",
      "updated_at": "2026-08-28T20:27:25.000Z"
    },
    {
      "type": "template",
      "slug": "yieldsentinel-a2h",
      "url": "https://grokbot.dev/marketplace/yieldsentinel-a2h/",
      "detail_url": "https://grokbot.dev/api/v1/templates/yieldsentinel-a2h.json",
      "headline": "YieldSentinel A2H",
      "summary": "Checks one DeFi yield position against rules you set before you commit",
      "categories": [
        "investor",
        "crypto",
        "research",
        "decision-support",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MyEnsNames",
        "url": "https://x.com/MyEnsNames/status/2093434321700831688"
      },
      "share_url": "https://x.ai/bot/RFXogCwTbb2mUODW6rfVe",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T20:23:31.000Z",
      "updated_at": "2026-08-28T20:23:31.000Z"
    },
    {
      "type": "template",
      "slug": "google-agent",
      "url": "https://grokbot.dev/marketplace/google-agent/",
      "detail_url": "https://grokbot.dev/api/v1/templates/google-agent.json",
      "headline": "Google Agent",
      "summary": "A read-first operator for Gmail, Drive and Calendar",
      "categories": [
        "personal",
        "productivity",
        "email",
        "calendar",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ryanthawks",
        "url": "https://x.com/ryanthawks/status/2093431148860817626"
      },
      "share_url": "https://x.ai/bot/tttQVA2UtlNwCzITNCIr0",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T20:10:54.000Z",
      "updated_at": "2026-08-28T20:10:54.000Z"
    },
    {
      "type": "template",
      "slug": "shopbot",
      "url": "https://grokbot.dev/marketplace/shopbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/shopbot.json",
      "headline": "ShopBot",
      "summary": "Searches Shopify catalogs, hunts coupons and picks the best card",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "life-hacks",
        "finance",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@shubgaur",
        "url": "https://x.com/shubgaur/status/2093429398829736195"
      },
      "share_url": "https://x.ai/bot/rBXWgythSa09pIp14rnV4",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T20:03:57.000Z",
      "updated_at": "2026-08-28T20:03:57.000Z"
    },
    {
      "type": "template",
      "slug": "lucy-creative-companion",
      "url": "https://grokbot.dev/marketplace/lucy-creative-companion/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lucy-creative-companion.json",
      "headline": "Lucy (creative companion)",
      "summary": "An open-ended creative companion for art, worlds, poems and films",
      "categories": [
        "personal",
        "creator",
        "content",
        "wellbeing",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@princess414141",
        "url": "https://x.com/princess414141/status/2093428767947456999"
      },
      "share_url": "https://x.ai/bot/4E6m-7mPfUHzLt_aIJ_5D",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T20:01:26.000Z",
      "updated_at": "2026-08-28T20:01:26.000Z"
    },
    {
      "type": "template",
      "slug": "be-happier",
      "url": "https://grokbot.dev/marketplace/be-happier/",
      "detail_url": "https://grokbot.dev/api/v1/templates/be-happier.json",
      "headline": "Be Happier",
      "summary": "Suggests three concrete things each week that would make you happier",
      "categories": [
        "personal",
        "health",
        "life-hacks",
        "productivity",
        "learning",
        "scheduled",
        "wellbeing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lennysan",
        "url": "https://x.com/lennysan/status/2093428147194847238"
      },
      "share_url": "https://x.ai/bot/0VC1XzREXRFGe0hVo-JEG",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T19:58:58.000Z",
      "updated_at": "2026-08-28T19:58:58.000Z"
    },
    {
      "type": "template",
      "slug": "lennybot",
      "url": "https://grokbot.dev/marketplace/lennybot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lennybot.json",
      "headline": "Lennybot",
      "summary": "Answers product and growth questions from Lenny Rachitsky's own archive",
      "categories": [
        "business",
        "marketer",
        "student",
        "learning",
        "research",
        "on-demand",
        "knowledge-base"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lennysan",
        "url": "https://x.com/lennysan/status/2093428147194847238"
      },
      "share_url": "https://x.ai/bot/VjbtJ_qTdzbhJGmXdvTIc",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T19:58:58.000Z",
      "updated_at": "2026-08-28T19:58:58.000Z"
    },
    {
      "type": "template",
      "slug": "talent-matchmaker",
      "url": "https://grokbot.dev/marketplace/talent-matchmaker/",
      "detail_url": "https://grokbot.dev/api/v1/templates/talent-matchmaker.json",
      "headline": "Talent Matchmaker",
      "summary": "Matches people looking for work against roles hiding in your inbox",
      "categories": [
        "business",
        "investor",
        "recruiting",
        "growth",
        "email",
        "monitoring",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lennysan",
        "url": "https://x.com/lennysan/status/2093428147194847238"
      },
      "share_url": "https://x.ai/bot/l8p6rXw-lalL-UNiHySnJ",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T19:58:58.000Z",
      "updated_at": "2026-08-28T19:58:58.000Z"
    },
    {
      "type": "template",
      "slug": "ai-harness-assistant",
      "url": "https://grokbot.dev/marketplace/ai-harness-assistant/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ai-harness-assistant.json",
      "headline": "AI Harness Assistant",
      "summary": "Keeps every AI coding tool on your machines up to date",
      "categories": [
        "developer",
        "ops",
        "automation",
        "back-office",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@gheeunit",
        "url": "https://x.com/gheeunit/status/2093427364973695253"
      },
      "share_url": "https://x.ai/bot/oq-mYZXM23ShlY7UbJWeB",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T19:55:52.000Z",
      "updated_at": "2026-08-28T19:55:52.000Z"
    },
    {
      "type": "template",
      "slug": "mappy-talent-map",
      "url": "https://grokbot.dev/marketplace/mappy-talent-map/",
      "detail_url": "https://grokbot.dev/api/v1/templates/mappy-talent-map.json",
      "headline": "Mappy (Talent Map)",
      "summary": "Maps everyone currently working at a target company",
      "categories": [
        "recruiting",
        "business",
        "sales",
        "research",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@NickRoman",
        "url": "https://x.com/NickRoman/status/2093426904950833178"
      },
      "share_url": "https://x.ai/bot/spIXb6rwPJq_iFlu1L-_l",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T19:54:02.000Z",
      "updated_at": "2026-08-28T19:54:02.000Z"
    },
    {
      "type": "template",
      "slug": "life-life-door",
      "url": "https://grokbot.dev/marketplace/life-life-door/",
      "detail_url": "https://grokbot.dev/api/v1/templates/life-life-door.json",
      "headline": "Life (Life Door)",
      "summary": "A standing inbox for everything personal that spawns the bots you need",
      "categories": [
        "personal",
        "ops",
        "productivity",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TylerNishida",
        "url": "https://x.com/TylerNishida/status/2093426221732532457"
      },
      "share_url": "https://x.ai/bot/6I-yjMRU1BmiYNfZgWXBK",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T19:51:19.000Z",
      "updated_at": "2026-08-28T19:51:19.000Z"
    },
    {
      "type": "template",
      "slug": "work-work-door",
      "url": "https://grokbot.dev/marketplace/work-work-door/",
      "detail_url": "https://grokbot.dev/api/v1/templates/work-work-door.json",
      "headline": "Work (Work Door)",
      "summary": "The work-side counterpart to Life, one door for professional tasks",
      "categories": [
        "business",
        "ops",
        "productivity",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TylerNishida",
        "url": "https://x.com/TylerNishida/status/2093426221732532457"
      },
      "share_url": "https://x.ai/bot/vOipeiu0AZ7CuC5ynw5h0",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T19:51:19.000Z",
      "updated_at": "2026-08-28T19:51:19.000Z"
    },
    {
      "type": "template",
      "slug": "cursor-agent-local",
      "url": "https://grokbot.dev/marketplace/cursor-agent-local/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cursor-agent-local.json",
      "headline": "Cursor Agent (Local)",
      "summary": "Runs the cursor-agent CLI locally for experiments and shop-floor work",
      "categories": [
        "developer",
        "ops",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ryanthawks",
        "url": "https://x.com/ryanthawks/status/2093425622282375169"
      },
      "share_url": "https://x.ai/bot/z4r7D8iILsTQDf7r7DwKR",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T19:48:56.000Z",
      "updated_at": "2026-08-28T19:48:56.000Z"
    },
    {
      "type": "template",
      "slug": "homework-checker",
      "url": "https://grokbot.dev/marketplace/homework-checker/",
      "detail_url": "https://grokbot.dev/api/v1/templates/homework-checker.json",
      "headline": "Homework Checker",
      "summary": "Weekday recap of a student's missing assignments and grades",
      "categories": [
        "personal",
        "student",
        "learning",
        "monitoring",
        "scheduled",
        "family"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kevinace",
        "url": "https://x.com/kevinace/status/2093425364353667118"
      },
      "share_url": "https://x.ai/bot/Mm_WhYXIjZ3xDNf3s3p91",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T19:47:55.000Z",
      "updated_at": "2026-08-28T19:47:55.000Z"
    },
    {
      "type": "template",
      "slug": "forge-template-foundry",
      "url": "https://grokbot.dev/marketplace/forge-template-foundry/",
      "detail_url": "https://grokbot.dev/api/v1/templates/forge-template-foundry.json",
      "headline": "Forge (Template Foundry)",
      "summary": "One keyword in, a production-ready Grok Bot recipe out",
      "categories": [
        "developer",
        "personal",
        "business",
        "automation",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@rryssf",
        "url": "https://x.com/rryssf/status/2093423943243747773"
      },
      "share_url": "https://x.ai/bot/uF_uodOFUz9mdv6XDWE70",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T19:42:16.000Z",
      "updated_at": "2026-08-28T19:42:16.000Z"
    },
    {
      "type": "template",
      "slug": "ai-orchestrator-jp",
      "url": "https://grokbot.dev/marketplace/ai-orchestrator-jp/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ai-orchestrator-jp.json",
      "headline": "AI Orchestrator (JP)",
      "summary": "A Japanese-language commander that distributes work to specialists",
      "categories": [
        "business",
        "ops",
        "personal",
        "automation",
        "agent-team",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mei_999_",
        "url": "https://x.com/mei_999_/status/2093423565676954067"
      },
      "share_url": "https://x.ai/bot/-kSMWtBCorQFkgUhm0DLk",
      "includes": [
        "instructions",
        "schedule",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T19:40:46.000Z",
      "updated_at": "2026-08-28T19:40:46.000Z"
    },
    {
      "type": "template",
      "slug": "wedding-photo-hunter",
      "url": "https://grokbot.dev/marketplace/wedding-photo-hunter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/wedding-photo-hunter.json",
      "headline": "Wedding Photo Hunter",
      "summary": "Collects every wedding photo and video into one folder",
      "categories": [
        "personal",
        "life-hacks",
        "automation",
        "on-demand",
        "family"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ajt",
        "url": "https://x.com/ajt/status/2093421988580675775"
      },
      "share_url": "https://x.ai/bot/qL6Dww98g_OGhwqDmgvJK",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T19:34:30.000Z",
      "updated_at": "2026-08-28T19:34:30.000Z"
    },
    {
      "type": "template",
      "slug": "storiesbot",
      "url": "https://grokbot.dev/marketplace/storiesbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/storiesbot.json",
      "headline": "StoriesBot",
      "summary": "Searches 17 years of MacStories, filterable by time and author",
      "categories": [
        "personal",
        "creator",
        "research",
        "learning",
        "content",
        "on-demand",
        "knowledge-base"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@viticci",
        "url": "https://x.com/viticci/status/2093420134962540763"
      },
      "share_url": "https://x.ai/bot/cV7nGFO88pb2WXNN56h8A",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T19:27:08.000Z",
      "updated_at": "2026-08-28T19:27:08.000Z"
    },
    {
      "type": "template",
      "slug": "clipper",
      "url": "https://grokbot.dev/marketplace/clipper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/clipper.json",
      "headline": "Clipper",
      "summary": "Turns videos into short clips and captioned GIFs, picking the joke itself",
      "categories": [
        "creator",
        "marketer",
        "content",
        "social-media",
        "design",
        "automation",
        "on-demand",
        "video"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thesoragirls",
        "url": "https://x.com/thesoragirls/status/2093420118487310516"
      },
      "share_url": "https://x.ai/bot/ozEfaAFJMDGoB-ysym8_V",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T19:27:04.000Z",
      "updated_at": "2026-08-28T19:27:04.000Z"
    },
    {
      "type": "template",
      "slug": "travel-event-agency",
      "url": "https://grokbot.dev/marketplace/travel-event-agency/",
      "detail_url": "https://grokbot.dev/api/v1/templates/travel-event-agency.json",
      "headline": "Travel & Event Agency",
      "summary": "Finds live flight and event tickets and compares real fares",
      "categories": [
        "personal",
        "travel",
        "shopping",
        "saving-money",
        "research",
        "on-demand",
        "events"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DogecoinNorway",
        "url": "https://x.com/DogecoinNorway/status/2093419031407845671"
      },
      "share_url": "https://x.ai/bot/m7sSNlYWSxqrsHrMiEnsh",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T19:22:45.000Z",
      "updated_at": "2026-08-28T19:22:45.000Z"
    },
    {
      "type": "template",
      "slug": "linkedin-desk",
      "url": "https://grokbot.dev/marketplace/linkedin-desk/",
      "detail_url": "https://grokbot.dev/api/v1/templates/linkedin-desk.json",
      "headline": "LinkedIn Desk",
      "summary": "Vets LinkedIn invitations daily against a policy you set",
      "categories": [
        "business",
        "sales",
        "personal",
        "social-media",
        "productivity",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SEO",
        "url": "https://x.com/SEO/status/2093418792546181548"
      },
      "share_url": "https://x.ai/bot/tQuoQ94ErUfXNJu4xPqZi",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T19:21:48.000Z",
      "updated_at": "2026-08-28T19:21:48.000Z"
    },
    {
      "type": "template",
      "slug": "socials-short-form-scout",
      "url": "https://grokbot.dev/marketplace/socials-short-form-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/socials-short-form-scout.json",
      "headline": "Socials (Short-Form Scout)",
      "summary": "Hourly scout that hands you filmable short-form content kits",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "content",
        "growth",
        "monitoring",
        "research",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ashen_one",
        "url": "https://x.com/ashen_one/status/2093416120371835232"
      },
      "share_url": "https://x.ai/bot/bjsbaj_a2ds2pQY1YiXqE",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T19:11:11.000Z",
      "updated_at": "2026-08-28T19:11:11.000Z"
    },
    {
      "type": "template",
      "slug": "contra-job-scraper",
      "url": "https://grokbot.dev/marketplace/contra-job-scraper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/contra-job-scraper.json",
      "headline": "Contra Job Scraper",
      "summary": "Checks Contra's freelance feed every 6 hours and emails only on change",
      "categories": [
        "creator",
        "developer",
        "sales",
        "monitoring",
        "automation",
        "growth",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@techking_007",
        "url": "https://x.com/techking_007/status/2093415230932177139"
      },
      "share_url": "https://x.ai/bot/__sNWxlx-8H08UluQuOeo",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T19:07:39.000Z",
      "updated_at": "2026-08-28T19:07:39.000Z"
    },
    {
      "type": "template",
      "slug": "research-bot",
      "url": "https://grokbot.dev/marketplace/research-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/research-bot.json",
      "headline": "Research Bot",
      "summary": "Deep research that returns concise answers with verified citations",
      "categories": [
        "personal",
        "student",
        "business",
        "research",
        "learning",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ArthurMacwaters",
        "url": "https://x.com/ArthurMacwaters/status/2093412671144296661"
      },
      "share_url": "https://x.ai/bot/Nn0ykGa3vJ6YS7ib7F6yH",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:57:29.000Z",
      "updated_at": "2026-08-28T18:57:29.000Z"
    },
    {
      "type": "template",
      "slug": "leader-1-1-bot",
      "url": "https://grokbot.dev/marketplace/leader-1-1-bot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/leader-1-1-bot.json",
      "headline": "Leader 1:1 Bot",
      "summary": "Walks into your weekly 1:1 with last week's thread and three things worth saying",
      "categories": [
        "business",
        "ops",
        "personal",
        "productivity",
        "learning",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scottxmetcalf",
        "url": "https://x.com/scottxmetcalf/status/2093410582099808561"
      },
      "share_url": "https://x.ai/bot/eZhKhPkfxxFSml18TS2X8",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:49:11.000Z",
      "updated_at": "2026-08-28T18:49:11.000Z"
    },
    {
      "type": "template",
      "slug": "peekaboo-mac",
      "url": "https://grokbot.dev/marketplace/peekaboo-mac/",
      "detail_url": "https://grokbot.dev/api/v1/templates/peekaboo-mac.json",
      "headline": "Peekaboo Mac",
      "summary": "Adds screen recording, screenshots and UI input to your registered Macs",
      "categories": [
        "developer",
        "ops",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@brandon_ai",
        "url": "https://x.com/brandon_ai/status/2093410540559470920"
      },
      "share_url": "https://x.ai/bot/zY0fbKG9UqTMWIu1NcudB",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:49:01.000Z",
      "updated_at": "2026-08-28T18:49:01.000Z"
    },
    {
      "type": "template",
      "slug": "lease-finder",
      "url": "https://grokbot.dev/marketplace/lease-finder/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lease-finder.json",
      "headline": "Lease Finder",
      "summary": "Hunts current car lease deals nationwide for the deepest discount to MSRP",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "life-hacks",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@dannymacias",
        "url": "https://x.com/dannymacias/status/2093409778265694256"
      },
      "share_url": "https://x.ai/bot/_A_AZayMmSNuN_-sdq_M1",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:45:59.000Z",
      "updated_at": "2026-08-28T18:45:59.000Z"
    },
    {
      "type": "template",
      "slug": "melissa-fitness-nutrition-coach",
      "url": "https://grokbot.dev/marketplace/melissa-fitness-nutrition-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/melissa-fitness-nutrition-coach.json",
      "headline": "Melissa (Fitness & Nutrition Coach)",
      "summary": "A fitness and nutrition coach built around Type 1 diabetes constraints",
      "categories": [
        "personal",
        "health",
        "learning",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tpgoebel",
        "url": "https://x.com/tpgoebel/status/2093409295291310106"
      },
      "share_url": "https://x.ai/bot/3foGoeh6ksDhD4jTxYjyE",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:44:04.000Z",
      "updated_at": "2026-08-28T18:44:04.000Z"
    },
    {
      "type": "template",
      "slug": "mr-laser",
      "url": "https://grokbot.dev/marketplace/mr-laser/",
      "detail_url": "https://grokbot.dev/api/v1/templates/mr-laser.json",
      "headline": "Mr. Laser",
      "summary": "Project lead for a one-person laser-engraving shop",
      "categories": [
        "business",
        "creator",
        "ops",
        "design",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RichSilver",
        "url": "https://x.com/RichSilver/status/2093409240962506861"
      },
      "share_url": "https://x.ai/bot/GU4KJSYtPZeiLf8ubPMXY",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T18:43:51.000Z",
      "updated_at": "2026-08-28T18:43:51.000Z"
    },
    {
      "type": "template",
      "slug": "clark-kent-daily-diary",
      "url": "https://grokbot.dev/marketplace/clark-kent-daily-diary/",
      "detail_url": "https://grokbot.dev/api/v1/templates/clark-kent-daily-diary.json",
      "headline": "Clark Kent (Daily Diary)",
      "summary": "Writes up what actually happened in your shop each day",
      "categories": [
        "business",
        "ops",
        "personal",
        "back-office",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RichSilver",
        "url": "https://x.com/RichSilver/status/2093409237451903032"
      },
      "share_url": "https://x.ai/bot/6sF7_MwHMcWgWwq0Z6Xes",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:43:50.000Z",
      "updated_at": "2026-08-28T18:43:50.000Z"
    },
    {
      "type": "template",
      "slug": "thoth-researcher-archivist",
      "url": "https://grokbot.dev/marketplace/thoth-researcher-archivist/",
      "detail_url": "https://grokbot.dev/api/v1/templates/thoth-researcher-archivist.json",
      "headline": "Thoth (Researcher & Archivist)",
      "summary": "Does deep research and files the dossiers so you can find them again",
      "categories": [
        "business",
        "personal",
        "student",
        "research",
        "data",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RichSilver",
        "url": "https://x.com/RichSilver/status/2093409239246971049"
      },
      "share_url": "https://x.ai/bot/W4Z5pvEm6UgCml48Ig4dT",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:43:50.000Z",
      "updated_at": "2026-08-28T18:43:50.000Z"
    },
    {
      "type": "template",
      "slug": "data-science-querie",
      "url": "https://grokbot.dev/marketplace/data-science-querie/",
      "detail_url": "https://grokbot.dev/api/v1/templates/data-science-querie.json",
      "headline": "Data Science (Querie)",
      "summary": "Owns analytics queries, spreadsheet pulls and metric definitions",
      "categories": [
        "business",
        "developer",
        "ops",
        "data",
        "research",
        "back-office",
        "on-demand",
        "analytics"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@egavrilenko11",
        "url": "https://x.com/egavrilenko11/status/2093409119302791170"
      },
      "share_url": "https://x.ai/bot/Bu2sEQqu0hEjpbzN_07D3",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:43:22.000Z",
      "updated_at": "2026-08-28T18:43:22.000Z"
    },
    {
      "type": "template",
      "slug": "chicken-joe-surf-report",
      "url": "https://grokbot.dev/marketplace/chicken-joe-surf-report/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chicken-joe-surf-report.json",
      "headline": "Chicken Joe (Surf Report)",
      "summary": "Scans NorCal surf reports and cams each morning and tells you where to go",
      "categories": [
        "personal",
        "life-hacks",
        "monitoring",
        "travel",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@parker__conrad",
        "url": "https://x.com/parker__conrad/status/2093408518816899425"
      },
      "share_url": "https://x.ai/bot/7f5AjmpjZkmTIsSybedYS",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:40:59.000Z",
      "updated_at": "2026-08-28T18:40:59.000Z"
    },
    {
      "type": "template",
      "slug": "learn-math-ml-video-teacher",
      "url": "https://grokbot.dev/marketplace/learn-math-ml-video-teacher/",
      "detail_url": "https://grokbot.dev/api/v1/templates/learn-math-ml-video-teacher.json",
      "headline": "Learn (Math & ML Video Teacher)",
      "summary": "Builds first-principles lessons and renders them as animated explainers",
      "categories": [
        "student",
        "personal",
        "creator",
        "learning",
        "content",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JeffreyLind",
        "url": "https://x.com/JeffreyLind/status/2093407660657775081"
      },
      "share_url": "https://x.ai/bot/s5JszATSty0w-uDTw_NzK",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:37:34.000Z",
      "updated_at": "2026-08-28T18:37:34.000Z"
    },
    {
      "type": "template",
      "slug": "ethan",
      "url": "https://grokbot.dev/marketplace/ethan/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ethan.json",
      "headline": "Ethan",
      "summary": "A research desk with five specialist skills that fact-checks its own findings",
      "categories": [
        "research",
        "knowledge-base",
        "analytics",
        "developer",
        "automation"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jumperz",
        "url": "https://x.com/jumperz/status/2093407073815929223"
      },
      "share_url": "https://x.ai/bot/F5Mm-0O3fPPZjYGIdsycE",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:35:14.000Z",
      "updated_at": "2026-08-28T18:35:14.000Z"
    },
    {
      "type": "template",
      "slug": "freelance-prospector",
      "url": "https://grokbot.dev/marketplace/freelance-prospector/",
      "detail_url": "https://grokbot.dev/api/v1/templates/freelance-prospector.json",
      "headline": "Freelance Prospector",
      "summary": "Scans freelance marketplaces and books the meetings in your voice",
      "categories": [
        "sales",
        "creator",
        "business",
        "growth",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@cristianmock",
        "url": "https://x.com/cristianmock/status/2093406266349474212"
      },
      "share_url": "https://x.ai/bot/UMCdNlqEH7USe3eOznd1U",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:32:02.000Z",
      "updated_at": "2026-08-28T18:32:02.000Z"
    },
    {
      "type": "template",
      "slug": "imogen-alt-text",
      "url": "https://grokbot.dev/marketplace/imogen-alt-text/",
      "detail_url": "https://grokbot.dev/api/v1/templates/imogen-alt-text.json",
      "headline": "Imogen (Alt Text)",
      "summary": "Replies to images you post with clean, copyable alt text",
      "categories": [
        "creator",
        "social-media",
        "content",
        "automation",
        "design",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kentcdodds",
        "url": "https://x.com/kentcdodds/status/2093405822730825820"
      },
      "share_url": "https://x.ai/bot/9y2GcFkKMAUhYlMxRUS0X",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:30:16.000Z",
      "updated_at": "2026-08-28T18:30:16.000Z"
    },
    {
      "type": "template",
      "slug": "grok-bot-coach",
      "url": "https://grokbot.dev/marketplace/grok-bot-coach/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-bot-coach.json",
      "headline": "Grok Bot Coach",
      "summary": "Audits and tunes the Grok bots you already have",
      "categories": [
        "personal",
        "developer",
        "learning",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GuleidAmina",
        "url": "https://x.com/GuleidAmina/status/2093404361972122011"
      },
      "share_url": "https://x.ai/bot/BrjELcmSwatjRc8DYjtrT",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:24:28.000Z",
      "updated_at": "2026-08-28T18:24:28.000Z"
    },
    {
      "type": "template",
      "slug": "dispatch",
      "url": "https://grokbot.dev/marketplace/dispatch/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dispatch.json",
      "headline": "Dispatch",
      "summary": "Nightly scan of email, Slack, LinkedIn and X DMs that books the missing calls",
      "categories": [
        "business",
        "sales",
        "ops",
        "productivity",
        "automation",
        "email",
        "back-office",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@FilippoFonseca",
        "url": "https://x.com/FilippoFonseca/status/2093402774704914915"
      },
      "share_url": "https://x.ai/bot/YkmZEZYBk-BqylyQbM3kq",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:18:09.000Z",
      "updated_at": "2026-08-28T18:18:09.000Z"
    },
    {
      "type": "template",
      "slug": "linky",
      "url": "https://grokbot.dev/marketplace/linky/",
      "detail_url": "https://grokbot.dev/api/v1/templates/linky.json",
      "headline": "Linky",
      "summary": "Send it any file, folder or bot output and it hands back a shareable URL",
      "categories": [
        "personal",
        "developer",
        "productivity",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@adamludwin",
        "url": "https://x.com/adamludwin/status/2093402167394914392"
      },
      "share_url": "https://x.ai/bot/zcHEE4_hbqw3cZsy7X2Vk",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:15:44.000Z",
      "updated_at": "2026-08-28T18:15:44.000Z"
    },
    {
      "type": "template",
      "slug": "local-deals",
      "url": "https://grokbot.dev/marketplace/local-deals/",
      "detail_url": "https://grokbot.dev/api/v1/templates/local-deals.json",
      "headline": "Local Deals",
      "summary": "Daily local marketplace deals that it will negotiate for you",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "life-hacks",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@brandon_galang",
        "url": "https://x.com/brandon_galang/status/2093402021789593873"
      },
      "share_url": "https://x.ai/bot/KmR5kmGnalq1b2nhCRXyo",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:15:10.000Z",
      "updated_at": "2026-08-28T18:15:10.000Z"
    },
    {
      "type": "template",
      "slug": "x-brief",
      "url": "https://grokbot.dev/marketplace/x-brief/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-brief.json",
      "headline": "X Brief",
      "summary": "Learns what you pay attention to from your own posts, then watches that beat",
      "categories": [
        "personal",
        "creator",
        "marketer",
        "social-media",
        "monitoring",
        "research",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@daniel_mac8",
        "url": "https://x.com/daniel_mac8/status/2093401980987425103"
      },
      "share_url": "https://x.ai/bot/GkX6X536UK2MlbkfGLQnb",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:15:00.000Z",
      "updated_at": "2026-08-28T18:15:00.000Z"
    },
    {
      "type": "template",
      "slug": "fixer-uzi",
      "url": "https://grokbot.dev/marketplace/fixer-uzi/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fixer-uzi.json",
      "headline": "Fixer (Uzi)",
      "summary": "The operator that actually does the work, and pushes back when a plan is wrong",
      "categories": [
        "business",
        "ops",
        "personal",
        "productivity",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@UziObi",
        "url": "https://x.com/UziObi/status/2093401597048975758"
      },
      "share_url": "https://x.ai/bot/jiF_km66YLNm5LBVJ5_Ho",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T18:13:28.000Z",
      "updated_at": "2026-08-28T18:13:28.000Z"
    },
    {
      "type": "use-case",
      "slug": "faceless-youtube-channel-automation",
      "url": "https://grokbot.dev/use-cases/faceless-youtube-channel-automation/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/faceless-youtube-channel-automation.json",
      "headline": "Run a faceless YouTube channel: source, edit, caption and schedule",
      "summary": "A faceless channel is a production line - find raw material, cut a short, add captions, make a thumbnail, upload. RoundtableSpace flagged Grok Bot running the whole line. This is the version with a human gate: the bot does the repetitive work, you approve before anything publishes, on content you have rights to use.",
      "categories": [
        "marketing",
        "personal"
      ],
      "awesome_score": 72,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RoundtableSpace",
        "url": "https://x.com/RoundtableSpace/status/2093303833359265886"
      },
      "added_at": "2026-08-28T18:10:00Z",
      "updated_at": "2026-08-28T18:10:00Z"
    },
    {
      "type": "template",
      "slug": "grimoire-s-tome-the-grim-council",
      "url": "https://grokbot.dev/marketplace/grimoire-s-tome-the-grim-council/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grimoire-s-tome-the-grim-council.json",
      "headline": "Grimoire's Tome & The Grim Council",
      "summary": "A 50-skill coding wizard with a 20-member advisory council",
      "categories": [
        "developer",
        "business",
        "personal",
        "automation",
        "productivity",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@NickADobos",
        "url": "https://x.com/NickADobos/status/2093400318063284581"
      },
      "share_url": "https://x.ai/bot/luPJeAxuAjhqO97wU3wm0",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T18:08:23.000Z",
      "updated_at": "2026-08-28T18:08:23.000Z"
    },
    {
      "type": "template",
      "slug": "frontier-model-watch",
      "url": "https://grokbot.dev/marketplace/frontier-model-watch/",
      "detail_url": "https://grokbot.dev/api/v1/templates/frontier-model-watch.json",
      "headline": "Frontier Model Watch",
      "summary": "One verified daily digest of releases from ten frontier AI labs",
      "categories": [
        "developer",
        "personal",
        "research",
        "monitoring",
        "learning",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GuleidAmina",
        "url": "https://x.com/GuleidAmina/status/2093400067617309106"
      },
      "share_url": "https://x.ai/bot/YHqn0iTQuvI-8LC01IP6S",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:07:24.000Z",
      "updated_at": "2026-08-28T18:07:24.000Z"
    },
    {
      "type": "use-case",
      "slug": "pitch-deck-analyzer-bot",
      "url": "https://grokbot.dev/use-cases/pitch-deck-analyzer-bot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/pitch-deck-analyzer-bot.json",
      "headline": "A shareable bot that screens every pitch deck against your own criteria",
      "summary": "Brian Evans gets pitched 5-10 times a week, so he built a Grok Bot that learns exactly what he looks for and scores each deck against it - filtering the misfits before he spends a minute. He built it on Grok Bot's new shareable-templates feature, which strips your data so the workflow can be handed to someone else.",
      "categories": [
        "work"
      ],
      "awesome_score": 78,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BrianDEvans",
        "url": "https://x.com/BrianDEvans/status/2093386515972030780"
      },
      "added_at": "2026-08-28T18:05:00Z",
      "updated_at": "2026-08-28T18:05:00Z"
    },
    {
      "type": "template",
      "slug": "deal-hunting",
      "url": "https://grokbot.dev/marketplace/deal-hunting/",
      "detail_url": "https://grokbot.dev/api/v1/templates/deal-hunting.json",
      "headline": "Deal Hunting",
      "summary": "Landed-cost shopping that compares real prices including shipping and tax",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "life-hacks",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2093399328836440571"
      },
      "share_url": "https://x.ai/bot/MGiEdMz0TNxBkvMgUZAbf",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:04:28.000Z",
      "updated_at": "2026-08-28T18:04:28.000Z"
    },
    {
      "type": "template",
      "slug": "fenrir-paper-trading",
      "url": "https://grokbot.dev/marketplace/fenrir-paper-trading/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fenrir-paper-trading.json",
      "headline": "Fenrir (Paper Trading)",
      "summary": "Runs a paper-trading tournament on NSE or NASDAQ",
      "categories": [
        "investor",
        "personal",
        "finance",
        "research",
        "data",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@shantanugoel",
        "url": "https://x.com/shantanugoel/status/2093399035529085059"
      },
      "share_url": "https://x.ai/bot/FReKiR82_-lF359lhshpR",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:03:18.000Z",
      "updated_at": "2026-08-28T18:03:18.000Z"
    },
    {
      "type": "template",
      "slug": "invoice-hunter",
      "url": "https://grokbot.dev/marketplace/invoice-hunter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/invoice-hunter.json",
      "headline": "Invoice Hunter",
      "summary": "Finds invoice PDFs in Gmail and packs a month into a CSV",
      "categories": [
        "business",
        "ops",
        "back-office",
        "finance",
        "email",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2093398873247031468"
      },
      "share_url": "https://x.ai/bot/-kO6HrXokJZANVwUOMZO9",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:02:39.000Z",
      "updated_at": "2026-08-28T18:02:39.000Z"
    },
    {
      "type": "template",
      "slug": "stitchy-personal-stylist",
      "url": "https://grokbot.dev/marketplace/stitchy-personal-stylist/",
      "detail_url": "https://grokbot.dev/api/v1/templates/stitchy-personal-stylist.json",
      "headline": "Stitchy (Personal Stylist)",
      "summary": "Suggests a fresh outfit each morning and hunts for bargains overnight",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "life-hacks",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Mitch_Sweigart",
        "url": "https://x.com/Mitch_Sweigart/status/2093398705298641323"
      },
      "share_url": "https://x.ai/bot/P-8iKYx3Eeq3pelx_UPHq",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:01:59.000Z",
      "updated_at": "2026-08-28T18:01:59.000Z"
    },
    {
      "type": "template",
      "slug": "newsletter-cleanup",
      "url": "https://grokbot.dev/marketplace/newsletter-cleanup/",
      "detail_url": "https://grokbot.dev/api/v1/templates/newsletter-cleanup.json",
      "headline": "Newsletter Cleanup",
      "summary": "Audits six months of newsletters and unsubscribes only from what you approve",
      "categories": [
        "personal",
        "email",
        "productivity",
        "life-hacks",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2093398594745254196"
      },
      "share_url": "https://x.ai/bot/dHd69sBvMG2o3lJa__T7K",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:01:33.000Z",
      "updated_at": "2026-08-28T18:01:33.000Z"
    },
    {
      "type": "template",
      "slug": "lurk-reddit-researcher",
      "url": "https://grokbot.dev/marketplace/lurk-reddit-researcher/",
      "detail_url": "https://grokbot.dev/api/v1/templates/lurk-reddit-researcher.json",
      "headline": "Lurk (Reddit Researcher)",
      "summary": "Mines Reddit for exact quotes and files a pain-point pack",
      "categories": [
        "business",
        "marketer",
        "creator",
        "research",
        "growth",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tinkerersanky",
        "url": "https://x.com/tinkerersanky/status/2093398451958489561"
      },
      "share_url": "https://x.ai/bot/12Gbp1lPVsfTVAHPXKd3B",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T18:00:59.000Z",
      "updated_at": "2026-08-28T18:00:59.000Z"
    },
    {
      "type": "template",
      "slug": "competitor-watching",
      "url": "https://grokbot.dev/marketplace/competitor-watching/",
      "detail_url": "https://grokbot.dev/api/v1/templates/competitor-watching.json",
      "headline": "Competitor Watching",
      "summary": "Snapshots you against 3-8 competitors and alerts only on material change",
      "categories": [
        "business",
        "marketer",
        "monitoring",
        "growth",
        "research",
        "data",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2093398377056678001"
      },
      "share_url": "https://x.ai/bot/5PKSzU0ruN_DQbNXc7m0N",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T18:00:41.000Z",
      "updated_at": "2026-08-28T18:00:41.000Z"
    },
    {
      "type": "use-case",
      "slug": "build-a-crm-from-your-calendar",
      "url": "https://grokbot.dev/use-cases/build-a-crm-from-your-calendar/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/build-a-crm-from-your-calendar.json",
      "headline": "Turn ten years of calendar meetings into a Notion CRM, automatically",
      "summary": "Gaurav Munjal pointed Grok Bot at ten years of his calendar and told it to build a Notion database of every person he ever met - each with their LinkedIn, what they're doing now, and tags. It ran 2.5 hours straight and logged ~1,000 people from the first three years alone. A back-office job no human ever gets to.",
      "categories": [
        "work",
        "personal"
      ],
      "awesome_score": 80,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@gauravmunjal",
        "url": "https://x.com/gauravmunjal/status/2093366092920144201"
      },
      "added_at": "2026-08-28T18:00:00Z",
      "updated_at": "2026-08-28T18:00:00Z"
    },
    {
      "type": "template",
      "slug": "grok-bot-use-case-scout",
      "url": "https://grokbot.dev/marketplace/grok-bot-use-case-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/grok-bot-use-case-scout.json",
      "headline": "Grok Bot Use-Case Scout",
      "summary": "A short morning list of new Grok Bot use cases worth setting up",
      "categories": [
        "personal",
        "developer",
        "learning",
        "research",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2093397994263515578"
      },
      "share_url": "https://x.ai/bot/DTNL6V2HxpUHj3MkI-bSj",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:59:09.000Z",
      "updated_at": "2026-08-28T17:59:09.000Z"
    },
    {
      "type": "template",
      "slug": "site-audit",
      "url": "https://grokbot.dev/marketplace/site-audit/",
      "detail_url": "https://grokbot.dev/api/v1/templates/site-audit.json",
      "headline": "Site Audit",
      "summary": "One-pass site audit across SEO, speed, accessibility, CRO and schema",
      "categories": [
        "marketer",
        "business",
        "developer",
        "monitoring",
        "growth",
        "data",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2093397637487596019"
      },
      "share_url": "https://x.ai/bot/s6JVFYDIDMsCQMBeTcznW",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:57:44.000Z",
      "updated_at": "2026-08-28T17:57:44.000Z"
    },
    {
      "type": "template",
      "slug": "daily-youtube-recap",
      "url": "https://grokbot.dev/marketplace/daily-youtube-recap/",
      "detail_url": "https://grokbot.dev/api/v1/templates/daily-youtube-recap.json",
      "headline": "Daily YouTube Recap",
      "summary": "Morning recap of the YouTube channels you follow, silent when nothing dropped",
      "categories": [
        "personal",
        "creator",
        "youtube",
        "research",
        "monitoring",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2093397281928053001"
      },
      "share_url": "https://x.ai/bot/dug1Zq29P009fdcI5-tTC",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:56:20.000Z",
      "updated_at": "2026-08-28T17:56:20.000Z"
    },
    {
      "type": "template",
      "slug": "overwatch",
      "url": "https://grokbot.dev/marketplace/overwatch/",
      "detail_url": "https://grokbot.dev/api/v1/templates/overwatch.json",
      "headline": "Overwatch",
      "summary": "Housekeeper for your Grok Bot VM so a shared machine does not rot",
      "categories": [
        "developer",
        "ops",
        "automation",
        "back-office",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2093397147882229897"
      },
      "share_url": "https://x.ai/bot/7u3XiRiTYw4GVZmuZboyP",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:55:48.000Z",
      "updated_at": "2026-08-28T17:55:48.000Z"
    },
    {
      "type": "template",
      "slug": "chef",
      "url": "https://grokbot.dev/marketplace/chef/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chef.json",
      "headline": "Chef",
      "summary": "Plans the week's meals, builds the list and orders the groceries",
      "categories": [
        "personal",
        "shopping",
        "life-hacks",
        "saving-money",
        "automation",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DogecoinNorway",
        "url": "https://x.com/DogecoinNorway/status/2093396816087990331"
      },
      "share_url": "https://x.ai/bot/3U6zxtPa1b8GbWheaIr4J",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:54:29.000Z",
      "updated_at": "2026-08-28T17:54:29.000Z"
    },
    {
      "type": "template",
      "slug": "chief-router",
      "url": "https://grokbot.dev/marketplace/chief-router/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-router.json",
      "headline": "Chief (Router)",
      "summary": "A pure router that assigns one owner per job and otherwise stays out of the way",
      "categories": [
        "business",
        "ops",
        "developer",
        "productivity",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nykdotdev",
        "url": "https://x.com/nykdotdev/status/2093395691452457171"
      },
      "share_url": "https://x.ai/bot/JugVUSPe_wSZg-in69owM",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T17:50:00.000Z",
      "updated_at": "2026-08-28T17:50:00.000Z"
    },
    {
      "type": "template",
      "slug": "phonezero-operator",
      "url": "https://grokbot.dev/marketplace/phonezero-operator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/phonezero-operator.json",
      "headline": "PhoneZero Operator",
      "summary": "Lets your bot place and receive real phone calls",
      "categories": [
        "business",
        "developer",
        "sales",
        "support",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ibelevy",
        "url": "https://x.com/ibelevy/status/2093395583809785868"
      },
      "share_url": "https://x.ai/bot/vB2o6vvmHjDQRM5yFH9vn",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:49:35.000Z",
      "updated_at": "2026-08-28T17:49:35.000Z"
    },
    {
      "type": "template",
      "slug": "pr-reviewer",
      "url": "https://grokbot.dev/marketplace/pr-reviewer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/pr-reviewer.json",
      "headline": "PR Reviewer",
      "summary": "Reviews pull requests risk-first",
      "categories": [
        "developer",
        "automation",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mustafaergisi",
        "url": "https://x.com/mustafaergisi/status/2093393924870058039"
      },
      "share_url": "https://x.ai/bot/rt629UEZFtE4Wz0A_0c37",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:42:59.000Z",
      "updated_at": "2026-08-28T17:42:59.000Z"
    },
    {
      "type": "template",
      "slug": "alfred-bot-chief-advisor",
      "url": "https://grokbot.dev/marketplace/alfred-bot-chief-advisor/",
      "detail_url": "https://grokbot.dev/api/v1/templates/alfred-bot-chief-advisor.json",
      "headline": "Alfred (Bot Chief Advisor)",
      "summary": "Designs and keeps restructuring your whole roster of bots",
      "categories": [
        "business",
        "ops",
        "developer",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@heyrobinai",
        "url": "https://x.com/heyrobinai/status/2093393717545648305"
      },
      "share_url": "https://x.ai/bot/KZ9xav0Qad1U5QigEn7rh",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T17:42:10.000Z",
      "updated_at": "2026-08-28T17:42:10.000Z"
    },
    {
      "type": "template",
      "slug": "chieeeeefy-chief-of-staff",
      "url": "https://grokbot.dev/marketplace/chieeeeefy-chief-of-staff/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chieeeeefy-chief-of-staff.json",
      "headline": "Chieeeeefy (Chief of Staff)",
      "summary": "Chief of staff for a field engineer, calendar and work inbox first",
      "categories": [
        "personal",
        "business",
        "ops",
        "productivity",
        "back-office",
        "email",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@naoufal_elh",
        "url": "https://x.com/naoufal_elh/status/2093393130447921346"
      },
      "share_url": "https://x.ai/bot/GiBPBQR2WrHNul4k9Tz6Q",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:39:50.000Z",
      "updated_at": "2026-08-28T17:39:50.000Z"
    },
    {
      "type": "template",
      "slug": "dr-eggbot",
      "url": "https://grokbot.dev/marketplace/dr-eggbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/dr-eggbot.json",
      "headline": "Dr Eggbot",
      "summary": "A bot that builds other Grok bots for you",
      "categories": [
        "personal",
        "developer",
        "productivity",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@poteto",
        "url": "https://x.com/poteto/status/2093392701005946931"
      },
      "share_url": "https://x.ai/bot/93gOz3op1UQdBdbekQFLK",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:38:07.000Z",
      "updated_at": "2026-08-28T17:38:07.000Z"
    },
    {
      "type": "template",
      "slug": "blair-personal-shopper",
      "url": "https://grokbot.dev/marketplace/blair-personal-shopper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/blair-personal-shopper.json",
      "headline": "Blair (Personal Shopper)",
      "summary": "A personal shopper that hunts down secondhand designer pieces and can buy them",
      "categories": [
        "personal",
        "shopping",
        "saving-money",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jediahkatz",
        "url": "https://x.com/jediahkatz/status/2093391579964694670"
      },
      "share_url": "https://x.ai/bot/BAbHIps4VA0Hr4GLIOJme",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:33:40.000Z",
      "updated_at": "2026-08-28T17:33:40.000Z"
    },
    {
      "type": "template",
      "slug": "credit-card-max",
      "url": "https://grokbot.dev/marketplace/credit-card-max/",
      "detail_url": "https://grokbot.dev/api/v1/templates/credit-card-max.json",
      "headline": "Credit Card Max",
      "summary": "Tells you which card to use for a purchase to maximise points and perks",
      "categories": [
        "personal",
        "finance",
        "saving-money",
        "life-hacks",
        "shopping",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@trevin",
        "url": "https://x.com/trevin/status/2093390512925610067"
      },
      "share_url": "https://x.ai/bot/D831qeIZ5QrobdVh-X79U",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:29:26.000Z",
      "updated_at": "2026-08-28T17:29:26.000Z"
    },
    {
      "type": "template",
      "slug": "illo",
      "url": "https://grokbot.dev/marketplace/illo/",
      "detail_url": "https://grokbot.dev/api/v1/templates/illo.json",
      "headline": "illo",
      "summary": "Turns ideas and posts into mascot-led editorial illustrations",
      "categories": [
        "creator",
        "marketer",
        "design",
        "content",
        "social-media",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@trevin",
        "url": "https://x.com/trevin/status/2093390512925610067"
      },
      "share_url": "https://x.ai/bot/y3uTGY5hkl6iTmE-ZAX02",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:29:26.000Z",
      "updated_at": "2026-08-28T17:29:26.000Z"
    },
    {
      "type": "template",
      "slug": "housebot",
      "url": "https://grokbot.dev/marketplace/housebot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/housebot.json",
      "headline": "HouseBot",
      "summary": "Hunts rentals and homes every 12 hours across six listing sites",
      "categories": [
        "personal",
        "real-estate",
        "monitoring",
        "saving-money",
        "life-hacks",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@shubgaur",
        "url": "https://x.com/shubgaur/status/2093389744650818036"
      },
      "share_url": "https://x.ai/bot/3ufXSXC-Z8OadVsV9yMLL",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:26:23.000Z",
      "updated_at": "2026-08-28T17:26:23.000Z"
    },
    {
      "type": "template",
      "slug": "post-call-assistant",
      "url": "https://grokbot.dev/marketplace/post-call-assistant/",
      "detail_url": "https://grokbot.dev/api/v1/templates/post-call-assistant.json",
      "headline": "Post Call Assistant",
      "summary": "Drops your to-dos and a draft follow-up after every meeting",
      "categories": [
        "business",
        "sales",
        "ops",
        "productivity",
        "back-office",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@itspriyaptl",
        "url": "https://x.com/itspriyaptl/status/2093389586864988661"
      },
      "share_url": "https://x.ai/bot/xF12c5y4LVe7nf7IFguWI",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:25:45.000Z",
      "updated_at": "2026-08-28T17:25:45.000Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-avid",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-avid/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-avid.json",
      "headline": "Chief of Staff (Avid)",
      "summary": "A single-desk chief of staff that runs your day and your company at once",
      "categories": [
        "business",
        "personal",
        "ops",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Av1dlive",
        "url": "https://x.com/Av1dlive/status/2093389300490752106"
      },
      "share_url": "https://x.ai/bot/d8OshqLZvtcKDcNluPuyo",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:24:37.000Z",
      "updated_at": "2026-08-28T17:24:37.000Z"
    },
    {
      "type": "template",
      "slug": "scout-competitive-intelligence",
      "url": "https://grokbot.dev/marketplace/scout-competitive-intelligence/",
      "detail_url": "https://grokbot.dev/api/v1/templates/scout-competitive-intelligence.json",
      "headline": "Scout (Competitive Intelligence)",
      "summary": "Watches rival sites, search rank and AI-answer visibility",
      "categories": [
        "marketer",
        "business",
        "monitoring",
        "growth",
        "research",
        "data",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@adamta",
        "url": "https://x.com/adamta/status/2093388517044830237"
      },
      "share_url": "https://x.ai/bot/rthl9MdskO2f-JCzmyINP",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:21:30.000Z",
      "updated_at": "2026-08-28T17:21:30.000Z"
    },
    {
      "type": "template",
      "slug": "news-scout",
      "url": "https://grokbot.dev/marketplace/news-scout/",
      "detail_url": "https://grokbot.dev/api/v1/templates/news-scout.json",
      "headline": "News Scout",
      "summary": "A weekday morning news digest in your own timezone",
      "categories": [
        "personal",
        "research",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@byeleni",
        "url": "https://x.com/byeleni/status/2093388385763119459"
      },
      "share_url": "https://x.ai/bot/9Mo5saoPQYIp45IgzMT7P",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:20:59.000Z",
      "updated_at": "2026-08-28T17:20:59.000Z"
    },
    {
      "type": "template",
      "slug": "index-seo-aeo-teammate",
      "url": "https://grokbot.dev/marketplace/index-seo-aeo-teammate/",
      "detail_url": "https://grokbot.dev/api/v1/templates/index-seo-aeo-teammate.json",
      "headline": "Index (SEO/AEO Teammate)",
      "summary": "An SEO and AEO teammate that writes briefs for your writers",
      "categories": [
        "marketer",
        "business",
        "content",
        "growth",
        "data",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@adamta",
        "url": "https://x.com/adamta/status/2093387269356785800"
      },
      "share_url": "https://x.ai/bot/Viv2NbC5skPslV1WH9Fs7",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:16:32.000Z",
      "updated_at": "2026-08-28T17:16:32.000Z"
    },
    {
      "type": "template",
      "slug": "1000x-product-engineer",
      "url": "https://grokbot.dev/marketplace/1000x-product-engineer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/1000x-product-engineer.json",
      "headline": "1000x Product Engineer",
      "summary": "A full-stack product engineer that ships Convex, TanStack and React apps",
      "categories": [
        "developer",
        "design",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@TomZarebczan",
        "url": "https://x.com/TomZarebczan/status/2093387240479051938"
      },
      "share_url": "https://x.ai/bot/sQDD87Gp6VLT0m99tFpzu",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:16:26.000Z",
      "updated_at": "2026-08-28T17:16:26.000Z"
    },
    {
      "type": "template",
      "slug": "x-top-100-fans-weekly",
      "url": "https://grokbot.dev/marketplace/x-top-100-fans-weekly/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-top-100-fans-weekly.json",
      "headline": "X Top 100 Fans (Weekly)",
      "summary": "Ranks the 100 people who engaged most with your X posts each week",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "growth",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AdamLowisz",
        "url": "https://x.com/AdamLowisz/status/2093386801692201110"
      },
      "share_url": "https://x.ai/bot/HU7XArfGhUgLnzVcr7neB",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:14:41.000Z",
      "updated_at": "2026-08-28T17:14:41.000Z"
    },
    {
      "type": "template",
      "slug": "x-top-500-fans-monthly",
      "url": "https://grokbot.dev/marketplace/x-top-500-fans-monthly/",
      "detail_url": "https://grokbot.dev/api/v1/templates/x-top-500-fans-monthly.json",
      "headline": "X Top 500 Fans (Monthly)",
      "summary": "Monthly ranking of your 500 biggest X supporters, saved to a private list",
      "categories": [
        "creator",
        "marketer",
        "social-media",
        "growth",
        "monitoring",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AdamLowisz",
        "url": "https://x.com/AdamLowisz/status/2093386801692201110"
      },
      "share_url": "https://x.ai/bot/XzEATGwJNRvgsCLlcD9ox",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:14:41.000Z",
      "updated_at": "2026-08-28T17:14:41.000Z"
    },
    {
      "type": "template",
      "slug": "ai-usage-meter",
      "url": "https://grokbot.dev/marketplace/ai-usage-meter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/ai-usage-meter.json",
      "headline": "AI Usage Meter",
      "summary": "Tracks how much of each AI subscription you have actually used",
      "categories": [
        "personal",
        "developer",
        "saving-money",
        "monitoring",
        "productivity",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BrianDEvans",
        "url": "https://x.com/BrianDEvans/status/2093386518375346484"
      },
      "share_url": "https://x.ai/bot/2atUDeldi9vF1R_ySRgCo",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T17:13:33.000Z",
      "updated_at": "2026-08-28T17:13:33.000Z"
    },
    {
      "type": "template",
      "slug": "decklens-pitch-deck-analyzer",
      "url": "https://grokbot.dev/marketplace/decklens-pitch-deck-analyzer/",
      "detail_url": "https://grokbot.dev/api/v1/templates/decklens-pitch-deck-analyzer.json",
      "headline": "DeckLens (Pitch Deck Analyzer)",
      "summary": "Interviews you to build a review rubric, then scores pitch decks against it",
      "categories": [
        "investor",
        "business",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@BrianDEvans",
        "url": "https://x.com/BrianDEvans/status/2093386518375346484"
      },
      "share_url": "https://x.ai/bot/KlcxAG1I8cMQoqS_8Hrdn",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:13:33.000Z",
      "updated_at": "2026-08-28T17:13:33.000Z"
    },
    {
      "type": "template",
      "slug": "cost-smart-health-brief",
      "url": "https://grokbot.dev/marketplace/cost-smart-health-brief/",
      "detail_url": "https://grokbot.dev/api/v1/templates/cost-smart-health-brief.json",
      "headline": "Cost-Smart Health Brief",
      "summary": "Turns one health question into a three-minute brief",
      "categories": [
        "personal",
        "health",
        "saving-money",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GuleidAmina",
        "url": "https://x.com/GuleidAmina/status/2093386135452152155"
      },
      "share_url": "https://x.ai/bot/Rm6VqcE8cOWXwotPth9qM",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:12:02.000Z",
      "updated_at": "2026-08-28T17:12:02.000Z"
    },
    {
      "type": "plugin",
      "slug": "sightkick",
      "url": "https://grokbot.dev/plugins/sightkick/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/sightkick.json",
      "headline": "Sightkick",
      "summary": "Run SEO end to end: AI-answer visibility, articles, publishing, Search Console proof.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "sightkick.so",
        "url": "https://sightkick.so/mcp"
      },
      "added_at": "2026-08-28T17:11:54Z",
      "updated_at": "2026-08-28T17:11:54Z"
    },
    {
      "type": "template",
      "slug": "chief-of-staff-aryaman",
      "url": "https://grokbot.dev/marketplace/chief-of-staff-aryaman/",
      "detail_url": "https://grokbot.dev/api/v1/templates/chief-of-staff-aryaman.json",
      "headline": "Chief of Staff (Aryaman)",
      "summary": "Low-noise chief of staff across desk, Slack, inbox and calendar",
      "categories": [
        "personal",
        "business",
        "ops",
        "productivity",
        "email",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@aryamankhawow",
        "url": "https://x.com/aryamankhawow/status/2093385343928033312"
      },
      "share_url": "https://x.ai/bot/XjQ-AZTMrGLmQOTeMu3LF",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:08:53.000Z",
      "updated_at": "2026-08-28T17:08:53.000Z"
    },
    {
      "type": "template",
      "slug": "interview-prep",
      "url": "https://grokbot.dev/marketplace/interview-prep/",
      "detail_url": "https://grokbot.dev/api/v1/templates/interview-prep.json",
      "headline": "Interview Prep",
      "summary": "Picks a topic and level and climbs it with you until you are actually ready",
      "categories": [
        "student",
        "developer",
        "personal",
        "learning",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@techdevnotes",
        "url": "https://x.com/techdevnotes/status/2093385170896216257"
      },
      "share_url": "https://x.ai/bot/4aTE8S1KT93GkqHYxWIo3",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:08:12.000Z",
      "updated_at": "2026-08-28T17:08:12.000Z"
    },
    {
      "type": "template",
      "slug": "home-robots",
      "url": "https://grokbot.dev/marketplace/home-robots/",
      "detail_url": "https://grokbot.dev/api/v1/templates/home-robots.json",
      "headline": "Home Robots",
      "summary": "Control your mower, vacuum and other Matter home robots from one chat",
      "categories": [
        "personal",
        "home",
        "automation",
        "life-hacks",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SawyerMerritt",
        "url": "https://x.com/SawyerMerritt/status/2093384986162352495"
      },
      "share_url": "https://x.ai/bot/3mf-UN4mGnCp8DbPBnW5u",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:07:28.000Z",
      "updated_at": "2026-08-28T17:07:28.000Z"
    },
    {
      "type": "template",
      "slug": "master-orchestrator",
      "url": "https://grokbot.dev/marketplace/master-orchestrator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/master-orchestrator.json",
      "headline": "Master (Orchestrator)",
      "summary": "A lean orchestrator that routes every task to the right specialist and never works",
      "categories": [
        "business",
        "creator",
        "ops",
        "productivity",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@farzyness",
        "url": "https://x.com/farzyness/status/2093384064363377099"
      },
      "share_url": "https://x.ai/bot/j7B5LHnEIPTuPQZxxQwpx",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T17:03:48.000Z",
      "updated_at": "2026-08-28T17:03:48.000Z"
    },
    {
      "type": "template",
      "slug": "john-wick",
      "url": "https://grokbot.dev/marketplace/john-wick/",
      "detail_url": "https://grokbot.dev/api/v1/templates/john-wick.json",
      "headline": "John Wick",
      "summary": "Maps a target company and works upward until it reaches the decision maker",
      "categories": [
        "sales",
        "business",
        "growth",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383148906184985"
      },
      "share_url": "https://x.ai/bot/_OlL8LPI6lc2xi82F4Gf7",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:10.000Z",
      "updated_at": "2026-08-28T17:00:10.000Z"
    },
    {
      "type": "template",
      "slug": "examiner",
      "url": "https://grokbot.dev/marketplace/examiner/",
      "detail_url": "https://grokbot.dev/api/v1/templates/examiner.json",
      "headline": "Examiner",
      "summary": "When something breaks it shows you what changed just before",
      "categories": [
        "developer",
        "ops",
        "business",
        "research",
        "monitoring",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383146599301252"
      },
      "share_url": "https://x.ai/bot/rBnJhXhks-_7n1zhZCN3E",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:09.000Z",
      "updated_at": "2026-08-28T17:00:09.000Z"
    },
    {
      "type": "template",
      "slug": "reaper",
      "url": "https://grokbot.dev/marketplace/reaper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/reaper.json",
      "headline": "Reaper",
      "summary": "Finds the subscriptions, meetings and processes that should be killed",
      "categories": [
        "business",
        "personal",
        "ops",
        "saving-money",
        "productivity",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383144334348374"
      },
      "share_url": "https://x.ai/bot/Gd-cqXG8xG_RPmKGixa73",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:09.000Z",
      "updated_at": "2026-08-28T17:00:09.000Z"
    },
    {
      "type": "template",
      "slug": "interrogator",
      "url": "https://grokbot.dev/marketplace/interrogator/",
      "detail_url": "https://grokbot.dev/api/v1/templates/interrogator.json",
      "headline": "Interrogator",
      "summary": "Finds the assumptions you have been treating as facts",
      "categories": [
        "business",
        "personal",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383139250917746"
      },
      "share_url": "https://x.ai/bot/-TlSH1rNkA-c2JLsFFVc7",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:08.000Z",
      "updated_at": "2026-08-28T17:00:08.000Z"
    },
    {
      "type": "template",
      "slug": "witness",
      "url": "https://grokbot.dev/marketplace/witness/",
      "detail_url": "https://grokbot.dev/api/v1/templates/witness.json",
      "headline": "Witness",
      "summary": "Keeps a record of why you made each important decision",
      "categories": [
        "business",
        "ops",
        "personal",
        "productivity",
        "back-office",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383141901709505"
      },
      "share_url": "https://x.ai/bot/p_0KTQ41WwupGeD-iShbK",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:08.000Z",
      "updated_at": "2026-08-28T17:00:08.000Z"
    },
    {
      "type": "template",
      "slug": "bodyguard",
      "url": "https://grokbot.dev/marketplace/bodyguard/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bodyguard.json",
      "headline": "Bodyguard",
      "summary": "Sorts incoming requests by whether they deserve your time",
      "categories": [
        "personal",
        "business",
        "ops",
        "productivity",
        "email",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383136621060285"
      },
      "share_url": "https://x.ai/bot/tII28kVM4dxPvzSLjwqko",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:07.000Z",
      "updated_at": "2026-08-28T17:00:07.000Z"
    },
    {
      "type": "template",
      "slug": "gatekeeper",
      "url": "https://grokbot.dev/marketplace/gatekeeper/",
      "detail_url": "https://grokbot.dev/api/v1/templates/gatekeeper.json",
      "headline": "Gatekeeper",
      "summary": "Shows you what you would have to drop before you say yes to something new",
      "categories": [
        "business",
        "personal",
        "ops",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383132137279825"
      },
      "share_url": "https://x.ai/bot/T5FSfM91XA6gMgh2rX56K",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:06.000Z",
      "updated_at": "2026-08-28T17:00:06.000Z"
    },
    {
      "type": "template",
      "slug": "bounty-hunter",
      "url": "https://grokbot.dev/marketplace/bounty-hunter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/bounty-hunter.json",
      "headline": "Bounty Hunter",
      "summary": "Digs through your email and bills for refunds and credits you never chased",
      "categories": [
        "personal",
        "saving-money",
        "life-hacks",
        "email",
        "finance",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383127162925558"
      },
      "share_url": "https://x.ai/bot/gCWYD009F66A3XDEYdZgf",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:05.000Z",
      "updated_at": "2026-08-28T17:00:05.000Z"
    },
    {
      "type": "template",
      "slug": "fixer-liam",
      "url": "https://grokbot.dev/marketplace/fixer-liam/",
      "detail_url": "https://grokbot.dev/api/v1/templates/fixer-liam.json",
      "headline": "Fixer (Liam)",
      "summary": "Hand it the admin thing you keep putting off and it gets it nearly solved",
      "categories": [
        "personal",
        "saving-money",
        "life-hacks",
        "back-office",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383129780109562"
      },
      "share_url": "https://x.ai/bot/CEtFUY1_kkn78AJSNINHI",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:05.000Z",
      "updated_at": "2026-08-28T17:00:05.000Z"
    },
    {
      "type": "template",
      "slug": "morpheus",
      "url": "https://grokbot.dev/marketplace/morpheus/",
      "detail_url": "https://grokbot.dev/api/v1/templates/morpheus.json",
      "headline": "Morpheus",
      "summary": "Give it options you are stuck between and it picks one and defends the choice",
      "categories": [
        "personal",
        "business",
        "productivity",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383122465288695"
      },
      "share_url": "https://x.ai/bot/uv4r3mNUgymF11q0N3L7F",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:04.000Z",
      "updated_at": "2026-08-28T17:00:04.000Z"
    },
    {
      "type": "template",
      "slug": "sherlock-holmes",
      "url": "https://grokbot.dev/marketplace/sherlock-holmes/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sherlock-holmes.json",
      "headline": "Sherlock Holmes",
      "summary": "Give it a symptom and it works out what actually caused the drop",
      "categories": [
        "business",
        "marketer",
        "ops",
        "research",
        "data",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093383124948324505"
      },
      "share_url": "https://x.ai/bot/fXHgGtuPfTcHBTVKSCZ1d",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T17:00:04.000Z",
      "updated_at": "2026-08-28T17:00:04.000Z"
    },
    {
      "type": "template",
      "slug": "spark-onboarding",
      "url": "https://grokbot.dev/marketplace/spark-onboarding/",
      "detail_url": "https://grokbot.dev/api/v1/templates/spark-onboarding.json",
      "headline": "Spark (Onboarding)",
      "summary": "A five-minute onboarding bot that spawns the starter bots you need",
      "categories": [
        "personal",
        "developer",
        "learning",
        "automation",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@vincentzhu",
        "url": "https://x.com/vincentzhu/status/2093382794630377806"
      },
      "share_url": "https://x.ai/bot/_2vi1lOY4oiBaJDA3S8l1",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T16:58:46.000Z",
      "updated_at": "2026-08-28T16:58:46.000Z"
    },
    {
      "type": "template",
      "slug": "harvey-specter",
      "url": "https://grokbot.dev/marketplace/harvey-specter/",
      "detail_url": "https://grokbot.dev/api/v1/templates/harvey-specter.json",
      "headline": "Harvey Specter",
      "summary": "Negotiates a deal, renewal or quote for the best realistic terms",
      "categories": [
        "business",
        "personal",
        "sales",
        "saving-money",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2093382733019939198"
      },
      "share_url": "https://x.ai/bot/lkkCqhC1jBFp6ouZOQd9m",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T16:58:31.000Z",
      "updated_at": "2026-08-28T16:58:31.000Z"
    },
    {
      "type": "template",
      "slug": "shikamaru",
      "url": "https://grokbot.dev/marketplace/shikamaru/",
      "detail_url": "https://grokbot.dev/api/v1/templates/shikamaru.json",
      "headline": "Shikamaru",
      "summary": "A chief of staff that hires and manages specialists in a named world",
      "categories": [
        "business",
        "personal",
        "ops",
        "agent-team",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@WorldlyReviewer",
        "url": "https://x.com/WorldlyReviewer/status/2093382383802151353"
      },
      "share_url": "https://x.ai/bot/rrvGu13S5uYCc09WP7A-9",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T16:57:08.000Z",
      "updated_at": "2026-08-28T16:57:08.000Z"
    },
    {
      "type": "template",
      "slug": "sable-game-art",
      "url": "https://grokbot.dev/marketplace/sable-game-art/",
      "detail_url": "https://grokbot.dev/api/v1/templates/sable-game-art.json",
      "headline": "Sable: Game Art",
      "summary": "Generates 2D game art and sprite sheets in a style you pick",
      "categories": [
        "creator",
        "developer",
        "design",
        "content",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DannyLimanseta",
        "url": "https://x.com/DannyLimanseta/status/2093381938484810054"
      },
      "share_url": "https://x.ai/bot/oSvAMKX_ahD56ZmgwtRys",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T16:55:21.000Z",
      "updated_at": "2026-08-28T16:55:21.000Z"
    },
    {
      "type": "template",
      "slug": "projects-manager",
      "url": "https://grokbot.dev/marketplace/projects-manager/",
      "detail_url": "https://grokbot.dev/api/v1/templates/projects-manager.json",
      "headline": "Projects Manager",
      "summary": "Runs a team of Grok bots as a project org, with Notion as the source of truth",
      "categories": [
        "business",
        "ops",
        "developer",
        "productivity",
        "automation",
        "data",
        "agent-team",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ericzakariasson",
        "url": "https://x.com/ericzakariasson/status/2093381689041109349"
      },
      "share_url": "https://x.ai/bot/FU-Ev6_Ju4lFGWwWRD0GD",
      "includes": [
        "instructions",
        "agent-team",
        "workflow"
      ],
      "added_at": "2026-08-28T16:54:22.000Z",
      "updated_at": "2026-08-28T16:54:22.000Z"
    },
    {
      "type": "template",
      "slug": "kody",
      "url": "https://grokbot.dev/marketplace/kody/",
      "detail_url": "https://grokbot.dev/api/v1/templates/kody.json",
      "headline": "Kody",
      "summary": "A chief of staff that turns your priorities into coordinated action",
      "categories": [
        "personal",
        "business",
        "developer",
        "productivity",
        "ops",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kentcdodds",
        "url": "https://x.com/kentcdodds/status/2093380421883252897"
      },
      "share_url": "https://x.ai/bot/yTSGElYcIjFW_5IXu2I-e",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T16:49:20.000Z",
      "updated_at": "2026-08-28T16:49:20.000Z"
    },
    {
      "type": "template",
      "slug": "jess-executive-assistant",
      "url": "https://grokbot.dev/marketplace/jess-executive-assistant/",
      "detail_url": "https://grokbot.dev/api/v1/templates/jess-executive-assistant.json",
      "headline": "Jess (Executive Assistant)",
      "summary": "Recaps email, calendar, Notion and Slack before you open any of them",
      "categories": [
        "personal",
        "business",
        "ops",
        "productivity",
        "email",
        "back-office",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@LoganARobison",
        "url": "https://x.com/LoganARobison/status/2093380304891167113"
      },
      "share_url": "https://x.ai/bot/Nmv2fCQEcQc3EHzVXJZKN",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T16:48:52.000Z",
      "updated_at": "2026-08-28T16:48:52.000Z"
    },
    {
      "type": "template",
      "slug": "loops",
      "url": "https://grokbot.dev/marketplace/loops/",
      "detail_url": "https://grokbot.dev/api/v1/templates/loops.json",
      "headline": "loops",
      "summary": "An engineering outer loop that sits above your coding agents",
      "categories": [
        "developer",
        "productivity",
        "automation",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mattyp",
        "url": "https://x.com/mattyp/status/2093380201128595966"
      },
      "share_url": "https://x.ai/bot/Ub3T7usX-c6yRQibQq83P",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T16:48:27.000Z",
      "updated_at": "2026-08-28T16:48:27.000Z"
    },
    {
      "type": "template",
      "slug": "inbot",
      "url": "https://grokbot.dev/marketplace/inbot/",
      "detail_url": "https://grokbot.dev/api/v1/templates/inbot.json",
      "headline": "Inbot",
      "summary": "An inbox-zero bot across every inbox you actually use",
      "categories": [
        "personal",
        "business",
        "ops",
        "email",
        "productivity",
        "automation",
        "back-office",
        "scheduled"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@matt_silberman",
        "url": "https://x.com/matt_silberman/status/2093378871403933751"
      },
      "share_url": "https://x.ai/bot/yH2UttxbMwMugweZrigHT",
      "includes": [
        "instructions",
        "schedule",
        "workflow"
      ],
      "added_at": "2026-08-28T16:43:10.000Z",
      "updated_at": "2026-08-28T16:43:10.000Z"
    },
    {
      "type": "template",
      "slug": "pg-prospecting",
      "url": "https://grokbot.dev/marketplace/pg-prospecting/",
      "detail_url": "https://grokbot.dev/api/v1/templates/pg-prospecting.json",
      "headline": "PG (Prospecting)",
      "summary": "Researches accounts and mines podcasts for a real outreach hook",
      "categories": [
        "sales",
        "business",
        "growth",
        "research",
        "on-demand"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kristaletz",
        "url": "https://x.com/kristaletz/status/2093378627932918087"
      },
      "share_url": "https://x.ai/bot/fcJJMM58AdXSTBdW3xWyW",
      "includes": [
        "instructions",
        "workflow"
      ],
      "added_at": "2026-08-28T16:42:12.000Z",
      "updated_at": "2026-08-28T16:42:12.000Z"
    },
    {
      "type": "use-case",
      "slug": "market-expectations-desk",
      "url": "https://grokbot.dev/use-cases/market-expectations-desk/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/market-expectations-desk.json",
      "headline": "See what the market is pricing in before the crowd reacts to it",
      "summary": "Now that Grok Bot reads live prices and option chains, most will ask 'should I buy NVDA'. Alex Prompter uses it as an expectations desk: it reads the ATM straddle to show the market's expected move before earnings and Fed days, contrasts it with the headlines, and names which side has to be wrong. Read-only by design.",
      "categories": [
        "personal",
        "work"
      ],
      "awesome_score": 78,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@alex_prompter",
        "url": "https://x.com/alex_prompter/status/2093289003302764585"
      },
      "added_at": "2026-08-28T12:00:00Z",
      "updated_at": "2026-08-28T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "build-a-one-person-hedge-fund",
      "url": "https://grokbot.dev/use-cases/build-a-one-person-hedge-fund/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/build-a-one-person-hedge-fund.json",
      "headline": "Eight named bots run the whole fund: research, trading, risk and back office",
      "summary": "RohOnChain's field-report paper argues a fund's headcount moat has collapsed: research desk, trading, and back office map onto eight named bots on one shared cloud computer. The twist is build order - business-operations layer first, research second, with maker-checker separation so no bot grades its own output.",
      "categories": [
        "engineering",
        "work"
      ],
      "awesome_score": 82,
      "format": "guide",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RohOnChain",
        "url": "https://x.com/RohOnChain/status/2093019378698842564"
      },
      "added_at": "2026-08-28T11:00:00Z",
      "updated_at": "2026-08-28T11:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "stock-valuation-levels-agent",
      "url": "https://grokbot.dev/use-cases/stock-valuation-levels-agent/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/stock-valuation-levels-agent.json",
      "headline": "Teach a bot one analyst's valuation method, then just feed it tickers",
      "summary": "Money_or_Life_X had Grok Bot study a finance YouTuber's price-target method, pull free data, and learn to assign P/E multiples - a 'valuation levels' agent that outputs a chart for any ticker. Two other investing agents critique its method. Honest about its one human variable: the multiple is the agent's own judgment.",
      "categories": [
        "personal",
        "work"
      ],
      "awesome_score": 79,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Money_or_Life_X",
        "url": "https://x.com/Money_or_Life_X/status/2092905577995526193"
      },
      "added_at": "2026-08-28T10:05:00Z",
      "updated_at": "2026-08-28T10:05:00Z"
    },
    {
      "type": "use-case",
      "slug": "replicate-social-analytics-follower-cleanup",
      "url": "https://grokbot.dev/use-cases/replicate-social-analytics-follower-cleanup/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/replicate-social-analytics-follower-cleanup.json",
      "headline": "Replace a $50/mo follower analytics tool with your X data archive and a bot",
      "summary": "kloss_xyz didn't want to pay for social analytics, so he had Grok Bot replicate it from his X data archive. Hand the bot following.js and follower.js and it sorts everyone into mutuals, people you've talked to, inactives and spam - then tags who to cut. You approve every batch; it never unfollows more than 100 a day.",
      "categories": [
        "marketing",
        "personal"
      ],
      "awesome_score": 77,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kloss_xyz",
        "url": "https://x.com/kloss_xyz/status/2092999741982536085"
      },
      "added_at": "2026-08-28T10:00:00Z",
      "updated_at": "2026-08-28T10:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "aituber",
      "url": "https://grokbot.dev/plugins/aituber/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/aituber.json",
      "headline": "AITuber",
      "summary": "Give your agent a video studio: script, voice-over, captions and publishing.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "aituber.app",
        "url": "https://aituber.app"
      },
      "added_at": "2026-08-28T00:00:00Z",
      "updated_at": "2026-08-28T00:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "track-the-grok-bot-team",
      "url": "https://grokbot.dev/use-cases/track-the-grok-bot-team/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/track-the-grok-bot-team.json",
      "headline": "Be first to know about new Grok Bot features - your bot tracks the team that builds it",
      "summary": "Ben Lang posted the list of engineers and designers building Grok Bot and said: follow them. The better move: have your bot do it for you. A daily check of all seven profiles, a seen-log so nothing repeats, a signal filter so only feature news gets through - delivered to you, or straight to your Chief of Staff bot.",
      "categories": [
        "engineering",
        "work"
      ],
      "awesome_score": 76,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@benln",
        "url": "https://x.com/benln/status/2092995402953884072"
      },
      "added_at": "2026-08-27T16:10:00Z",
      "updated_at": "2026-08-27T16:10:00Z"
    },
    {
      "type": "plugin",
      "slug": "pdf-ai",
      "url": "https://grokbot.dev/plugins/pdf-ai/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/pdf-ai.json",
      "headline": "PDF.ai",
      "summary": "Turn any PDF into structured data your bot can use - parse, extract, split, one API key.",
      "categories": [
        "data"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "pdf.ai",
        "url": "https://pdf.ai"
      },
      "added_at": "2026-08-27T09:00:00Z",
      "updated_at": "2026-08-27T09:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "ai-search-lead",
      "url": "https://grokbot.dev/use-cases/ai-search-lead/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/ai-search-lead.json",
      "headline": "Shape what AI says about you",
      "summary": "Reads engine answers and citations, crawls and 404 demand, plus Search Console and GA4 through a connected DevTune project. Drafts the next evidence-ranked page for review and reports what moved after it ships. Nothing publishes without approval.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 71,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@theplgeek",
        "url": "https://x.com/theplgeek"
      },
      "added_at": "2026-08-27T07:20:00Z",
      "updated_at": "2026-08-27T07:20:00Z"
    },
    {
      "type": "use-case",
      "slug": "personal-cfo-bank-access",
      "url": "https://grokbot.dev/use-cases/personal-cfo-bank-access/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/personal-cfo-bank-access.json",
      "headline": "He gave his Grok Bot full bank access and made it his personal CFO",
      "summary": "Teslaconomics connected everything - personal and business banks, credit cards, Apple Card, X Money - and one question now answers his morning: can I cover what's coming, or am I short? Green/red per bill with the exact shortfall, daily reminders until it goes green, pie charts on demand. Day 1, receipts included.",
      "categories": [
        "personal"
      ],
      "awesome_score": 80,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Teslaconomics",
        "url": "https://x.com/Teslaconomics/status/2092837438146351407"
      },
      "added_at": "2026-08-27T07:05:00Z",
      "updated_at": "2026-08-27T07:05:00Z"
    },
    {
      "type": "use-case",
      "slug": "house-memory-bot",
      "url": "https://grokbot.dev/use-cases/house-memory-bot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/house-memory-bot.json",
      "headline": "One bot's only job: be the long-term memory of your house",
      "summary": "Morgan Linton's idea for a bot no chatbot can be: photograph every appliance sticker, breaker panel, filter size and paint can once, and the bot files it all for years. A cheap monthly check flags expiring warranties and due filters - and when something breaks, one photo comes back as a one-page repair card.",
      "categories": [
        "personal"
      ],
      "awesome_score": 78,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@morganlinton",
        "url": "https://x.com/morganlinton/status/2092714740095271058"
      },
      "added_at": "2026-08-27T06:10:00Z",
      "updated_at": "2026-08-27T06:10:00Z"
    },
    {
      "type": "plugin",
      "slug": "pallyy",
      "url": "https://grokbot.dev/plugins/pallyy/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/pallyy.json",
      "headline": "Pallyy",
      "summary": "Let your agent draft, schedule, and publish social posts through Pallyy's REST API.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "pallyy.com",
        "url": "https://pallyy.com"
      },
      "added_at": "2026-08-27T00:00:00Z",
      "updated_at": "2026-08-27T00:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "daily-youtube-summary",
      "url": "https://grokbot.dev/use-cases/daily-youtube-summary/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/daily-youtube-summary.json",
      "headline": "A 7am daily recap of the YouTube channels you actually follow",
      "summary": "One bot, one routine: it interviews you about your interests, locks in 7-10 favorite channels, then checks them every morning through the TranscriptAPI plugin. New videos in the last 24 hours get summarized from their transcripts into one chat message at 7am - and a seen-log guarantees it never repeats itself.",
      "categories": [
        "personal",
        "work"
      ],
      "awesome_score": 81,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai"
      },
      "added_at": "2026-08-26T16:30:00Z",
      "updated_at": "2026-08-26T16:30:00Z"
    },
    {
      "type": "plugin",
      "slug": "phonezero",
      "url": "https://grokbot.dev/plugins/phonezero/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/phonezero.json",
      "headline": "PhoneZero",
      "summary": "Enable phone to phone tasks in Grok Bot using Grok Voice Agents and Telnyx. Zero infra.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "github.com",
        "url": "https://github.com/function1st/PhoneZero"
      },
      "added_at": "2026-08-26T16:07:16Z",
      "updated_at": "2026-08-26T16:07:16Z"
    },
    {
      "type": "use-case",
      "slug": "newsletter-unsubscribe-audit",
      "url": "https://grokbot.dev/use-cases/newsletter-unsubscribe-audit/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/newsletter-unsubscribe-audit.json",
      "headline": "Newsletter detox: the bot audits, you review one page, it unsubscribes",
      "summary": "A two-phase inbox detox with a human gate. The bot sweeps your email and builds a simple HTML review page of every newsletter you receive, sorted into keep vs certainly-unsubscribe with its reasoning. You decide. Then it works the list slowly in the browser, logging every attempt in a progress file.",
      "categories": [
        "work",
        "personal"
      ],
      "awesome_score": 86,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2092591711557947796"
      },
      "added_at": "2026-08-26T14:30:00Z",
      "updated_at": "2026-08-26T15:40:00Z"
    },
    {
      "type": "plugin",
      "slug": "composio",
      "url": "https://grokbot.dev/plugins/composio/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/composio.json",
      "headline": "Composio",
      "summary": "One connector that gives your Grok Bot 1,000+ app integrations via MCP.",
      "categories": [
        "engineering"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "composio.dev",
        "url": "https://composio.dev"
      },
      "added_at": "2026-08-26T13:30:00Z",
      "updated_at": "2026-08-26T13:30:00Z"
    },
    {
      "type": "use-case",
      "slug": "composio-connector-hack",
      "url": "https://grokbot.dev/use-cases/composio-connector-hack/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/composio-connector-hack.json",
      "headline": "The connector hack - one Composio MCP gives your bot 1,000+ tools",
      "summary": "Corey Ganim's workaround for Grok Bot's thinner connector catalog: connect the Composio connector once, then connect any of Composio's 1,000+ integrations through it - your bot uses all of them via Composio MCP. Unsponsored, in his words the easiest way to reach tools that have no native Cursor connector.",
      "categories": [
        "engineering",
        "work"
      ],
      "awesome_score": 75,
      "format": "guide",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@coreyganim",
        "url": "https://x.com/coreyganim/status/2092559429275447742"
      },
      "added_at": "2026-08-26T12:40:00Z",
      "updated_at": "2026-08-26T12:40:00Z"
    },
    {
      "type": "use-case",
      "slug": "seven-bot-content-team",
      "url": "https://grokbot.dev/use-cases/seven-bot-content-team/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/seven-bot-content-team.json",
      "headline": "Seven bots run his content calendar - he only reviews",
      "summary": "Ridark gave Grok Bot his content calendar instead of a to-do list: seven named bots on one shared machine - discovery, research, writing, visuals, distribution, analytics, and Anchor, the chief of staff he DMs. One group chat per post, hard approval fences, and week one shipped 14 of 25 drafts with his inbox at zero.",
      "categories": [
        "marketing",
        "work"
      ],
      "awesome_score": 87,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ridark_eth",
        "url": "https://x.com/ridark_eth/status/2092292504066429381"
      },
      "added_at": "2026-08-26T12:20:00Z",
      "updated_at": "2026-08-26T12:20:00Z"
    },
    {
      "type": "use-case",
      "slug": "affiliate-program-manager",
      "url": "https://grokbot.dev/use-cases/affiliate-program-manager/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/affiliate-program-manager.json",
      "headline": "Automate your affiliate program with an AI affiliate manager",
      "summary": "An Affonso-powered Grok Bot automates weekly affiliate management: it compares performance, finds growth opportunities and risks, and prepares partner actions. Program changes, payouts, and partner messages still require approval.",
      "categories": [
        "marketing",
        "finance-ops"
      ],
      "awesome_score": 80,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@affonso-io",
        "url": "https://github.com/affonso-io"
      },
      "added_at": "2026-08-26T12:12:25Z",
      "updated_at": "2026-08-26T13:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "affonso",
      "url": "https://grokbot.dev/plugins/affonso/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/affonso.json",
      "headline": "Affonso",
      "summary": "Give your Grok Bot affiliate data and approval-gated program operations.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "affonso.io",
        "url": "https://affonso.io"
      },
      "added_at": "2026-08-26T12:12:25Z",
      "updated_at": "2026-08-26T12:12:25Z"
    },
    {
      "type": "use-case",
      "slug": "be-happier-bot",
      "url": "https://grokbot.dev/use-cases/be-happier-bot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/be-happier-bot.json",
      "headline": "Lenny's 'Be Happier' bot - 3 weekly suggestions from your real life",
      "summary": "Lenny Rachitsky's favorite new use case is one sentence: a 'Be Happier' bot that analyzes his emails, calendar and Slack and suggests three things per week to be happier. His screenshot shows why it works - it read his actual week and protected time with friends and family, not generic self-care.",
      "categories": [
        "personal"
      ],
      "awesome_score": 81,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lennysan",
        "url": "https://x.com/lennysan/status/2092283728877990128"
      },
      "added_at": "2026-08-26T11:40:00Z",
      "updated_at": "2026-08-26T11:40:00Z"
    },
    {
      "type": "use-case",
      "slug": "give-your-grok-bot-a-phone-number",
      "url": "https://grokbot.dev/use-cases/give-your-grok-bot-a-phone-number/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/give-your-grok-bot-a-phone-number.json",
      "headline": "Give your Grok Bot a phone number - it makes the calls and reports back",
      "summary": "Peter bought a $15 phone number on Bland, gave his Grok Bot the API key, and the bot worked out the rest. Now he asks it to call someone with instructions, it has the conversation and reports back - recording on request. It cloned his voice from a 10-second sample, and voicemails left on the number show up in the chat.",
      "categories": [
        "personal",
        "work"
      ],
      "awesome_score": 85,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SPCXTSLA",
        "url": "https://x.com/SPCXTSLA/status/2092356603349815435"
      },
      "added_at": "2026-08-26T11:35:00Z",
      "updated_at": "2026-08-26T11:35:00Z"
    },
    {
      "type": "plugin",
      "slug": "bland",
      "url": "https://grokbot.dev/plugins/bland/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/bland.json",
      "headline": "Bland",
      "summary": "Give your Grok Bot a real phone number and a voice that makes actual calls.",
      "categories": [
        "sales"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "bland.ai",
        "url": "https://www.bland.ai"
      },
      "added_at": "2026-08-26T11:30:00Z",
      "updated_at": "2026-08-26T11:30:00Z"
    },
    {
      "type": "use-case",
      "slug": "find-customers-complaining-about-competitors",
      "url": "https://grokbot.dev/use-cases/find-customers-complaining-about-competitors/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/find-customers-complaining-about-competitors.json",
      "headline": "Find customers on X who already said they want to switch",
      "summary": "Amplemarket founder Luis Batalha's playbook: have your Grok Bot search X for people complaining about your competitors or asking for alternatives, enrich the poster and company via the Amplemarket connector, reach out - then make it a weekly routine. You don't guess who has the problem; they publicly told you.",
      "categories": [
        "sales"
      ],
      "awesome_score": 82,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@luismbat",
        "url": "https://x.com/luismbat/status/2092250997221433848"
      },
      "added_at": "2026-08-26T09:35:00Z",
      "updated_at": "2026-08-26T09:35:00Z"
    },
    {
      "type": "plugin",
      "slug": "amplemarket",
      "url": "https://grokbot.dev/plugins/amplemarket/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/amplemarket.json",
      "headline": "Amplemarket",
      "summary": "Give your Grok Bot a full sales stack - prospect data, signals, and outreach.",
      "categories": [
        "sales"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "amplemarket.com",
        "url": "https://www.amplemarket.com"
      },
      "added_at": "2026-08-26T09:30:00Z",
      "updated_at": "2026-08-26T09:30:00Z"
    },
    {
      "type": "plugin",
      "slug": "appllama",
      "url": "https://grokbot.dev/plugins/appllama/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/appllama.json",
      "headline": "Appllama",
      "summary": "Let your Grok Bot study 39,000+ screens from the App Store's top-earning apps.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "appllama.io",
        "url": "https://appllama.io"
      },
      "added_at": "2026-08-26T09:00:00Z",
      "updated_at": "2026-08-26T09:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "bargain-hunter-bot-buys-within-budget",
      "url": "https://grokbot.dev/use-cases/bargain-hunter-bot-buys-within-budget/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/bargain-hunter-bot-buys-within-budget.json",
      "headline": "Give your bot specs and a max price - it bids when the bargain appears",
      "summary": "Vox runs two real-money errands on one rule. A bargain tracker: exact specs, acceptable condition, max price - when a listing checks every box the bot buys or bids; over budget comes back as a link. And a haircut booked end to end, paid via Stripe Link. The rule: within range, go ahead; outside it, ask first.",
      "categories": [
        "personal"
      ],
      "awesome_score": 78,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Voxyz_ai",
        "url": "https://x.com/Voxyz_ai/status/2092376252120535477"
      },
      "added_at": "2026-08-26T08:15:00Z",
      "updated_at": "2026-08-26T08:15:00Z"
    },
    {
      "type": "use-case",
      "slug": "exact-chief-of-staff-prompt",
      "url": "https://grokbot.dev/use-cases/exact-chief-of-staff-prompt/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/exact-chief-of-staff-prompt.json",
      "headline": "The exact two-part prompt behind a Chief of Staff that protects your time",
      "summary": "Corey Ganim's verbatim Chief of Staff build: a bot description that locks three priorities in order, defaults to acting, and never sends or invents a number - plus a first message that wires Gmail/Calendar/Todoist/Notion, builds a Sunday week-plan skill, and hires specialist bots only after the brief is locked.",
      "categories": [
        "work",
        "sales"
      ],
      "awesome_score": 86,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@coreyganim",
        "url": "https://x.com/coreyganim/status/2092375719292862933"
      },
      "added_at": "2026-08-26T07:50:00Z",
      "updated_at": "2026-08-26T08:40:00Z"
    },
    {
      "type": "use-case",
      "slug": "ai-tools-maintainer",
      "url": "https://grokbot.dev/use-cases/ai-tools-maintainer/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/ai-tools-maintainer.json",
      "headline": "A weekday bot that updates only what you already installed",
      "summary": "Each weekday morning this Grok Bot inventories real binaries on the PC or Mac it can reach, updates only installed tools on the same channel already used, re-runs post-update hooks, honors a deny list, and stays quiet if nothing changed.",
      "categories": [
        "engineering",
        "personal"
      ],
      "awesome_score": 75,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@gheeunit",
        "url": "https://x.com/gheeunit/status/2092455037486137501"
      },
      "added_at": "2026-08-26T03:34:00Z",
      "updated_at": "2026-08-26T09:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "omnisocials",
      "url": "https://grokbot.dev/plugins/omnisocials/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/omnisocials.json",
      "headline": "OmniSocials",
      "summary": "Give your agent one API to schedule, publish, and analyze posts across 12 platforms.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "omnisocials.com",
        "url": "https://omnisocials.com"
      },
      "added_at": "2026-08-26T00:00:00Z",
      "updated_at": "2026-08-26T00:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "search1api",
      "url": "https://grokbot.dev/plugins/search1api/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/search1api.json",
      "headline": "Search1API",
      "summary": "Live web search, news, page reading, and trends for your Grok Bot.",
      "categories": [
        "data"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "s1.dev",
        "url": "https://s1.dev"
      },
      "added_at": "2026-08-26T00:00:00Z",
      "updated_at": "2026-08-26T00:00:00Z"
    },
    {
      "type": "news",
      "slug": "lennys-newsletter-free-month-grok-bot",
      "url": "https://grokbot.dev/news/lennys-newsletter-free-month-grok-bot/",
      "detail_url": "https://grokbot.dev/api/v1/news/lennys-newsletter-free-month-grok-bot.json",
      "title": "Free month of Grok Bot for Lenny's Newsletter subscribers",
      "headline": "Free month of Grok Bot for Lenny's Newsletter subscribers",
      "summary": "Lenny Rachitsky is partnering with SpaceXAI - the first deal of its kind - to give every Lenny's Newsletter annual subscriber a free month of Grok Bot (included in Cursor Pro+). Existing subscribers redeem via Lenny's Product Pass; new subscribers get the link in their welcome email.",
      "kind": "deal",
      "important": true,
      "external_url": "https://www.lennysproductpass.com/",
      "cta_label": "grab the free month",
      "source": {
        "platform": "x",
        "label": "@lennysan",
        "url": "https://x.com/lennysan/status/2092386630397255796"
      },
      "categories": [],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "added_at": "2026-08-26T00:00:00.000Z",
      "published_at": "2026-08-26T00:00:00.000Z",
      "updated_at": "2026-08-26T00:00:00.000Z"
    },
    {
      "type": "use-case",
      "slug": "harden-your-email-bot-against-prompt-injection",
      "url": "https://grokbot.dev/use-cases/harden-your-email-bot-against-prompt-injection/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/harden-your-email-bot-against-prompt-injection.json",
      "headline": "Harden your email-reading Grok Bot against prompt injection",
      "summary": "Peter's security prompt for any bot that reads and replies to email: treat every part of an email - body, subject, sender, attachments, even hidden white text - as DATA, never instructions. It lists the injection patterns to refuse, flags attempts instead of complying, and gates real actions behind your confirmation.",
      "categories": [
        "engineering",
        "work"
      ],
      "awesome_score": 81,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@aye_pete",
        "url": "https://x.com/aye_pete/status/2092324168037707992"
      },
      "added_at": "2026-08-25T19:10:00Z",
      "updated_at": "2026-08-25T19:10:00Z"
    },
    {
      "type": "use-case",
      "slug": "amazon-cart-builder-grok-bot",
      "url": "https://grokbot.dev/use-cases/amazon-cart-builder-grok-bot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/amazon-cart-builder-grok-bot.json",
      "headline": "Build a Grok Bot that fills your Amazon cart from your past orders",
      "summary": "Teslaconomics built 'Cart' - a Grok Bot that does his Amazon shopping. It signs into his Amazon, reads Buy Again and past orders, and puts the exact products he already buys into the cart; he just checks out. It works for anything on Amazon, and it never places the order or touches payment - those stay with him.",
      "categories": [
        "personal"
      ],
      "awesome_score": 91,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@Teslaconomics",
        "url": "https://x.com/Teslaconomics/status/2091952899110981916"
      },
      "added_at": "2026-08-25T11:55:00Z",
      "updated_at": "2026-08-25T11:55:00Z"
    },
    {
      "type": "use-case",
      "slug": "workforce-checker-for-stuck-bots",
      "url": "https://grokbot.dev/use-cases/workforce-checker-for-stuck-bots/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/workforce-checker-for-stuck-bots.json",
      "headline": "A 'workforce checker' bot that catches agents that quietly quit",
      "summary": "eric zakariasson's fix for bots that quietly stall: a workforce-checker bot. Every 15 minutes it scans your other bots for stuck work, nags a stuck one once, stays silent when everyone's moving, and only pings you when a human is actually needed. One short prompt turns fleet-babysitting into a background routine.",
      "categories": [
        "engineering",
        "work"
      ],
      "awesome_score": 83,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ericzakariasson",
        "url": "https://x.com/ericzakariasson/status/2092205948505059435"
      },
      "added_at": "2026-08-25T11:20:00Z",
      "updated_at": "2026-08-25T11:20:00Z"
    },
    {
      "type": "use-case",
      "slug": "give-grok-bot-reliable-youtube-access",
      "url": "https://grokbot.dev/use-cases/give-grok-bot-reliable-youtube-access/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/give-grok-bot-reliable-youtube-access.json",
      "headline": "Give your Grok Bot reliable YouTube access with the TranscriptAPI plugin",
      "summary": "@scheemunai's first test for any new agent is YouTube - and browser control burned his entire Grok Bot trial trying to summarize one video (blocked caption API, empty transcript panel). The fix: the TranscriptAPI plugin, which gives the Bot timestamped transcripts, search, channels and playlists in one request.",
      "categories": [
        "work",
        "data",
        "marketing"
      ],
      "awesome_score": 85,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2092205040429682919"
      },
      "added_at": "2026-08-25T11:15:00Z",
      "updated_at": "2026-08-25T11:15:00Z"
    },
    {
      "type": "use-case",
      "slug": "cancel-subscriptions-with-grok-bot",
      "url": "https://grokbot.dev/use-cases/cancel-subscriptions-with-grok-bot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/cancel-subscriptions-with-grok-bot.json",
      "headline": "Have your Grok Bot cancel subscriptions for you - workarounds and all",
      "summary": "Morgan Linton asked his Grok Bot to cancel a service - and it just figured it out. When it couldn't log in, instead of getting stuck it clicked a 'manage plan' link in an email, triggered a one-time sign-in email, and used that to finish the cancellation. He had to ask the bot how it pulled it off.",
      "categories": [
        "finance-ops",
        "personal"
      ],
      "awesome_score": 77,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@morganlinton",
        "url": "https://x.com/morganlinton/status/2092016807943250150"
      },
      "added_at": "2026-08-24T22:45:00Z",
      "updated_at": "2026-08-24T22:45:00Z"
    },
    {
      "type": "use-case",
      "slug": "one-bad-grok-bot-devils-advocate",
      "url": "https://grokbot.dev/use-cases/one-bad-grok-bot-devils-advocate/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/one-bad-grok-bot-devils-advocate.json",
      "headline": "Add a Disruptor bot to your team that disagrees with you on purpose",
      "summary": "Liam keeps one deliberately difficult Grok Bot around. Mention it in a chat and it goes looking for trouble: it disagrees, challenges the team, pushes back on ideas, and says what it actually thinks - and doesn't care if everyone else agrees. A built-in devil's advocate that kills groupthink and sycophancy.",
      "categories": [
        "work",
        "personal"
      ],
      "awesome_score": 80,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2091944229647868192"
      },
      "added_at": "2026-08-24T20:15:00Z",
      "updated_at": "2026-08-24T20:45:00Z"
    },
    {
      "type": "use-case",
      "slug": "clip-youtube-podcasts-with-grok-bot",
      "url": "https://grokbot.dev/use-cases/clip-youtube-podcasts-with-grok-bot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/clip-youtube-podcasts-with-grok-bot.json",
      "headline": "Clip a YouTube podcast by timestamp, then let a bot team write the post",
      "summary": "KanekoaTheGreat sends his Grok Bot a YouTube link and says 'cut from 16:43 to 18:17' - a few minutes later the exact HD clip is in the chat. His Clipper bot hands it to a Researcher and a Writer bot that pull quotes and draft the caption. No code - he just connected his Google account and asked Grok Bot to clip it.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 84,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@KanekoaTheGreat",
        "url": "https://x.com/KanekoaTheGreat/status/2091968024370897102"
      },
      "added_at": "2026-08-24T19:30:00Z",
      "updated_at": "2026-08-24T19:30:00Z"
    },
    {
      "type": "plugin",
      "slug": "cribble",
      "url": "https://grokbot.dev/plugins/cribble/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/cribble.json",
      "headline": "Cribble",
      "summary": "Ranks your Grok (and 47 other AI tools) usage on a worldwide leaderboard.",
      "categories": [
        "fun"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "cribble.dev",
        "url": "https://cribble.dev"
      },
      "added_at": "2026-08-24T06:20:00Z",
      "updated_at": "2026-08-24T06:20:00Z"
    },
    {
      "type": "plugin",
      "slug": "tubealfred",
      "url": "https://grokbot.dev/plugins/tubealfred/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/tubealfred.json",
      "headline": "TubeAlfred",
      "summary": "Give your Grok Bot read-only access to any public YouTube video, channel, or playlist.",
      "categories": [
        "data"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "tubealfred.com",
        "url": "https://tubealfred.com"
      },
      "added_at": "2026-08-24T00:00:00Z",
      "updated_at": "2026-08-24T00:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "sequenzy",
      "url": "https://grokbot.dev/plugins/sequenzy/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/sequenzy.json",
      "headline": "Sequenzy",
      "summary": "Run your email marketing - subscribers, campaigns, sequences - from your Grok Bot.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "sequenzy.com",
        "url": "https://www.sequenzy.com"
      },
      "added_at": "2026-08-23T22:15:00Z",
      "updated_at": "2026-08-23T22:15:00Z"
    },
    {
      "type": "use-case",
      "slug": "vision-md-so-agents-self-triage",
      "url": "https://grokbot.dev/use-cases/vision-md-so-agents-self-triage/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/vision-md-so-agents-self-triage.json",
      "headline": "Give every repo a VISION.md so your bot triages issues for you",
      "summary": "Kun Chen owns 24k+-star open-source repos and was drowning in issues and PRs. His fix wasn't more review - it was moving his influence up a level: an explicit VISION.md per repo saying where the project is going, so his Grok Bot triages every incoming issue as vision-aligned or not, and only the aligned ones get built.",
      "categories": [
        "engineering",
        "work"
      ],
      "awesome_score": 77,
      "format": "guide",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kunchenguid",
        "url": "https://x.com/kunchenguid/status/2091638832307536357"
      },
      "added_at": "2026-08-23T22:00:00Z",
      "updated_at": "2026-08-23T22:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "fretwork",
      "url": "https://grokbot.dev/plugins/fretwork/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/fretwork.json",
      "headline": "Fretwork",
      "summary": "Local-first freelance management - time, invoices, expenses, CRM - for your Grok Bot.",
      "categories": [
        "finance-ops"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "fretwork.ai",
        "url": "https://fretwork.ai"
      },
      "added_at": "2026-08-23T16:50:00Z",
      "updated_at": "2026-08-23T16:50:00Z"
    },
    {
      "type": "use-case",
      "slug": "run-a-business-with-grok-bot-agent-teams",
      "url": "https://grokbot.dev/use-cases/run-a-business-with-grok-bot-agent-teams/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/run-a-business-with-grok-bot-agent-teams.json",
      "headline": "Run a one-person business on a Grok Bot agent team",
      "summary": "Billy Howell runs a 6,000-subscriber local newsletter on a Grok Bot agent team. His method: one project per account, a Chief of Staff that audits the business and proposes the first three revenue agents, perfect each task by hand before spinning off a dedicated bot, then automate the routine work.",
      "categories": [
        "work",
        "marketing",
        "sales"
      ],
      "awesome_score": 85,
      "format": "guide",
      "featured": true,
      "source": {
        "platform": "youtube",
        "label": "Greg Isenberg",
        "url": "https://youtu.be/qQluNEfSVHk"
      },
      "added_at": "2026-08-23T13:45:00Z",
      "updated_at": "2026-08-23T13:45:00Z"
    },
    {
      "type": "use-case",
      "slug": "connect-deepseek-to-grok-bot",
      "url": "https://grokbot.dev/use-cases/connect-deepseek-to-grok-bot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/connect-deepseek-to-grok-bot.json",
      "headline": "Connect DeepSeek (or any LLM) to your Grok Bot and route work by cost",
      "summary": "Thomas Heimann's copy-paste directive registers DeepSeek V4 Flash as a callable tool on your Chief of Staff bot (OpenAI-compatible, key stored securely), then gives the bot a routing policy: send ops, API/browser, tool-use and bulk work to the cheap fast model, and reserve native Grok for deep reasoning.",
      "categories": [
        "engineering",
        "work"
      ],
      "awesome_score": 82,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@thomasheimann",
        "url": "https://x.com/thomasheimann/status/2090435932520329252"
      },
      "added_at": "2026-08-23T12:15:00Z",
      "updated_at": "2026-08-23T12:15:00Z"
    },
    {
      "type": "use-case",
      "slug": "give-your-grok-bot-its-own-email-inbox",
      "url": "https://grokbot.dev/use-cases/give-your-grok-bot-its-own-email-inbox/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/give-your-grok-bot-its-own-email-inbox.json",
      "headline": "One prompt that gives your Grok Bot its own email inbox and identity",
      "summary": "Adi Singh's AgentMail guide, turned into a single prompt you paste into your Grok Bot. The bot explains why it shouldn't use your personal Gmail, walks you step by step through installing the AgentMail plugin and tells you exactly what to do on your end, then creates its own inbox and proves it works by emailing you.",
      "categories": [
        "work",
        "support",
        "sales"
      ],
      "awesome_score": 88,
      "format": "guide",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@adisingh",
        "url": "https://x.com/adisingh/status/2091295851943780737"
      },
      "added_at": "2026-08-23T12:05:00Z",
      "updated_at": "2026-08-23T12:05:00Z"
    },
    {
      "type": "plugin",
      "slug": "agentmail",
      "url": "https://grokbot.dev/plugins/agentmail/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/agentmail.json",
      "headline": "AgentMail",
      "summary": "Give your Grok Bot its own email inbox and identity on the internet.",
      "categories": [
        "work"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "agentmail.to",
        "url": "https://www.agentmail.to"
      },
      "added_at": "2026-08-23T12:00:00Z",
      "updated_at": "2026-08-23T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "food-shopping-agent-team",
      "url": "https://grokbot.dev/use-cases/food-shopping-agent-team/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/food-shopping-agent-team.json",
      "headline": "Build a 3-agent team that plans, carts, and cooks your meals",
      "summary": "Michael Fenech's exact prompt designs a three-agent team on your Chief of Staff bot: a Meal Organiser plans easy meals for your diet, a Shopper fills your online grocery cart (you do the final payment), and a Cooking agent gives step-by-step instructions. It maps the pipeline for your review first.",
      "categories": [
        "personal"
      ],
      "awesome_score": 78,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Michael_Fenech_",
        "url": "https://x.com/Michael_Fenech_/status/2091452896738935246"
      },
      "added_at": "2026-08-23T09:15:00Z",
      "updated_at": "2026-08-23T09:15:00Z"
    },
    {
      "type": "use-case",
      "slug": "make-your-grok-bot-elon-musk",
      "url": "https://grokbot.dev/use-cases/make-your-grok-bot-elon-musk/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/make-your-grok-bot-elon-musk.json",
      "headline": "Make your Grok Bot think, build, and roast like Elon Musk",
      "summary": "mr fundman's most fun Grok Bot: paste this persona into your Bot's Instructions and it becomes Elon Musk - first-principles, dry-humored, applying 'The Algorithm' (question, delete, simplify, accelerate, automate). It stays in character, fires 10x ideas, and plays the visionary advisor for your agent team.",
      "categories": [
        "fun"
      ],
      "awesome_score": 79,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@mrfundman",
        "url": "https://x.com/mrfundman/status/2088723708521099278"
      },
      "added_at": "2026-08-23T08:55:00Z",
      "updated_at": "2026-08-23T08:55:00Z"
    },
    {
      "type": "use-case",
      "slug": "overwatch-keep-your-bot-vm-clean-and-backed-up",
      "url": "https://grokbot.dev/use-cases/overwatch-keep-your-bot-vm-clean-and-backed-up/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/overwatch-keep-your-bot-vm-clean-and-backed-up.json",
      "headline": "Overwatch: keep your Grok Bot's shared VM clean and backed up",
      "summary": "scheemunai's Overwatch prompt turns one Grok Bot into the housekeeper for a shared multi-bot VM: it organizes /workspace, backs the whole tree up to a private git repo on a weekday cadence (never secrets), enforces temp/archive/delete retention, keeps a live bot registry, and files a weekly org review.",
      "categories": [
        "engineering"
      ],
      "awesome_score": 79,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@scheemunai",
        "url": "https://x.com/scheemunai/status/2091446628611699121"
      },
      "added_at": "2026-08-23T08:10:00Z",
      "updated_at": "2026-08-23T08:46:00Z"
    },
    {
      "type": "plugin",
      "slug": "2chat",
      "url": "https://grokbot.dev/plugins/2chat/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/2chat.json",
      "headline": "2Chat",
      "summary": "Give your Grok Bot a WhatsApp + SMS phone system for messaging and contacts.",
      "categories": [
        "support"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "2chat.co",
        "url": "https://2chat.co"
      },
      "added_at": "2026-08-22T20:30:00Z",
      "updated_at": "2026-08-22T20:30:00Z"
    },
    {
      "type": "use-case",
      "slug": "agent-run-directory-business",
      "url": "https://grokbot.dev/use-cases/agent-run-directory-business/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/agent-run-directory-business.json",
      "headline": "Run a directory business with a team of Grok Bots",
      "summary": "The Startup Ideas Podcast's playbook for a directory business run by Grok Bots: pick a niche you have taste in, build the site on Astro, set a research agent to write a brand page a day in Markdown, a publisher agent to post it, and once traffic is real, a third agent to gather referral links and chase deals.",
      "categories": [
        "marketing",
        "sales"
      ],
      "awesome_score": 76,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@startupideaspod",
        "url": "https://x.com/startupideaspod/status/2091238981337858473"
      },
      "added_at": "2026-08-22T19:40:00Z",
      "updated_at": "2026-08-22T19:40:00Z"
    },
    {
      "type": "use-case",
      "slug": "grade-bookmarks-into-skills",
      "url": "https://grokbot.dev/use-cases/grade-bookmarks-into-skills/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/grade-bookmarks-into-skills.json",
      "headline": "Grade a month of bookmarks into spoken skills",
      "summary": "Ryan Staley pasted one prompt to make a Grok Bot grade 140 bookmarks from the last 30 days — a one-line thesis, the link, a high/medium/noise grade, and the mechanism to steal — discarding anything he couldn't name in a sentence. He kept a third and turned the keepers into 10 skills with a spoken trigger.",
      "categories": [
        "personal"
      ],
      "awesome_score": 76,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@Ryan_Staley1",
        "url": "https://x.com/Ryan_Staley1/status/2091135093112774904"
      },
      "added_at": "2026-08-22T18:00:00Z",
      "updated_at": "2026-08-22T18:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "odyssey-visuals-grok-imagine",
      "url": "https://grokbot.dev/use-cases/odyssey-visuals-grok-imagine/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/odyssey-visuals-grok-imagine.json",
      "headline": "The Odyssey, storyboarded and shot by one bot",
      "summary": "X Freeze asked a Grok Bot for Odyssey movie visuals and it ran the whole creative pipeline: it researched the story, planned the scenes, characters, costumes, locations and camera angles, wrote every prompt, generated the shots with Grok Imagine, and organized them into a folder.",
      "categories": [
        "fun"
      ],
      "awesome_score": 73,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@XFreeze",
        "url": "https://x.com/XFreeze/status/2091193462133498299"
      },
      "added_at": "2026-08-22T18:00:00Z",
      "updated_at": "2026-08-22T18:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "marketbetter",
      "url": "https://grokbot.dev/plugins/marketbetter/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/marketbetter.json",
      "headline": "MarketBetter",
      "summary": "Turn website visits and buyer intent into a daily sales playbook your agent runs.",
      "categories": [
        "sales"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "marketbetter.ai",
        "url": "https://marketbetter.ai"
      },
      "added_at": "2026-08-22T17:00:00Z",
      "updated_at": "2026-08-22T17:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "bot-with-its-own-email",
      "url": "https://grokbot.dev/use-cases/bot-with-its-own-email/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/bot-with-its-own-email.json",
      "headline": "Give the bot its own email, act from a CC",
      "summary": "Michael Fenech gave his Grok Bot its own email address (via AgentMail), with a webhook that wakes it on each message. He CCs the bot and puts the instruction on the last line — 'Book Tuesday at 3pm and get back to them' — and it reads the thread, books the calendar, and replies to everyone from its own address.",
      "categories": [
        "work"
      ],
      "awesome_score": 76,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@Michael_Fenech_",
        "url": "https://x.com/Michael_Fenech_/status/2091135546089451983"
      },
      "added_at": "2026-08-22T16:00:00Z",
      "updated_at": "2026-08-22T16:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "close-inbound-sponsorships",
      "url": "https://grokbot.dev/use-cases/close-inbound-sponsorships/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/close-inbound-sponsorships.json",
      "headline": "It closed a $10k sponsorship from my inbox in 4 hours",
      "summary": "Alex Finn gave a Grok Bot access to his business inbox and told it to answer and negotiate with legit companies. Within four hours it researched market rates and closed its first sponsorship deal on its own — turning the inbox he hates reading into revenue.",
      "categories": [
        "sales"
      ],
      "awesome_score": 73,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@AlexFinn",
        "url": "https://x.com/AlexFinn/status/2090939211159650633"
      },
      "added_at": "2026-08-22T16:00:00Z",
      "updated_at": "2026-08-22T16:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "extract-art-prompts",
      "url": "https://grokbot.dev/use-cases/extract-art-prompts/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/extract-art-prompts.json",
      "headline": "13,425 art prompts, extracted and sorted",
      "summary": "Julie McCann had a Grok Bot go through 557 chats across all her projects, extract every art prompt, and sort them by subject into one searchable library — 13,425 in total. When it hit context limits it switched to smaller blocks on its own and finished the ~30-hour job.",
      "categories": [
        "data"
      ],
      "awesome_score": 64,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@JulieZMcCann",
        "url": "https://x.com/JulieZMcCann/status/2091142158283632826"
      },
      "added_at": "2026-08-22T16:00:00Z",
      "updated_at": "2026-08-22T16:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "find-local-website-leads",
      "url": "https://grokbot.dev/use-cases/find-local-website-leads/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/find-local-website-leads.json",
      "headline": "Fifty local businesses that need a new website",
      "summary": "Ben Nash had spent months getting small, mediocre results asking ChatGPT and Gemini to find local businesses that could use a new website. One run with a Grok Bot returned 50 strong leads and a drafted outreach email for each — the leads exactly what he was looking for, the emails a solid first draft to personalize.",
      "categories": [
        "sales"
      ],
      "awesome_score": 58,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@bennash",
        "url": "https://x.com/bennash/status/2091136666542997852"
      },
      "added_at": "2026-08-22T16:00:00Z",
      "updated_at": "2026-08-22T16:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "instagram-bug-to-pr",
      "url": "https://grokbot.dev/use-cases/instagram-bug-to-pr/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/instagram-bug-to-pr.json",
      "headline": "An Instagram bug report that routes itself to QA",
      "summary": "Dan Peguine's Grok Bot watches his Instagram inbox. A website-bug complaint got routed to a QA bot in the Ship channel (with his engineer bot 'David'); QA tested the funnel, found nothing, and had a Writer bot reply — and a real bug would have become David's fix and a PR.",
      "categories": [
        "support"
      ],
      "awesome_score": 73,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@danpeguine",
        "url": "https://x.com/danpeguine/status/2091109796686471339"
      },
      "added_at": "2026-08-22T16:00:00Z",
      "updated_at": "2026-08-22T16:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "marketplace-flipper",
      "url": "https://grokbot.dev/use-cases/marketplace-flipper/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/marketplace-flipper.json",
      "headline": "A bot that flips marketplace deals while you sleep",
      "summary": "alucardiox ran a Grok Bot on its own cloud machine, logged into a second marketplace account, that flags listings priced 35% under the 30-day median, reads the photos not the title, checks the feed every four minutes, sends one all-cash line, and books the pickup. Nine days: $680 spent, $1,610 back.",
      "categories": [
        "personal"
      ],
      "awesome_score": 87,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@alucardiox",
        "url": "https://x.com/alucardiox/status/2091114193470840969"
      },
      "added_at": "2026-08-22T16:00:00Z",
      "updated_at": "2026-08-22T16:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "photos-to-3d-printed-materials",
      "url": "https://grokbot.dev/use-cases/photos-to-3d-printed-materials/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/photos-to-3d-printed-materials.json",
      "headline": "Four photos to a 3D-printed materials experiment",
      "summary": "MIT's Markus Buehler ran a three-bot team that turned four reference photos into transferable design principles, an interactive physics simulator, 47 experiments, a scientific report, and two parts sliced and printed on a Bambu H2D — the whole loop overnight.",
      "categories": [
        "engineering"
      ],
      "awesome_score": 88,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@ProfBuehlerMIT",
        "url": "https://x.com/ProfBuehlerMIT/status/2091108225806454802"
      },
      "added_at": "2026-08-22T16:00:00Z",
      "updated_at": "2026-08-22T16:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "teach-a-chore-by-recording",
      "url": "https://grokbot.dev/use-cases/teach-a-chore-by-recording/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/teach-a-chore-by-recording.json",
      "headline": "Teach your bot a chore from a screen recording",
      "summary": "Dillon Loomis recorded his screen with narration while sorting a week of desktop files, and his Chief of Staff learned not just what he did but how and why — it compressed the oversized video itself to watch it, answered a question he'd planted mid-recording, and coached him on part two.",
      "categories": [
        "work"
      ],
      "awesome_score": 67,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DillonLoomis",
        "url": "https://x.com/DillonLoomis/status/2091133785106686153"
      },
      "added_at": "2026-08-22T16:00:00Z",
      "updated_at": "2026-08-22T16:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "dangerously-good-at-grok-bot",
      "url": "https://grokbot.dev/use-cases/dangerously-good-at-grok-bot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/dangerously-good-at-grok-bot.json",
      "headline": "From beginner to dangerously good at Grok Bot",
      "summary": "Robin Delta's beginner-to-pro Grok Bot guide: the install decisions that make a bot a worker not another chat window, a five-part task brief, the brief→observe→correct→schedule→deliver loop, and 21 bot builds worth stealing.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": "guide",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@heyrobinai",
        "url": "https://x.com/heyrobinai/status/2090732576637952348"
      },
      "added_at": "2026-08-22T15:00:00Z",
      "updated_at": "2026-08-22T15:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "one-prompt-agent-team",
      "url": "https://grokbot.dev/use-cases/one-prompt-agent-team/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/one-prompt-agent-team.json",
      "headline": "One bot, one prompt — it hired its own team",
      "summary": "Paste one prompt into a single Grok Bot, Atlas the chief of staff. It interviews you, writes its own operating manual, then specs and launches four teammates — each on its own cloud computer, with a review gate before anything sends.",
      "categories": [
        "work"
      ],
      "awesome_score": 88,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@nykdotdev",
        "url": "https://x.com/nykdotdev/status/2091068926235144607"
      },
      "added_at": "2026-08-22T14:00:00Z",
      "updated_at": "2026-08-22T14:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "gojiberry",
      "url": "https://grokbot.dev/plugins/gojiberry/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/gojiberry.json",
      "headline": "Gojiberry AI",
      "summary": "Find warm B2B leads, manage outreach campaigns, and work your inbox from the agent",
      "categories": [
        "sales"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "gojiberry.ai",
        "url": "https://gojiberry.ai"
      },
      "added_at": "2026-08-22T00:00:00Z",
      "updated_at": "2026-09-02T18:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "mediafast",
      "url": "https://grokbot.dev/plugins/mediafast/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/mediafast.json",
      "headline": "MediaFast",
      "summary": "Let your agent run your Reddit marketing without getting banned.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "mediafa.st",
        "url": "https://www.mediafa.st"
      },
      "added_at": "2026-08-22T00:00:00Z",
      "updated_at": "2026-08-22T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "mentions-so",
      "url": "https://grokbot.dev/plugins/mentions-so/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/mentions-so.json",
      "headline": "Mentions.so",
      "summary": "Track how your brand shows up in ChatGPT, Perplexity, Grok and other AI answers.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": {
        "platform": "web",
        "label": "mentions.so",
        "url": "https://mentions.so"
      },
      "added_at": "2026-08-22T00:00:00Z",
      "updated_at": "2026-08-22T13:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "tiiny-host",
      "url": "https://grokbot.dev/plugins/tiiny-host/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/tiiny-host.json",
      "headline": "Tiiny Host",
      "summary": "Let your agent deploy a static site or file to a live URL in seconds.",
      "categories": [
        "engineering"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "tiiny.host",
        "url": "https://tiiny.host"
      },
      "added_at": "2026-08-22T00:00:00Z",
      "updated_at": "2026-08-22T13:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "zernio",
      "url": "https://grokbot.dev/plugins/zernio/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/zernio.json",
      "headline": "Zernio",
      "summary": "A developer-first API and MCP for scheduling and analyzing social posts everywhere.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "zernio.com",
        "url": "https://zernio.com"
      },
      "added_at": "2026-08-22T00:00:00Z",
      "updated_at": "2026-08-22T13:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "ai-research-desk",
      "url": "https://grokbot.dev/use-cases/ai-research-desk/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/ai-research-desk.json",
      "headline": "A research desk that studies markets while you sleep",
      "summary": "Roan's article on turning Grok Bot into a self-improving AI hedge-fund research desk: an army of agents that study the markets around the clock, grade their own past calls to improve, and hand you a decision-ready brief — a desk that runs while you sleep. It researches and proposes, never trades.",
      "categories": [
        "trading-crypto",
        "data"
      ],
      "awesome_score": 72,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RohOnChain",
        "url": "https://x.com/RohOnChain/status/2090443377556996209"
      },
      "added_at": "2026-08-21T21:30:00Z",
      "updated_at": "2026-08-21T21:30:00Z"
    },
    {
      "type": "use-case",
      "slug": "grok-bot-masterclass",
      "url": "https://grokbot.dev/use-cases/grok-bot-masterclass/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/grok-bot-masterclass.json",
      "headline": "The masterclass that makes Grok Bot click",
      "summary": "Avi Chawla's Grok Bot Masterclass — a popular, end-to-end guide to understanding, setting up, and getting real work out of Grok Bot. It covers what a Bot actually is, how the shared computer works underneath, how Grok Bot compares to Hermes Agent, and how to put it to work.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": "guide",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@_avichawla",
        "url": "https://x.com/_avichawla/status/2089657097244024858"
      },
      "added_at": "2026-08-21T21:00:00Z",
      "updated_at": "2026-08-21T21:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "solo-newsletter-business",
      "url": "https://grokbot.dev/use-cases/solo-newsletter-business/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/solo-newsletter-business.json",
      "headline": "Run a whole newsletter business while you sleep",
      "summary": "Greg Isenberg's thread on his friend Billy: a non-technical solo founder runs an entire newsletter business on a team of Grok Bot agents — research, drafting, editing, scheduling and growth handled by the agents, so one person operates what used to need a small team.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 79,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@gregisenberg",
        "url": "https://x.com/gregisenberg/status/2090901863814017300"
      },
      "added_at": "2026-08-21T20:00:00Z",
      "updated_at": "2026-08-21T20:40:26Z"
    },
    {
      "type": "use-case",
      "slug": "role-based-agent-team",
      "url": "https://grokbot.dev/use-cases/role-based-agent-team/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/role-based-agent-team.json",
      "headline": "Run daily GTM and dev on collaborating agents",
      "summary": "Chris Maconi on how Hechura runs on Grok Bot: a team of role-based agents — a Head of Sales and a Head of Product Marketing running the daily GTM motion, plus agents collaborating on daily development work — so the company's day-to-day is operated by agents that specialize and coordinate.",
      "categories": [
        "sales",
        "marketing",
        "engineering"
      ],
      "awesome_score": 71,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@chrismaconi",
        "url": "https://x.com/chrismaconi/status/2090805113249996956"
      },
      "added_at": "2026-08-21T14:00:00Z",
      "updated_at": "2026-08-21T14:15:58Z"
    },
    {
      "type": "use-case",
      "slug": "team-in-10-minutes",
      "url": "https://grokbot.dev/use-cases/team-in-10-minutes/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/team-in-10-minutes.json",
      "headline": "A company with no employees, in ten minutes",
      "summary": "darkzodchi's guide to standing up a whole Grok Bot team in under 10 minutes: create one bot called Chief of Staff as your single entry point — its description field is the entire config, no code. It coordinates the rest, so you talk to one bot and a team does the work.",
      "categories": [
        "engineering"
      ],
      "awesome_score": 68,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@zodchiii",
        "url": "https://x.com/zodchiii/status/2090778823050592662"
      },
      "added_at": "2026-08-21T12:31:00Z",
      "updated_at": "2026-08-21T12:31:30Z"
    },
    {
      "type": "use-case",
      "slug": "marketing-os",
      "url": "https://grokbot.dev/use-cases/marketing-os/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/marketing-os.json",
      "headline": "Your whole marketing team, open-sourced",
      "summary": "Vlad Dubchak's team (Maxfusion) open-sourced their marketing department as one skill — Marketing OS. Fourteen modules cover audits scored 0-100, an 18-tactic hook engine, graded copy, ad diagnosis, GEO, email, social, launches and positioning. Hand Grok Bot the repo link and it's ready in minutes.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 93,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@vladdubchak_x",
        "url": "https://x.com/vladdubchak_x/status/2090770900241297844"
      },
      "added_at": "2026-08-21T12:00:00Z",
      "updated_at": "2026-08-21T12:00:01Z"
    },
    {
      "type": "use-case",
      "slug": "mine-my-machine-into-a-team",
      "url": "https://grokbot.dev/use-cases/mine-my-machine-into-a-team/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/mine-my-machine-into-a-team.json",
      "headline": "Turn your messy machine into a real agent team",
      "summary": "Avid's chief-of-staff prompt: it mines everything you've done on your machine — configs, recurring tasks, repeated prompts, the corrections you keep giving — and turns it into a real agent team with role files, skills, a verified run and a handbook, all written to files.",
      "categories": [
        "engineering"
      ],
      "awesome_score": 91,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@Av1dlive",
        "url": "https://x.com/Av1dlive/status/2090736683503468914"
      },
      "added_at": "2026-08-21T09:44:00Z",
      "updated_at": "2026-08-21T09:44:04Z"
    },
    {
      "type": "use-case",
      "slug": "account-expert",
      "url": "https://grokbot.dev/use-cases/account-expert/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/account-expert.json",
      "headline": "Ask where the deal stalled, get dates and links",
      "summary": "Krista Letz’s SpaceXAI GTM write-up describes a Customer Expert: one agent per strategic account that watches Slack, Gmail, Gong, and Granola, answers from running context, and flags feature requests plus support tickets. Same article as her weekly GTM operator.",
      "categories": [
        "sales"
      ],
      "awesome_score": 68,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kristaletz",
        "url": "https://x.com/kristaletz"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "adkit",
      "url": "https://grokbot.dev/plugins/adkit/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/adkit.json",
      "headline": "AdKit",
      "summary": "Let your agent draft and run Meta, Google and TikTok ads.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "adkit.so",
        "url": "https://adkit.so"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "aeo-content-autopilot",
      "url": "https://grokbot.dev/use-cases/aeo-content-autopilot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/aeo-content-autopilot.json",
      "headline": "Your old sales calls become the next ranking post",
      "summary": "Eric Osiu, Grok Botting on Starlink, described an AEO/SEO bot: ingest top content (sales calls, customer calls, podcasts, YouTube), combine ClickFlow / GA4 / Ahrefs / GSC, and draft into the CMS on autopilot. Listed as an agent to build, with a real stack, not a one-word role.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 63,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ericosiu",
        "url": "https://x.com/ericosiu/status/2089523616824357179"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "always-on-x-presence",
      "url": "https://grokbot.dev/use-cases/always-on-x-presence/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/always-on-x-presence.json",
      "headline": "48 hours alone with a Mac and my X account",
      "summary": "Daniel gave a bot a full macOS machine plus Gmail and an X account. It ran for two days posting and joining group chats. 353 likes / 86K views.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 62,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@Daniel_Farinax",
        "url": "https://x.com/Daniel_Farinax/status/2088462885295186237"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "amazon-tasks-via-telegram",
      "url": "https://grokbot.dev/use-cases/amazon-tasks-via-telegram/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/amazon-tasks-via-telegram.json",
      "headline": "Text an errand from the couch, approve the cart",
      "summary": "Same tweet: Amazon tasks with a Telegram hookup so he can tap the bot from his phone.",
      "categories": [
        "personal"
      ],
      "awesome_score": 52,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MatthewBerman",
        "url": "https://x.com/MatthewBerman"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "arduino-live-ticker",
      "url": "https://grokbot.dev/use-cases/arduino-live-ticker/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/arduino-live-ticker.json",
      "headline": "An LED strip on my desk scrolls the SPCX price",
      "summary": "Dan connected Grok Bot to his Arduino and turned the LED display into a live scrolling SPCX stock ticker with a line graph plus SpaceX headlines. Video in the post. 350 likes / 149.8K views.",
      "categories": [
        "fun"
      ],
      "awesome_score": 67,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@KettlebellDan",
        "url": "https://x.com/KettlebellDan/status/2089387837204693202"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "article-newsletter-writer",
      "url": "https://grokbot.dev/use-cases/article-newsletter-writer/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/article-newsletter-writer.json",
      "headline": "A draft in my voice that flags its own weak claims",
      "summary": "Farzad’s Grok Bot team list is mostly names; the job to copy is Writey — article/newsletter writer. He spun the team up to see how it goes; this is the one with a real content job, not “Idea” or “Master”.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 55,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@farzyness",
        "url": "https://x.com/farzyness/status/2087340859138224540"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "attention-inbox-email-slack",
      "url": "https://grokbot.dev/use-cases/attention-inbox-email-slack/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/attention-inbox-email-slack.json",
      "headline": "Five inboxes, six Slacks, silence unless it needs me",
      "summary": "Same Yu-kai setup: the bot informs him of any message from five email addresses and six Slack servers that requires his attention, and keeps him organized. Ping only what needs him.",
      "categories": [
        "work"
      ],
      "awesome_score": 59,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@yukaichou",
        "url": "https://x.com/yukaichou"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "autonomous-trading-agent",
      "url": "https://grokbot.dev/use-cases/autonomous-trading-agent/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/autonomous-trading-agent.json",
      "headline": "Paper trades only, until you arm it yourself",
      "summary": "RitOnchain posted a Stanford researcher’s write-up: an autonomous trading agent built entirely with Grok Bots. Screenshot of the agent stack. Bookmark-it-before-it’s-lost energy — research/paper first, not a hot-tip bot.",
      "categories": [
        "trading-crypto"
      ],
      "awesome_score": 70,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@RitOnchain",
        "url": "https://x.com/RitOnchain/status/2090455054876864748"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "award-tickets-japan",
      "url": "https://grokbot.dev/use-cases/award-tickets-japan/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/award-tickets-japan.json",
      "headline": "Three first-class seats to Japan for 60K points",
      "summary": "Same non-coder run: he asked Grok Bot to find first-class award tickets to Japan. With permission it logged into his airline accounts and found three first-class Japan tickets for 60K points. He stopped it because the dates were not firm — it would have booked.",
      "categories": [
        "personal"
      ],
      "awesome_score": 59,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@congressdj",
        "url": "https://x.com/congressdj"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "back-to-school-mental-load",
      "url": "https://grokbot.dev/use-cases/back-to-school-mental-load/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/back-to-school-mental-load.json",
      "headline": "The school inbox, split into a checklist per kid",
      "summary": "Stella used Grok Bot on her back-to-school emails and to-dos for multiple kids, plus other household jobs it handled independently that week. 787 likes / 1.9M views.",
      "categories": [
        "personal"
      ],
      "awesome_score": 64,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@startupstella",
        "url": "https://x.com/startupstella/status/2090450591688360033"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "bannerbear",
      "url": "https://grokbot.dev/plugins/bannerbear/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/bannerbear.json",
      "headline": "Bannerbear",
      "summary": "Give your agent an API to auto-generate branded images and videos.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "bannerbear.com",
        "url": "https://www.bannerbear.com"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "bot-team-manager",
      "url": "https://grokbot.dev/use-cases/bot-team-manager/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/bot-team-manager.json",
      "headline": "The one bot whose only job is chasing the others",
      "summary": "Peter Yang's setup tutorial starts with a bot-manager / advisor that coordinates the rest of the crew (YouTube researcher, X scout, and others). 1.5K likes / 8.9M views.",
      "categories": [
        "work"
      ],
      "awesome_score": 67,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@petergyang",
        "url": "https://x.com/petergyang/status/2089401696946634801"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "breakcold",
      "url": "https://grokbot.dev/plugins/breakcold/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/breakcold.json",
      "headline": "Breakcold",
      "summary": "Let your agent run your CRM across email, LinkedIn and WhatsApp.",
      "categories": [
        "sales"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "breakcold.com",
        "url": "https://www.breakcold.com"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "ca-unclaimed-funds",
      "url": "https://grokbot.dev/use-cases/ca-unclaimed-funds/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/ca-unclaimed-funds.json",
      "headline": "$300 of your own money, sitting with the state",
      "summary": "Royce’s 24-hour Grok Bot receipts start with $300 in unclaimed funds from the state of California. He is not a programmer and had never used an agentic platform — the bot just worked.",
      "categories": [
        "personal"
      ],
      "awesome_score": 60,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@royce_james",
        "url": "https://x.com/royce_james/status/2090617019708408140"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "calendar-conflict-fixer",
      "url": "https://grokbot.dev/use-cases/calendar-conflict-fixer/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/calendar-conflict-fixer.json",
      "headline": "Double-bookings arrive with a fix already drafted",
      "summary": "Same Matthew Berman tweet: the bot handled calendar conflict scheduling. A reconstructed Grok Bot use case drawn from a high-engagement X post.",
      "categories": [
        "work"
      ],
      "awesome_score": 46,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MatthewBerman",
        "url": "https://x.com/MatthewBerman"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "call-follow-up-drafter",
      "url": "https://grokbot.dev/use-cases/call-follow-up-drafter/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/call-follow-up-drafter.json",
      "headline": "Follow-ups built from the notes, not the pleasantries",
      "summary": "In the same GTM article, Krista automates follow-up drafts from Granola or Gong notes after external calls. Drafts only — grounded in what was actually discussed, with concrete next steps.",
      "categories": [
        "sales"
      ],
      "awesome_score": 58,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kristaletz",
        "url": "https://x.com/kristaletz"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "churn-exit-feedback",
      "url": "https://grokbot.dev/use-cases/churn-exit-feedback/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/churn-exit-feedback.json",
      "headline": "Five reasons they left, five things to ship this week",
      "summary": "After the win-back emails, Liam's bot analysed overnight why people left and turned that into a 5-step plan. Same tweet as the win-back campaign — this is the research half of the job.",
      "categories": [
        "data"
      ],
      "awesome_score": 56,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "churn-winback",
      "url": "https://grokbot.dev/use-cases/churn-winback/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/churn-winback.json",
      "headline": "The win-back bot that paid for its own subscription",
      "summary": "Liam gave Grok Bot one job: win back churned customers. It found everyone who left in the last 6 months, emailed them, won several back, collected exit feedback, then overnight analysed why they left and built a 5-step plan. The bot covered its own subscription cost. 3.",
      "categories": [
        "sales"
      ],
      "awesome_score": 71,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@liam_fallen",
        "url": "https://x.com/liam_fallen/status/2090355235751379002"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "company-brain-cos",
      "url": "https://grokbot.dev/use-cases/company-brain-cos/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/company-brain-cos.json",
      "headline": "One chat that knows the business better than I do",
      "summary": "A non-developer connected Slack, email, meeting notes, Notion, and Stripe so one Grok Bot chat knows the business better than he does. 1.8K likes / 705K views.",
      "categories": [
        "work"
      ],
      "awesome_score": 66,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DavidCarbutt_",
        "url": "https://x.com/DavidCarbutt_/status/2090603356649562522"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "content-pipeline",
      "url": "https://grokbot.dev/use-cases/content-pipeline/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/content-pipeline.json",
      "headline": "One post, four surfaces, canonical never dropped",
      "summary": "After the first-look video, Debbie set up a content pipeline: write with her add-content skill, publish on debbie.codes, syndicate to Dev.to with a canonical URL, then draft LinkedIn and X. She called it the start of the workflow, not a toy list.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 65,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@debs_obrien",
        "url": "https://x.com/debs_obrien"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "cut-monthly-subs",
      "url": "https://grokbot.dev/use-cases/cut-monthly-subs/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/cut-monthly-subs.json",
      "headline": "$50 a month gone, with cancel screenshots to prove it",
      "summary": "Royce’s bot helped cut $50 in monthly subscriptions in the first 24 hours — one of the line items that made Grok Bot earn its keep for a non-programmer.",
      "categories": [
        "finance-ops"
      ],
      "awesome_score": 53,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@royce_james",
        "url": "https://x.com/royce_james"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "deal-desk",
      "url": "https://grokbot.dev/use-cases/deal-desk/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/deal-desk.json",
      "headline": "Stalled deals get a next move drafted every day",
      "summary": "Same Eric Osiu post: a deal-desk bot whose job is to move the ball on stalled, lost, and lookalike deals — every day, not a weekly pipeline poem.",
      "categories": [
        "sales"
      ],
      "awesome_score": 61,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ericosiu",
        "url": "https://x.com/ericosiu"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "debs-chief-of-staff",
      "url": "https://grokbot.dev/use-cases/debs-chief-of-staff/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/debs-chief-of-staff.json",
      "headline": "The bot that audits the bots you already built",
      "summary": "Debbie O’Brien’s CoS tweet is the prompt: look at me, look at the bots I already created, tell me what to change, how to manage the team, and what else would make me productive. The screenshot is the answer she got back.",
      "categories": [
        "work"
      ],
      "awesome_score": 70,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@debs_obrien",
        "url": "https://x.com/debs_obrien/status/2087832375526920381"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "distribb",
      "url": "https://grokbot.dev/plugins/distribb/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/distribb.json",
      "headline": "Distribb",
      "summary": "Let your agent do SEO — keywords, articles and backlinks.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "distribb.io",
        "url": "https://distribb.io"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "dmv-errand",
      "url": "https://grokbot.dev/use-cases/dmv-errand/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/dmv-errand.json",
      "headline": "Your vehicle renewal, filled out on the real DMV site",
      "summary": "Same tweet: he had it handle DMV registration — the boring civic errand agents are actually good at.",
      "categories": [
        "personal"
      ],
      "awesome_score": 53,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MatthewBerman",
        "url": "https://x.com/MatthewBerman"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "email-triage-partner",
      "url": "https://grokbot.dev/use-cases/email-triage-partner/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/email-triage-partner.json",
      "headline": "An inbox that triages itself every morning",
      "summary": "A dedicated bot that runs a daily three-stage inbox triage: it archives what you never need to see, summarizes low-attention mail, and does full-context triage on the rest — reading prior history, cross-checking HubSpot and Drive, and drafting replies in your voice.",
      "categories": [
        "work",
        "support"
      ],
      "awesome_score": 80,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "youtube",
        "label": "Matthew Berman",
        "url": "https://youtu.be/5CSXUsljJ_E"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "enterprise-gtm-workflows",
      "url": "https://grokbot.dev/use-cases/enterprise-gtm-workflows/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/enterprise-gtm-workflows.json",
      "headline": "The weekly GTM loop a real operator actually runs",
      "summary": "Krista Letz (GTM) published the actual enterprise go-to-market workflows she runs on Grok Bot — not a toy demo. 3.3K likes / 1.5M views.",
      "categories": [
        "sales"
      ],
      "awesome_score": 63,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kristaletz",
        "url": "https://x.com/kristaletz/status/2089103618121314689"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "firstmate-front-door",
      "url": "https://grokbot.dev/use-cases/firstmate-front-door/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/firstmate-front-door.json",
      "headline": "Dump a messy ask, get plain-language results back",
      "summary": "Kun Chen’s Firstmate setup is a single Grok Bot you talk to for everything. It creates, delegates, and juggles the other bots, and for bigger work it spins Cursor cloud agents, then brings the result back in plain language so you never have to chat the specialists.",
      "categories": [
        "work"
      ],
      "awesome_score": 65,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@kunchenguid",
        "url": "https://x.com/kunchenguid/status/2089792928092963234"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "freight-dispatch-tms",
      "url": "https://grokbot.dev/use-cases/freight-dispatch-tms/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/freight-dispatch-tms.json",
      "headline": "A dispatch desk texting 100+ drivers in a few hours",
      "summary": "A supply-chain CEO with limited product knowledge stood up a dispatch bot in a few hours: it tracked hundreds of loads, texted 100+ drivers, booked loads, requested proofs of delivery, and uploaded them to the TMS. He is on the $300/month plan.",
      "categories": [
        "work"
      ],
      "awesome_score": 74,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@John__Ferguson",
        "url": "https://x.com/John__Ferguson/status/2090185259791053100"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "game-art-png-pipeline",
      "url": "https://grokbot.dev/use-cases/game-art-png-pipeline/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/game-art-png-pipeline.json",
      "headline": "Game assets that match the last approved style",
      "summary": "A game developer had Grok Bot drive his custom art-gen webpage to generate game art assets and prep them as transparent PNGs in a consistent style. 992 likes / 375.8K views.",
      "categories": [
        "fun"
      ],
      "awesome_score": 61,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@DannyLimanseta",
        "url": "https://x.com/DannyLimanseta/status/2087228218797617404"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "gmail-mass-purge",
      "url": "https://grokbot.dev/use-cases/gmail-mass-purge/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/gmail-mass-purge.json",
      "headline": "90,000 emails triaged, banks and legal untouched",
      "summary": "Mike P let Grok Bot go through 90,000 emails across two Gmail accounts and delete the junk. Follow-up screenshots in the thread. 1.2K likes / 7.9M views; Elon amplified it.",
      "categories": [
        "work"
      ],
      "awesome_score": 64,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@mikepat711",
        "url": "https://x.com/mikepat711/status/2089879632929554498"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "grill-me-interview",
      "url": "https://grokbot.dev/use-cases/grill-me-interview/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/grill-me-interview.json",
      "headline": "Get interrogated until your plan is actually specific",
      "summary": "Nate Herk’s week-of-lessons article starts with a job he actually runs: a Grill Me skill that relentlessly interviews him about the business, goals, and plans until the bots share context. He uses it before quarterly planning or a new project — not a four-bot staffing listicle.",
      "categories": [
        "work"
      ],
      "awesome_score": 65,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nateherk",
        "url": "https://x.com/nateherk/status/2089917020087210160"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "grinder-subscription-killer",
      "url": "https://grokbot.dev/use-cases/grinder-subscription-killer/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/grinder-subscription-killer.json",
      "headline": "It argued with Restream support and got an offer",
      "summary": "The second bot is Grinder. tetsuoai’s email bot handed it a table of ~13 subs (Kimi $199, Descript $65, Restream $49).",
      "categories": [
        "finance-ops"
      ],
      "awesome_score": 61,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tetsuoai",
        "url": "https://x.com/tetsuoai"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "grocery-autopilot",
      "url": "https://grokbot.dev/use-cases/grocery-autopilot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/grocery-autopilot.json",
      "headline": "The cart that never forgets the no-olives rule",
      "summary": "Rhys’s benchmark for agents is automated grocery ordering. Grok Bot was the first to do it well: a dedicated groceries chat that remembers preferences, a browser signed into Amazon and Costco, scheduled orders, and calendar updates for what to cook — cheaper and more granular than HelloFresh.",
      "categories": [
        "personal"
      ],
      "awesome_score": 67,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@RhysSullivan",
        "url": "https://x.com/RhysSullivan/status/2089338930009374994"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "grok-bot-cto",
      "url": "https://grokbot.dev/use-cases/grok-bot-cto/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/grok-bot-cto.json",
      "headline": "A bot that hires its own child bots to ship PRs",
      "summary": "Ray Fernando handed Grok Bot the GitHub repo and told it to run the show: spin up cloud agents off his machine, follow the PRs, hire child bots (PRs, Convex backend, auth) that talk to each other while he reads view-only.",
      "categories": [
        "engineering"
      ],
      "awesome_score": 73,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@RayFernando1337",
        "url": "https://x.com/RayFernando1337/status/2090588423350616494"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "grok-ship-factory",
      "url": "https://grokbot.dev/use-cases/grok-ship-factory/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/grok-ship-factory.json",
      "headline": "Hundreds of PRs in a day, each closed with proof",
      "summary": "Kun rabbit-holed into Grok Ship — a software factory inside Grok Bot. He said yesterday alone, hundreds of issues and PRs across his repos got done by it. Captain the ship; it ships.",
      "categories": [
        "engineering"
      ],
      "awesome_score": 67,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@kunchenguid",
        "url": "https://x.com/kunchenguid/status/2090463366762676732"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "help-center-from-prs",
      "url": "https://grokbot.dev/use-cases/help-center-from-prs/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/help-center-from-prs.json",
      "headline": "The docs update themselves the moment a PR merges",
      "summary": "Damon’s Intercom + GitHub bot watches every merged PR, decides whether a help-center article needs updating, then drafts and publishes it. 82 likes / 11.4K views.",
      "categories": [
        "support"
      ],
      "awesome_score": 68,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@damonchen",
        "url": "https://x.com/damonchen/status/2090319001813676471"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "hourly-political-brief",
      "url": "https://grokbot.dev/use-cases/hourly-political-brief/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/hourly-political-brief.json",
      "headline": "An hourly brief that says nothing when nothing changed",
      "summary": "From the same Gmail-connected setup, he created standing agents, including an hourly political update on his work topics and a rule to always check with him on key decisions. No posting. Cite sources. Stay quiet if nothing new.",
      "categories": [
        "data"
      ],
      "awesome_score": 55,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@congressdj",
        "url": "https://x.com/congressdj"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "inbox-classifier",
      "url": "https://grokbot.dev/use-cases/inbox-classifier/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/inbox-classifier.json",
      "headline": "Every sponsor email scored before you open it",
      "summary": "A standing classifier that labels mail so it is sortable later and scores every inbound sponsorship email — spammy ones auto-archive, the rest become a lead-scoring queue. Classify and sync are two separate steps; your own decisions are never overwritten.",
      "categories": [
        "work"
      ],
      "awesome_score": 85,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "youtube",
        "label": "Matthew Berman",
        "url": "https://youtu.be/5CSXUsljJ_E"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "inbox-delete-unsub",
      "url": "https://grokbot.dev/use-cases/inbox-delete-unsub/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/inbox-delete-unsub.json",
      "headline": "6,000 emails gone and 40 lists unsubscribed",
      "summary": "Same Royce tweet: the bot cleaned the inbox — 6,000 deletions and 40+ unsubscribes so far — as part of earning its keep in under 24 hours.",
      "categories": [
        "work"
      ],
      "awesome_score": 51,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@royce_james",
        "url": "https://x.com/royce_james"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "inbox-marie-kondo",
      "url": "https://grokbot.dev/use-cases/inbox-marie-kondo/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/inbox-marie-kondo.json",
      "headline": "A daily declutter capped at ten items you approve",
      "summary": "Peter Yang’s five-bot tutorial includes a digital Marie Kondo that audits Gmail, Google Drive, and paid subscriptions, then proposes a cleanup plan. It only unsubscribes, deletes, renames, or cancels after he approves each action. Same tweet as the advisor / YouTube / X-scout crew.",
      "categories": [
        "personal"
      ],
      "awesome_score": 62,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@petergyang",
        "url": "https://x.com/petergyang"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "inbox-receipt-sorter",
      "url": "https://grokbot.dev/use-cases/inbox-receipt-sorter/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/inbox-receipt-sorter.json",
      "headline": "Find the spend first, let another bot go kill it",
      "summary": "tetsuoai set up two bots so Grok Bot would pay for itself. The first has Gmail and keeps the inbox sorted so it knows where receipts and billing mail live — the feed for the subscription killer sitting next to it.",
      "categories": [
        "finance-ops"
      ],
      "awesome_score": 56,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@tetsuoai",
        "url": "https://x.com/tetsuoai/status/2090282440577388572"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "inbox-zero-operator",
      "url": "https://grokbot.dev/use-cases/inbox-zero-operator/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/inbox-zero-operator.json",
      "headline": "Twice-daily triage that reports its own unread count",
      "summary": "Matthew Berman used Grok Bot for inbox zero (plus calendar, DMV, Amazon — split out). 509 likes / 41K views.",
      "categories": [
        "work"
      ],
      "awesome_score": 48,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@MatthewBerman",
        "url": "https://x.com/MatthewBerman/status/2090510856950038587"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "jesse-cos-briefing",
      "url": "https://grokbot.dev/use-cases/jesse-cos-briefing/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/jesse-cos-briefing.json",
      "headline": "It noticed who I was ignoring and booked the call",
      "summary": "Jesse’s Chief of Staff reads Gmail, Calendar, Slack/Discord, and sends a 5am summary with fires. Unlike his old script, he can ask it to do something after: it noticed he was ignoring Nate Berkopec, opened SavvyCal, and found a time in both timezones.",
      "categories": [
        "work"
      ],
      "awesome_score": 62,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jessethanley",
        "url": "https://x.com/jessethanley"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "jesse-saas-cfo",
      "url": "https://grokbot.dev/use-cases/jesse-saas-cfo/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/jesse-saas-cfo.json",
      "headline": "A CFO report that leaves runway blank if it can’t tell",
      "summary": "Same Jesse thread: a CFO bot on Stripe, Xero/QuickBooks, and Gmail. Weekly spend scan for things he missed, a COGS audit, a monthly CFO report. He told people to get concrete, not theatrical — connect the three systems and look.",
      "categories": [
        "finance-ops"
      ],
      "awesome_score": 65,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jessethanley",
        "url": "https://x.com/jessethanley"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "jesse-support-autopilot",
      "url": "https://grokbot.dev/use-cases/jesse-support-autopilot/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/jesse-support-autopilot.json",
      "headline": "Reply by text, and it works the helpdesk for you",
      "summary": "Jesse Hanley’s thread is not a one-liner dump: he already runs a support bot against Bento Chat / helpdesk. It sweeps a few times a day, summarises what is assigned or escalated, and he texts back what to do — then it hits the admin MCP. “This is what I’ve done and it’s fantastic.”",
      "categories": [
        "support"
      ],
      "awesome_score": 68,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@jessethanley",
        "url": "https://x.com/jessethanley/status/2087799804126761304"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "junk-purge-150k",
      "url": "https://grokbot.dev/use-cases/junk-purge-150k/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/junk-purge-150k.json",
      "headline": "150,000 junk emails, deleted after one dry run",
      "summary": "Yu-kai Chou used Grok Bot to clean up 150,000 junk emails and unsubscribe from senders he never reads. Same tweet as the attention watch on five addresses and six Slack workspaces. This is Yu-kai’s 150k, not the separate 90k two-account purge.",
      "categories": [
        "work"
      ],
      "awesome_score": 54,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@yukaichou",
        "url": "https://x.com/yukaichou/status/2090288085125013553"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "lenny-support-replies",
      "url": "https://grokbot.dev/use-cases/lenny-support-replies/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/lenny-support-replies.json",
      "headline": "Support replies already waiting when you sit down",
      "summary": "Lenny’s same early-access note: auto-replying to support emails, which he said saves him hours. Drafts in his voice; he stays on the send button.",
      "categories": [
        "support"
      ],
      "awesome_score": 50,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lennysan",
        "url": "https://x.com/lennysan"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "linkedin-poster",
      "url": "https://grokbot.dev/use-cases/linkedin-poster/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/linkedin-poster.json",
      "headline": "A voice note becomes a live LinkedIn post",
      "summary": "Debbie created a LinkedIn bot, signed in on the bot’s computer (it never sees the password), let it learn her existing posts, dumped a messy voice note, and told it to post. It posted. Receipt, not a draft-only demo.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 59,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@debs_obrien",
        "url": "https://x.com/debs_obrien"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "mass-unsubscribe",
      "url": "https://grokbot.dev/use-cases/mass-unsubscribe/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/mass-unsubscribe.json",
      "headline": "120 days of marketing mail, unsubscribed in one run",
      "summary": "Todd had Grok Bot unsubscribe him from 120 days of marketing mail. Same tweet also audited paid subscriptions. 2.1K likes / 422K views.",
      "categories": [
        "work"
      ],
      "awesome_score": 52,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@toddsaunders",
        "url": "https://x.com/toddsaunders/status/2089896096298627248"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "math-explainer-video",
      "url": "https://grokbot.dev/use-cases/math-explainer-video/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/math-explainer-video.json",
      "headline": "A dense optimizer paper as a 4-minute animation",
      "summary": "He asked Grok Bot to generate a 4:22 animated video explaining rank, spectral power, and optimization vs Adam/Muon/Aurora. Video attached. 377 likes / 1.7M views (Elon quote-tweet did 2.1M).",
      "categories": [
        "fun"
      ],
      "awesome_score": 66,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@yunta_tsai",
        "url": "https://x.com/yunta_tsai/status/2090484253071151424"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "meeting-prep-brief",
      "url": "https://grokbot.dev/use-cases/meeting-prep-brief/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/meeting-prep-brief.json",
      "headline": "Tomorrow’s meetings, one phone-readable page each",
      "summary": "Krista’s daily meeting-prep routine pulls Salesforce, Gmail, Slack, Granola, and Gong into a short, skimmable brief she can read on her phone. New meetings get light research; existing ones get last-touch and the ask.",
      "categories": [
        "work"
      ],
      "awesome_score": 65,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@kristaletz",
        "url": "https://x.com/kristaletz"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "meeting-summary-splitter",
      "url": "https://grokbot.dev/use-cases/meeting-summary-splitter/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/meeting-summary-splitter.json",
      "headline": "Every meeting split into your promises and theirs",
      "summary": "Polls your notetaker for newly recorded meetings, ingests the transcript, and writes a summary plus action items — specifically separating what you committed to from what the other party committed to you, delivered into Grok Bot, Slack, or Telegram.",
      "categories": [
        "work"
      ],
      "awesome_score": 79,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "youtube",
        "label": "Matthew Berman",
        "url": "https://youtu.be/5CSXUsljJ_E"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "merchant-refund-hunter",
      "url": "https://grokbot.dev/use-cases/merchant-refund-hunter/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/merchant-refund-hunter.json",
      "headline": "Five merchants that quietly never sent the refund",
      "summary": "Darian told Grok Bot to pay its own fee: it scanned email for lost money and emailed five merchants that never refunded his returns — already net-positive vs the subscription. 136 likes / 110.5K views.",
      "categories": [
        "personal"
      ],
      "awesome_score": 60,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@darian314",
        "url": "https://x.com/darian314/status/2089381004524093752"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "nate-cos-front-door",
      "url": "https://grokbot.dev/use-cases/nate-cos-front-door/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/nate-cos-front-door.json",
      "headline": "One thread in, and the right bot picks it up",
      "summary": "Nate’s second run job: Klaus is the only bot he talks to. Before doing work, Klaus checks whether another Grok Bot owns it, delegates, and brings the result back to the main thread. Specialists stay narrow; he does not want a four-bot org chart to babysit.",
      "categories": [
        "work"
      ],
      "awesome_score": 55,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nateherk",
        "url": "https://x.com/nateherk"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "org-chart-bot-company",
      "url": "https://grokbot.dev/use-cases/org-chart-bot-company/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/org-chart-bot-company.json",
      "headline": "Eight bots, an org chart, and no task list",
      "summary": "Ridark gave Grok Bot an org chart instead of tasks. Eight bots running the company; he shared the full design. 1.6K likes / 409K views.",
      "categories": [
        "work"
      ],
      "awesome_score": 70,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ridark_eth",
        "url": "https://x.com/ridark_eth/status/2090138832511324179"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "overnight-media-buyer",
      "url": "https://grokbot.dev/use-cases/overnight-media-buyer/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/overnight-media-buyer.json",
      "headline": "Wake up to the CPA spike already diagnosed",
      "summary": "A media buyer paid Cursor Ultra $200 vs ~$100 for Codex/Claude and gave Grok Bot one job: be my media buyer. It connected ad accounts, spreadsheets, analytics, and campaign context.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 67,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@nwtseira",
        "url": "https://x.com/nwtseira/status/2090689291236282371"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "phoenix-plumbing-content-planner",
      "url": "https://grokbot.dev/use-cases/phoenix-plumbing-content-planner/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/phoenix-plumbing-content-planner.json",
      "headline": "The $2k-a-month marketing bottleneck a bot took over",
      "summary": "Jon ONeill (HouseHackerJon) hired a Grok Bot named Mary as marketing manager for his Phoenix plumbing company.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 69,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@HouseHackerJon",
        "url": "https://x.com/HouseHackerJon/status/2088305236003926468"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "phone-site-and-domain",
      "url": "https://grokbot.dev/use-cases/phone-site-and-domain/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/phone-site-and-domain.json",
      "headline": "Two prompts from a phone: site, domain, redirects",
      "summary": "Wayne Sutton installed Convex and Cloudflare plugins, built a demo site (front and backend), bought the domain, and set up Cloudflare redirect rules — all in two prompts from his phone (tryground.dev). 377 likes / 566K views.",
      "categories": [
        "engineering"
      ],
      "awesome_score": 68,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@waynesutton",
        "url": "https://x.com/waynesutton/status/2088416215203295346"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "playwright-issue-closer",
      "url": "https://grokbot.dev/use-cases/playwright-issue-closer/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/playwright-issue-closer.json",
      "headline": "It read the tests, found the bug gone, and closed it",
      "summary": "Debbie spun up a coding bot on debs-obrien/playwright-movies-app. It checked issue 29, found the tests already used waitForURL with no hard waits, asked if it should close, then closed it with a note after GitHub was connected — she clicked through to GitHub to confirm.",
      "categories": [
        "engineering"
      ],
      "awesome_score": 65,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@debs_obrien",
        "url": "https://x.com/debs_obrien"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "plumbing-work-order-intake",
      "url": "https://grokbot.dev/use-cases/plumbing-work-order-intake/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/plumbing-work-order-intake.json",
      "headline": "Ten minutes per work order, booked across five systems",
      "summary": "Jon ONeill (HouseHackerJon), a plumbing-company owner, spent about four hours on a Grok Bot free trial after a week of ~80% Claude work.",
      "categories": [
        "work"
      ],
      "awesome_score": 70,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@HouseHackerJon",
        "url": "https://x.com/HouseHackerJon/status/2087635639701573962"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "podcast-guest-briefer",
      "url": "https://grokbot.dev/use-cases/podcast-guest-briefer/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/podcast-guest-briefer.json",
      "headline": "Guest briefs with three threads and a first question",
      "summary": "Lenny Rachitsky got early access and listed real jobs that made his life better — including “really good” briefs for upcoming podcast guests. Same tweet as his support auto-replies.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 55,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@lennysan",
        "url": "https://x.com/lennysan/status/2087241423792087518"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "podcast-summarizer",
      "url": "https://grokbot.dev/use-cases/podcast-summarizer/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/podcast-summarizer.json",
      "headline": "Built in 15 seconds, better than the paid tool",
      "summary": "Gavin Baker built a podcast summarizer in about 15 seconds inside Grok Bot that beat the tool he was already paying for. Said his personal AI usage jumped ~100x. 5.7K likes / 5.2M views.",
      "categories": [
        "personal"
      ],
      "awesome_score": 54,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GavinSBaker",
        "url": "https://x.com/GavinSBaker/status/2089379355692527813"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "post-bridge",
      "url": "https://grokbot.dev/plugins/post-bridge/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/post-bridge.json",
      "headline": "Post Bridge",
      "summary": "Give your agent one API to post to 10+ social platforms.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "post-bridge.com",
        "url": "https://www.post-bridge.com"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "postiz",
      "url": "https://grokbot.dev/plugins/postiz/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/postiz.json",
      "headline": "Postiz",
      "summary": "Let your agent schedule and post across 30+ social platforms.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "postiz.com",
        "url": "https://postiz.com"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "remote-lawn-mower",
      "url": "https://grokbot.dev/use-cases/remote-lawn-mower/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/remote-lawn-mower.json",
      "headline": "Mow the lawn from 50 miles away",
      "summary": "Sawyer set up Grok Bot to remotely control his autonomous lawn mower, 50 miles from home. Two-minute setup. Video. 3.6K likes / 269K views.",
      "categories": [
        "personal"
      ],
      "awesome_score": 58,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@SawyerMerritt",
        "url": "https://x.com/SawyerMerritt/status/2090179852171174211"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "collection",
      "slug": "research-you-can-trust",
      "url": "https://grokbot.dev/collections/research-you-can-trust/",
      "detail_url": "https://grokbot.dev/api/v1/collections/research-you-can-trust.json",
      "headline": "Research You Can Trust",
      "summary": "Three research Bots that find the signal and show their receipts.",
      "categories": [
        "work"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "revid-ai",
      "url": "https://grokbot.dev/plugins/revid-ai/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/revid-ai.json",
      "headline": "Revid.ai",
      "summary": "Let your agent script, render and publish AI videos.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "revid.ai",
        "url": "https://www.revid.ai"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "robot-vacuum-from-chat",
      "url": "https://grokbot.dev/use-cases/robot-vacuum-from-chat/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/robot-vacuum-from-chat.json",
      "headline": "One bot built the bridge to my robot vacuum",
      "summary": "Yun-Ta Tsai had his 'Chief Engineer' bot build a feature so he can text his Matic robot vacuum from Grok Bot. Video/thread. 2.7K likes / 1.8M views.",
      "categories": [
        "personal"
      ],
      "awesome_score": 68,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@yunta_tsai",
        "url": "https://x.com/yunta_tsai/status/2089223114416898288"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "roofing-lead-to-proposal",
      "url": "https://grokbot.dev/use-cases/roofing-lead-to-proposal/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/roofing-lead-to-proposal.json",
      "headline": "Roof measured, proposal staged, change orders signed",
      "summary": "Same two-day roofing run: it pulled roof measurements for a new inbound lead, built a full proposal/estimate with the contract staged pending his approval, then filled out, drafted, and emailed two change orders via e-signature.",
      "categories": [
        "sales"
      ],
      "awesome_score": 67,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@pricefoulger",
        "url": "https://x.com/pricefoulger"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "roofing-permit-and-inspection",
      "url": "https://grokbot.dev/use-cases/roofing-permit-and-inspection/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/roofing-permit-and-inspection.json",
      "headline": "Through the city permit form, captcha and all",
      "summary": "A roofing contractor spent two days with Grok Bot on live jobs. Among the runs: it filled out and pulled an online roofing permit, then filled out and booked a roof inspection via an online form that had a captcha. Same thread as the proposal and sub/COI work.",
      "categories": [
        "work"
      ],
      "awesome_score": 60,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@pricefoulger",
        "url": "https://x.com/pricefoulger/status/2090444744853766643"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "roofing-sub-coi-and-po",
      "url": "https://grokbot.dev/use-cases/roofing-sub-coi-and-po/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/roofing-sub-coi-and-po.json",
      "headline": "It caught the insurance gap before the job started",
      "summary": "Same contractor run: it found a discrepancy in subcontractor insurance certificates and drafted/sent email to their brokers; wrote a work order for a sub from a customer contract plus a materials list; filled out a credit application for a new supplier and emailed the right person.",
      "categories": [
        "finance-ops"
      ],
      "awesome_score": 65,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@pricefoulger",
        "url": "https://x.com/pricefoulger"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "screenshotone",
      "url": "https://grokbot.dev/plugins/screenshotone/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/screenshotone.json",
      "headline": "ScreenshotOne",
      "summary": "Give your agent a screenshot API for any URL or HTML.",
      "categories": [
        "data"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "screenshotone.com",
        "url": "https://screenshotone.com"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "social-shame-extension",
      "url": "https://grokbot.dev/use-cases/social-shame-extension/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/social-shame-extension.json",
      "headline": "Record the shame video or X stays locked",
      "summary": "Alex Lieberman (businessbarista) one-shotted a Chrome extension with Grok Bot: when he hits X or LinkedIn, it bricks the screen until he records himself saying “I’m being a bad, bad boy.” Best Grok Bot use case he had, with video.",
      "categories": [
        "fun"
      ],
      "awesome_score": 72,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@businessbarista",
        "url": "https://x.com/businessbarista/status/2090493546730074582"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "southwest-flight-credit",
      "url": "https://grokbot.dev/use-cases/southwest-flight-credit/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/southwest-flight-credit.json",
      "headline": "A forgotten $150 Southwest credit, found in Gmail",
      "summary": "Same 24-hour run: Royce’s bot found a $150 Southwest flight credit he thought he had misplaced. Receipt, not a generic “travel agent” prompt.",
      "categories": [
        "personal"
      ],
      "awesome_score": 52,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@royce_james",
        "url": "https://x.com/royce_james"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "starlink-flight-finder",
      "url": "https://grokbot.dev/use-cases/starlink-flight-finder/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/starlink-flight-finder.json",
      "headline": "Book flights where wifi outranks price",
      "summary": "Ben Lang collected internal Grok Bot use cases; the one to copy is his: find/book flights biased toward Starlink access. Peer one-liners (contractors, recipes, film scans) skipped — this is the job with a clear preference.",
      "categories": [
        "personal"
      ],
      "awesome_score": 60,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@benln",
        "url": "https://x.com/benln/status/2087929147406299313"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "stayingapi",
      "url": "https://grokbot.dev/plugins/stayingapi/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/stayingapi.json",
      "headline": "StayingAPI",
      "summary": "Agent access to booking sites — availability and price compare.",
      "categories": [
        "personal"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "stayingapi.com",
        "url": "https://stayingapi.com"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "subscription-cancellation-audit",
      "url": "https://grokbot.dev/use-cases/subscription-cancellation-audit/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/subscription-cancellation-audit.json",
      "headline": "Every subscription sorted into keep, cancel, or ask me",
      "summary": "Same Todd Saunders tweet: after the unsubscribes, the bot audited all subscriptions and recommended cancellations. One tweet, two jobs.",
      "categories": [
        "finance-ops"
      ],
      "awesome_score": 52,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@toddsaunders",
        "url": "https://x.com/toddsaunders"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "superx",
      "url": "https://grokbot.dev/plugins/superx/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/superx.json",
      "headline": "SuperX",
      "summary": "Give your agent your X analytics and a 50M-post idea library.",
      "categories": [
        "marketing"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "superx.so",
        "url": "https://superx.so"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "support-stripe-refunds",
      "url": "https://grokbot.dev/use-cases/support-stripe-refunds/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/support-stripe-refunds.json",
      "headline": "In-policy refunds issued straight through Stripe",
      "summary": "Gergely Orosz hooked Grok Bot to customer support email and the Stripe API so routine refunds run as an agentic workflow. 764 likes / 366K views.",
      "categories": [
        "support"
      ],
      "awesome_score": 68,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@GergelyOrosz",
        "url": "https://x.com/GergelyOrosz/status/2090085668768694562"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "support-ticket-fixer",
      "url": "https://grokbot.dev/use-cases/support-ticket-fixer/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/support-ticket-fixer.json",
      "headline": "One ticket, a root-caused PR, and a reply by morning",
      "summary": "Wilson (euboid) built the loop after asking whether Grok Bot could debug tickets, open a PR, and draft a reply. Incoming ticket → agent reads Fern docs, codebase, Axiom logs → bug gets RCA + PR + Linear, feature request hits the board, customer reply is drafted in his voice.",
      "categories": [
        "support"
      ],
      "awesome_score": 71,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@euboid",
        "url": "https://x.com/euboid/status/2089291320271482895"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "taxes-from-gmail",
      "url": "https://grokbot.dev/use-cases/taxes-from-gmail/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/taxes-from-gmail.json",
      "headline": "The tax return, assembled from 40,000 emails",
      "summary": "A non-coder connected Gmail (~40,000 emails) and asked Grok Bot to do his taxes. It found the documents in mail and assembled the return. Same tweet as the Japan award-ticket hunt and the hourly political brief — he is not a programmer.",
      "categories": [
        "finance-ops"
      ],
      "awesome_score": 65,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@congressdj",
        "url": "https://x.com/congressdj/status/2090093942079447451"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "tee-time-from-group-chat",
      "url": "https://grokbot.dev/use-cases/tee-time-from-group-chat/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/tee-time-from-group-chat.json",
      "headline": "When the group chat agrees, the tee time is booked",
      "summary": "Shane Mac spent a month trying to make agents useful in groups. Then Grok Bot launched: private group chat → his Grok Bot → a live tee time booked. Screen recording. That was the TestFlight.",
      "categories": [
        "personal"
      ],
      "awesome_score": 68,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@ShaneMac",
        "url": "https://x.com/ShaneMac/status/2090773688643629228"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "telegram-inbox-bridge",
      "url": "https://grokbot.dev/use-cases/telegram-inbox-bridge/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/telegram-inbox-bridge.json",
      "headline": "Run your whole bot fleet from a Telegram thread",
      "summary": "Sets up an inbound Telegram bridge so you can talk to your Grok Bot from anywhere, the way an OpenClaw Telegram webhook works — using your own BotFather bot, with every real-world failure (tunnels, webhook 409s, typing timeouts) already solved inside the prompt.",
      "categories": [
        "engineering"
      ],
      "awesome_score": 87,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "youtube",
        "label": "Matthew Berman",
        "url": "https://youtu.be/5CSXUsljJ_E"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "transcriptapi",
      "url": "https://grokbot.dev/plugins/transcriptapi/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/transcriptapi.json",
      "headline": "TranscriptAPI",
      "summary": "Give your agents accurate transcripts from any audio or video.",
      "categories": [
        "data"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "transcriptapi.com",
        "url": "https://transcriptapi.com"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "trip-concierge",
      "url": "https://grokbot.dev/use-cases/trip-concierge/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/trip-concierge.json",
      "headline": "The booking email lands, the fare hunt begins",
      "summary": "The fifth bot in Peter’s tutorial is a personal concierge that saves money on trips. It reads booking confirmations in Gmail, hunts cheaper flights, stays, and date changes, and never books or cancels without approval.",
      "categories": [
        "personal"
      ],
      "awesome_score": 60,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@petergyang",
        "url": "https://x.com/petergyang"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "weekly-disk-cleanup",
      "url": "https://grokbot.dev/use-cases/weekly-disk-cleanup/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/weekly-disk-cleanup.json",
      "headline": "380GB flagged, and it still deletes nothing",
      "summary": "Exploits the fact that Grok Bot is a cloud agent that also has access to your machine: it scans every file weekly, finds deletion candidates, and sorts them into low, medium and high risk — with one hard rule, do not delete anything, categorize by risk.",
      "categories": [
        "personal"
      ],
      "awesome_score": 75,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "youtube",
        "label": "Matthew Berman",
        "url": "https://youtu.be/5CSXUsljJ_E"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "x-content-engine",
      "url": "https://grokbot.dev/use-cases/x-content-engine/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/x-content-engine.json",
      "headline": "The entire X loop, from research to posting time",
      "summary": "Scotty documented how he automated X end to end with Grok Bot: research, design, copy, analytics, and timing. 1.4K likes / 4.5M views.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 64,
      "format": "use-case",
      "featured": true,
      "source": {
        "platform": "x",
        "label": "@ScottyBeamIO",
        "url": "https://x.com/ScottyBeamIO/status/2090174525468033116"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "x-viral-tweet-scout",
      "url": "https://grokbot.dev/use-cases/x-viral-tweet-scout/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/x-viral-tweet-scout.json",
      "headline": "Catch the angle traveling before you write",
      "summary": "Another of Peter's bots watches X for tweets that are breaking out, so he can see which angles travel before he writes.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 53,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@petergyang",
        "url": "https://x.com/petergyang"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "use-case",
      "slug": "youtube-outlier-researcher",
      "url": "https://grokbot.dev/use-cases/youtube-outlier-researcher/",
      "detail_url": "https://grokbot.dev/api/v1/use-cases/youtube-outlier-researcher.json",
      "headline": "Videos at 3x their channel median, mined for format",
      "summary": "One of Peter's five bots is a YouTube outlier researcher — it hunts videos that outperform the channel's baseline so you can learn the format, not copy the topic blindly.",
      "categories": [
        "marketing"
      ],
      "awesome_score": 56,
      "format": "use-case",
      "featured": false,
      "source": {
        "platform": "x",
        "label": "@petergyang",
        "url": "https://x.com/petergyang"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "plugin",
      "slug": "zillapi",
      "url": "https://grokbot.dev/plugins/zillapi/",
      "detail_url": "https://grokbot.dev/api/v1/plugins/zillapi.json",
      "headline": "ZillAPI",
      "summary": "Give your agents fast, structured data on demand.",
      "categories": [
        "data"
      ],
      "awesome_score": null,
      "format": null,
      "featured": true,
      "source": {
        "platform": "web",
        "label": "zillapi.com",
        "url": "https://zillapi.com"
      },
      "added_at": "2026-08-21T00:00:00Z",
      "updated_at": "2026-08-21T12:00:00Z"
    },
    {
      "type": "collection",
      "slug": "grok-ship-firstmate",
      "url": "https://grokbot.dev/collections/grok-ship-firstmate/",
      "detail_url": "https://grokbot.dev/api/v1/collections/grok-ship-firstmate.json",
      "headline": "Grok Ship + Firstmate",
      "summary": "Firstmate at the helm, Grok Ship as the software factory.",
      "categories": [
        "engineering"
      ],
      "awesome_score": null,
      "format": null,
      "featured": false,
      "source": null,
      "added_at": "2026-08-20T22:45:00Z",
      "updated_at": "2026-08-20T23:45:00Z"
    }
  ]
}
