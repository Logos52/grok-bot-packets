---
id: 2026-09-16-moon-how-south-africa-became-3rd-world
kind: podcast
title: How South Africa Became 3rd World in 10 Years
source: "https://www.youtube.com/watch?v=YKGGUexEhUw"
author: Moon
published: 2026-09-15
captured: 2026-09-16
via: grok-bot/Recap
lane: ideas
status: raw
private: false
---

South Africa is a warning to [music] the west because if you went back just 20
west because if you went back just 20 years, it would have completely defied
years, it would have completely defied the image in your head today. Apartheid
the image in your head today. Apartheid had ended. This is Africa's strongest
had ended. This is Africa's strongest economy with worldclass companies and
economy with worldclass companies and stacks of precious metals and gemstones.
stacks of precious metals and gemstones. Walk the streets and you'd feel the
Walk the streets and you'd feel the warmth and vibrancy all around you. But
warmth and vibrancy all around you. But if you were dropped on those same
if you were dropped on those same neighborhoods right now, this is what
neighborhoods right now, this is what you would encounter. Angry mobs yielding
you would encounter. Angry mobs yielding machetes on the streets of Rex cities.
machetes on the streets of Rex cities. regular mass shootings.
regular mass shootings. >> Another month, another mass shooting in
>> Another month, another mass shooting in South Africa.
South Africa. >> Armed robberies, violent attacks, and
>> Armed robberies, violent attacks, and kidnapping so regular that the locals
kidnapping so regular that the locals turn a blind eye. And this is why
turn a blind eye. And this is why gunmen firing AK-47s from a speeding
gunmen firing AK-47s from a speeding luxury sedan.
luxury sedan. >> The murder rate is now 10 times
>> The murder rate is now 10 times Americans, and six South African
Americans, and six South African countries rank among the 50 most violent
countries rank among the 50 most violent cities on Earth. So, what happened over
cities on Earth. So, what happened over such a short space of time? We can trace
such a short space of time? We can trace it back to 2009 when Jacob Sumer took
it back to 2009 when Jacob Sumer took power. One party, the ANC, had run South
power. One party, the ANC, had run South Africa for years and they dominated the
Africa for years and they dominated the state. A committee meets and decides who
state. A committee meets and decides who runs the institutions. [music]
runs the institutions. [music] And his first step was to use that
And his first step was to use that system to give the top jobs to his
system to give the top jobs to his friends. This is when you meet the Gupta
friends. This is when you meet the Gupta family, three Indian-born brothers who
family, three Indian-born brothers who built a business empire within the state
built a business empire within the state itself. They got so close to Zuma that
itself. They got so close to Zuma that he flew 200 guests to a military base
he flew 200 guests to a military base for a private wedding. But for most
for a private wedding. But for most people, the first sign that something
people, the first sign that something was seriously wrong was when their
was seriously wrong was when their lights started going out. Escom, South
lights started going out. Escom, South Africa's state-owned power company, used
Africa's state-owned power company, used to export cheap power across the region.
to export cheap power across the region. When the country started needing more
When the country started needing more electricity, Zuma had two options.
electricity, Zuma had two options. Option one, build more power stations,
Option one, build more power stations, complicated, expensive, and requires
complicated, expensive, and requires planning. Or option two, turn the
planning. Or option two, turn the company into a cash cow. Option two was
company into a cash cow. Option two was much easier. Millions of South Africans
much easier. Millions of South Africans own this app to tell them when it's
own this app to tell them when it's their turn [music] to get cut off. So
their turn [music] to get cut off. So for many years now, South Africa has
for many years now, South Africa has been suffering from something that they
been suffering from something that they call here load shedding. Really planned
call here load shedding. Really planned power cuts. These can be 2 hours a day.
power cuts. These can be 2 hours a day. They can be 6 hours a day. They can even
They can be 6 hours a day. They can even be 12 hours a day. This is when whole
be 12 hours a day. This is when whole parts of the country are blacked out.
parts of the country are blacked out. The corruption quickly spiraled out
The corruption quickly spiraled out [music] of control. Escom was paying
[music] of control. Escom was paying Zuma's friends an incredible $80,000
Zuma's friends an incredible $80,000 rand for one knee [music] pad, which is
rand for one knee [music] pad, which is about $4,500.
about $4,500. All for a bit of foam you strapped to
All for a bit of foam you strapped to your leg. You wouldn't dare step in that
your leg. You wouldn't dare step in that way. In
way. In >> one very spectacular instance, I [music]
>> one very spectacular instance, I [music] went into a plant and I was shown some
went into a plant and I was shown some some knee pads. We were paying 80,000
some knee pads. We were paying 80,000 rand for one. So, a pair [music] would
rand for one. So, a pair [music] would be double that. When a new CEO tried to
be double that. When a new CEO tried to overhaul the company and bring in
overhaul the company and bring in investigators to root out all of this
investigators to root out all of this corruption, someone tried to take him
corruption, someone tried to take him out with cyanide.
out with cyanide. >> Then I asked the doctor to run a tox.
>> Then I asked the doctor to run a tox. Turned [music] out that the cyanide
Turned [music] out that the cyanide levels in my blood were elevated. So I
levels in my blood were elevated. So I guess it was a very close shave. Uh and
guess it was a very close shave. Uh and some people were quite serious about
some people were quite serious about getting rid of me.
getting rid of me. >> The railways became the same story. In
>> The railways became the same story. In 2008, the commuter network carried a
2008, the commuter network carried a very respectable 600,000 people a day.
very respectable 600,000 people a day. Last year, it was just under 14,000
Last year, it was just under 14,000 because gangs kept stealing the cables
because gangs kept stealing the cables and signaling components and no one
and signaling components and no one intervened. There was a glimmer of hope
intervened. There was a glimmer of hope in 2010 when South Africa hosted the
in 2010 when South Africa hosted the World Cup. For a second, it looked
World Cup. For a second, it looked restored to its pre990s glory. But that
restored to its pre990s glory. But that brief high came with a bruising come
brief high came with a bruising come down in 2012 when the police opened fire
down in 2012 when the police opened fire on striking mine workers, killing 34. An
on striking mine workers, killing 34. An extraordinary series of protests is
extraordinary series of protests is spreading across South Africa. 3,000
spreading across South Africa. 3,000 striking miners today marched through
striking miners today marched through the streets near the Lonmin mine where
the streets near the Lonmin mine where 34 of their colleagues were shot dead by
34 of their colleagues were shot dead by police last month.
police last month. >> The civil unrest exploded and Zuma's
>> The civil unrest exploded and Zuma's nemesis Julius Malemma appears on the
nemesis Julius Malemma appears on the scene to offer a radical alternative.
scene to offer a radical alternative. These men are protesting not only
These men are protesting not only against their mind bosses, but an entire
against their mind bosses, but an entire system that they feel has failed them.
system that they feel has failed them. They sing in praise of their new hero
They sing in praise of their new hero Julius Malemma, the arch rival of
Julius Malemma, the arch rival of President Jacob Zuma.
President Jacob Zuma. >> By this stage, Zuma was on the war path,
>> By this stage, Zuma was on the war path, claiming millions in state cash for his
claiming millions in state cash for his own personal mansion, including a lavish
own personal mansion, including a lavish swimming pool a leaked document calls a
swimming pool a leaked document calls a fire pool, as in a pool for putting out
fire pool, as in a pool for putting out fires. By 2015, Zuma suddenly fired his
fires. By 2015, Zuma suddenly fired his respected finance minister. And then the
respected finance minister. And then the country's currency crashed. Why? Because
country's currency crashed. Why? Because the Gupta family had lined up someone
the Gupta family had lined up someone who would benefit them instead.
who would benefit them instead. But before we continue, I've got a bit
But before we continue, I've got a bit of a confession. After spending many
of a confession. After spending many hours going down rabbit holes
hours going down rabbit holes researching videos like this one, my
researching videos like this one, my brain is fried and what I reach for is
brain is fried and what I reach for is my phone, mobile games. It's my guilty
my phone, mobile games. It's my guilty pleasure. Except lately, I felt a lot
pleasure. Except lately, I felt a lot less guilty about it because that time
less guilty about it because that time has actually started paying me back.
has actually started paying me back. It's an online platform called Free
It's an online platform called Free Cash. And the idea is simple. You make
Cash. And the idea is simple. You make money by playing mobile games. You sign
money by playing mobile games. You sign up for free, head to the earn tab, and
up for free, head to the earn tab, and pick from a huge list of game offers
pick from a huge list of game offers across different categories. You play,
across different categories. You play, you hit milestones, and you get paid
you hit milestones, and you get paid real money for it. And before you assume
real money for it. And before you assume this is too good to [music] be true,
this is too good to [music] be true, it's sitting at 4.7 stars with over
it's sitting at 4.7 stars with over 270,000 reviews on Trust Pilot. This
270,000 reviews on Trust Pilot. This isn't a small operation, so I want to
isn't a small operation, so I want to show you how this looks. Here's me
show you how this looks. Here's me actually using it. I picked this one
actually using it. I picked this one because it's the kind of game I
because it's the kind of game I genuinely play anyway. One thing that
genuinely play anyway. One thing that matters, you've got to enable app
matters, you've got to enable app tracking. Otherwise, free cash doesn't
tracking. Otherwise, free cash doesn't see your progress and can't pay you. I
see your progress and can't pay you. I played a few minutes here and there on
played a few minutes here and there on the couch half watching TV, and you can
the couch half watching TV, and you can see what's stacked up in my balance. I
see what's stacked up in my balance. I even threw in a couple of inapp
even threw in a couple of inapp purchases to speed things along and got
purchases to speed things along and got cash back on those through bonus
cash back on those through bonus rewards. And it actually pays. Here's me
rewards. And it actually pays. Here's me cashing out to PayPal. All done. And the
cashing out to PayPal. All done. And the minimum cash out is $25, which honestly
minimum cash out is $25, which honestly doesn't take long to hit at all. And
doesn't take long to hit at all. And this is where you withdraw. You see,
this is where you withdraw. You see, once you hit $25 in your balance, you
once you hit $25 in your balance, you come here and you've got real options.
come here and you've got real options. PayPal, Bitcoin, Ethereum, Litecoin,
PayPal, Bitcoin, Ethereum, Litecoin, gift cards. You just pick your payment
gift cards. You just pick your payment method and once you've hit your $25
method and once you've hit your $25 minimum cash out, it will all go through
minimum cash out, it will all go through that simply. That's literally it. So, I
that simply. That's literally it. So, I highly recommend you check them out
highly recommend you check them out today by using the link in the
today by using the link in the description below or scan this QR code
description below or scan this QR code as when you sign up with my link, you'll
as when you sign up with my link, you'll get a $10 bonus on your first offer.
get a $10 bonus on your first offer. According to this declassified document
According to this declassified document we found in the government archives,
we found in the government archives, they offered 600 million rand, around
they offered 600 million rand, around $40 million to any account he chose. The
$40 million to any account he chose. The documents show it got so bad that they
documents show it got so bad that they literally started dishing out cash to
literally started dishing out cash to anyone they were connected with. And not
anyone they were connected with. And not just a few thousand here and there. The
just a few thousand here and there. The figure here is well over $200 million.
figure here is well over $200 million. Obviously, the government hemorrhaging
Obviously, the government hemorrhaging billions is making life horrible for
billions is making life horrible for everyone and decaying where they live.
everyone and decaying where they live. Look up in Johannesburg today and you'll
Look up in Johannesburg today and you'll see a 54story building that's still the
see a 54story building that's still the tallest residential building in Africa.
tallest residential building in Africa. In the 70s it was full of cafes, trendy
In the 70s it was full of cafes, trendy bookshops, European migrants, and
bookshops, European migrants, and designer shops with pen houses reserved
designer shops with pen houses reserved for the rich. This was Africa's
for the rich. This was Africa's Manhattan. And this is what it looks
Manhattan. And this is what it looks like now. When they attempted to restore
like now. When they attempted to restore it, they found 23 bodies in a rubbish
it, they found 23 bodies in a rubbish pile that had reached almost 13 stories
pile that had reached almost 13 stories high. There were hundreds of hijacked
high. There were hundreds of hijacked buildings scattered across Johannesburg.
buildings scattered across Johannesburg. So with the country rotting from the
So with the country rotting from the inside, Zoomer and his crew moved on to
inside, Zoomer and his crew moved on to the next step of their plan, which
the next step of their plan, which involved privatizing anything [music]
involved privatizing anything [music] decent. The underfunded joke of a police
decent. The underfunded joke of a police force had no chance of keeping on top of
force had no chance of keeping on top of the rocketing crime rate. Nelson Mandela
the rocketing crime rate. Nelson Mandela Bay has over a million people and only
Bay has over a million people and only one working rapid response vehicle with
one working rapid response vehicle with over 300 km on the clock. So millions of
over 300 km on the clock. So millions of working private security guards flooded
working private security guards flooded the market to close the gap. More than
the market to close the gap. More than the army and police combined.
the army and police combined. >> With more than 2.7 million registered
>> With more than 2.7 million registered private security officers in the
private security officers in the country, South Africa's security
country, South Africa's security industry is one of the world's largest.
industry is one of the world's largest. In comparison, there are fewer than
In comparison, there are fewer than 150,000 police officers for a population
150,000 police officers for a population of 62 million people.
of 62 million people. >> The rich can now at least insulate
>> The rich can now at least insulate themselves from the impoverished
themselves from the impoverished population. They don't need the trains
population. They don't need the trains because they have cars. They don't need
because they have cars. They don't need the police because they have guards.
the police because they have guards. They don't need the grid because they
They don't need the grid because they have generators. They don't need public
have generators. They don't need public space because they live behind walls.
space because they live behind walls. Gated compounds are becoming preferable
Gated compounds are becoming preferable across the West for the same reason. And
across the West for the same reason. And on the extreme end of the scale, it's
on the extreme end of the scale, it's the same reason why Teal Zuckerberg and
the same reason why Teal Zuckerberg and Ultim all have bunkers. Reed Hoffman,
Ultim all have bunkers. Reed Hoffman, who founded LinkedIn, reckons more than
who founded LinkedIn, reckons more than half of Silicon Valley's billionaires
half of Silicon Valley's billionaires have what he calls apocalypse insurance.
have what he calls apocalypse insurance. However, there was a big problem for
However, there was a big problem for South Africa's elites. They could sense
South Africa's elites. They could sense intense public anger brewing under the
intense public anger brewing under the surface. So luckily they had the perfect
surface. So luckily they had the perfect tool to subjugate that divide and
tool to subjugate that divide and conquer. When the curtains came down on
conquer. When the curtains came down on apartheid, the economy was still almost
apartheid, the economy was still almost entirely whitoned, which the new
entirely whitoned, which the new government set out to change. Inequality
government set out to change. Inequality then was brutal and unjust and nobody
then was brutal and unjust and nobody sensible argues with the aim. But this
sensible argues with the aim. But this involved creating some 145 racial laws
involved creating some 145 racial laws classifying everyone by race. And in
classifying everyone by race. And in doing that, South Africa might have
doing that, South Africa might have engineered the most permanently divided
engineered the most permanently divided state on the planet.
>> This is Zuma's arch nemesis again and the leader of the populist ultralleft
the leader of the populist ultralleft party. In many cases, the white bore
party. In many cases, the white bore settlers he opposes are just pensioners
settlers he opposes are just pensioners being brutally tortured and murdered.
being brutally tortured and murdered. >> My one neighbor, Honest Kitchen, and his
>> My one neighbor, Honest Kitchen, and his wife, they were murdered about 6 months
wife, they were murdered about 6 months ago. Um then there's uh Miss Simpson
ago. Um then there's uh Miss Simpson just Nikki Simpson. Uh she was tortured,
just Nikki Simpson. Uh she was tortured, drilled through her knees and feet. Um
drilled through her knees and feet. Um then there's Piku,
then there's Piku, also a neighbor not far from here. He
also a neighbor not far from here. He was shot. Carl Hall was shot.
was shot. Carl Hall was shot. >> The state has completely deserted them,
>> The state has completely deserted them, leaving only armed vigilantes with
leaving only armed vigilantes with automatic weapons to protect them.
automatic weapons to protect them. >> Keep your barrel on the target. I want
>> Keep your barrel on the target. I want as many barrels pointing at windows as
as many barrels pointing at windows as possible.
possible. When a farm attacks reported, armed
When a farm attacks reported, armed civilians often arrive long before
civilians often arrive long before police.
police. >> And because South Africa's racial makeup
>> And because South Africa's racial makeup changes dramatically from place to
changes dramatically from place to place, the system designed to favor
place, the system designed to favor black South Africans discriminates
black South Africans discriminates against black South Africans, too.
against black South Africans, too. Because their local demographics don't
Because their local demographics don't match the national formula. Eventually,
match the national formula. Eventually, even the ruling ANC party had enough of
even the ruling ANC party had enough of this absurd situation. So, they forced
this absurd situation. So, they forced Zoomer out in 2018, and a huge judicial
Zoomer out in 2018, and a huge judicial inquiry started exposing the full extent
inquiry started exposing the full extent of the damage. A staggering $65 billion
of the damage. A staggering $65 billion have been taken in total and they coined
have been taken in total and they coined a term for it, state capture. State
a term for it, state capture. State capture follows a remarkably
capture follows a remarkably recognizable pattern wherever it
recognizable pattern wherever it happens. In this essay, two political
happens. In this essay, two political scientists compare Zuma's attacks with a
scientists compare Zuma's attacks with a pattern happening pretty much
pattern happening pretty much everywhere. The essay is titled South
everywhere. The essay is titled South Africa's warning for the United States
Africa's warning for the United States and other democracies. [music] In their
and other democracies. [music] In their words, it's all just a way of making
words, it's all just a way of making corruption legal. Another thing that
corruption legal. Another thing that crawled out of the woodwork was that
crawled out of the woodwork was that Zuma and the Guptas had outside help,
Zuma and the Guptas had outside help, including help from the American
including help from the American consultancy giant McKenzie. [music]
consultancy giant McKenzie. [music] McKenzie was involved in a bribery
McKenzie was involved in a bribery scheme to win lucrative contracts from
scheme to win lucrative contracts from Escro and the rail company, generating
Escro and the rail company, generating around $85 million in profits. [music]
around $85 million in profits. [music] Years later, the company paid more than
Years later, the company paid more than $122 million to settle a US criminal
$122 million to settle a US criminal investigation. Zuma was eventually
investigation. Zuma was eventually arrested and imprisoned, but then was
arrested and imprisoned, but then was released after a pathetic two months
released after a pathetic two months amid a storm of controversy. It was
amid a storm of controversy. It was actually his imprisonment which
actually his imprisonment which triggered the worst violence yet with
triggered the worst violence yet with more than 350 people dying in a wave of
more than 350 people dying in a wave of riots that engulfed the country. Two of
riots that engulfed the country. Two of the Gupta brothers simply escaped to
the Gupta brothers simply escaped to Dubai and South Africa failed to get
Dubai and South Africa failed to get them sent back. The two wealthy
them sent back. The two wealthy Indianborn business brothers were
Indianborn business brothers were friends with former South African
friends with former South African president Jacob Zuma. The Guptas were
president Jacob Zuma. The Guptas were found to be at the center of a web of
found to be at the center of a web of corruption during Zuma's tenure. They
corruption during Zuma's tenure. They were allegedly at the center of a
were allegedly at the center of a corruption scandal that dog Zuma's
corruption scandal that dog Zuma's 9-year administration until 2018.
9-year administration until 2018. >> Zuma soon joined them in this massive
>> Zuma soon joined them in this massive mansion with Robert McGabby as his next
mansion with Robert McGabby as his next door neighbor, which is even more
door neighbor, which is even more ridiculous than it sounds when you learn
ridiculous than it sounds when you learn McGabby once plotted Zuma's
McGabby once plotted Zuma's assassination. He then visited the other
assassination. He then visited the other Gupta in India, publicly naming him as
Gupta in India, publicly naming him as his brother and friend. coming to a
his brother and friend. coming to a brother and friend of mine.
brother and friend of mine. >> So, they won the battle in every sense.
>> So, they won the battle in every sense. There was barely any retribution except
There was barely any retribution except a couple months in prison and an endless
a couple months in prison and an endless report no one will learn from. While
report no one will learn from. While they put their feet up by the pool and
they put their feet up by the pool and enjoy a comfortable life, it's far from
enjoy a comfortable life, it's far from over for the South African population.
over for the South African population. Right now, the elites are creating a
Right now, the elites are creating a migrant crisis that's tearing an already
migrant crisis that's tearing an already weakened country apart. Around 1 million
weakened country apart. Around 1 million people have immigrated, many of them
people have immigrated, many of them doctors, engineers, skilled workers, and
doctors, engineers, skilled workers, and business owners who pay the tax. So the
business owners who pay the tax. So the new government decided to plug the gaps
new government decided to plug the gaps with cheap labor from Zimbabwe,
with cheap labor from Zimbabwe, Mozambique, Malawi, and Leoto.
Mozambique, Malawi, and Leoto. >> There isn't any consensus on the number
>> There isn't any consensus on the number of foreigners in the Republic, either
of foreigners in the Republic, either legal or illegal. The numbers can be
legal or illegal. The numbers can be exaggerated from between 4 and 14
exaggerated from between 4 and 14 million.
million. >> The divide and conquer tactics work. The
>> The divide and conquer tactics work. The natives react with violence, standing
natives react with violence, standing outside hospitals and checking ID cards,
outside hospitals and checking ID cards, threatening violence against any
threatening violence against any outsider.
outsider. >> The songs that some of these protesters
>> The songs that some of these protesters are singing carry extremely threatening
are singing carry extremely threatening messages. one saying, "Burn the
messages. one saying, "Burn the foreigner. We will go to the garage, buy
foreigner. We will go to the garage, buy some petrol, and burn the foreigner."
some petrol, and burn the foreigner." The new president came in with the usual
The new president came in with the usual rhetoric of then smashing corruption.
rhetoric of then smashing corruption. Yet robbers found $580,000 in foreign
Yet robbers found $580,000 in foreign cash hidden in his furniture, which he
cash hidden in his furniture, which he claimed was just a payment for 20
claimed was just a payment for 20 buffalo from his ranch. South Africa
buffalo from his ranch. South Africa looks like Western decline on steroids.
looks like Western decline on steroids. And while tempting to dismiss, it
And while tempting to dismiss, it mirrors something happening here on a
mirrors something happening here on a different time scale, but only slightly
different time scale, but only slightly different. Because outside of the elites
different. Because outside of the elites bubble, things are rapidly declining.
bubble, things are rapidly declining. The place you live is probably uglier
The place you live is probably uglier than it was. Maybe it's visibly decaying
than it was. Maybe it's visibly decaying with cracks on the sidewalks or potholes
with cracks on the sidewalks or potholes in the road. Or maybe they've replaced
in the road. Or maybe they've replaced the parks with jarring office blocks.
the parks with jarring office blocks. Who saves money on the repairs or gets
Who saves money on the repairs or gets the brown envelope for the developments.
the brown envelope for the developments. The [snorts] decay of the built
The [snorts] decay of the built environment matches the decay of the
environment matches the decay of the state itself. Taxes always go up. Yet
state itself. Taxes always go up. Yet [music] healthcare in the US is a
[music] healthcare in the US is a gamble.
gamble. >> It's an open secret among Americans that
>> It's an open secret among Americans that calling for an ambulance is a financial
calling for an ambulance is a financial gamble. It's similar in the UK with the
gamble. It's similar in the UK with the NHS. I mean, it's free, but if you want
NHS. I mean, it's free, but if you want to get seen in decent time, you'll
to get seen in decent time, you'll strongly consider going private. Another
strongly consider going private. Another glaring parallel is how the police are
glaring parallel is how the police are becoming abysmally bad at their job.
becoming abysmally bad at their job. Police confidence in the US came to an
Police confidence in the US came to an end in 2020 and hit an all-time low in
end in 2020 and hit an all-time low in 2023. In the UK, a measly 14% of people
2023. In the UK, a measly 14% of people think police would properly investigate
think police would properly investigate a minor crime. Last year, 72% of
a minor crime. Last year, 72% of burglary cases were closed without
burglary cases were closed without anyone even being identified. So the
anyone even being identified. So the market comes up with the answers the
market comes up with the answers the government can't give. Ring doorbells or
government can't give. Ring doorbells or flock cameras or palunteer keeping
flock cameras or palunteer keeping everyone permanently in line and
everyone permanently in line and annihilating their sense of freedom.
annihilating their sense of freedom. Apple kicked an app called vigilante off
Apple kicked an app called vigilante off the app store so it returned as citizen
the app store so it returned as citizen streaming robbery shootings and raw
streaming robbery shootings and raw police reports. Then it started selling
police reports. Then it started selling private security through the same app
private security through the same app while private police forces are becoming
while private police forces are becoming ubiquitous across America. [music]
ubiquitous across America. [music] >> A big part of that comes down to
>> A big part of that comes down to response time. You can't beat the
response time. You can't beat the response time of someone that's there on
response time of someone that's there on site already.
site already. >> The system is failing you twice. First
>> The system is failing you twice. First by taking something your taxes paid for
by taking something your taxes paid for away and then by selling a more
away and then by selling a more expensive replacement back to you. Even
expensive replacement back to you. Even South Africa's relentless pursuit of
South Africa's relentless pursuit of equity over merit is the same thing our
equity over merit is the same thing our institutions increasingly try to
institutions increasingly try to engineer so that we have the right mix
engineer so that we have the right mix rather than simply picking the best
rather than simply picking the best candidates. Look no further than the UK
candidates. Look no further than the UK where we have people like Matthew
where we have people like Matthew Furlong who applied to the Cheshire
Furlong who applied to the Cheshire police and passed the recruitment
police and passed the recruitment process. When he didn't get the job, he
process. When he didn't get the job, he exposed how the force declared all 127
exposed how the force declared all 127 successful candidates to be of equal
successful candidates to be of equal merit [music] so it could favor
merit [music] so it could favor applicants with protected
applicants with protected characteristics. Furong was white, male,
characteristics. Furong was white, male, and heterosexual. He didn't get the job.
and heterosexual. He didn't get the job. He sued and a tribunal found he'd been
He sued and a tribunal found he'd been directly discriminated against on all
directly discriminated against on all three grounds. And this happens every
three grounds. And this happens every day, every year. It poisons everyone
day, every year. It poisons everyone against everyone. [music]
against everyone. [music] And you might be angry about it, but who
And you might be angry about it, but who makes the laws in the first place?
makes the laws in the first place? Because [snorts] South Africa didn't
Because [snorts] South Africa didn't wake up one morning as a failed society.
wake up one morning as a failed society. Eventually, the wealthy live behind the
Eventually, the wealthy live behind the walls, the middle class watch the
walls, the middle class watch the streets through cameras, and the poor
streets through cameras, and the poor rely on whatever order they can enforce
rely on whatever order they can enforce themselves. And by the time everyone
themselves. And by the time everyone realizes what's actually happening, the
realizes what's actually happening, the elites who hollowed out the system are
elites who hollowed out the system are living the high life in insulated
living the high life in insulated bunkers. The West doesn't have to become
bunkers. The West doesn't have to become South Africa overnight. It just has to
South Africa overnight. It just has to keep on following in its footsteps, one
keep on following in its footsteps, one failure at a time.
