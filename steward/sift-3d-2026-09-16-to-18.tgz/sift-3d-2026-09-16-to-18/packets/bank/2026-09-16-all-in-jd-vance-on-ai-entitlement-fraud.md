---
id: 2026-09-16-all-in-jd-vance-on-ai-entitlement-fraud
kind: podcast
title: JD Vance on AI, Entitlement Fraud, Iran War, Israel, H-1B Abuse & the Midterms
source: "https://www.youtube.com/watch?v=PUcooQRy0PU"
author: All-In Podcast
published: 2026-09-15
captured: 2026-09-16
via: grok-bot/Recap
lane: ideas
status: raw
private: false
---

I, James Vance, do solemnly swear that I will support and defend the Constitution
will support and defend the Constitution of the United States. So help me God.
of the United States. So help me God. >> Congratulations, Mr. Vice President.
>> Congratulations, Mr. Vice President. >> We're the senior [music] partner. We're
>> We're the senior [music] partner. We're the world's superpower. That's the way
the world's superpower. That's the way that it works.
that it works. >> This is not just theft of the American
>> This is not just theft of the American people's money. This is also theft of
people's money. This is also theft of critical services that the American
critical services that the American people rely on. This is a [music]
people rely on. This is a [music] problem that has festered in this
problem that has festered in this country for far too long. You stop
country for far too long. You stop socialism by making people's lives
socialism by making people's lives better. [music] And that's what we're
better. [music] And that's what we're trying to do every single day.
trying to do every single day. >> We got to take care of business this
>> We got to take care of business this November, then we'll worry about [music]
November, then we'll worry about [music] what comes next.
what comes next. >> Please welcome Vice President J. D.
>> Please welcome Vice President J. D. Vance. [music]
All right. [applause] Nice to see you, Mr. Vice President. How
Nice to see you, Mr. Vice President. How are you?
are you? >> I'm good. I'm good. I Jason, I I caught
>> I'm good. I'm good. I Jason, I I caught the very tail end of that panel
the very tail end of that panel discussion and you you were asking
discussion and you you were asking somebody about how their life had
somebody about how their life had changed. I couldn't see who it was, but
changed. I couldn't see who it was, but asking how their life had changed cuz
asking how their life had changed cuz they had been in the big house, which it
they had been in the big house, which it appears to me you meant prison, but I I
appears to me you meant prison, but I I thought you were talking about the
thought you were talking about the Michigan football team stadium
Michigan football team stadium [laughter] they played. So, very
[laughter] they played. So, very different understanding of what you were
different understanding of what you were talking about and what was actually
talking about and what was actually going on.
going on. >> Yeah.
>> Yeah. >> Uh, well, it's great it's great to have
>> Uh, well, it's great it's great to have you back. We always appreciate that you
you back. We always appreciate that you take the time to join the besties and
take the time to join the besties and have a very candid, honest discussion.
have a very candid, honest discussion. This is your, I think, third or fourth
This is your, I think, third or fourth time on the program. Uh, and it's a
time on the program. Uh, and it's a great time to be on the program because
great time to be on the program because you're halfway through uh your term
you're halfway through uh your term approximately and the midterms are
approximately and the midterms are coming up. maybe you could assess what's
coming up. maybe you could assess what's went really well for and what you're
went really well for and what you're proud of with this uh first two years
proud of with this uh first two years and then let's get into some things that
and then let's get into some things that maybe your own constituents
maybe your own constituents um are not happy with and uh let's start
um are not happy with and uh let's start with the positive. What do you think
with the positive. What do you think you've accomplished in these first two
you've accomplished in these first two years?
years? Well, look, I I think the the two things
Well, look, I I think the the two things that I'm most proud of are first of all,
that I'm most proud of are first of all, we actually got control of the southern
we actually got control of the southern border, but started to reverse the flow
border, but started to reverse the flow of illegal immigration, which is about 3
of illegal immigration, which is about 3 million lower today than it was when we
million lower today than it was when we came into office. Obviously, there's a
came into office. Obviously, there's a lot more to do, but if you look at the
lot more to do, but if you look at the history of Western governments in the
history of Western governments in the post-war era, they open the border. They
post-war era, they open the border. They invite border invasions, but they never
invite border invasions, but they never actually reverse it. At best, they slow
actually reverse it. At best, they slow it down. I think President Trump was the
it down. I think President Trump was the first president in my lifetime to
first president in my lifetime to actually reverse that flow of illegal
actually reverse that flow of illegal immigration. I'm extremely proud of
immigration. I'm extremely proud of that. I'm also proud, as you guys know,
that. I'm also proud, as you guys know, I've been obsessively focused on this.
I've been obsessively focused on this. [applause]
I I I've been obsessively focused on this for a long time, which is the idea
this for a long time, which is the idea of re-industrializing and recapitalizing
of re-industrializing and recapitalizing the the the manufacturing base of the
the the the manufacturing base of the United States of America. And, you know,
United States of America. And, you know, this was a bipartisan consensus that
this was a bipartisan consensus that leaned into globalization that sort of
leaned into globalization that sort of bought into this idea that you could
bought into this idea that you could have a prosperous economy that was built
have a prosperous economy that was built entirely around services, tech, and
entirely around services, tech, and finance. And the reality of course is
finance. And the reality of course is that to have a truly prosperous economy,
that to have a truly prosperous economy, you still have to make stuff. And I
you still have to make stuff. And I think Donald Trump understood that
think Donald Trump understood that better than anybody else. Obviously, it
better than anybody else. Obviously, it takes a long time uh to rebuild the
takes a long time uh to rebuild the manufacturing base of the country. But
manufacturing base of the country. But if you look at the trillions of dollars
if you look at the trillions of dollars of new investment, the new construction,
of new investment, the new construction, uh the new manufacturing facilities
uh the new manufacturing facilities being built, I do think that you're
being built, I do think that you're seeing the obvious signs that over the
seeing the obvious signs that over the past 18 months, we've reversed a 40-year
past 18 months, we've reversed a 40-year trend. Now, Rome wasn't built in a day.
trend. Now, Rome wasn't built in a day. going to take longer to fully undo the
going to take longer to fully undo the damage wrought by the last 40 years. But
damage wrought by the last 40 years. But the fact that we're actually on the
the fact that we're actually on the right pathway is a signature achievement
right pathway is a signature achievement of Donald Trump. But I think it's the
of Donald Trump. But I think it's the thing that he will be remembered for
thing that he will be remembered for even more than the border. He will be
even more than the border. He will be remembered for ending the sort of
remembered for ending the sort of consensus around globalization and
consensus around globalization and actually enacting policies that get us
actually enacting policies that get us on the on the right track. Again,
on the on the right track. Again, >> I think we we all agree with those two
>> I think we we all agree with those two and just absolute congratulations on
and just absolute congratulations on that. Uh you guys have crushed it. I
that. Uh you guys have crushed it. I think we all concur. um your
think we all concur. um your constituents, the people who voted for
constituents, the people who voted for you are extremely frustrated about two
you are extremely frustrated about two issues. Let's just tackle them head-on.
issues. Let's just tackle them head-on. The first is you promised us you
The first is you promised us you wouldn't start a foreign war. You
wouldn't start a foreign war. You promised us you wouldn't start a foreign
promised us you wouldn't start a foreign war in the Middle East specifically. And
war in the Middle East specifically. And then you promised you would get
then you promised you would get inflation under control. You haven't
inflation under control. You haven't been able to get inflation under
been able to get inflation under control. Still 3 or 4% this year. It's
control. Still 3 or 4% this year. It's not looking good. And Americans,
not looking good. And Americans, specifically the people who voted for
specifically the people who voted for you, Mr. vice president are very upset
you, Mr. vice president are very upset about starting this war. What is your
about starting this war. What is your message to them? How do these two issues
message to them? How do these two issues get resolved? Because people are very
get resolved? Because people are very unhappy about it.
unhappy about it. >> Yeah. So, so Jason, I understand that
>> Yeah. So, so Jason, I understand that and I certainly hear from people. And
and I certainly hear from people. And what I would say first of all is we
what I would say first of all is we invite people into the coalition who
invite people into the coalition who disagree with us. You don't have to
disagree with us. You don't have to agree with us on every single issue. But
agree with us on every single issue. But on the war specifically, what I I would
on the war specifically, what I I would say is look, the president came in and
say is look, the president came in and yes, he wanted to keep the United States
yes, he wanted to keep the United States out of foreign entanglements. He also
out of foreign entanglements. He also said that he was committed to Iran not
said that he was committed to Iran not having a nuclear weapon. And I think
having a nuclear weapon. And I think that wanting to keep the United States
that wanting to keep the United States out of foreign entanglements does not
out of foreign entanglements does not mean that you can never use the military
mean that you can never use the military in order to accomplish the American
in order to accomplish the American people's objectives. Now, all that said,
people's objectives. Now, all that said, despite the fact that we did accomplish
despite the fact that we did accomplish a substantial destruction, not just of
a substantial destruction, not just of their nuclear program, but also of the
their nuclear program, but also of the Iranian conventional military, we've
Iranian conventional military, we've seen the Iranians shooting at commercial
seen the Iranians shooting at commercial shipping even in the midst of peace
shipping even in the midst of peace negotiations. And I think the president
negotiations. And I think the president has actually done the responsible thing
has actually done the responsible thing here, which is to try to ensure that
here, which is to try to ensure that world energy markets, despite Iranian
world energy markets, despite Iranian terrorism, continue to get that flow of
terrorism, continue to get that flow of oil and gas. And so what I would say to
oil and gas. And so what I would say to anybody who's frustrated right now is
anybody who's frustrated right now is the alternative here, which is the
the alternative here, which is the United States effectively says to the
United States effectively says to the Middle East, you're on your own, would
Middle East, you're on your own, would mean necessarily a worldwide energy
mean necessarily a worldwide energy crisis so long as the Iranians keep on
crisis so long as the Iranians keep on shooting at shipping, which we know
shooting at shipping, which we know that's exactly what they would do. So, I
that's exactly what they would do. So, I think the president is taking the
think the president is taking the responsible course of action. He's
responsible course of action. He's protecting America's assets in the
protecting America's assets in the region while also ensuring that world
region while also ensuring that world energy markets continue to get a supply
energy markets continue to get a supply of oil and natural gas. And you on the
of oil and natural gas. And you on the inflation, Jason, I I think we've made a
inflation, Jason, I I think we've made a lot of progress. To my point earlier,
lot of progress. To my point earlier, Rome was not built in a day, but you
Rome was not built in a day, but you know, under the Biden administration, we
know, under the Biden administration, we had inflation, I think, at 9 12%
had inflation, I think, at 9 12% annualized. That's the highest rate in
annualized. That's the highest rate in about 48 years. You're right. three and
about 48 years. You're right. three and a half% is still too high, but you've
a half% is still too high, but you've seen substantial progress and of course
seen substantial progress and of course we're going to keep on making progress.
we're going to keep on making progress. I guess my pitch to the American people
I guess my pitch to the American people and to to your listeners certainly would
and to to your listeners certainly would be do you want to reelect the people who
be do you want to reelect the people who have made substantial progress accepting
have made substantial progress accepting there's still a lot of work to be done
there's still a lot of work to be done or do you want to go back to the people
or do you want to go back to the people who caused the problem in the first
who caused the problem in the first place? And obviously I'm biased but I
place? And obviously I'm biased but I think that you should elect the people
think that you should elect the people who have actually made substantial
who have actually made substantial progress while recognizing a lot more
progress while recognizing a lot more progress needs to happen. Mr. Mr. Vice
progress needs to happen. Mr. Mr. Vice President, the um [applause]
one of the other things many of us were excited about with this incoming
excited about with this incoming administration was addressing the fiscal
administration was addressing the fiscal deficit. Uh it seems to become more
deficit. Uh it seems to become more apparent to markets that this is
apparent to markets that this is potentially a risk to the to the the US
potentially a risk to the to the the US um dollar over time. The the 30-year I
um dollar over time. The the 30-year I think is around 5.2% now. What's your
think is around 5.2% now. What's your view? And you know, when the
view? And you know, when the administration came in, there was an
administration came in, there was an effort with Doge. Uh, but it's been very
effort with Doge. Uh, but it's been very hard to get congressional action to take
hard to get congressional action to take the steps necessary to reduce the
the steps necessary to reduce the deficit. Maybe you can share the
deficit. Maybe you can share the administration's view, your view on what
administration's view, your view on what can we do to write the fiscal course for
can we do to write the fiscal course for the federal government now and over
the federal government now and over time.
time. >> Yeah, look, it's a very important and
>> Yeah, look, it's a very important and fair question. I mean, I I think that in
fair question. I mean, I I think that in fundamentally the the anti-fraud efforts
fundamentally the the anti-fraud efforts that I've been focused on, we've saved
that I've been focused on, we've saved about $250 billion of the American
about $250 billion of the American taxpayers money that would have
taxpayers money that would have otherwise gone to fraudsters. And in the
otherwise gone to fraudsters. And in the scale of a 7 trillion federal budget,
scale of a 7 trillion federal budget, obviously $250 billion isn't the whole
obviously $250 billion isn't the whole thing, but it's a lot and it's something
thing, but it's a lot and it's something that we're very proud of. I think we
that we're very proud of. I think we have to continue to sort of just
have to continue to sort of just tackling the basic fraud and waste
tackling the basic fraud and waste that's endemic to our government. And of
that's endemic to our government. And of course, we are going to need some real
course, we are going to need some real bipartisan legislative solutions to give
bipartisan legislative solutions to give markets confidence. Not just that we're
markets confidence. Not just that we're going to be serious about the deficit,
going to be serious about the deficit, but that hopefully the president who
but that hopefully the president who comes after and the Congress that comes
comes after and the Congress that comes after is going to be serious about the
after is going to be serious about the deficit. I think fundamentally the
deficit. I think fundamentally the problem here, and I I think what the
problem here, and I I think what the markets are responding to at this moment
markets are responding to at this moment is the perception that neither
is the perception that neither congressional Republicans or Democrats
congressional Republicans or Democrats are serious about the debt and the
are serious about the debt and the deficit. Obviously, I think the
deficit. Obviously, I think the administration, I'm biased. I think that
administration, I'm biased. I think that we are serious about this issue. If you
we are serious about this issue. If you look at what Scott Bassen, who I'm going
look at what Scott Bassen, who I'm going to meet with in a couple of hours,
to meet with in a couple of hours, actually, uh what Scott Bassen has
actually, uh what Scott Bassen has talked about is, you know, let's be
talked about is, you know, let's be realistic. We have we we inherited a $2
realistic. We have we we inherited a $2 trillion fiscal deficit. And you're not
trillion fiscal deficit. And you're not going to get back to a balanced budget
going to get back to a balanced budget by cutting $2 trillion out of a $7
by cutting $2 trillion out of a $7 trillion budget overnight. What you can
trillion budget overnight. What you can do is you can cut smartly but also grow
do is you can cut smartly but also grow and get the economy in a position where
and get the economy in a position where that fiscal deficit is closer to 3% of
that fiscal deficit is closer to 3% of GDP. Now yes we got to make more
GDP. Now yes we got to make more progress but if you look at what Scott
progress but if you look at what Scott has done at the Treasury I think that we
has done at the Treasury I think that we are on pace to get to a point where we
are on pace to get to a point where we can get the fiscal deficit to a
can get the fiscal deficit to a sustainable level and then of course you
sustainable level and then of course you get it to a sustainable level and you
get it to a sustainable level and you can continue to make progress from
can continue to make progress from there. But it is certainly a very
there. But it is certainly a very serious problem, something that we're
serious problem, something that we're very focused on. And I guess what I
very focused on. And I guess what I would say to to markets is we've got a
would say to to markets is we've got a secretary of the Treasury, but also a
secretary of the Treasury, but also a president who are very focused on the
president who are very focused on the problem, but it's going to require a
problem, but it's going to require a long-term solution. Ideally, something
long-term solution. Ideally, something with some bipartisan consensus, which is
with some bipartisan consensus, which is something we'll have to see about
something we'll have to see about because let's be honest, uh, a lot of
because let's be honest, uh, a lot of people in Congress, not just Democrats,
people in Congress, not just Democrats, but a lot of people in Congress have not
but a lot of people in Congress have not shown a willingness to be serious about
shown a willingness to be serious about spending. We have to change that.
spending. We have to change that. >> Let's, um, let's maybe double click on
>> Let's, um, let's maybe double click on that, Mr. Vice President. There's one
that, Mr. Vice President. There's one one of the ways that we can get out of
one of the ways that we can get out of this is through growth and productivity
this is through growth and productivity growth. But there is this crazy dynamic
growth. But there is this crazy dynamic where it just seems like there are
where it just seems like there are forces many inside the United States um
forces many inside the United States um that try to slow us down whether it's
that try to slow us down whether it's data centers and you may have heard
data centers and you may have heard yesterday but the president called in
yesterday but the president called in and tried to help debunk it with Jensen
and tried to help debunk it with Jensen Meta uh was here debunking uh Microsoft
Meta uh was here debunking uh Microsoft was here but it just seems like a
was here but it just seems like a whack-a-mole problem of trying to
whack-a-mole problem of trying to actually get the truth out. just talk to
actually get the truth out. just talk to us about
us about how we've ended up in this situation
how we've ended up in this situation where there are these forces that are
where there are these forces that are trying to effectively
trying to effectively lie or fear-monger to try to take power.
lie or fear-monger to try to take power. >> Yeah. So, this is something I think we
>> Yeah. So, this is something I think we could spend an hour talking about. I
could spend an hour talking about. I know we don't have that much time,
know we don't have that much time, Chimath, but but fundamentally when I
Chimath, but but fundamentally when I see the backlash to data centers, what I
see the backlash to data centers, what I see is the the the the necessary the
see is the the the the necessary the inevitable consequence of the United
inevitable consequence of the United States not building enough power for a
States not building enough power for a generation. And so we've talked about
generation. And so we've talked about this before, but if if when I talk to
this before, but if if when I talk to people, I obviously sort of I'm out
people, I obviously sort of I'm out there campaigning a lot. I'm talking to
there campaigning a lot. I'm talking to people a lot. Uh there there's
people a lot. Uh there there's definitely some basic nimiism in the
definitely some basic nimiism in the anti-data center thing, but there's
anti-data center thing, but there's also, you know, you talk to a guy who a
also, you know, you talk to a guy who a year ago his power bill was $290 a month
year ago his power bill was $290 a month and now it's $580 a month. And the
and now it's $580 a month. And the reality is that in blue states where
reality is that in blue states where we've made it impossible to build
we've made it impossible to build additional electricity generation,
additional electricity generation, you're seeing a backlash when people
you're seeing a backlash when people start paying additional power costs.
start paying additional power costs. Now, my response to that is you can't
Now, my response to that is you can't just stop building because of it. What
just stop building because of it. What you've got to do is build the things
you've got to do is build the things that you need, specifically power. So,
that you need, specifically power. So, you know, Elon talks about this all the
you know, Elon talks about this all the time, but I talk about it, too. If you
time, but I talk about it, too. If you look at the amount of power generated by
look at the amount of power generated by the PRC, the People's Republic of China,
the PRC, the People's Republic of China, and compare it to the amount of power
and compare it to the amount of power generated by the United States of
generated by the United States of America in 2005, they crossed the line,
America in 2005, they crossed the line, meaning they started to generate just a
meaning they started to generate just a little bit more power than we did in
little bit more power than we did in 2005. And since then, we have
2005. And since then, we have effectively flatlined. and the PRC now
effectively flatlined. and the PRC now generates three times as much
generates three times as much electricity as the United States of
electricity as the United States of America does. I think that a lot of our
America does. I think that a lot of our problems um are downstream of that
problems um are downstream of that fundamental problem and we just have to
fundamental problem and we just have to build more. We have to build more power.
build more. We have to build more power. We I mean, you know, I I think we have
We I mean, you know, I I think we have to have this vision in the United States
to have this vision in the United States of electricity that is too cheap to
of electricity that is too cheap to meter. And that's I think the way that
meter. And that's I think the way that you push back against some of this
you push back against some of this ridiculous um you know sort of
ridiculous um you know sort of anti-building power comes from the
anti-building power comes from the failure to generate the electricity that
failure to generate the electricity that we need. And I I just I don't understand
we need. And I I just I don't understand how we ever got here as a country. I
how we ever got here as a country. I think the environmental movement
think the environmental movement obviously has a lot to do with it, but
obviously has a lot to do with it, but we've just got to build more power and
we've just got to build more power and that's how we solve this problem
that's how we solve this problem fundamentally. And then you know
fundamentally. And then you know obviously some of this gets into the
obviously some of this gets into the broader AI stuff Jamaimoth and you know
broader AI stuff Jamaimoth and you know the president I think is very rightly
the president I think is very rightly asking the question why is it that the
asking the question why is it that the people who are at the frontier of the AI
people who are at the frontier of the AI economy are throwing up their hands and
economy are throwing up their hands and saying well we've built Frankenstein and
saying well we've built Frankenstein and the solution to Frankenstein apparently
the solution to Frankenstein apparently is to create a one world governance
is to create a one world governance structure for artificial intelligence.
structure for artificial intelligence. What I would say to those people, if
What I would say to those people, if you're building Frankenstein, stop. Or
you're building Frankenstein, stop. Or maybe build, you know, if if the cat is
maybe build, you know, if if the cat is out of the bag, then build the defensive
out of the bag, then build the defensive mechanism against Frankenstein. And, you
mechanism against Frankenstein. And, you know, I I I I I don't know Daario well.
know, I I I I I don't know Daario well. I I've read everything that he said over
I I've read everything that he said over the past couple of weeks. Everybody that
the past couple of weeks. Everybody that I know tells me that he's very earnest,
I know tells me that he's very earnest, that this is a deeply held belief. It's
that this is a deeply held belief. It's not cynical. It's not about regulatory
not cynical. It's not about regulatory capture, that he genuinely cares about
capture, that he genuinely cares about this. But at the same time, I talk to
this. But at the same time, I talk to tech companies. I'm sure you guys talk
tech companies. I'm sure you guys talk to a lot more tech companies than I do.
to a lot more tech companies than I do. At the same time that you have this sort
At the same time that you have this sort of cyber hacking tool that's come out of
of cyber hacking tool that's come out of Anthropic's newest models, you have
Anthropic's newest models, you have companies that are desperate for the
companies that are desperate for the defensive mechanisms to defend against
defensive mechanisms to defend against that cyber hacking tool and they're
that cyber hacking tool and they're being denied access to it. So if you're
being denied access to it. So if you're going to create Frankenstein, don't come
going to create Frankenstein, don't come to the government and say we need
to the government and say we need regulation. look inward and accept that
regulation. look inward and accept that if you're building Frankenstein, number
if you're building Frankenstein, number one, you should stop. And number two,
one, you should stop. And number two, when the companies come to you and say,
when the companies come to you and say, "We need the tools to fight back against
"We need the tools to fight back against Frankenstein," give them those tools.
Frankenstein," give them those tools. >> Right. Oh,
>> Right. Oh, >> it's incredibly common sensical.
>> it's incredibly common sensical. Uh Brad and then maybe Sachs. Yep.
Uh Brad and then maybe Sachs. Yep. >> Mr. Vice President, great to see you. Um
>> Mr. Vice President, great to see you. Um you know, the president called in
you know, the president called in yesterday. He's on top of the AI issue.
yesterday. He's on top of the AI issue. you you're working for somebody who's
you you're working for somebody who's the most incredibly entrepreneurial and
the most incredibly entrepreneurial and risk-taking president perhaps in the
risk-taking president perhaps in the last 50 years. I just had a at a you
last 50 years. I just had a at a you know personal level how is it working
know personal level how is it working with somebody who is willing to take the
with somebody who is willing to take the risk that you know some people you know
risk that you know some people you know Jason criticized some of the things that
Jason criticized some of the things that haven't happened in the first 20 months
haven't happened in the first 20 months but the fact of the matter is unlike a
but the fact of the matter is unlike a lot of people who occupy that office who
lot of people who occupy that office who are just looking to stay the course and
are just looking to stay the course and take the safe path he's taking a lot of
take the safe path he's taking a lot of risks and then you have to help explain
risks and then you have to help explain some of those I would I would put Trump
some of those I would I would put Trump accounts in that category the main
accounts in that category the main street agenda But, you know, just talk
street agenda But, you know, just talk to us a little bit at a personal level
to us a little bit at a personal level how working with him, how hard it is to
how working with him, how hard it is to keep up with his energy, his enthusiasm,
keep up with his energy, his enthusiasm, his entrepreneurialism.
his entrepreneurialism. >> Yeah, Brad, you know him well. He he
>> Yeah, Brad, you know him well. He he sleeps less than any person that I've
sleeps less than any person that I've ever met. I don't sleep that much, but I
ever met. I don't sleep that much, but I certainly sleep more than him. You know,
certainly sleep more than him. You know, Scott Bassin and I always joke that
Scott Bassin and I always joke that he'll call us at 2:30 in the morning and
he'll call us at 2:30 in the morning and he'll say, "Were you up?" And it's like,
he'll say, "Were you up?" And it's like, "No, sir, I wasn't, but I am now. So,
"No, sir, I wasn't, but I am now. So, let's let's talk about what's on your
let's let's talk about what's on your mind." Uh, he's working at all hours of
mind." Uh, he's working at all hours of the day. But but your point, Brad, is is
the day. But but your point, Brad, is is very well taken. He is certainly willing
very well taken. He is certainly willing to take risks. And I I I think, you
to take risks. And I I I think, you know, you ask what it's like working for
know, you ask what it's like working for a guy like that. Well, one, it's never
a guy like that. Well, one, it's never boring. But two, he's constantly
boring. But two, he's constantly probing, are we taking the easy path or
probing, are we taking the easy path or are we taking the right path? And yes,
are we taking the right path? And yes, maybe this thing is going to cause some
maybe this thing is going to cause some political backlash or maybe the payoff
political backlash or maybe the payoff is not going to be obvious until, you
is not going to be obvious until, you know, two years from now, 5 years from
know, two years from now, 5 years from now, 10 years from now. But I think it's
now, 10 years from now. But I think it's the exact right mindset. You know, one
the exact right mindset. You know, one one of the frustrations I've had just
one of the frustrations I've had just looking at the economy, you know, pretty
looking at the economy, you know, pretty much my entire life is there's there's
much my entire life is there's there's been this division between true
been this division between true entrepreneurs and managers, between
entrepreneurs and managers, between bureaucrats and people who are genuinely
bureaucrats and people who are genuinely innovative and willing to take risks. I
innovative and willing to take risks. I think that we've had way too many
think that we've had way too many caretaker presidents during my lifetime.
caretaker presidents during my lifetime. Uh, frankly, way too many caretaker CEOs
Uh, frankly, way too many caretaker CEOs and not enough people who are genuinely
and not enough people who are genuinely innovative and willing to take risks.
innovative and willing to take risks. Obviously, he gets criticized for it
Obviously, he gets criticized for it from time to time, but I'd much rather
from time to time, but I'd much rather have a president who's willing to take
have a president who's willing to take those risks, who's willing to take on
those risks, who's willing to take on the big projects. It's the only way I
the big projects. It's the only way I think you're going to reverse America's
think you're going to reverse America's long-term decline is to be willing to
long-term decline is to be willing to take those risks. Thank God for the past
take those risks. Thank God for the past 18 months, we've had a president willing
18 months, we've had a president willing to do just that.
[applause] >> Uh Mr. Vice President, uh Jake forgot to
>> Uh Mr. Vice President, uh Jake forgot to ask uh his normal gotcha question on
ask uh his normal gotcha question on H1Bs. [laughter] So, um,
H1Bs. [laughter] So, um, >> well, that's because they took my advice
>> well, that's because they took my advice and they raised the price. You were in
and they raised the price. You were in sync on that one.
sync on that one. >> Um, it, you know, it's an issue that the
>> Um, it, you know, it's an issue that the tech community cares about. At the same
tech community cares about. At the same time, we have learned that the program
time, we have learned that the program was riddled with fraud. I'm curious what
was riddled with fraud. I'm curious what can you give us an update on, you know,
can you give us an update on, you know, where do those efforts stand? What, you
where do those efforts stand? What, you know, what's happening with that the
know, what's happening with that the H-1Bs?
H-1Bs? >> Yeah. No, this is the the vin diagram
>> Yeah. No, this is the the vin diagram overlap of Jason Calcconis and Steven
overlap of Jason Calcconis and Steven Miller. It's a very small area.
Miller. It's a very small area. [laughter]
[laughter] But but look man, we we we looked at the
But but look man, we we we looked at the fraud in the system and we said, you
fraud in the system and we said, you know, one, Congress is not going to pass
know, one, Congress is not going to pass a law changing this, there just isn't
a law changing this, there just isn't the political will to do it. So what are
the political will to do it. So what are the things that we can do
the things that we can do administratively to ensure that if a
administratively to ensure that if a tech company is going to try to get an
tech company is going to try to get an H-1B visa, it it's an actual genius.
H-1B visa, it it's an actual genius. It's a person that is going to
It's a person that is going to significantly enrich the tech ecosystem
significantly enrich the tech ecosystem or the American economy. you know,
or the American economy. you know, you're not just replacing one accountant
you're not just replacing one accountant who makes $60,000 with a lower wage
who makes $60,000 with a lower wage foreign accountant who makes $45,000 a
foreign accountant who makes $45,000 a year. That is not what the program
year. That is not what the program exists for. And so, we came up with this
exists for. And so, we came up with this idea to impose $100,000 fee. We're also
idea to impose $100,000 fee. We're also looking at various ways of preventing
looking at various ways of preventing companies that use H-1B visas from
companies that use H-1B visas from laying off a bunch of American workers.
laying off a bunch of American workers. Uh so, you know, one of the the things
Uh so, you know, one of the the things that I find just shocking about this is
that I find just shocking about this is you'll have a company that applies for
you'll have a company that applies for an H-1B and they'll say, "Oh, we're
an H-1B and they'll say, "Oh, we're desperate for workers. we can't find the
desperate for workers. we can't find the workers. And then you go and look at
workers. And then you go and look at their history and they've laid off 5,000
their history and they've laid off 5,000 people. Well, that's ridiculous. If
people. Well, that's ridiculous. If you're laying off American workers, you
you're laying off American workers, you shouldn't be going to the market
shouldn't be going to the market searching for foreign workers to replace
searching for foreign workers to replace them. So, we're doing a lot within the
them. So, we're doing a lot within the confines, of course, of what we're
confines, of course, of what we're allowed to do legally. We've gotten sued
allowed to do legally. We've gotten sued on some of this stuff, but I think
on some of this stuff, but I think fundamentally we're on the right on both
fundamentally we're on the right on both the law and the policy. The H1B should
the law and the policy. The H1B should not exist to replace American workers
not exist to replace American workers with low-wage foreigners. It should
with low-wage foreigners. It should exist to enrich the American economy.
exist to enrich the American economy. And that's exactly what we're trying to
And that's exactly what we're trying to make sure it does.
make sure it does. >> Mr. Vice President, can I can I ask um
>> Mr. Vice President, can I can I ask um you're you're I I think you're you're
you're you're I I think you're you're titled the frauds are now. And just
titled the frauds are now. And just going back to the the um the deficit
going back to the the um the deficit question, every week we're seeing these
question, every week we're seeing these videos. You know, we've got Nick Shirley
videos. You know, we've got Nick Shirley here this afternoon. I think he really
here this afternoon. I think he really started this trend of some of the
started this trend of some of the citizen journalists going out and trying
citizen journalists going out and trying to find the fraud in the system
to find the fraud in the system themselves. And every week there's a new
themselves. And every week there's a new story that's being uncovered that's just
story that's being uncovered that's just mind-blowing. tens of billions of
mind-blowing. tens of billions of dollars over and over again. How much
dollars over and over again. How much fraud do you think there? And and you
fraud do you think there? And and you know this California highspeed rail,
know this California highspeed rail, there was a guy that got paid half a
there was a guy that got paid half a billion dollars for not working. Some
billion dollars for not working. Some billionaire in Italy who owns a football
billionaire in Italy who owns a football team. I couldn't believe it. I I tracked
team. I couldn't believe it. I I tracked all this stuff and I'm like it just your
all this stuff and I'm like it just your head starts to spin. How much of our $7
head starts to spin. How much of our $7 trillion federal spending do you think
trillion federal spending do you think is tied up in fraud, in this kind of
is tied up in fraud, in this kind of system of waste and this corruption? And
system of waste and this corruption? And what's your sense of the scale of the
what's your sense of the scale of the the problem?
the problem? Yeah. So, to two quick things on that.
Yeah. So, to two quick things on that. First of all, you know, Elon during the
First of all, you know, Elon during the height of Doge said that it was 20%,
height of Doge said that it was 20%, that's $1.4 trillion. Uh whether it's
that's $1.4 trillion. Uh whether it's 10% or 20%, you're talking about
10% or 20%, you're talking about something on the scale of hundreds and
something on the scale of hundreds and hundreds of billions of dollars. The
hundreds of billions of dollars. The biggest problem with finding fraud is is
biggest problem with finding fraud is is actually that the states where it's
actually that the states where it's worst are also the states that have the
worst are also the states that have the least willingness to cooperate with what
least willingness to cooperate with what we're doing. So when you look at some of
we're doing. So when you look at some of the bigger ticket items for fraud, you
the bigger ticket items for fraud, you know, you're looking at Medicare fraud
know, you're looking at Medicare fraud in California, people who are illegal,
in California, people who are illegal, people who aren't even like human
people who aren't even like human beings. They're just like a completely
beings. They're just like a completely madeup, you know, shell of a person. Uh
madeup, you know, shell of a person. Uh but but unfortunately, the the state of
but but unfortunately, the the state of California is not actually helping us
California is not actually helping us fight back against that particular
fight back against that particular fraud. or we know that there are
fraud. or we know that there are hundreds [snorts] of thousands maybe
hundreds [snorts] of thousands maybe more illegal aliens in Illinois, New
more illegal aliens in Illinois, New York and California who are on Medicaid.
York and California who are on Medicaid. That obviously is billions and billions
That obviously is billions and billions of dollars to provide health care uh to
of dollars to provide health care uh to those people. So the the the basic fraud
those people. So the the the basic fraud that exists is the big programs in
that exists is the big programs in states that have allowed themselves to
states that have allowed themselves to be overrun by illegal immigration.
be overrun by illegal immigration. Another very good example, and this was
Another very good example, and this was shocking to me when we came in and
shocking to me when we came in and started doing this work, is the way the
started doing this work, is the way the SNAP program, this is the food stamp
SNAP program, this is the food stamp program that ensures that low-income
program that ensures that low-income Americans have access to food that they
Americans have access to food that they need. Obviously, one of the most
need. Obviously, one of the most important things that we do in the
important things that we do in the federal government is make sure that,
federal government is make sure that, you know, poor kids can eat. But that
you know, poor kids can eat. But that program is rife with fraud in part
program is rife with fraud in part because the way it works is, you know,
because the way it works is, you know, California bills us once a month for the
California bills us once a month for the cost of their SNAP program. It's seven
cost of their SNAP program. It's seven or eight or 9 billion depending on the
or eight or 9 billion depending on the month that we're talking about. So what
month that we're talking about. So what happens is the federal government wires
happens is the federal government wires $9 billion to California, no questions
$9 billion to California, no questions asked. So, it's not an exaggeration to
asked. So, it's not an exaggeration to say that we have no ability to know who
say that we have no ability to know who is even on the SNAP program, whether
is even on the SNAP program, whether they're a real human being, whether
they're a real human being, whether they're a legal resident of the United
they're a legal resident of the United States of America. And when we go to the
States of America. And when we go to the big blue states and say, "Why don't you
big blue states and say, "Why don't you help us just confirm basic eligibility?"
help us just confirm basic eligibility?" We get totally push back. We we get no
We get totally push back. We we get no cooperation on this basic fact of good
cooperation on this basic fact of good governance, confirming eligibility for
governance, confirming eligibility for federal programs. So my guess is that if
federal programs. So my guess is that if the number is $700 billion, a few
the number is $700 billion, a few hundred billion of that is in the blue
hundred billion of that is in the blue states and we could deal with it just by
states and we could deal with it just by checking eligibility criteria. We're
checking eligibility criteria. We're working on innovative ways to force
working on innovative ways to force that. But it's actually legally much
that. But it's actually legally much harder than it should be to force the
harder than it should be to force the blue states to comply with some basic
blue states to comply with some basic anti-fraud initiatives.
anti-fraud initiatives. >> Uh JD, before we wrap here, I want to
>> Uh JD, before we wrap here, I want to ask you another hard question. Um this
ask you another hard question. Um this one about our relationship with the
one about our relationship with the state of Israel and the president's
state of Israel and the president's relationship with BB Netanyahu. Um many
relationship with BB Netanyahu. Um many people in the Republican party, MAGA are
people in the Republican party, MAGA are now moving to a new party, America
now moving to a new party, America first, America only. There's a rise in
first, America only. There's a rise in anti-semitism and there's a persistent
anti-semitism and there's a persistent belief amongst a lot of the people on
belief amongst a lot of the people on the right that maybe our foreign policy
the right that maybe our foreign policy is too influenced by the state of Israel
is too influenced by the state of Israel or BB Netanyahu. Can you take us into
or BB Netanyahu. Can you take us into the relationship right now where it
the relationship right now where it stands uh and and and the you know the
stands uh and and and the you know the administration's position on
administration's position on collaborating with Israel on a lot of
collaborating with Israel on a lot of these military activities?
these military activities? >> Yeah. You know what the president has
>> Yeah. You know what the president has said, Jason, is obviously Israel has
said, Jason, is obviously Israel has been an important partner when it comes
been an important partner when it comes to military technology, when it comes to
to military technology, when it comes to intelligence sharing, but also sometimes
intelligence sharing, but also sometimes the United States doesn't always agree
the United States doesn't always agree with Israel. And I think that more than
with Israel. And I think that more than frankly any president in the last 40
frankly any president in the last 40 years, he has shown a willingness uh to
years, he has shown a willingness uh to actually part ways with BB Netanyahu
actually part ways with BB Netanyahu when he feels like the interests of the
when he feels like the interests of the American people are different from the
American people are different from the interests of of the government of
interests of of the government of Israel. And I find it a little ironic,
Israel. And I find it a little ironic, Jason, that you have Democrats
Jason, that you have Democrats criticizing Donald Trump for his
criticizing Donald Trump for his relationship with BB when Donald Trump
relationship with BB when Donald Trump is the one president of the last 40
is the one president of the last 40 years who's been willing to say, you
years who's been willing to say, you know what, yeah, BB's a good partner,
know what, yeah, BB's a good partner, but also BB and I have a different
but also BB and I have a different opinion on this, or BB's wrong about
opinion on this, or BB's wrong about this, or maybe BB's right about this
this, or maybe BB's right about this from the perspective of Israel, but the
from the perspective of Israel, but the American people need us to go in a
American people need us to go in a different direction. So I I I just think
different direction. So I I I just think that rooting this relationship like all
that rooting this relationship like all relationships in America's interest is
relationships in America's interest is the way to actually have a rational
the way to actually have a rational conversation here because when you're
conversation here because when you're talking about whether a given policy is
talking about whether a given policy is in America's interest and you keep
in America's interest and you keep yourself laser focused on that, I think
yourself laser focused on that, I think that's how you make sure that the
that's how you make sure that the American people know that you're
American people know that you're fighting for them. But I also think that
fighting for them. But I also think that it allows us to actually rationally
it allows us to actually rationally focus and force ourselves to have a
focus and force ourselves to have a conversation about when something that
conversation about when something that maybe sounded good or maybe has become a
maybe sounded good or maybe has become a cliche or a slogan for the past 20 or 30
cliche or a slogan for the past 20 or 30 years. Well, maybe we have to do
years. Well, maybe we have to do something different now. And I I think
something different now. And I I think that that's how we have to approach not
that that's how we have to approach not just this relationship but all
just this relationship but all relationships. By by the way, you you
relationships. By by the way, you you see a similar push back when the
see a similar push back when the president makes the argument that he's
president makes the argument that he's made about NATO, which is yes, obviously
made about NATO, which is yes, obviously a lot of important relationships, a lot
a lot of important relationships, a lot of important partnerships in NATO, but
of important partnerships in NATO, but that doesn't mean that we're going to
that doesn't mean that we're going to completely make our European foreign
completely make our European foreign policy subservient to NATO in the same
policy subservient to NATO in the same way that we cannot let our Middle
way that we cannot let our Middle Eastern foreign policy be subservient to
Eastern foreign policy be subservient to the state of Israel. We're going to work
the state of Israel. We're going to work with people when we work with them.
with people when we work with them. We're going to disagree when we
We're going to disagree when we disagree. And we're going to pursue
disagree. And we're going to pursue America's interest. That's the only way
America's interest. That's the only way to have a rational foreign policy.
to have a rational foreign policy. >> I know Trum wants to get one last
>> I know Trum wants to get one last question in here. Um, just before he
question in here. Um, just before he does, uh, tell us, how's Marco Rubio
does, uh, tell us, how's Marco Rubio doing in his job so far? Can you rate
doing in his job so far? Can you rate his performance in the first two years?
>> He's doing great, man. I love Marco. Jason, the the funniest media narrative
Jason, the the funniest media narrative is that somehow Marco and I are like
is that somehow Marco and I are like hyper competitive and we sit around like
hyper competitive and we sit around like thinking about, you know, how we're
thinking about, you know, how we're going to run for president against each
going to run for president against each other in 2028. Like I I literally What
other in 2028. Like I I literally What time is it right now? It's 2:25. I have
time is it right now? It's 2:25. I have a call with Marco in five minutes. So
a call with Marco in five minutes. So Chimat's got to ask his question first.
Chimat's got to ask his question first. I got to answer it quickly and then
I got to answer it quickly and then Marco and I have to go do the business
Marco and I have to go do the business of the American people. He's a great
of the American people. He's a great dude. He's a great human being. He's
dude. He's a great human being. He's doing a great job, too.
doing a great job, too. >> So maybe maybe as we wrap, um there's a
>> So maybe maybe as we wrap, um there's a very consequential midterm coming up. I
very consequential midterm coming up. I think uh a poll on one day will say that
think uh a poll on one day will say that the Republicans are going to keep, you
the Republicans are going to keep, you know, everything as is. the poll on the
know, everything as is. the poll on the other day say it's going to be a
other day say it's going to be a socialist sweep of America. It's very
socialist sweep of America. It's very complicated, but can you just give us
complicated, but can you just give us some insight into what's actually
some insight into what's actually happening on the ground and what is the
happening on the ground and what is the message that needs to be delivered so
message that needs to be delivered so that folks can uh come to the right
that folks can uh come to the right conclusion November?
conclusion November? >> You know, I guess I have two basic
>> You know, I guess I have two basic messages there is a lot of good that
messages there is a lot of good that we've done over the past 18 months. We
we've done over the past 18 months. We cut taxes bigly. We cut taxes on
cut taxes bigly. We cut taxes on overtime, social security, and tips.
overtime, social security, and tips. Those are tax cuts for middle American
Those are tax cuts for middle American workers, not just for the elites in in
workers, not just for the elites in in Washington and New York City. Uh we've
Washington and New York City. Uh we've had an amazing success with the border
had an amazing success with the border with immigration. We've pursued H-1B
with immigration. We've pursued H-1B reform that prioritizes American workers
reform that prioritizes American workers over foreign nationals. There's a lot of
over foreign nationals. There's a lot of good that's been done, but there's a lot
good that's been done, but there's a lot of work left to do. Don't give power to
of work left to do. Don't give power to the people who cause the problems that
the people who cause the problems that we're fixing. give us another chance or
we're fixing. give us another chance or give us another couple of years to
give us another couple of years to continue to work on the amazing things
continue to work on the amazing things that we've been doing for the past 2
that we've been doing for the past 2 years. And the second argument I'd make
years. And the second argument I'd make is even if you don't agree with us on
is even if you don't agree with us on every issue, the other party is consumed
every issue, the other party is consumed by craziness. They're consumed by people
by craziness. They're consumed by people who want to steal everything, who want
who want to steal everything, who want to give the country over to illegal
to give the country over to illegal aliens and criminals. They actively brag
aliens and criminals. They actively brag about about it. I mean, I've heard a lot
about about it. I mean, I've heard a lot of crazy stuff, guys, over the past, you
of crazy stuff, guys, over the past, you know, few years in politics. But when I
know, few years in politics. But when I heard somebody running for Congress in
heard somebody running for Congress in New York say that July 4th was about the
New York say that July 4th was about the liberation of Puerto Rico and Palestine,
liberation of Puerto Rico and Palestine, I thought to myself, this person needs
I thought to myself, this person needs to be checked into a mental hospital
to be checked into a mental hospital hospital, not given a seat in Congress.
hospital, not given a seat in Congress. So to the American people, I'd say send
So to the American people, I'd say send these people packing. Put them in the
these people packing. Put them in the middle hospital. Do not put them in
middle hospital. Do not put them in Congress. Because even if you don't
Congress. Because even if you don't agree with us on every policy issue, at
agree with us on every policy issue, at least we're motivated by common sense
least we're motivated by common sense and American interest, they're just
and American interest, they're just motivated by left-wing interest groups
motivated by left-wing interest groups and radicalism, and they're going to do
and radicalism, and they're going to do a very bad job if we give them power.
a very bad job if we give them power. >> All right, ladies and gentlemen, Vice
>> All right, ladies and gentlemen, Vice President J.
President J. >> Thank you all. Good to see you guys.
>> Thank you all. Good to see you guys. [music]
