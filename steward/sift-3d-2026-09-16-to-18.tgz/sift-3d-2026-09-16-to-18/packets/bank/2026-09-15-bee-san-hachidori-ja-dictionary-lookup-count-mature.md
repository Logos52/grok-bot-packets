---
id: 2026-09-15-bee-san-hachidori-ja-dictionary-lookup-count-mature
kind: article
title: Hachidori — JA dictionary lookup-count + mature-Anki definition blur
source: "https://github.com/bee-san/hachidori"
author: bee-san
published: 2026-09-02
captured: 2026-09-15
via: grok-bot/Field
lane: learning
status: raw
private: false
---

=== README ===
<p align="center">
  <img src="docs/assets/hachidori.png" width="180" alt="Hachidori pink and lilac hummingbird logo">
</p>

<h1 align="center">Hachidori</h1>

<p align="center"><strong>The fastest, most feature rich Japanese dictionary app in the world</strong></p>

<p align="center">
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-GPL--3.0--or--later-7c3aed" alt="GPL-3.0-or-later license"></a>
  <a href="#install-in-15-seconds"><img src="https://img.shields.io/badge/Chrome-128%2B-4285F4?logo=googlechrome&logoColor=white" alt="Chrome 128 or newer"></a>
  <a href="docs/privacy.md"><img src="https://img.shields.io/badge/dictionary_engine-local-0f766e" alt="Dictionary engine runs locally"></a>
  <a href="https://sonarcloud.io/summary/new_code?id=bee-san_hachidori"><img src="https://sonarcloud.io/api/project_badges/measure?project=bee-san_hachidori&metric=alert_status" alt="SonarQube Cloud quality gate"></a>
  <a href="https://github.com/bee-san/hachidori"><img src="https://img.shields.io/github/stars/bee-san/hachidori?style=flat&logo=github&color=f59e0b" alt="GitHub stars"></a>
</p>

<p align="center">
  <a href="#install-in-15-seconds">Install</a> ·
  <a href="benchmark/README.md">Benchmarks</a> ·
  <a href="docs/architecture.md">Architecture</a> ·
  <a href="extension/README.md">Extension</a> ·
  <a href="docs/sharing.md">Sharing</a> ·
  <a href="docs/chrome-web-store.md">Chrome Web Store guide</a> ·
  <a href="docs/privacy.md">Privacy</a> ·
  <a href="CONTRIBUTING.md">Contributing</a>
</p>

Hachidori is a blazing fast Japanese Dictionary Chrome Extension that is feature rich and optionated.

## Install in 15 seconds

Click <a href="https://chromewebstore.google.com/detail/hachidori/mikpaebfdmidjnopgffchicnmoahhcbe">here to install from Chrome store.</a> (note: this will always lag behind the repo and may have bugs fixed in the repo)

<p align="center">
  <img src="docs/assets/install-in-60-seconds.gif" alt="Animated walkthrough of Hachidori's first-run setup, dictionary installation, Anki detection, and Japanese lookup" width="720">
</p>

# Blazing Fast

Hachidori is 83 times faster than the worlds most popular Japanese dictionary app at importing dictionaries.

<img width="1672" height="941" alt="ChatGPT Image Sep 9, 2026, 09_18_59 AM" src="https://github.com/user-attachments/assets/c507c940-f61e-4063-8d2c-9e43184cd7d3" />

See [the measured results](docs/browser-performance.md).

# Media mining

<img width="917" height="362" alt="Screenshot 2026-09-09 at 11 26 31" src="https://github.com/user-attachments/assets/c0f6d1b5-187d-45b7-9bda-aadf32879586" />

Hachidori can record your screen and capture sentence audio + a gif. Not just in Chrome but in all windows on your desktop.

This feature is **experimental** and may not work very well. I may remove it or reduce it also.

See [Media mining setup, limits, and verification](docs/media-capture.md).

# Custom Dictionary

Do you keep on seeing a name pop up over & over again in a book, but it's not in the dictionary?

With Hachidori, you can highlight the word and add it as a custom definition.

<p align="center">
  <img src="docs/assets/custom-dictionary.gif" alt="Animated demonstration of adding and viewing a custom dictionary definition in Hachidori" width="720">
</p>

# Lookup blur

Sometimes we fall into a trap of looking up a word over & over again, but never learning it.

Hachidori records how many times you have looked up a word and can blur it for you for a few seconds to force you to remember it.

It can even use anki.

<p align="center">
  <img src="docs/assets/lookup-blur.gif" alt="Animated demonstration of Hachidori blurring repeated lookups before revealing their definitions" width="720">
</p>

# Sharing

Set up Hachidori once and use that setup from every other Hachidori, in GameSentenceMiner, another browser or another computer. Same dictionaries and settings used across multiple Hachidoris.

Install [Hachidori Relay for Anki](https://github.com/bee-san/hachidori-anki)
from **Settings → Sharing → Download the Anki add-on**, then follow the
[sharing guide](docs/sharing.md) to link your other browsers.

<img width="775" height="471" alt="Screenshot 2026-09-14 at 14 19 41" src="https://github.com/user-attachments/assets/991d570a-599e-4277-8736-c72b2f371ed0" />

# Optionated

Hachidori is an optionated program. If it does not benefit me, the creator, personally than I will not add that feature.

I do this because I am a pretty average learner, and if I make this tool great for myself than I am making it great for the average Japanese learner.

# AI Usage

This program was created with the assistance of AI. I used GPT 5.6 Ultra, and then GPT 6.0 Astra Ultra exclusively. When Codex goes down, I use Fable 5.1 with ultrathink and ultracode.

I have reviewed all plans, I set the direction of how this program works. Large parts of the program such as the actual dictionary core are hand-written.

I also have personally been using this for months, and as I am the main user of this program I find bugs pretty often which I fix.

The assets used are AI generated. If you are an artist and want to contribute to open source, please feel free to make a real logo or a visual novel style background.

## Credits

The logo pack and six visual novel backgrounds were supplied by bee-san. See the
[asset ownership and publishing record](docs/asset-rights.md) for the original
assets and their copyright declaration.

Hachidori is powered by [hoshidicts](https://github.com/Manhhao/hoshidicts) by Manhhao. Its popup renderer, structured-content renderer, furigana segmentation, and CSS are ported from [GameSentenceMiner PR #549](https://github.com/bpwhelan/GameSentenceMiner/pull/549), which adapts [Hoshi Reader](https://github.com/Manhhao/Hoshi-Reader) and [Yomitan](https://github.com/yomidevs/yomitan). See the full [renderer attribution](extension/render/ATTRIBUTION.md).

## License

Hachidori is available under [GPL-3.0-or-later](LICENSE), matching hoshidicts and the ported GameSentenceMiner code.

=== docs/lookup-statistics.md ===
# Lookup counts

Settings → Reading → Lookup history controls recording and display. It is on by
default. Turning it off keeps existing history but stops new increments. The
Design preview uses a fixed sample count and never records a lookup.

A successful new reader request records its primary result's canonical term and
reading, not the inflected search text. Readings remain distinct. Misses and
obsolete replies do not count. Internal links and clicked-kanji term entries
are independent visits; native kanji entries are not term lookups. Tabs,
expansion, Back, and Note refresh reuse the original visit. A lost statistics
reply is never retried as an increment.

The All tab shows the primary result's count. A dictionary/group projection may
display another expression, so it does not borrow that count. Definitions do
not wait for storage: counts arrive independently, guarded by the current
request and committed statistics namespace. Statistics changes do not reload
dictionaries or invalidate lookup results.

![Local lookup history controls](assets/lookup-statistics-settings.png)

Lookup history belongs to Hachidori and stays in this browser. Recording and
reading a count never contacts another application or service. Old external
corpus connection settings are ignored; restoring an older backup discards those
retired fields while preserving its other preferences and lookup history.

The service worker serializes updates. Each lookup reads a descriptor and one
term/reading row, then writes that row and the advanced descriptor together;
it does not scan or rewrite the collection. Terms and readings are trimmed and
NFC-normalized, with JSON-pair keys preserving delimiter identity. Counts and
## Definition blur

Settings → Reading → Definition blur hides definitions, compact summaries and
reading furigana behind a blur until you recall the word. Both rules are off by
default and can be enabled independently; a match from either rule qualifies.
**Blur definitions by lookup count** needs lookup counts. Choose **At least**
to blur words looked up the threshold number of times (default 5) or more, or
**Below** to blur words looked up fewer times. Zero is a valid Below count. The decision uses the same count the popup displays, after
the current lookup is recorded.

**Blur definitions for mature Anki words** works even with lookup counts off.
It checks the first result's canonical expression against the configured Anki
note type across all decks. A word qualifies if at least one matching card is
in review with an interval of **21 days or more**, following
[Anki's card states](https://docs.ankiweb.net/getting-started.html#card-states).
New, learning and relearning cards do not qualify. The mining deck and duplicate
scope do not restrict this check; the reading and inflected search text do not
form part of the match.

In Settings → Anki, map **Expression** to a dedicated field, or use a field
template containing only `{expression}`. Templates that combine the expression
with other text, readings or markup cannot identify the word through this check.
A missing or unsupported mapping leaves maturity unavailable without changing
the mapping. The Design preview uses a fixed mature sample with three lookups,
without contacting Anki or recording history.

The check makes one read-only AnkiConnect `findCards` request after the result
renders. It does not add or edit notes, cards or scheduling data. The existing
AnkiConnect timeout bounds the wait; Anki being closed, denied access, malformed
responses and other errors leave this rule unqualified. There is no persistent
known-word cache: each new lookup checks again, and only the count rule remains
available offline. Dictionary lookup never waits for Anki.

![Lookup-count and mature-Anki definition blur controls](assets/anki-mature-blur-settings.png)

A new lookup renders blurred while an enabled rule is undecided. A qualifying
rule keeps the blur; when neither qualifies, including unavailable checks,
definitions reveal. Hovering a definition or the compact summary
reveals in either mode. With the timed reveal, one deadline runs from the
first display: navigating to a kanji entry or another word cancels the live
timer, and Back continues with the remaining time rather than restarting, as
does a page restored from the back/forward cache. The decision belongs to that
lookup, so tabs, Show more, a Note refresh and Back keep it; a later count for
the same word never blurs a revealed view, and a different lookup starts
fresh. A lookup made before the saved settings have loaded waits for them.
Native kanji entries are outside term blur; term entries reached through a
clicked kanji participate.

Automatic pronunciation waits until the definitions are revealed, so the audio
does not give the reading away while they are blurred. The first count snapshot
and Anki result decide the blur once for the whole visit. A result that does not
qualify reveals and plays at once; a blurred result plays once when hover, the
deadline or disabling blur reveals it. Pressing the Audio button while blurred
plays it then instead, and nothing replays at the reveal.

Turning both rules off reveals open popups without touching a Note draft.
Disabling lookup counts removes only the count rule. Changes to Anki settings
invalidate pending and completed maturity evidence, including a word retained
for Back; old replies cannot blur the current view.
Revealed definitions never become blurred again during the same lookup. Other
live edits apply to unrevealed popups from their original display time. With
Anki blur off, the original count behavior and lookup path are unchanged.
