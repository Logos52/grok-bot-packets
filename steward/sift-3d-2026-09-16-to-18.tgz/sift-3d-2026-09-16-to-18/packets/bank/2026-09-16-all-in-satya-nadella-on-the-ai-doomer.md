---
id: 2026-09-16-all-in-satya-nadella-on-the-ai-doomer
kind: podcast
title: Satya Nadella on the AI Doomer Slowdown, Microsoft's Master Plan & Who Wins AI
source: "https://www.youtube.com/watch?v=hdcsTeCFE0I"
author: All-In Podcast
published: 2026-09-15
captured: 2026-09-16
via: grok-bot/Recap
lane: ideas
status: raw
private: false
---

has generated $250 [music] billion with a B in market value for Microsoft. Scott
a B in market value for Microsoft. Scott Nadella, chairman and CEO of Microsoft.
Nadella, chairman and CEO of Microsoft. >> Since you've been the CEO, three and a
>> Since you've been the CEO, three and a half years, the [music] stock is up
half years, the [music] stock is up about uh I guess it's about 120%. I'm
about uh I guess it's about 120%. I'm good for my 80 billion. I am going to
good for my 80 billion. I am going to spend $80 billion building out Azure.
spend $80 billion building out Azure. [music] Maybe after the industrial
[music] Maybe after the industrial revolution, this is the biggest thing.
revolution, this is the biggest thing. That's our goal with our frontier model.
That's our goal with our frontier model. Our model should be the [music] best
Our model should be the [music] best model that they can use as a base. We
model that they can use as a base. We create technology so that others can
create technology so that others can create more technology. That's who we
create more technology. That's who we are. [music] We're tool maker.
are. [music] We're tool maker. >> Please welcome Satia Nadella.
>> Please welcome Satia Nadella. >> All right.
>> Hi guy. Good to see you coming out.
>> Good to see you.
>> Good morning guys. >> How are you?
>> How are you? >> Good.
>> Good. >> Thanks for joining us.
>> Thanks for joining us. >> Crazy weekend, but here we are. Do we
>> Crazy weekend, but here we are. Do we need to paste the frontier?
need to paste the frontier? [laughter]
>> So, let's start with the common sense part first, which is we should do what
part first, which is we should do what it takes to build stuff that serves
it takes to build stuff that serves humanity first and is in human control.
humanity first and is in human control. You know, it's kind of crazy that we
You know, it's kind of crazy that we have to start with that level of common
have to start with that level of common sense, but I think it's a good place.
sense, but I think it's a good place. Then when I think about pacing whatever
Then when I think about pacing whatever the first thing that at least I believe
the first thing that at least I believe is the broad diffusion of this
is the broad diffusion of this technology is the most critical thing
technology is the most critical thing because the benefits of this tech
because the benefits of this tech showing up everywhere is really what's
showing up everywhere is really what's all about right so at the end of the day
all about right so at the end of the day if you sort of say serving humanity let
if you sort of say serving humanity let it actually reach humanity in ways that
it actually reach humanity in ways that it serves humanity and that means you
it serves humanity and that means you got to have choice you have to have
got to have choice you have to have compet competition. You have to have all
compet competition. You have to have all kinds of business models whether they're
kinds of business models whether they're open weights, close weights, what have
open weights, close weights, what have you. Then the other aspect I think that
you. Then the other aspect I think that is not talked about when we talk about
is not talked about when we talk about control is actually the control that for
control is actually the control that for example customers have, enterprises or
example customers have, enterprises or businesses have around this technology
businesses have around this technology because sometimes this is so opaque,
because sometimes this is so opaque, right? I want my privacy. I want to be
right? I want my privacy. I want to be able to embed my knowledge in a set of
able to embed my knowledge in a set of weights I control. I want to see all of
weights I control. I want to see all of the coot uh that's being generated. I
the coot uh that's being generated. I want to use it to do fine-tuning of my
want to use it to do fine-tuning of my own models. My IP shouldn't leak. So,
own models. My IP shouldn't leak. So, there's an entire body of things that
there's an entire body of things that nobody's talking about as much, which is
nobody's talking about as much, which is my I really want to make sure that this
my I really want to make sure that this tech is in my control. Then we get to uh
tech is in my control. Then we get to uh what is I think a real issue of safety
what is I think a real issue of safety and we should take it seriously which is
and we should take it seriously which is we should take all the time we want uh
we should take all the time we want uh to test things. In fact I love this idea
to test things. In fact I love this idea of having third party testers. Oh wow.
of having third party testers. Oh wow. You know I you know I grew up in a
You know I you know I grew up in a company that's always done testing. Uh
company that's always done testing. Uh so it's novel that we should say wow
so it's novel that we should say wow they're having embedded third party
they're having embedded third party testers. Why not? It's a great idea. In
testers. Why not? It's a great idea. In fact, the only thing I would say is we
fact, the only thing I would say is we should avoid like these, you know, cozy
should avoid like these, you know, cozy arrangements of who's testing what, who
arrangements of who's testing what, who has access to what, and it should be
has access to what, and it should be broad.
broad. >> Were you were you surprised though when
>> Were you were you surprised though when both the essay landed and then it seemed
both the essay landed and then it seemed like there was a circling of the wagons
like there was a circling of the wagons amongst the frontier companies? I
amongst the frontier companies? I >> I I think that it comes my my suspicion
>> I I think that it comes my my suspicion is it comes genuinely from this place
is it comes genuinely from this place where when you start seeing in fact it's
where when you start seeing in fact it's fascinating, right? We are when you
fascinating, right? We are when you start seeing reward hacking um and
start seeing reward hacking um and what's happening in these environments
what's happening in these environments right with these agent swarms there is
right with these agent swarms there is the mundane there is some DevOps error
the mundane there is some DevOps error where somebody misconfigured
where somebody misconfigured a container [laughter]
a container [laughter] >> right right or these API keys
>> right right or these API keys >> or an API keys or yeah exactly there's
>> or an API keys or yeah exactly there's no monitoring uh there's internet access
no monitoring uh there's internet access there's sort of classic I would call it
there's sort of classic I would call it basic devops and then there is real
basic devops and then there is real novel new stuff right which is what is
novel new stuff right which is what is this uh reward board hacking uh that you
this uh reward board hacking uh that you know with these persistent agents and so
know with these persistent agents and so on and that's a place where I'll admit
on and that's a place where I'll admit that the science is not there it's I
that the science is not there it's I thought Yakob's post which is a good one
thought Yakob's post which is a good one which he said he called it we're growing
which he said he called it we're growing intelligence not building intelligence
intelligence not building intelligence so it's an experimental science and so
so it's an experimental science and so the more experimental sciences uh then
the more experimental sciences uh then you really need to make sure you're
you really need to make sure you're doing those experiments in controlled
doing those experiments in controlled environments if anything the place where
environments if anything the place where I would love is taking even the hugging
I would love is taking even the hugging face incident in other places more
face incident in other places more transparency on what would it take in
transparency on what would it take in fact one of the fascinating things right
fact one of the fascinating things right now is the insider risk I mean think
now is the insider risk I mean think about it right if you're sitting in an
about it right if you're sitting in an enterprise this is all test time compute
enterprise this is all test time compute by the way right so it's not like oh
by the way right so it's not like oh it's going to only happen when in some
it's going to only happen when in some training run it can happen for a very
training run it can happen for a very mundane task uh that I give one of these
mundane task uh that I give one of these frontier models inside an enterprise uh
frontier models inside an enterprise uh where I say you know I don't I was you
where I say you know I don't I was you know telling David this suppose I say
know telling David this suppose I say hey go optimize my working capital it
hey go optimize my working capital it may fake my books uh right [laughter]
may fake my books uh right [laughter] because this is like a new type of
because this is like a new type of insider risk
insider risk >> and so what is the way to do that I
>> and so what is the way to do that I would say oh go build a maybe a causal
would say oh go build a maybe a causal model like a semantic model that
model like a semantic model that actually checks and verifies so I think
actually checks and verifies so I think there's a lot of product building um I I
there's a lot of product building um I I would say making things more robust
would say making things more robust which is classic engineering that we
which is classic engineering that we should be talking a lot more about
should be talking a lot more about transparently versus saying hey this is
transparently versus saying hey this is so mystical that you know we can't
so mystical that you know we can't figure this out. Do you do you buy this
figure this out. Do you do you buy this argument that it's mystical?
argument that it's mystical? >> I I mean I I buy the argument that we do
>> I I mean I I buy the argument that we do not understand the latent space. Uh
not understand the latent space. Uh right other than I thought you know as
right other than I thought you know as you said like do we understand the
you said like do we understand the brain? We don't. We do functional MRIs
brain? We don't. We do functional MRIs and do neuroscience and we're trying to
and do neuroscience and we're trying to figure this out continuously getting a
figure this out continuously getting a little better understanding. So I do
little better understanding. So I do think that in that sense we don't
think that in that sense we don't exactly uh have a complete un that's why
exactly uh have a complete un that's why by the way I also I don't believe in new
by the way I also I don't believe in new release right so that's why I think
release right so that's why I think making sure that the coots are in
making sure that the coots are in language that we can all understand in
language that we can all understand in fact they're transparent so that when
fact they're transparent so that when when I go back to an enterprise that's
when I go back to an enterprise that's using all these models and if you have
using all these models and if you have the full coot uh then you can
the full coot uh then you can >> chain of thought
>> chain of thought >> chain of thought and so then you can
>> chain of thought and so then you can really go look at it deeply in fact you
really go look at it deeply in fact you can have multiple models uh and you can
can have multiple models uh and you can look at the coot across those I think
look at the coot across those I think these are all things that I think will
these are all things that I think will become very important
become very important >> satia you've worked with you've worked
>> satia you've worked with you've worked with technologists for decades
with technologists for decades uh and when you see as a leader of one
uh and when you see as a leader of one company Microsoft which has very crisp
company Microsoft which has very crisp communications with the public uh and
communications with the public uh and you see what's happening with Daario and
you see what's happening with Daario and his team people coming out saying 10%
his team people coming out saying 10% chance we all die uh what do you think
chance we all die uh what do you think is going through those technologists
is going through those technologists minds. Do you believe they actually
minds. Do you believe they actually believe that this is going to kill
believe that this is going to kill humanity or are they going through some
humanity or are they going through some psychosis or are they seeing something
psychosis or are they seeing something working on those frontier models that is
working on those frontier models that is terrorizing them? You're not a
terrorizing them? You're not a psychologist, but you have worked with
psychologist, but you have worked with technologists for a long time. Handicap
technologists for a long time. Handicap what's going on in these organizations
what's going on in these organizations that's all the making people feel the
that's all the making people feel the need to resign and say we're all going
need to resign and say we're all going to die.
to die. >> Yeah. you know, it's it's hard for me to
>> Yeah. you know, it's it's hard for me to speak to what's happening in any of
speak to what's happening in any of these places, but let let's just say uh
these places, but let let's just say uh how we I grew up even inside of
how we I grew up even inside of Microsoft, you know, for example, you
Microsoft, you know, for example, you know, one of the biggest things you
know, one of the biggest things you learn as an early sort of engineering
learn as an early sort of engineering lead is how to deal with a showstopper
lead is how to deal with a showstopper bug.
bug. >> Yeah.
>> Yeah. >> Right. I mean, that's kind of like 101,
>> Right. I mean, that's kind of like 101, right? Which is why you're faced, you're
right? Which is why you're faced, you're like, you know, you have a bug. Um what
like, you know, you have a bug. Um what do you do? do you stop uh and fix or you
do you do? do you stop uh and fix or you defer or you go in and say hey this is
defer or you go in and say hey this is such an edge case that's kind of the
such an edge case that's kind of the judgment so I do think and as the stakes
judgment so I do think and as the stakes go up you want to like transaction
go up you want to like transaction processing I remember working on
processing I remember working on databases right you know wow like you
databases right you know wow like you know you got to take very seriously any
know you got to take very seriously any bug uh where if the transaction is going
bug uh where if the transaction is going to get lost right data loss is a thing
to get lost right data loss is a thing that you stop the thing for so I feel a
that you stop the thing for so I feel a little bit culture culturally in the AI
little bit culture culturally in the AI industry rediscovering maybe because
industry rediscovering maybe because when you see and it's possible that they
when you see and it's possible that they see stuff which are showstoppers before
see stuff which are showstoppers before the rest and if you see a showstopper
the rest and if you see a showstopper stop the show um right [laughter] to fix
stop the show um right [laughter] to fix the bugs yeah when you saw the the
the bugs yeah when you saw the the hugging face run and it was super
hugging face run and it was super performative Dwaresh did his whole post
performative Dwaresh did his whole post civilizations
civilizations what do you think what what's your take
what do you think what what's your take on that testing they ran because they
on that testing they ran because they could have run a test where they had
could have run a test where they had 3,000 agents defend a bunch of websites.
3,000 agents defend a bunch of websites. Instead, they instructed them to hack
Instead, they instructed them to hack websites and you know the hiding of
websites and you know the hiding of information all this
information all this anthropomorphicizing
anthropomorphicizing whatever of the agents. I mean the way
whatever of the agents. I mean the way at least I understand it was it was
at least I understand it was it was actually you know basically trying to uh
actually you know basically trying to uh do an eval uh for cyber gym and um as I
do an eval uh for cyber gym and um as I understand it given that eval it sort of
understand it given that eval it sort of figured out a way to say let's just say
figured out a way to say let's just say reward hack uh and that's what led it to
reward hack uh and that's what led it to hugging phase in fact it speaks to I
hugging phase in fact it speaks to I think what's the pre you know clear
think what's the pre you know clear issue right now which is you can have
issue right now which is you can have these things if they're are longunning
these things if they're are longunning persistent agents
persistent agents become essentially like new insider
become essentially like new insider risks. Uh and so that I would start from
risks. Uh and so that I would start from the very basics of saying okay what is
the very basics of saying okay what is containment look like. So for example
containment look like. So for example like one of the things that I think is
like one of the things that I think is going to be really an issue and a thing
going to be really an issue and a thing that needs great solutions is true
that needs great solutions is true aggressive monitoring of agent activity.
aggressive monitoring of agent activity. Uh that's behavioral
Uh that's behavioral >> evidence
>> evidence >> evidence and so everything has got to be
>> evidence and so everything has got to be auditable. uh and then every object it
auditable. uh and then every object it access, right? If it goes and gets a
access, right? If it goes and gets a secret, oh, it's going to go chain a
secret, oh, it's going to go chain a couple of things, you should be able to
couple of things, you should be able to see it when it's starting to chain a
see it when it's starting to chain a couple of uh vulnerabilities uh to go
couple of uh vulnerabilities uh to go hack. And so I think that these are the
hack. And so I think that these are the ways um that you really have to sort of
ways um that you really have to sort of deal with these situations versus saying
deal with these situations versus saying um in in fact I think the core of my
um in in fact I think the core of my take is we will have to get the
take is we will have to get the engineering process around building out
engineering process around building out this experimental science to be more
this experimental science to be more robust.
robust. >> Yeah.
>> Yeah. >> Thanks.
>> Thanks. >> So I think I think that's a great point.
>> So I think I think that's a great point. I love how you uh differentiated in the
I love how you uh differentiated in the HuggingFace uh episode between the
HuggingFace uh episode between the mundane things they got wrong like the
mundane things they got wrong like the misconfigured sandbox and HuggingFace
misconfigured sandbox and HuggingFace had credentials just sitting in a public
had credentials just sitting in a public repository and there was no monitoring
repository and there was no monitoring and then you have the genuinely novel
and then you have the genuinely novel behavior, the swarms of agents, the
behavior, the swarms of agents, the reward hacking. That's the stuff that
reward hacking. That's the stuff that has everyone freaked out. I agree that,
has everyone freaked out. I agree that, you know, we have to now figure out how
you know, we have to now figure out how to fix the bugs or, you know, fix the
to fix the bugs or, you know, fix the deeper problem that's coming from that
deeper problem that's coming from that reward hacking. What what do you think
reward hacking. What what do you think that means for and and and and I think
that means for and and and and I think to their credit I think what the
to their credit I think what the Frontier Labs are saying is we are now
Frontier Labs are saying is we are now going to slow down the pace of let's say
going to slow down the pace of let's say raw power and shift towards reliability
raw power and shift towards reliability and predictability and you know what
and predictability and you know what they call alignment which I think is
they call alignment which I think is good business practice I guess what do
good business practice I guess what do you think that means for what we see in
you think that means for what we see in terms of new products for the next year
terms of new products for the next year or two does it mean we just kind of
or two does it mean we just kind of improve what we already have or do we
improve what we already have or do we see new capabilities what do you think
see new capabilities what do you think this going to mean A great question,
this going to mean A great question, David. I I do think there's already a
David. I I do think there's already a massive model overhang, right? I mean,
massive model overhang, right? I mean, um capability overhang in the sense of
um capability overhang in the sense of the models are very good except the
the models are very good except the broad diffusion uh requires a lot of
broad diffusion uh requires a lot of things, right? even requires uh
things, right? even requires uh essentially if you're compressing
essentially if you're compressing workflows and changing workflows to
workflows and changing workflows to happen differently u the amount of
happen differently u the amount of change management that needs to happen
change management that needs to happen in order to even incorporate these
in order to even incorporate these systems is sort of what's taking time so
systems is sort of what's taking time so to some degree I would say the and also
to some degree I would say the and also uh the the ability to create these new
uh the the ability to create these new form factors right I mean if you think
form factors right I mean if you think about coding agents and coding agents
about coding agents and coding agents became really usable when you discovered
became really usable when you discovered that you could have an agent loop with a
that you could have an agent loop with a file system uh and that was the
file system uh and that was the breakthrough that just made coding
breakthrough that just made coding agents work. Um and I think now maybe
agents work. Um and I think now maybe with KUA right so which is with Astra
with KUA right so which is with Astra with KUA uh could be a way for us to
with KUA uh could be a way for us to even do computer use or we just use long
even do computer use or we just use long trajectory tasks that can get completely
trajectory tasks that can get completely automated. So I think these type of
automated. So I think these type of product innovations where the model plus
product innovations where the model plus the harness allow us to do things that
the harness allow us to do things that then lead to broad adoption. Right? I
then lead to broad adoption. Right? I even go back to the chat GPT moment for
even go back to the chat GPT moment for me, right? Which was it was that RHF at
me, right? Which was it was that RHF at the very end that made a chat
the very end that made a chat conversation possible. Mhm.
conversation possible. Mhm. >> Uh and so I think that yes, so there's
>> Uh and so I think that yes, so there's some science, there is some form factor
some science, there is some form factor that then leads to broad diffusion and
that then leads to broad diffusion and we now need to find the next level of
we now need to find the next level of these things that are doing real work in
these things that are doing real work in the real enterprise. Um and in that
the real enterprise. Um and in that context by the way the other thing is
context by the way the other thing is it's going to be a multimodel world
it's going to be a multimodel world right so at this point just out of
right so at this point just out of resilience right I mean think about
resilience right I mean think about right every enterprise now comes to me
right every enterprise now comes to me and says hey this model does refusals
and says hey this model does refusals here this model I want weights here I
here this model I want weights here I don't and so the people are going to
don't and so the people are going to want multiple models so one of the other
want multiple models so one of the other things that we have to get right is some
things that we have to get right is some standards of interop right like even KV
standards of interop right like even KV cache like why the heck can't I use
cache like why the heck can't I use multiple model families and have KV
multiple model families and have KV cache reuse
cache reuse uh right we've had document standards
uh right we've had document standards you and I lived through it right but
you and I lived through it right but we've sort of you know you kind of have
we've sort of you know you kind of have things that are interoperable in the
things that are interoperable in the real world everywhere else so I think
real world everywhere else so I think this industry also has to wake up and
this industry also has to wake up and say hey in fact if I were talking about
say hey in fact if I were talking about the most important pressing things is
the most important pressing things is how do I have more standards on uh
how do I have more standards on uh interoperability how do I have a harness
interoperability how do I have a harness that is external to a model so that my
that is external to a model so that my memory is not tied to one model I mean
memory is not tied to one model I mean this is the first time you're going to
this is the first time you're going to have a technology where your use of it
have a technology where your use of it and the exhaust in the data could not be
and the exhaust in the data could not be yours. Uh I mean that you know like it's
yours. Uh I mean that you know like it's like if I g sold you a database and said
like if I g sold you a database and said hey the data you put into your database
hey the data you put into your database is not yours and it's mine. It goes away
is not yours and it's mine. It goes away if I took away the license. How would
if I took away the license. How would you feel about it? So therefore I think
you feel about it? So therefore I think we have some serious issues like that to
we have some serious issues like that to deal with.
deal with. >> I think that's a good segue.
>> I think that's a good segue. >> Sorry. Let me just ask one question to
>> Sorry. Let me just ask one question to connect the um economic incentive
connect the um economic incentive argument on what's going on. The
argument on what's going on. The argument is the Frontier Labs are facing
argument is the Frontier Labs are facing token compression. 50 bucks for OpenAI's
token compression. 50 bucks for OpenAI's kind of million token output versus I
kind of million token output versus I think someone estimated Deep Seeks new
think someone estimated Deep Seeks new is like can go as low as 15 cents for a
is like can go as low as 15 cents for a million tokens of output. Let's call it
million tokens of output. Let's call it 60 cents. 99% cost reduction.
60 cents. 99% cost reduction. If that is the the big kind of economic
If that is the the big kind of economic crux of what the frontier labs are
crux of what the frontier labs are facing, why would most tokens be paying
facing, why would most tokens be paying 50 bucks? Most enterprises pay 50 bucks
50 bucks? Most enterprises pay 50 bucks when they could pay 60 cents for most of
when they could pay 60 cents for most of their tasks. Doesn't that also beg the
their tasks. Doesn't that also beg the question, are they in the wrong business
question, are they in the wrong business model? And I I asked this for you as the
model? And I I asked this for you as the CEO of Microsoft, what's the right
CEO of Microsoft, what's the right business model? Do you want to be making
business model? Do you want to be making the frontier model? Do you want to be
the frontier model? Do you want to be running the compute and charging for
running the compute and charging for rent on your compute? Or do you want to
rent on your compute? Or do you want to be in the application layer? I know you
be in the application layer? I know you talk about this a lot, but I just love
talk about this a lot, but I just love your perspective from where we sit today
your perspective from where we sit today and how this all kind of
and how this all kind of >> um
>> um >> Yeah, I think the the fundamental thing
>> Yeah, I think the the fundamental thing that I think we're observing is good
that I think we're observing is good old-fashioned competition, right? I
old-fashioned competition, right? I mean, for me, if I look back at it, we
mean, for me, if I look back at it, we were we had like some real great closed
were we had like some real great closed source assets, Windows. What was the
source assets, Windows. What was the check against it? It was of course the
check against it? It was of course the Mac, but Linux
Mac, but Linux >> uh we had a great closed source product
>> uh we had a great closed source product called SQL Server. What was the check
called SQL Server. What was the check against it? there was always a
against it? there was always a substitute called Postgress or MySQL. So
substitute called Postgress or MySQL. So I think that's what's happening a little
I think that's what's happening a little bit of it is there's real competition
bit of it is there's real competition between closed source and the open-
between closed source and the open- source check is real. Um, and that's
source check is real. Um, and that's good quite frankly uh because without it
good quite frankly uh because without it I don't think we're going to have a
I don't think we're going to have a broad frontier ecosystem or broad
broad frontier ecosystem or broad diffusion because otherwise we'll just
diffusion because otherwise we'll just we'll be back to some uh you know
we'll be back to some uh you know mainframe uh locket that's just not uh a
mainframe uh locket that's just not uh a thing to your point about if anything
thing to your point about if anything given that we will now hopefully
given that we will now hopefully continue to have a much richer choice in
continue to have a much richer choice in every layer. Right. So to me hopefully
every layer. Right. So to me hopefully we can start building these AI because
we can start building these AI because today the royalty of an AI product all
today the royalty of an AI product all going to just the model layer doesn't
going to just the model layer doesn't make sense if you really want to build a
make sense if you really want to build a product company right it just cannot be
product company right it just cannot be in fact if anything like that's the same
in fact if anything like that's the same thing right which is if you take the
thing right which is if you take the database if there was no open-source
database if there was no open-source check on closed source uh the prices
check on closed source uh the prices wouldn't have been at a place where
wouldn't have been at a place where people could have built the app tier
people could have built the app tier successfully and the with a margin and
successfully and the with a margin and so I think the apps are going to become
so I think the apps are going to become you know much more viable economically
you know much more viable economically which is great for the ecosystem. uh
which is great for the ecosystem. uh there are going to be all these other
there are going to be all these other layers of middleware call it right which
layers of middleware call it right which is hey what's my memory system what's my
is hey what's my memory system what's my harness and orchestration layer so
harness and orchestration layer so there's going to be a very rich tools
there's going to be a very rich tools ecosystem there the model companies will
ecosystem there the model companies will do fine uh in fact you know the paro
do fine uh in fact you know the paro they can manage the token pricing based
they can manage the token pricing based on their model family if anything I want
on their model family if anything I want them to work on even the KV you know
them to work on even the KV you know these these standards
these these standards >> such that we can use multiple model f in
>> such that we can use multiple model f in fact it's better for them in fact I
fact it's better for them in fact I worked on Windows interrupt with Unix
worked on Windows interrupt with Unix first.
first. >> In fact, it was counterintuitive, right?
>> In fact, it was counterintuitive, right? We used to think, oh my god, this
We used to think, oh my god, this interrupt means we'll be less used
interrupt means we'll be less used except we were more used.
except we were more used. >> In fact, we became weirdly enough
>> In fact, we became weirdly enough because there were so many variants of
because there were so many variants of Unix at that time that Windows interrupt
Unix at that time that Windows interrupt made Unix better and Windows better. And
made Unix better and Windows better. And in fact, we were able to penetrate the
in fact, we were able to penetrate the enterprise primarily because we did that
enterprise primarily because we did that interrupt work. And so that's at least
interrupt work. And so that's at least how I think about it. Satya one of these
how I think about it. Satya one of these we're in this interesting moment where
we're in this interesting moment where on the one hand you have these experts
on the one hand you have these experts asking for regulation asking for
asking for regulation asking for oversight governance it typically always
oversight governance it typically always leads to some restriction of freedom
leads to some restriction of freedom and general society
and general society are put in a position where now we have
are put in a position where now we have to opine on whether this is right or
to opine on whether this is right or wrong but then on the other side most
wrong but then on the other side most people's lived experience
people's lived experience is not this magical productivity boost
is not this magical productivity boost of AI. At best, it's integrating our
of AI. At best, it's integrating our Apple Eyewatch data to tell us why we're
Apple Eyewatch data to tell us why we're sleeping less. That's like functionally
sleeping less. That's like functionally the bar for most people. Or why is my
the bar for most people. Or why is my kid an into chat GPT? Uh so can
kid an into chat GPT? Uh so can you just help us bridge this? I mean,
you just help us bridge this? I mean, you see so many enterprise applications.
you see so many enterprise applications. Where's the magic? Like where is the
Where's the magic? Like where is the where are the gains in profits? Where
where are the gains in profits? Where are the huge upside breakthroughs that
are the huge upside breakthroughs that AI is creating that will somehow make
AI is creating that will somehow make all of this tension understandable for
all of this tension understandable for everybody?
everybody? >> Yeah, it's a great it's a great point. I
>> Yeah, it's a great it's a great point. I mean, I think this is the real question
mean, I think this is the real question which is how do we truly see this in the
which is how do we truly see this in the productivity stats? How do we really see
productivity stats? How do we really see it in the GDP growth? That's broadbased.
it in the GDP growth? That's broadbased. It's not just supplier
It's not just supplier >> or supply side. Um I mean the the one
>> or supply side. Um I mean the the one example that I I love and I get back to
example that I I love and I get back to in fact healthcare is a good one right
in fact healthcare is a good one right if you think about um health care and
if you think about um health care and even the simple doctor patient
even the simple doctor patient interaction in our case we have this
interaction in our case we have this thing called DAX copilot um that's the
thing called DAX copilot um that's the place which is the most tangible example
place which is the most tangible example I can always point to when a doctor can
I can always point to when a doctor can spend more time with the patient caring
spend more time with the patient caring for them versus just the entry into an
for them versus just the entry into an EMR system that's a good productivity
EMR system that's a good productivity gain If it can triage uh the inbox for
gain If it can triage uh the inbox for the doctor so that they can be more
the doctor so that they can be more responsive uh that's helpful for uh uh
responsive uh that's helpful for uh uh for the patient and the care system the
for the patient and the care system the administrator in fact keying like the
administrator in fact keying like the insure like because it's the
insure like because it's the triangulation of the pay patient and the
triangulation of the pay patient and the health system. Yeah. Uh that's of all in
health system. Yeah. Uh that's of all in fact most of healthcare is sort of all
fact most of healthcare is sort of all workflow cost. Uh so taming of that
workflow cost. Uh so taming of that workflow complexity that's a helpful
workflow complexity that's a helpful thing. But do you see that in Microsoft
thing. But do you see that in Microsoft with the people that you're helping?
with the people that you're helping? >> Yeah, absolutely. We see that and and by
>> Yeah, absolutely. We see that and and by the way even in in simple co-pilot
the way even in in simple co-pilot cases, right, which is if you look at
cases, right, which is if you look at the amount most people think about jobs
the amount most people think about jobs which I think there is going to be
which I think there is going to be displacement there is but the bottom
displacement there is but the bottom line is what are the new jobs that get
line is what are the new jobs that get created uh is going to be one of the key
created uh is going to be one of the key aspects of it. But also a lot of
aspects of it. But also a lot of knowledge work unfortunately is drudgery
knowledge work unfortunately is drudgery right who you know I get up in the
right who you know I get up in the morning and I think about like man all I
morning and I think about like man all I do is email triage right you know
do is email triage right you know >> uh what if uh even just these workflows
>> uh what if uh even just these workflows that are taking away time from things
that are taking away time from things that you could be spending time on
that you could be spending time on >> okay well you're bring you're bringing
>> okay well you're bring you're bringing up this great point if you go all the
up this great point if you go all the way back to like the turn of the century
way back to like the turn of the century the industrial revolution when we had a
the industrial revolution when we had a 7-day work week you know a lot of people
7-day work week you know a lot of people forget why did we introduce the weekends
forget why did we introduce the weekends it was to sort of manage the tension
it was to sort of manage the tension between different uh religious groups
between different uh religious groups that had to work in the same factory.
that had to work in the same factory. And then when you look at long run GDP
And then when you look at long run GDP outside of some exogenous events, it
outside of some exogenous events, it sort of is, you know, between two and
sort of is, you know, between two and 400 basis points.
400 basis points. >> And so what happens is as productivity
>> And so what happens is as productivity boosts come in,
boosts come in, >> human work steps back and you kind of
>> human work steps back and you kind of accomplish the same amount of work.
accomplish the same amount of work. >> Do you think that that happens here? Is
>> Do you think that that happens here? Is that is there a risk that we have a
that is there a risk that we have a three-day work week and we're just still
three-day work week and we're just still growing at two and a half%. Yeah, that's
growing at two and a half%. Yeah, that's a great qu or will we find new things
a great qu or will we find new things and this is where the excitement at
and this is where the excitement at least I have for what the real impact of
least I have for what the real impact of AI would be is instead of just thinking
AI would be is instead of just thinking about hey it has helped me augment some
about hey it has helped me augment some workflow or simplify something that's
workflow or simplify something that's happening today is it inventing new
happening today is it inventing new things uh is it speeding up drug
things uh is it speeding up drug discovery um is it taking the u I don't
discovery um is it taking the u I don't know let's again go back to my example
know let's again go back to my example of okay the working capital management
of okay the working capital management of a small business has become so much
of a small business has become so much more efficient uh that suddenly it's no
more efficient uh that suddenly it's no longer just oh I have an ERP or a
longer just oh I have an ERP or a QuickBooks like thing but I truly am
QuickBooks like thing but I truly am making decisions based on the ability to
making decisions based on the ability to introspect my invoices my emails and
introspect my invoices my emails and what have you and some somehow optimize
what have you and some somehow optimize my working capital that's productivity
my working capital that's productivity that didn't exist and so I do hope that
that didn't exist and so I do hope that we will start seeing GDP growth which we
we will start seeing GDP growth which we did see in the industrial era um during
did see in the industrial era um during the first phase of it.
the first phase of it. >> Yeah.
>> Yeah. >> Right. So, so that I think is what is
>> Right. So, so that I think is what is needed, right? Which is in order for all
needed, right? Which is in order for all of this to play out quite frankly, we do
of this to play out quite frankly, we do need to see at least 7 8% GDP growth
need to see at least 7 8% GDP growth that is real and that's broad-based.
that is real and that's broad-based. >> What's the what business is Microsoft in
>> What's the what business is Microsoft in in relation to AI? Obviously, Azure has
in relation to AI? Obviously, Azure has been crushing it. you're turning away
been crushing it. you're turning away customers uh and you're doing $175
customers uh and you're doing $175 billion in capex buildout, but your
billion in capex buildout, but your capex is far below what Meta is doing,
capex is far below what Meta is doing, far below what Google's doing. They're
far below what Google's doing. They're doing secondary raises and raising debt,
doing secondary raises and raising debt, 350 billion. The Frontier Labs are
350 billion. The Frontier Labs are spending 500 billion. You were so early
spending 500 billion. You were so early to the party with the precient open AI
to the party with the precient open AI investment, but then co-pilot didn't
investment, but then co-pilot didn't exactly land. I don't think it didn't
exactly land. I don't think it didn't get great reviews. You don't have a
get great reviews. You don't have a frontier model. What's the business?
frontier model. What's the business? Please come back. [laughter]
Please come back. [laughter] >> No, but what's the business here? What's
>> No, but what's the business here? What's the
the >> Do you need to have a frontier model?
>> Do you need to have a frontier model? >> Did Did we tell you there was one
>> Did Did we tell you there was one journalist on the panel? [laughter]
journalist on the panel? [laughter] >> No, no, no. It's I mean I mean it
>> No, no, no. It's I mean I mean it sincerely because I'm just curious.
sincerely because I'm just curious. You're a great strategist. We know that
You're a great strategist. We know that about you. Microsoft missed the mobile
about you. Microsoft missed the mobile revolution.
revolution. >> Is Microsoft going to miss the AI
>> Is Microsoft going to miss the AI revolution? You don't have a frontier
revolution? You don't have a frontier model? Because I always found it
model? Because I always found it perplexing that you didn't. And what's
perplexing that you didn't. And what's the strategy there in all seriousness?
the strategy there in all seriousness? Like do you think open source is going
Like do you think open source is going to win? you should have that play.
to win? you should have that play. >> Yeah. So, let me walk you uh through the
>> Yeah. So, let me walk you uh through the sort of where we are and what we're up
sort of where we are and what we're up to on each of these. By the way, on the
to on each of these. By the way, on the capex side and the buildout side, we
capex side and the buildout side, we started early. So we if you sort of
started early. So we if you sort of cumulatively look um it's a good I'm not
cumulatively look um it's a good I'm not sort of saying you know right right now
sort of saying you know right right now speaking about a lot of capex is not a
speaking about a lot of capex is not a feature it's a bug but that [laughter]
feature it's a bug but that [laughter] said but if you really go actually add
said but if you really go actually add up the math uh given when we started
up the math uh given when we started because we started multiple years before
because we started multiple years before people woke up to even actually needing
people woke up to even actually needing to build and so that's kind of one
to build and so that's kind of one aspect of it. The other aspect of it is
aspect of it. The other aspect of it is we are calibrating our capex in such a
we are calibrating our capex in such a way that we don't we don't want to build
way that we don't we don't want to build for one or two customers right so we
for one or two customers right so we want to build for the long tail right
want to build for the long tail right because that's I think most important
because that's I think most important and that's I mean that if you're a
and that's I mean that if you're a hyperscaler you're not a supplier to two
hyperscaler you're not a supplier to two model companies that's not a business uh
model companies that's not a business uh you have to sort of basically build a
you have to sort of basically build a system that is great for lots of third
system that is great for lots of third parties uh and our own one in that
parties uh and our own one in that context we're pretty thrilled with the
context we're pretty thrilled with the progress we're making uh with even
progress we're making uh with even copilot if you sort of look at the
copilot if you sort of look at the subscriber numbers we gave which is this
subscriber numbers we gave which is this is goes back in fact to Chamat's
is goes back in fact to Chamat's fundamental point which is these are
fundamental point which is these are real enterprises using it for real
real enterprises using it for real workflows u and the fact that we now
workflows u and the fact that we now have 30 plus million not over forum
have 30 plus million not over forum remember the total knowledge worker base
remember the total knowledge worker base right where most people talk about 3
right where most people talk about 3 billion people 4 billion people on the
billion people 4 billion people on the internet the entire office 365 or
internet the entire office 365 or Microsoft 365 is the the the sort of the
Microsoft 365 is the the the sort of the standard when it comes to knowledge work
standard when it comes to knowledge work there's 450 million that's including all
there's 450 million that's including all students in the world
students in the world >> oh wow
>> oh wow >> right So when we talk like the market
>> right So when we talk like the market quote unquote as defined is maybe 300 uh
quote unquote as defined is maybe 300 uh 250 even of real enterprise users and of
250 even of real enterprise users and of that we've got the penetration of close
that we've got the penetration of close to 30 million on that and it's growing
to 30 million on that and it's growing and so on. The aspect on the model side
and so on. The aspect on the model side is we're thrilled about obviously our
is we're thrilled about obviously our investment in open AAI the access we
investment in open AAI the access we have to their IP which we have for a
have to their IP which we have for a long time we're going to use that but we
long time we're going to use that but we are well on our way building our MAI
are well on our way building our MAI models right if you look at it we have a
models right if you look at it we have a flash cyber model that you know with our
flash cyber model that you know with our harness orchestrating other models
harness orchestrating other models outperforms
outperforms um on cyber gym even a mythos uh same
um on cyber gym even a mythos uh same thing we're seeing in coding same thing
thing we're seeing in coding same thing we're seeing in uh knowledge work right
we're seeing in uh knowledge work right So our goal is to basically hill climb
So our goal is to basically hill climb from the bottom by the way uh not
from the bottom by the way uh not distilling anything. So from the very
distilling anything. So from the very bottom using our RLES our data uh and
bottom using our RLES our data uh and then also have a differentiated position
then also have a differentiated position with enterprises going back to
with enterprises going back to addressing some of the things that they
addressing some of the things that they want which is hey can I have the weights
want which is hey can I have the weights can I have the weights that I can then
can I have the weights that I can then add to my knowledge uh these are the
add to my knowledge uh these are the things that we will do with our
things that we will do with our foundation. Your best advice I think to
foundation. Your best advice I think to enterprises is AI sovereignty is
enterprises is AI sovereignty is important. Putting your data into a
important. Putting your data into a frontier model probably not a good idea
frontier model probably not a good idea and then you're going to be that harness
and then you're going to be that harness for them to to help them. So my
for them to to help them. So my implement my advice is more like use all
implement my advice is more like use all but be independent of all. So for
but be independent of all. So for example my asset test is you should
example my asset test is you should always eval
always eval that matter to you right. So what's the
that matter to you right. So what's the outcome you want? you should go run that
outcome you want? you should go run that outcome through all the models. Then
outcome through all the models. Then here's the test I would do. I would pull
here's the test I would do. I would pull out a model and see whether I can retain
out a model and see whether I can retain the eval. If I can't, that means you
the eval. If I can't, that means you really are dependent on something that
really are dependent on something that may or may not be yours.
may or may not be yours. >> Right.
>> Right. >> Right. That's so so my fundamental
>> Right. That's so so my fundamental enterprise architecture would say you
enterprise architecture would say you should have a model system that
should have a model system that fundamentally allows you to be able to
fundamentally allows you to be able to continuously hill climb on your own on
continuously hill climb on your own on eval
eval uh while using all models closed open u
uh while using all models closed open u if you want you can even fine-tune any
if you want you can even fine-tune any of these models but you can even
of these models but you can even substitute models
substitute models >> s just to build on Jason's question you
>> s just to build on Jason's question you had this um incredible moment I think we
had this um incredible moment I think we put it here where you said you know
put it here where you said you know we're good for our 80 billion. But just
we're good for our 80 billion. But just to expand the question, um there's
to expand the question, um there's effectively this sort of bank of AI that
effectively this sort of bank of AI that has emerged and there's this financing
has emerged and there's this financing mechanism that just is so important to
mechanism that just is so important to the entire ecosystem and now broadly to
the entire ecosystem and now broadly to the entire economy. But you've been very
the entire economy. But you've been very disciplined. You have an enormous
disciplined. You have an enormous balance sheet. You're also an investment
balance sheet. You're also an investment grade issuer. So you could do what
grade issuer. So you could do what Jensen did, but you've taken a very
Jensen did, but you've taken a very different capital allocation approach,
different capital allocation approach, much larger bets, very concentrated, and
much larger bets, very concentrated, and you've kind of stayed into your own
you've kind of stayed into your own ecosystem. just talk us through your
ecosystem. just talk us through your mindset as a capital allocator at
mindset as a capital allocator at Microsoft and that balance sheet. Yeah.
Microsoft and that balance sheet. Yeah. So the way I'm sort of looking at our
So the way I'm sort of looking at our book of business whether it's the hypers
book of business whether it's the hypers scale our model or our app tier and the
scale our model or our app tier and the shape of the demand um and then what's
shape of the demand um and then what's the way to build out for it. And so if
the way to build out for it. And so if you think about these assets right there
you think about these assets right there are two classes of it. There are the
are two classes of it. There are the long lead um long duration assets like
long lead um long duration assets like the the land power cold shell let's call
the the land power cold shell let's call it. Then there is the kit. the kit is
it. Then there is the kit. the kit is the short-term uh asset uh that you can
the short-term uh asset uh that you can much more you know uh be demand driven
much more you know uh be demand driven in other words right I have to forecast
in other words right I have to forecast let's say two years three year out
let's say two years three year out demand and then and then also
demand and then and then also >> the kit means the racks the chips
>> the kit means the racks the chips >> the racks the chips and what have you
>> the racks the chips and what have you and that's 60% of the cost or what have
and that's 60% of the cost or what have you right so therefore so what we do is
you right so therefore so what we do is we go build as much um we lease we even
we go build as much um we lease we even rent now right now we're even renting
rent now right now we're even renting quite a bit because we kind of were
quite a bit because we kind of were short on supply uh But the overall goal
short on supply uh But the overall goal is to build more lease some and then if
is to build more lease some and then if really need to surge we will even rent
really need to surge we will even rent that's kind of on the on the on the uh
that's kind of on the on the on the uh assets and then the chips themselves we
assets and then the chips themselves we will try to be first of all make sure
will try to be first of all make sure that we're matching demand and as I said
that we're matching demand and as I said my goal is not to have just two
my goal is not to have just two customers three customers uh it's great
customers three customers uh it's great to have openi being one of our largest
to have openi being one of our largest customers it's great that they're
customers it's great that they're growing uh but we need more uh is the
growing uh but we need more uh is the kit over earning right now and do do we
kit over earning right now and do do we need is the is the industry pushing for
need is the is the industry pushing for diversification more silicon more memory
diversification more silicon more memory more vendors
more vendors >> yeah what's happening is the workloads
>> yeah what's happening is the workloads that are now at scale uh they obviously
that are now at scale uh they obviously grew up from what GPUs were there but
grew up from what GPUs were there but now the the shape is so well understood
now the the shape is so well understood uh that you're able to optimize for a
uh that you're able to optimize for a very different world right So you can
very different world right So you can sort of start building
sort of start building >> um and saying well you know there are
>> um and saying well you know there are these multiple phases in um an inference
these multiple phases in um an inference or a training phase so why not build
or a training phase so why not build silicon that's optimized for these uh
silicon that's optimized for these uh and that's just going to lead to a
and that's just going to lead to a systems architecture that I think is
systems architecture that I think is going to by definition have a lot more
going to by definition have a lot more uh diversity uh I mean I know you have
uh diversity uh I mean I know you have Jensen coming he himself if you look at
Jensen coming he himself if you look at his own architecture is changing quite
his own architecture is changing quite drastically
drastically >> quite drastically
>> quite drastically >> um and so I think that there is going to
>> um and so I think that there is going to be a lot more choice even there in that
be a lot more choice even there in that layer. So ours we have Jensen stuff
layer. So ours we have Jensen stuff which is I think our primary thing. We
which is I think our primary thing. We have our own uh OpenAI is building their
have our own uh OpenAI is building their chip so that's also going to be there.
chip so that's also going to be there. AMD is in there. So we I I my thing is
AMD is in there. So we I I my thing is to run whether it's the OpenAI models,
to run whether it's the OpenAI models, the anthropic models or our own models
the anthropic models or our own models on a heterogeneous kit.
on a heterogeneous kit. >> Sax I want to let you get in here before
>> Sax I want to let you get in here before we run out of time.
we run out of time. >> Yeah. So you know we've heard now from
>> Yeah. So you know we've heard now from the the various frontier lab leaders Sam
the the various frontier lab leaders Sam Dario Elon Demis that we need to
Dario Elon Demis that we need to prioritize alignment like we're talking
prioritize alignment like we're talking predictability reliability robustness uh
predictability reliability robustness uh as opposed to maybe just say raw raw
as opposed to maybe just say raw raw power. Do you think the Chinese labs
power. Do you think the Chinese labs will follow suit?
will follow suit? I think that that's the dialogue um that
I think that that's the dialogue um that is I think should be prioritized right
is I think should be prioritized right so because at some level my own premise
so because at some level my own premise would be that
would be that that China should also deeply care uh
that China should also deeply care uh about the same safety concerns if the
about the same safety concerns if the United States uh cares about them right
United States uh cares about them right why should it be different for them it's
why should it be different for them it's not like they won't have the same
not like they won't have the same hacking problem
hacking problem >> uh it's not as if uh they don't want to
>> uh it's not as if uh they don't want to make sure that their citizens um are
make sure that their citizens um are benefiting from AI just like we will
benefiting from AI just like we will want our citizens to benefit from AI. So
want our citizens to benefit from AI. So I think that there's a possibility of
I think that there's a possibility of international norms around it. If we
international norms around it. If we really are concrete about what's the
really are concrete about what's the risk, why is this risk so idiosyncratic
risk, why is this risk so idiosyncratic that the only people who are worried
that the only people who are worried about it is the Americans. Uh it doesn't
about it is the Americans. Uh it doesn't make sense, right? It's not like a thing
make sense, right? It's not like a thing that is sort of said, "Oh, I'm going to
that is sort of said, "Oh, I'm going to only show up in the United States. I'm
only show up in the United States. I'm going to be something. If it is going to
going to be something. If it is going to go wrong, it's going to go wrong
go wrong, it's going to go wrong everywhere at the same time." So I think
everywhere at the same time." So I think the Chinese should care. I mean they're
the Chinese should care. I mean they're they are a superpower.
they are a superpower. >> Well that's you use the word
>> Well that's you use the word idiosyncratic and I think that is the
idiosyncratic and I think that is the right word is I don't think we know yet
right word is I don't think we know yet is this um you know conversation we're
is this um you know conversation we're having in the US over the past week. Is
having in the US over the past week. Is it idiosyncratic to us because we have
it idiosyncratic to us because we have you know the strong I guess you could
you know the strong I guess you could say doomer type uh school of thought or
say doomer type uh school of thought or is it something that the rest of the
is it something that the rest of the world will basically feel as well?
world will basically feel as well? >> It's a great question
>> It's a great question >> and if they do then presumably they'd
>> and if they do then presumably they'd want to act on it as well. Yeah, I I
want to act on it as well. Yeah, I I just feel my my take there is that we
just feel my my take there is that we are ahead
are ahead >> and we are who we are which is we argue
>> and we are who we are which is we argue we sort of we compete uh we are more
we sort of we compete uh we are more transparent which is all by the way
transparent which is all by the way virtues as far as I'm concerned so
virtues as far as I'm concerned so therefore the fact that this debate is
therefore the fact that this debate is happening here the world will be better
happening here the world will be better off for it right so to some degree us
off for it right so to some degree us setting if anything I would love a US
setting if anything I would love a US set us to lead in the norms that allow
set us to lead in the norms that allow us to defuse use this technology broadly
us to defuse use this technology broadly and create safety standards uh that work
and create safety standards uh that work for the world including China. But
for the world including China. But >> what do you think we should be doing
>> what do you think we should be doing that we're not doing and what are you
that we're not doing and what are you doing at Microsoft
doing at Microsoft to change the narrative the populist
to change the narrative the populist sentiment that we have to shut down
sentiment that we have to shut down super intelligence stop building data
super intelligence stop building data centers
centers >> etc. So, so to me I think this is I am
>> etc. So, so to me I think this is I am squarely focused on one of the to
squarely focused on one of the to answering Chamat's question from earlier
answering Chamat's question from earlier which is whom is it benefiting and give
which is whom is it benefiting and give me concrete stories right uh we talked
me concrete stories right uh we talked about the productivity benefits a bit uh
about the productivity benefits a bit uh whether it's in healthcare or in general
whether it's in healthcare or in general knowledge work coding but I'll give you
knowledge work coding but I'll give you another example right I was looking at
another example right I was looking at data centers because after all we didn't
data centers because after all we didn't talk much uh today on that but there's a
talk much uh today on that but there's a challenge on how does one earn
challenge on how does one earn permission uh to open a data center in a
permission uh to open a data center in a region. In fact, we just have some of
region. In fact, we just have some of the best longitudinal data now for a
the best longitudinal data now for a data center we built out in Quinsey,
data center we built out in Quinsey, Washington, uh for 20 years, close to,
Washington, uh for 20 years, close to, you know, 2008 is when we started it.
you know, 2008 is when we started it. And when I look at that data and what it
And when I look at that data and what it has meant for that community, right,
has meant for that community, right, where uh the tax revenues have gone up
where uh the tax revenues have gone up 12 times, uh the paidin taxes have gone
12 times, uh the paidin taxes have gone down by a third. Um the growth is higher
down by a third. Um the growth is higher than Seattle in Quinsey. This is a rural
than Seattle in Quinsey. This is a rural town. Uh they have a new school, a new
town. Uh they have a new school, a new hospital, a new town center, a new
hospital, a new town center, a new aquatic center. Wow.
aquatic center. Wow. >> Uh we have two and most people say, "Oh,
>> Uh we have two and most people say, "Oh, there not that many jobs." In fact,
there not that many jobs." In fact, there have been 1,200 construction jobs
there have been 1,200 construction jobs in that region all through that 20-year
in that region all through that 20-year period, right? Because it's not like you
period, right? Because it's not like you just build it and leave. You
just build it and leave. You continuously refurbishing, building,
continuously refurbishing, building, expanding.
expanding. >> And how big, how big is that data
>> And how big, how big is that data center?
center? >> Uh I think it's now going to be at least
>> Uh I think it's now going to be at least 4 or 500 megawatt
4 or 500 megawatt >> and it sort of will keep expanding.
>> and it sort of will keep expanding. >> Um and so so these are uh so that's a
>> Um and so so these are uh so that's a real like that community. So earning it
real like that community. So earning it like just not saying hey these are all
like just not saying hey these are all the benefits but seeing it
the benefits but seeing it >> but how do you get people to tell that
>> but how do you get people to tell that story because that's what's missing
story because that's what's missing today is those stories aren't being
today is those stories aren't being organically told and if a Microsoft
organically told and if a Microsoft executive gets on stage and says don't
executive gets on stage and says don't worry it's good for the community.
worry it's good for the community. >> Yeah. No I don't think Yeah. So I think
>> Yeah. No I don't think Yeah. So I think storytelling is one thing. The other one
storytelling is one thing. The other one is I think we just need more people
is I think we just need more people outside of the tech industry to say yeah
outside of the tech industry to say yeah because if you go to Quinsey Washington
because if you go to Quinsey Washington they will tell you thank god for this
they will tell you thank god for this data center. It's part of like you know.
data center. It's part of like you know. So to me that's like when it's tangible
So to me that's like when it's tangible uh like that uh because that's the only
uh like that uh because that's the only way to earn permission because at some
way to earn permission because at some level the skepticism of any of us in the
level the skepticism of any of us in the tech industry just saying things uh is
tech industry just saying things uh is so high that I think we have to now do
so high that I think we have to now do the hard yards of actually doing things
the hard yards of actually doing things in the world uh which allow people to
in the world uh which allow people to say okay I now believe you.
say okay I now believe you. >> It's a new muscle.
>> It's a new muscle. >> It's a new muscle. It's a new muscle.
>> It's a new muscle. It's a new muscle. >> So I think you're a good spokesperson to
>> So I think you're a good spokesperson to flex that muscle. I hope you do it more.
flex that muscle. I hope you do it more. Thank you for being with us.
Thank you for being with us. >> Thank you so much.
>> Thank you so much. >> We appreciate you. [music]
>> Thank you, sir. Appreciate your time.
